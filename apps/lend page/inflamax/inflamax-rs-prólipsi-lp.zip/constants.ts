
export const ASSETS = {
  logo: "https://via.placeholder.com/300x100/000000/D4AF37?text=RS+PROLIPSI", 
  product1: "https://via.placeholder.com/400x400/111/D4AF37?text=INFLAMAX+1+POTE", 
  product3: "https://via.placeholder.com/400x400/111/D4AF37?text=INFLAMAX+3+POTES", 
  product6: "https://via.placeholder.com/400x400/111/D4AF37?text=INFLAMAX+6+POTES", 
  ceo: "https://via.placeholder.com/300x300/111/D4AF37?text=CEO+RS+PROLIPSI", 
  painBack: "https://images.unsplash.com/photo-1544118220-71752e258cb2?auto=format&fit=crop&q=80&w=600",
  painKnee: "https://images.unsplash.com/photo-1583873539867-b5266c589624?auto=format&fit=crop&q=80&w=600",
  painJoints: "https://images.unsplash.com/photo-1584650549491-b6a18d96b940?auto=format&fit=crop&q=80&w=600",
  activeLife: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?auto=format&fit=crop&q=80&w=1200",
};

export const CONTACT = {
  phone: "5541992863922",
  displayPhone: "(41) 99286-3922",
  email: "rsprolipsioficial@gmail.com"
};

export const INGREDIENTS = [
  { name: "Colágeno Tipo II", description: "Essencial para a regeneração da cartilagem." },
  { name: "Cúrcuma", description: "Poderoso anti-inflamatório natural." },
  { name: "Magnésio Dimalato", description: "Alivia dores musculares e melhora a energia." },
  { name: "Metilsulfonilmetano (MSM)", description: "Reduz inflamação e estresse oxidativo." },
  { name: "Vitamina D + Cálcio", description: "Fortalecimento ósseo e imunidade." }
];

export const BENEFITS = [
  { title: "Alívio de Dores", text: "Reduz inflamações articulares, musculares e crônicas.", image: "" },
  { title: "Saúde Articular", text: "Promove a regeneração das articulações e previne desgastes.", image: "" },
  { title: "Mais Mobilidade", text: "Recupere a flexibilidade e movimente-se livremente.", image: "" },
  { title: "Recuperação Muscular", text: "Ideal para pós-treino e alívio de tensões.", image: "" },
  { title: "Ação Antioxidante", text: "Combate radicais livres e previne envelhecimento precoce.", image: "" },
  { title: "Saúde Óssea", text: "Rico em vitaminas que mantêm os ossos fortes.", image: "" }
];

export const PRICING = {
  kit1: {
    id: 1,
    title: "TRATAMENTO INICIAL",
    subtitle: "1 Mês de Tratamento",
    units: 1,
    originalPrice: 299.90,
    price: 149.90,
    discount: 50,
    installments: 12,
    installmentValue: 15.05, 
    bestSeller: false,
    image: ASSETS.product1,
    checkoutUrl: `https://wa.me/${CONTACT.phone}?text=Olá! Gostaria de adquirir o *Tratamento Inicial (1 Pote)* do Inflamax por R$ 149,90.`
  },
  kit3: {
    id: 3,
    title: "TRATAMENTO RECOMENDADO",
    subtitle: "3 Meses de Tratamento",
    units: 3,
    originalPrice: 897.00,
    price: 397.00,
    discount: 55,
    installments: 12,
    installmentValue: 39.86, 
    bestSeller: true,
    image: ASSETS.product3,
    checkoutUrl: `https://wa.me/${CONTACT.phone}?text=Olá! Gostaria de adquirir o *Tratamento Recomendado (3 Potes)* do Inflamax por R$ 397,00.`
  },
  kit6: {
    id: 6,
    title: "TRATAMENTO MÁXIMO",
    subtitle: "6 Meses de Tratamento",
    units: 6,
    originalPrice: 1794.00,
    price: 797.00,
    discount: 65,
    installments: 12,
    installmentValue: 80.02, 
    bestSeller: false,
    image: ASSETS.product6,
    checkoutUrl: `https://wa.me/${CONTACT.phone}?text=Olá! Gostaria de adquirir o *Tratamento Máximo (6 Potes)* do Inflamax por R$ 797,00.`
  }
};
