
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import FormattedText from './FormattedText';

const ComparisonSection: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;

  if (!style.isVisible) return null;

  const items = Array.isArray(content.items) ? content.items : [];

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-20 relative group cursor-pointer border-2 transition-all ${activeSectionId === section.id ? 'border-yellow-500' : 'border-transparent'}`}
      style={{ backgroundColor: style.bgColor }}
    >
      <div className="container mx-auto px-4">
        {content.title && (
          <div className="text-center mb-16">
             <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tighter" style={{ color: style.titleColor }}>
               <FormattedText text={content.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
             </h2>
          </div>
        )}
        
        <div className="space-y-24">
          {items.map((item: any, idx: number) => (
            <div key={idx} className="max-w-5xl mx-auto">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="relative rounded-[2rem] md:rounded-[3rem] overflow-hidden border-4 border-red-500/20 shadow-2xl">
                   <img src={item.before?.image || "https://via.placeholder.com/600x600"} className="w-full h-80 md:h-[500px] object-cover" alt="Antes" />
                   <div className="absolute top-6 left-6 bg-red-600 text-white px-6 py-2 rounded-full font-black uppercase text-[10px] tracking-widest shadow-lg">
                     {item.before?.label || "Antes"}
                   </div>
                </div>
                <div className="relative rounded-[2rem] md:rounded-[3rem] overflow-hidden border-4 border-green-500/20 shadow-2xl">
                   <img src={item.after?.image || "https://via.placeholder.com/600x600"} className="w-full h-80 md:h-[500px] object-cover" alt="Depois" />
                   <div className="absolute top-6 left-6 bg-green-600 text-white px-6 py-2 rounded-full font-black uppercase text-[10px] tracking-widest shadow-lg">
                     {item.after?.label || "Depois"}
                   </div>
                </div>
              </div>
              {item.description && (
                <div className="text-center mt-8">
                  <p className="text-sm font-bold opacity-70 italic" style={{ color: style.textColor }}>{item.description}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ComparisonSection;
