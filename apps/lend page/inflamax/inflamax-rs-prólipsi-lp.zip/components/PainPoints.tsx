
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { AlertCircle, Edit3 } from 'lucide-react';
import FormattedText from './FormattedText';

const PainPoints: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const content = section.content;
  const style = section.style;

  if (!style.isVisible) return null;

  const bgStyle: any = {
    position: 'relative',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat'
  };

  if ((style.bgType === 'image' || style.bgType === 'gif') && style.bgImage) {
    bgStyle.backgroundImage = `url(${style.bgImage})`;
  } else if (style.bgType === 'gradient') {
    bgStyle.background = style.bgGradient;
  } else {
    bgStyle.backgroundColor = style.bgColor || '#050505';
  }

  const items = Array.isArray(content.items) ? content.items : [];
  const bottomBanner = content.bottomBanner || {};

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-20 relative group transition-all duration-300 border-2 cursor-pointer overflow-hidden ${activeSectionId === section.id ? 'border-yellow-500 ring-4 ring-yellow-500/10' : 'border-transparent'}`}
      style={bgStyle}
    >
      {style.bgType === 'video' && style.bgVideo && (
        <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover z-0 pointer-events-none">
          <source src={style.bgVideo} type="video/mp4" />
        </video>
      )}

      {(style.bgType === 'image' || style.bgType === 'video' || style.bgType === 'gradient' || style.bgType === 'gif') && (
        <div className="absolute inset-0 z-[1] pointer-events-none" style={{ backgroundColor: style.overlayColor || '#000', opacity: style.overlayOpacity ?? 0.5 }}></div>
      )}

      {isAdminOpen && (
        <div className="absolute top-4 right-4 z-[50] opacity-0 group-hover:opacity-100 transition-opacity bg-yellow-600 text-black p-2 rounded-lg text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
          <Edit3 size={12} /> Editar Cards
        </div>
      )}

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-black mb-4 uppercase tracking-tighter" style={{ color: style.titleColor }}>
            <FormattedText text={content.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
          </h2>
          <p className="max-w-2xl mx-auto font-medium leading-relaxed" style={{ color: style.textColor }}>
            <FormattedText text={content.subtitle} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {items.map((pain: any, idx: number) => (
            <div key={idx} className="relative group/card overflow-hidden rounded-3xl border border-zinc-800 shadow-xl bg-zinc-900">
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent z-10 opacity-90"></div>
              {pain.img && (
                <img 
                  src={pain.img} 
                  alt={pain.title} 
                  className="w-full h-80 object-cover transition-transform duration-700 group-hover/card:scale-110"
                />
              )}
              <div className="absolute bottom-6 left-6 z-20">
                <div className="flex items-center gap-2 mb-2">
                  <AlertCircle className="w-5 h-5" style={{ color: style.highlightColor }} />
                  <span className="font-black uppercase tracking-widest text-[10px]" style={{ color: style.highlightColor }}>Alerta</span>
                </div>
                <h3 className="text-xl font-black text-white uppercase tracking-tight">
                  <FormattedText text={pain.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
                </h3>
              </div>
            </div>
          ))}
        </div>

        {bottomBanner.title && (
          <div className="mt-16 bg-zinc-900/30 border border-zinc-800 rounded-[2.5rem] p-8 md:p-12 text-center max-w-4xl mx-auto shadow-2xl relative overflow-hidden backdrop-blur-sm">
            <h3 className="text-2xl md:text-4xl font-black mb-4 uppercase tracking-tighter">
              <FormattedText text={bottomBanner.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
            </h3>
            <p className="mb-8 text-lg font-medium" style={{ color: style.textColor }}>
              <FormattedText text={bottomBanner.text} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
            </p>
            <a 
              href={bottomBanner.buttonUrl || "#ofertas"} 
              className="inline-block text-black px-12 py-5 rounded-full font-black text-xs uppercase tracking-[0.2em] shadow-xl transition-transform hover:scale-105"
              style={{ backgroundColor: style.highlightColor }}
            >
              {bottomBanner.buttonText}
            </a>
          </div>
        )}
      </div>
    </section>
  );
};

export default PainPoints;
