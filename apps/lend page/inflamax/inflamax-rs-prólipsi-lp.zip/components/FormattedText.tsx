
import React from 'react';

interface CustomHighlight {
  text: string;
  color: string;
}

interface FormattedTextProps {
  text: string;
  highlightColor: string;
  customHighlights?: CustomHighlight[];
}

const FormattedText: React.FC<FormattedTextProps> = ({ text, highlightColor, customHighlights = [] }) => {
  if (!text) return null;

  // Garantir que customHighlights seja sempre um array
  const safeHighlights = Array.isArray(customHighlights) ? customHighlights : [];

  // Primeiro, processamos os asteriscos padrão
  let parts: (string | React.ReactNode)[] = text.split(/\*(.*?)\*/g).map((part, i) => {
    if (i % 2 === 1) {
      return <span key={`std-${i}`} style={{ color: highlightColor }}>{part}</span>;
    }
    return part;
  });

  // Se não houver destaques personalizados, retornamos o padrão
  if (safeHighlights.length === 0) return <>{parts}</>;

  // Função para aplicar destaques personalizados em um nó de texto
  const applyCustomHighlights = (node: string | React.ReactNode): (string | React.ReactNode)[] => {
    if (typeof node !== 'string') return [node];
    
    let subParts: (string | React.ReactNode)[] = [node];

    safeHighlights.forEach((highlight, hIdx) => {
      if (!highlight?.text || !highlight?.color) return;

      const newSubParts: (string | React.ReactNode)[] = [];
      subParts.forEach((part) => {
        if (typeof part !== 'string') {
          newSubParts.push(part);
          return;
        }

        const regex = new RegExp(`(${highlight.text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&')})`, 'gi');
        const split = part.split(regex);
        
        split.forEach((s, i) => {
          if (i % 2 === 1) {
            newSubParts.push(<span key={`custom-${hIdx}-${i}`} style={{ color: highlight.color }}>{s}</span>);
          } else if (s !== '') {
            newSubParts.push(s);
          }
        });
      });
      subParts = newSubParts;
    });

    return subParts;
  };

  // Aplicamos os destaques customizados em todas as partes que ainda são strings
  const finalParts: React.ReactNode[] = [];
  parts.forEach((part, i) => {
    const processed = applyCustomHighlights(part);
    processed.forEach((p, j) => finalParts.push(<React.Fragment key={`${i}-${j}`}>{p}</React.Fragment>));
  });

  return <>{finalParts}</>;
};

export default FormattedText;
