
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { Play, Edit3, Video as VideoIcon, ExternalLink } from 'lucide-react';
import FormattedText from './FormattedText';

const VideoSection: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;

  if (!style.isVisible) return null;

  /**
   * Extrai o ID do vídeo do YouTube de forma robusta.
   * Suporta links normais, Shorts, links curtos (youtu.be) e incorporados.
   */
  const getYoutubeId = (url: string) => {
    if (!url || typeof url !== 'string') return null;
    
    // 1. Limpeza: remove espaços e parâmetros de rastreio comuns que quebram o ID
    const cleanUrl = url.trim()
      .split('?si=')[0] // Remove o novo parâmetro de share do YouTube
      .split('&')[0]    // Remove outros parâmetros como &feature=shared
      .replace(/\s/g, ''); // Remove qualquer espaço em branco
    
    // 2. Regex para capturar o ID de 11 caracteres em diversos formatos
    const regExp = /^.*(?:(?:youtu\.be\/|v\/|vi\/|u\/\w\/|embed\/|shorts\/)|(?:(?:watch)?\?v(?:i)?=|\&v(?:i)?=))([^#\&\?]*).*/;
    const match = cleanUrl.match(regExp);
    
    if (match && match[1]) {
      const id = match[1].trim();
      // IDs do YouTube possuem exatamente 11 caracteres
      return id.length === 11 ? id : null;
    }
    
    // 3. Fallback: Se a regex falhar mas a URL parecer um ID puro de 11 caracteres
    if (cleanUrl.length === 11 && !cleanUrl.includes('/') && !cleanUrl.includes('.')) {
      return cleanUrl;
    }

    return null;
  };

  const bgStyle: any = {
    position: 'relative',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat'
  };

  if ((style.bgType === 'image' || style.bgType === 'gif') && style.bgImage) {
    bgStyle.backgroundImage = `url(${style.bgImage})`;
  } else if (style.bgType === 'gradient') {
    bgStyle.background = style.bgGradient;
  } else {
    bgStyle.backgroundColor = style.bgColor || '#050505';
  }

  const isGridLayout = style.layout && style.layout.startsWith('grid');
  const videoItems = Array.isArray(content.videos) ? content.videos : [];
  
  const gridCols = style.layout === 'grid-4' ? 'md:grid-cols-2 lg:grid-cols-4' : 
                   style.layout === 'grid-3' ? 'md:grid-cols-3' : 
                   style.layout === 'grid-2' ? 'md:grid-cols-2' : 
                   style.layout === 'grid-6' ? 'md:grid-cols-3' : 'grid-cols-1';

  const renderVideo = (url: string, title?: string) => {
    const videoId = getYoutubeId(url);
    
    if (!videoId) return (
      <div className="w-full aspect-video bg-zinc-900 flex flex-col items-center justify-center text-zinc-600 rounded-[2rem] border border-zinc-800 p-8 text-center">
        <VideoIcon size={40} className="opacity-20 mb-4" />
        <span className="text-[10px] font-black uppercase tracking-widest block">Link do vídeo não encontrado</span>
        <p className="text-[8px] mt-2 opacity-40 px-4">
          Certifique-se de colar o link completo do YouTube ou do Shorts.
        </p>
      </div>
    );

    return (
      <div className="w-full aspect-video rounded-[2rem] overflow-hidden shadow-2xl bg-black border border-white/5 relative group/vid">
        <iframe 
          src={`https://www.youtube.com/embed/${videoId}?rel=0&modestbranding=1`}
          className="w-full h-full"
          allowFullScreen
          title={title || "Vídeo"}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          loading="lazy"
        ></iframe>
        
        {/* Botão de segurança para abrir fora caso o embed esteja bloqueado pelo YouTube */}
        <div className="absolute top-4 right-4 opacity-0 group-hover/vid:opacity-100 transition-opacity z-20">
           <a 
             href={`https://www.youtube.com/watch?v=${videoId}`} 
             target="_blank" 
             rel="noopener noreferrer"
             className="bg-black/80 backdrop-blur-md text-white px-3 py-2 rounded-xl border border-white/10 flex items-center gap-2 text-[9px] font-black uppercase tracking-widest hover:bg-yellow-500 hover:text-black transition-all"
           >
             <ExternalLink size={12} /> Assistir no YouTube
           </a>
        </div>
      </div>
    );
  };

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-16 md:py-24 relative group cursor-pointer border-2 transition-all duration-300 ${activeSectionId === section.id ? 'border-yellow-500 ring-4 ring-yellow-500/10' : 'border-transparent'}`}
      style={bgStyle}
    >
      {style.bgType === 'video' && style.bgVideo && (
        <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover z-0 pointer-events-none">
          <source src={style.bgVideo} type="video/mp4" />
        </video>
      )}

      {(style.bgType === 'image' || style.bgType === 'video' || style.bgType === 'gradient' || style.bgType === 'gif') && (
        <div className="absolute inset-0 z-[1] pointer-events-none" style={{ backgroundColor: style.overlayColor || '#000', opacity: style.overlayOpacity ?? 0.6 }}></div>
      )}

      <div className="container mx-auto px-4 relative z-10 text-center">
        {(content.title || content.subtitle) && (
          <div className="mb-12 md:mb-16">
            <h2 className="text-3xl md:text-5xl font-black mb-6 uppercase tracking-tighter" style={{ color: style.titleColor }}>
              <FormattedText text={content.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
            </h2>
            <p className="max-w-2xl mx-auto font-medium opacity-70" style={{ color: style.textColor }}>
              <FormattedText text={content.subtitle} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
            </p>
          </div>
        )}

        {isGridLayout ? (
          <div className={`grid gap-6 md:gap-10 ${gridCols} max-w-7xl mx-auto`}>
            {videoItems.map((item: any, idx: number) => (
              <div key={idx} className="flex flex-col gap-4 animate-fade-in-up" style={{ animationDelay: `${idx * 150}ms` }}>
                {renderVideo(item.url, item.title)}
                {item.title && <h4 className="text-[10px] font-black uppercase tracking-[0.2em] opacity-60 italic" style={{ color: style.titleColor }}>{item.title}</h4>}
              </div>
            ))}
          </div>
        ) : (
          <div className="max-w-4xl mx-auto">
            {renderVideo(content.videoUrl, content.title)}
          </div>
        )}
      </div>
    </section>
  );
};

export default VideoSection;
