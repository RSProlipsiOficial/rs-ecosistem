
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import FormattedText from './FormattedText';

const MediaSection: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;

  if (!style.isVisible) return null;

  const bgStyle: any = {};
  if ((style.bgType === 'image' || style.bgType === 'gif') && style.bgImage) {
    bgStyle.backgroundImage = `url(${style.bgImage})`;
    bgStyle.backgroundSize = 'cover';
    bgStyle.backgroundPosition = 'center';
  } else if (style.bgType === 'gradient') {
    bgStyle.background = style.bgGradient;
  } else {
    bgStyle.backgroundColor = style.bgColor;
  }

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-24 relative overflow-hidden group cursor-pointer border-2 transition-all ${activeSectionId === section.id ? 'border-yellow-500' : 'border-transparent'}`}
      style={bgStyle}
    >
      {(style.bgType === 'image' || style.bgType === 'gif') && (
        <div className="absolute inset-0 z-0" style={{ backgroundColor: style.overlayColor || '#000', opacity: style.overlayOpacity || 0.4 }}></div>
      )}

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
           <h2 className="text-4xl md:text-6xl font-black mb-8 uppercase tracking-tighter" style={{ color: style.titleColor }}>
             <FormattedText text={content.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
           </h2>
           {content.image && (
             <div className="rounded-[3rem] overflow-hidden shadow-2xl border-4 border-white/5 transition-transform hover:scale-[1.01] duration-500">
               <img src={content.image} className="w-full h-auto object-cover" alt="Mídia" />
             </div>
           )}
           <p className="mt-8 text-xl font-medium" style={{ color: style.textColor }}>
             <FormattedText text={content.subtitle} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
           </p>
        </div>
      </div>
    </section>
  );
};

export default MediaSection;
