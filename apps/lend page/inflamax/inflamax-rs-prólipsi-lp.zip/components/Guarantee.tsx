
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import FormattedText from './FormattedText';

const Guarantee: React.FC<{ data: any }> = ({ data: section }) => {
  const { data, isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;

  if (!style.isVisible) return null;

  const bgStyle: any = {
    position: 'relative',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat'
  };

  if ((style.bgType === 'image' || style.bgType === 'gif') && style.bgImage) {
    bgStyle.backgroundImage = `url(${style.bgImage})`;
  } else if (style.bgType === 'gradient') {
    bgStyle.background = style.bgGradient;
  } else {
    bgStyle.backgroundColor = style.bgColor || '#050505';
  }

  return (
    <section 
      id="garantia" 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-16 scroll-mt-32 group relative cursor-pointer border-2 transition-all overflow-hidden ${activeSectionId === section.id ? 'border-yellow-500 ring-4 ring-yellow-500/10' : 'border-transparent'}`}
      style={bgStyle}
    >
      {style.bgType === 'video' && style.bgVideo && (
        <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover z-0 pointer-events-none">
          <source src={style.bgVideo} type="video/mp4" />
        </video>
      )}

      {(style.bgType === 'image' || style.bgType === 'video' || style.bgType === 'gradient' || style.bgType === 'gif') && (
        <div className="absolute inset-0 z-[1] pointer-events-none" style={{ backgroundColor: style.overlayColor || '#000', opacity: style.overlayOpacity ?? 0.5 }}></div>
      )}

      <div className="container mx-auto px-4 relative z-10">
        <div className="bg-zinc-900/50 rounded-[2.5rem] p-8 md:p-12 border border-zinc-800 flex flex-col md:flex-row items-center gap-8 relative overflow-hidden backdrop-blur-md">
          <div className="flex-shrink-0">
             <div className="w-28 h-28 md:w-32 md:h-32 rounded-full border-4 flex items-center justify-center bg-black shadow-xl transition-colors" style={{ borderColor: style.highlightColor }}>
                <div className="text-center">
                   <span className="block text-2xl md:text-3xl font-black leading-none" style={{ color: style.highlightColor }}>{data.general.guaranteeDays}</span>
                   <span className="block text-[8px] text-white uppercase font-black">Dias de<br/>Garantia</span>
                </div>
             </div>
          </div>

          <div className="flex-1 text-center md:text-left z-10">
            <h3 className="text-2xl md:text-3xl font-black mb-4 uppercase tracking-tighter" style={{ color: style.titleColor }}>
              <FormattedText text={content.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
            </h3>
            <p className="mb-6 text-base font-medium" style={{ color: style.textColor }}>
              <FormattedText text={content.text} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
            </p>
          </div>

          <div className="flex-shrink-0 md:ml-auto">
            <div className="flex flex-col items-center">
                <div className="w-28 h-28 rounded-full overflow-hidden border-2 mb-2 bg-zinc-800" style={{ borderColor: `${style.highlightColor}40` }}>
                  <img 
                    src={content.ceoImage || "https://via.placeholder.com/300x300/111/D4AF37?text=CEO"} 
                    alt="Assinatura" 
                    className={`w-full h-full object-cover ${style.removeBg ? 'mix-blend-lighten contrast-125' : ''}`}
                    style={{
                      objectPosition: `${style.imagePosX ?? 50}% ${style.imagePosY ?? 50}%`,
                      transform: `scale(${style.imageScale ?? 1})`
                    }}
                  />
                </div>
                <span className="text-[10px] font-black uppercase" style={{ color: style.highlightColor }}>{data.general.brandNameGold} {data.general.brandName}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Guarantee;
