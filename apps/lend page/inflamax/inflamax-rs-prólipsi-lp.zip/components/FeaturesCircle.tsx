
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import FormattedText from './FormattedText';

const FeaturesCircle: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;

  if (!style.isVisible) return null;

  const items = Array.isArray(content.items) ? content.items : [];
  
  // Layout dinâmico: Se tiver mais de 4, usa grid de 4, senão usa 3.
  const gridCols = items.length >= 4 ? 'grid-cols-2 md:grid-cols-4' : 'grid-cols-1 md:grid-cols-3';

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-20 relative group cursor-pointer border-2 transition-all ${activeSectionId === section.id ? 'border-yellow-500' : 'border-transparent'}`}
      style={{ backgroundColor: style.bgColor }}
    >
      <div className="container mx-auto px-4">
        {content.title && (
          <h2 className="text-3xl md:text-5xl font-black text-center mb-16 uppercase tracking-tighter" style={{ color: style.titleColor }}>
            <FormattedText text={content.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
          </h2>
        )}
        
        <div className={`grid ${gridCols} gap-12`}>
          {items.map((item: any, idx: number) => (
            <div key={idx} className="flex flex-col items-center text-center group/item">
              <div className="w-32 h-32 md:w-44 md:h-44 rounded-full overflow-hidden mb-6 border-4 shadow-2xl transition-transform group-hover/item:scale-110 duration-500" style={{ borderColor: style.highlightColor }}>
                <img src={item.image || "https://via.placeholder.com/200"} className="w-full h-full object-cover" alt={item.title} />
              </div>
              <h4 className="text-xl font-black uppercase mb-2" style={{ color: style.titleColor }}>{item.title}</h4>
              <p className="text-sm opacity-70" style={{ color: style.textColor }}>{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesCircle;
