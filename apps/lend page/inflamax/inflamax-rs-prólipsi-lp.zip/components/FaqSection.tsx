
import React, { useState } from 'react';
import { useSiteData } from '../context/SiteContext';
import { ChevronDown, ChevronUp } from 'lucide-react';
import FormattedText from './FormattedText';

const FaqSection: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  if (!style.isVisible) return null;

  const bgStyle: any = {
    position: 'relative',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat'
  };

  if ((style.bgType === 'image' || style.bgType === 'gif') && style.bgImage) {
    bgStyle.backgroundImage = `url(${style.bgImage})`;
  } else if (style.bgType === 'gradient') {
    bgStyle.background = style.bgGradient;
  } else {
    bgStyle.backgroundColor = style.bgColor || '#050505';
  }

  const items = Array.isArray(content.items) ? content.items : [];

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-20 relative group cursor-pointer border-2 transition-all overflow-hidden ${activeSectionId === section.id ? 'border-yellow-500 ring-4 ring-yellow-500/10' : 'border-transparent'}`}
      style={bgStyle}
    >
      {style.bgType === 'video' && style.bgVideo && (
        <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover z-0 pointer-events-none">
          <source src={style.bgVideo} type="video/mp4" />
        </video>
      )}

      {(style.bgType === 'image' || style.bgType === 'video' || style.bgType === 'gradient' || style.bgType === 'gif') && (
        <div className="absolute inset-0 z-[1] pointer-events-none" style={{ backgroundColor: style.overlayColor || '#000', opacity: style.overlayOpacity ?? 0.5 }}></div>
      )}

      <div className="container mx-auto px-4 max-w-3xl relative z-10">
        <h2 className="text-3xl md:text-5xl font-black text-center mb-12 uppercase tracking-tighter" style={{ color: style.titleColor }}>
          <FormattedText text={content.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
        </h2>
        
        <div className="space-y-4">
          {items.map((item: any, idx: number) => (
            <div key={idx} className="border border-zinc-800 rounded-2xl overflow-hidden bg-zinc-900/50 backdrop-blur-md">
              <button 
                onClick={() => setOpenIdx(openIdx === idx ? null : idx)}
                className="w-full p-6 text-left flex justify-between items-center hover:bg-zinc-800 transition-colors"
              >
                <span className="font-bold uppercase tracking-tight" style={{ color: style.titleColor }}>{item.question}</span>
                {openIdx === idx ? <ChevronUp style={{color: style.highlightColor}} /> : <ChevronDown style={{color: style.highlightColor}} />}
              </button>
              {openIdx === idx && (
                <div className="p-6 pt-0 text-sm leading-relaxed opacity-80" style={{ color: style.textColor }}>
                  {item.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FaqSection;
