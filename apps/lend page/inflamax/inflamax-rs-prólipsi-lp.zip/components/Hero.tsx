
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { Edit3, Star, ShieldCheck } from 'lucide-react';
import FormattedText from './FormattedText';

const Hero: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const content = section.content;
  const style = section.style;
  
  if (!style.isVisible) return null;

  const isImageFirst = style.layout === 'image-left' || style.layout === 'image-top';
  const flexOrder = isImageFirst ? 'lg:flex-row-reverse' : 'lg:flex-row';
  const mobileOrder = isImageFirst ? 'flex-col-reverse' : 'flex-col';

  // Lógica de Background
  const bgStyle: any = {
    position: 'relative',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat'
  };

  if ((style.bgType === 'image' || style.bgType === 'gif') && style.bgImage) {
    bgStyle.backgroundImage = `url(${style.bgImage})`;
  } else if (style.bgType === 'gradient') {
    bgStyle.background = style.bgGradient;
  } else if (style.bgType === 'solid' || !style.bgType) {
    bgStyle.backgroundColor = style.bgColor || '#050505';
  }

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`relative pt-32 pb-24 md:pt-44 md:pb-36 overflow-hidden group cursor-pointer border-2 transition-all duration-500 ${activeSectionId === section.id ? 'border-yellow-500 ring-4 ring-yellow-500/10' : 'border-transparent'}`}
      style={bgStyle}
    >
      {/* Background de Vídeo */}
      {style.bgType === 'video' && style.bgVideo && (
        <video
          autoPlay
          muted
          loop
          playsInline
          className="absolute inset-0 w-full h-full object-cover z-0 pointer-events-none"
        >
          <source src={style.bgVideo} type="video/mp4" />
          <source src={style.bgVideo} type="video/webm" />
        </video>
      )}

      {/* Overlay para legibilidade */}
      {(style.bgType === 'image' || style.bgType === 'video' || style.bgType === 'gradient' || style.bgType === 'gif') && (
        <div 
          className="absolute inset-0 z-[1] pointer-events-none" 
          style={{ 
            backgroundColor: style.overlayColor || '#000', 
            opacity: style.overlayOpacity ?? 0.5 
          }}
        ></div>
      )}

      {isAdminOpen && (
        <div className="absolute top-4 right-4 z-[70] opacity-0 group-hover:opacity-100 transition-opacity">
           <div className="bg-yellow-600 text-black px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-2xl">
             <Edit3 size={14}/> Editor Ativo
           </div>
        </div>
      )}

      <div className="container mx-auto px-4 relative z-10">
        <div className={`flex ${mobileOrder} ${flexOrder} items-center gap-16 lg:gap-8`}>
          <div className="flex-1 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 mb-6 px-4 py-2 rounded-full bg-yellow-500/10 border border-yellow-500/20">
               <div className="flex">
                  {[...Array(5)].map((_, i) => <Star key={i} size={10} className="text-yellow-500 fill-yellow-500" />)}
               </div>
               <span className="text-[9px] font-black uppercase tracking-widest text-yellow-500">+10.000 Clientes Satisfeitos</span>
            </div>
            
            <h1 
              className="text-4xl md:text-6xl lg:text-7xl font-black mb-8 leading-[1.05] uppercase tracking-tighter"
              style={{ color: style.titleColor }}
            >
              <FormattedText text={content.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
            </h1>
            
            <p 
              className="text-lg md:text-xl mb-10 leading-relaxed max-w-xl mx-auto lg:mx-0 opacity-80 font-medium"
              style={{ color: style.textColor }}
            >
              <FormattedText text={content.subtitle} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <a 
                href={content.buttonUrl || "#ofertas"} 
                className="text-black text-lg font-black px-14 py-5 rounded-2xl shadow-2xl flex justify-center items-center uppercase tracking-widest transition-all hover:scale-105 active:scale-95 text-center"
                style={{ backgroundColor: style.highlightColor }}
              >
                {content.cta}
              </a>
              <div className="flex items-center justify-center lg:justify-start gap-4 px-4 opacity-60">
                 <ShieldCheck className="text-yellow-500" />
                 <span className="text-[10px] font-bold text-white uppercase tracking-widest">Compra 100% Segura</span>
              </div>
            </div>
          </div>

          <div className="flex-1 relative flex justify-center items-center">
            <div className="relative w-full max-w-[500px] animate-float">
               <img 
                 src={content.image} 
                 alt="Produto"
                 className="w-full h-auto drop-shadow-[0_20px_50px_rgba(0,0,0,0.5)] product-glow block" 
               />
               <div className="absolute inset-0 bg-yellow-500/5 rounded-full blur-[100px] -z-10"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
