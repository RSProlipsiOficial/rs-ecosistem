
import React from 'react';
import { Star, Activity, Move, Plus, User } from 'lucide-react';
import { useSiteData } from '../context/SiteContext';
import FormattedText from './FormattedText';

const Testimonials: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;

  if (!style.isVisible) return null;

  const bgStyle: any = {
    position: 'relative',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat'
  };

  if ((style.bgType === 'image' || style.bgType === 'gif') && style.bgImage) {
    bgStyle.backgroundImage = `url(${style.bgImage})`;
  } else if (style.bgType === 'gradient') {
    bgStyle.background = style.bgGradient;
  } else {
    bgStyle.backgroundColor = style.bgColor || '#050505';
  }

  const testimonials = Array.isArray(content.items) ? content.items : [];
  
  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-16 md:py-24 text-white transition-all scroll-mt-24 cursor-pointer border-2 overflow-hidden ${activeSectionId === section.id ? 'border-yellow-500 ring-4 ring-yellow-500/10' : 'border-zinc-900'}`}
      style={bgStyle}
    >
      {style.bgType === 'video' && style.bgVideo && (
        <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover z-0 pointer-events-none">
          <source src={style.bgVideo} type="video/mp4" />
        </video>
      )}

      {(style.bgType === 'image' || style.bgType === 'video' || style.bgType === 'gradient' || style.bgType === 'gif') && (
        <div className="absolute inset-0 z-[1] pointer-events-none" style={{ backgroundColor: style.overlayColor || '#000', opacity: style.overlayOpacity ?? 0.5 }}></div>
      )}

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-5xl font-black mb-4 uppercase tracking-tighter" style={{ color: style.titleColor }}>
            <FormattedText text={content.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto font-medium text-sm md:text-base px-4">
            <FormattedText text={content.subtitle} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
          </p>
        </div>

        {content.image && (
          <div className="max-w-4xl mx-auto mb-16 md:mb-20 rounded-[2rem] md:rounded-[2.5rem] overflow-hidden border border-zinc-800 shadow-2xl mx-4">
            <img src={content.image} className="w-full h-auto object-cover" alt="Destaque Depoimentos" />
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 mb-12">
          {testimonials.length > 0 ? (
            testimonials.map((t: any, idx: number) => (
              <div key={idx} className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 p-6 md:p-8 rounded-[2rem] hover:border-yellow-600/30 transition-all flex flex-col group shadow-xl">
                <div className="flex items-center gap-4 mb-5">
                  <div className="w-14 h-14 md:w-16 md:h-16 rounded-full border-2 overflow-hidden bg-zinc-800 flex items-center justify-center flex-shrink-0 shadow-lg" style={{ borderColor: style.highlightColor }}>
                      {t.image ? (
                        <img src={t.image} className="w-full h-full object-cover" alt={t.name} />
                      ) : (
                        <User size={24} style={{ color: style.highlightColor }} />
                      )}
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-black text-white uppercase tracking-tight text-sm md:text-base truncate">{t.name || 'Cliente'}</h4>
                    <p className="text-[9px] md:text-[10px] font-black uppercase tracking-widest truncate" style={{ color: style.highlightColor }}>{t.location || 'Brasil'}</p>
                  </div>
                </div>
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={12} className="fill-current" style={{ color: style.highlightColor }} />
                  ))}
                </div>
                <p className="text-gray-300 italic text-xs md:text-sm leading-relaxed mb-6 flex-grow">"{t.text || 'Sem depoimento escrito.'}"</p>
                
                <div className="mt-auto pt-6 border-t border-zinc-800/50">
                    <p className="text-[8px] md:text-[9px] text-center text-gray-500 font-black uppercase tracking-[0.2em] mb-3">Evolução do Paciente</p>
                    <div className="flex items-center justify-between gap-2 h-14 md:h-16 bg-black/40 rounded-xl p-3 border border-zinc-800">
                        <div className="flex-1 flex flex-col items-center justify-center opacity-40">
                            <Activity size={18} className="text-red-500 mb-1" />
                            <span className="text-[7px] md:text-[8px] text-red-500 font-black">DOR</span>
                        </div>
                        <div className="text-zinc-700 font-black text-xs">→</div>
                        <div className="flex-1 flex flex-col items-center justify-center">
                            <Move size={18} className="text-yellow-500 mb-1" />
                            <span className="text-[7px] md:text-[8px] text-yellow-500 font-black">VIDA</span>
                        </div>
                    </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full py-20 border-2 border-dashed border-zinc-800 rounded-[2.5rem] flex flex-col items-center justify-center text-zinc-600 gap-4 mx-4">
               <Plus size={40} className="opacity-20" />
               <p className="font-black uppercase tracking-widest text-[10px]">Adicione depoimentos no painel lateral</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
