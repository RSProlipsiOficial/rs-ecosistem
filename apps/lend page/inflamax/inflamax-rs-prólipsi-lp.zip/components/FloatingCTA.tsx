
import React, { useState, useEffect } from 'react';

const FloatingCTA: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 500) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 md:hidden animate-fade-in-up">
      <a 
        href="#ofertas" 
        className="w-full bg-gradient-to-r from-yellow-600 to-yellow-400 text-black font-black py-5 rounded-2xl shadow-[0_15px_30px_rgba(234,179,8,0.4)] flex flex-col justify-center items-center text-xs tracking-widest border-2 border-white/30 uppercase active:scale-95 transition-transform"
      >
        <span className="opacity-70 text-[9px] mb-1">Oferta por Tempo Limitado</span>
        QUERO MEU INFLAMAX AGORA
      </a>
    </div>
  );
};

export default FloatingCTA;
