
export type SectionType = 
  | 'hero' 
  | 'painPoints' 
  | 'benefits' 
  | 'ingredients' 
  | 'testimonials' 
  | 'pricing' 
  | 'guarantee' 
  | 'specialBanner' 
  | 'media' 
  | 'video' 
  | 'reels'
  | 'featuresCircle'
  | 'gridCollage'
  | 'faq'
  | 'stepProcess'
  | 'comparison'
  | 'trustBadges'
  | 'nutritionalTable';

export interface MenuItem {
  label: string;
  href: string;
  isButton?: boolean;
}

export interface SectionBlock {
  id: string; // Este é o ID da âncora (#)
  type: SectionType;
  content: any;
  style: {
    bgColor: string;
    bgGradient?: string;
    bgImage?: string;
    bgVideo?: string;
    bgType: 'solid' | 'gradient' | 'image' | 'video' | 'gif';
    titleColor: string;
    textColor: string;
    highlightColor: string;
    overlayColor?: string;
    overlayOpacity?: number;
    isVisible: boolean;
    layout?: 'image-right' | 'image-left' | 'image-top' | 'image-bottom' | 'center' | 'grid-2' | 'grid-3' | 'grid-4';
    borderRadius?: number; 
    itemRadius?: number;   
    imageHeight?: number;  
    imageScale?: number;    
    imagePosX?: number;     
    imagePosY?: number;     
    removeBg?: boolean;     
    markerType?: 'dash' | 'dot' | 'triangle' | 'full-border' | 'none'; 
    markerColor?: string; 
  };
}

export interface SiteData {
  general: {
    brandName: string;
    brandNameGold: string;
    supportEmail: string;
    whatsapp: string;
    whatsappDisplay: string;
    guaranteeDays: number;
    logo?: string;
  };
  menu: MenuItem[];
  footer: {
    style: {
      bgColor: string;
      textColor: string;
      titleColor: string;
      highlightColor: string;
    };
    content: {
      brandDescription: string;
      aboutTitle: string;
      aboutText: string;
      missionTitle: string;
      missionText: string;
      certificationsTitle: string;
      certifications: { label: string, image: string }[];
      socials: { platform: 'Instagram' | 'Facebook' | 'Youtube' | 'Whatsapp', url: string }[];
      quickLinks: { label: string, href: string }[];
      contactItems: { label: string, value: string }[];
      overviewItems: { label: string }[];
      legalInfo: { title: string, description: string };
      bottomText: string;
      rightsText: string;
    };
  };
  social: {
    instagram: string;
    facebook: string;
    youtube: string;
  };
  sections: SectionBlock[];
}
