
import React, { createContext, useContext, useState, useEffect } from 'react';
import { SiteData, SectionBlock, SectionType } from '../types';
import { PRICING, BENEFITS, ASSETS, CONTACT, INGREDIENTS } from '../constants';

const STORAGE_KEY = 'inflamax_ultra_builder_v14';

const INITIAL_SECTIONS: SectionBlock[] = [
  {
    id: 'hero-principal',
    type: 'hero',
    style: { 
      bgType: 'image', 
      bgImage: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?q=80&w=2070&auto=format&fit=crop',
      bgColor: '#050505', 
      titleColor: '#ffffff', 
      textColor: '#d1d5db', 
      highlightColor: '#EAB308', 
      isVisible: true, 
      layout: 'image-right',
      overlayColor: '#000000',
      overlayOpacity: 0.65
    },
    content: {
      title: "Recupere Sua *Mobilidade* e Viva Sem Dores",
      subtitle: "Fórmula avançada desenvolvida para combater Artrite, Artrose e Fibromialgia na raiz do problema.",
      cta: "QUERO MINHA VIDA DE VOLTA",
      buttonUrl: "#ofertas",
      image: ASSETS.product3
    }
  },
  {
    id: 'dores-especificas',
    type: 'painPoints',
    style: { 
      bgType: 'image',
      bgImage: 'https://images.unsplash.com/photo-1516574187841-693083f6e1f9?q=80&w=2070&auto=format&fit=crop',
      bgColor: '#0a0a0a', 
      titleColor: '#ffffff', 
      textColor: '#d1d5db', 
      highlightColor: '#EAB308', 
      isVisible: true,
      overlayColor: '#000000',
      overlayOpacity: 0.85
    },
    content: {
      title: "As *Dores* Não Precisam Ser Parte Da Sua Rotina",
      subtitle: "Se você sofre com inflamações crônicas, o Inflamax é a solução definitiva que você buscava.",
      items: [
        { title: "Artrite e Artrose", img: ASSETS.painJoints },
        { title: "Fibromialgia", img: ASSETS.painBack },
        { title: "Dores de Desgaste", img: ASSETS.painKnee }
      ],
      bottomBanner: {
        title: "Chega de sentir *limitações* físicas!",
        text: "Volte a fazer o que você ama com liberdade total de movimentos.",
        buttonText: "QUERO ALÍVIO AGORA",
        buttonUrl: "#ofertas"
      }
    }
  },
  {
    id: 'comparativo-inflamax',
    type: 'comparison',
    style: { 
      bgType: 'image',
      bgImage: 'https://images.unsplash.com/photo-1584036561566-b93738066ba8?q=80&w=2070&auto=format&fit=crop',
      bgColor: '#050505', 
      titleColor: '#ffffff', 
      textColor: '#a1a1aa', 
      highlightColor: '#EAB308', 
      isVisible: true,
      overlayColor: '#000000',
      overlayOpacity: 0.8
    },
    content: {
      title: "A *Evolução* do Seu Tratamento",
      items: [
        { 
          before: { label: "Com Inflamação e Rigidez", image: "https://images.unsplash.com/photo-1544118220-71752e258cb2?auto=format&fit=crop&q=80&w=600" },
          after: { label: "Liberdade e Bem-Estar", image: ASSETS.activeLife },
          description: "Resultados comprovados por milhares de pacientes em todo o país."
        }
      ]
    }
  },
  {
    id: 'beneficios-reais',
    type: 'benefits',
    style: { 
      bgType: 'image',
      bgImage: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?q=80&w=2074&auto=format&fit=crop',
      bgColor: '#0a0a0a', 
      bgGradient: 'linear-gradient(180deg, #0a0a0a 0%, #050505 100%)', 
      titleColor: '#ffffff', 
      textColor: '#cbd5e1', 
      highlightColor: '#EAB308', 
      isVisible: true, 
      borderRadius: 32, 
      markerType: 'dot',
      overlayColor: '#000000',
      overlayOpacity: 0.7
    },
    content: {
      sectionTitle: "Por Que Escolher o *Inflamax*?",
      sectionSubtitle: "Diferencial Competitivo",
      items: BENEFITS
    }
  },
  {
    id: 'formula-secreta',
    type: 'ingredients',
    style: { 
      bgType: 'image',
      bgImage: 'https://images.unsplash.com/photo-1615485925694-a039163bbd06?q=80&w=2070&auto=format&fit=crop',
      bgColor: '#050505', 
      titleColor: '#ffffff', 
      textColor: '#d1d5db', 
      highlightColor: '#EAB308', 
      isVisible: true,
      overlayColor: '#000000',
      overlayOpacity: 0.85
    },
    content: {
      sectionTitle: "Fórmula de *Alta Performance*",
      sectionSubtitle: "Ingredientes selecionados para máxima absorção e eficácia no combate à dor.",
      items: INGREDIENTS,
      image: "https://images.unsplash.com/photo-1616671276445-162152671d8a?auto=format&fit=crop&q=80&w=600"
    }
  },
  {
    id: 'depoimentos-clientes',
    type: 'testimonials',
    style: { 
      bgType: 'image',
      bgImage: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?q=80&w=2084&auto=format&fit=crop',
      bgColor: '#0a0a0a', 
      titleColor: '#ffffff', 
      textColor: '#a1a1aa', 
      highlightColor: '#EAB308', 
      isVisible: true,
      overlayColor: '#000000',
      overlayOpacity: 0.85
    },
    content: {
      title: "Quem Usa, *Aprova*",
      subtitle: "Histórias reais de pessoas que transformaram sua saúde física com Inflamax.",
      items: [
        { name: "Maria Silva", location: "Curitiba/PR", text: "Depois de 5 anos com fibromialgia, finalmente encontrei algo que realmente me deu paz.", image: "" },
        { name: "João Pereira", location: "São Paulo/SP", text: "Minha artrose no joelho não me deixa mais mancar. Recomendo demais!", image: "" },
        { name: "Cláudia Souza", location: "Belo Horizonte/MG", text: "Voltei a caminhar no parque com meus netos. Obrigado RS Prólipsi!", image: "" }
      ]
    }
  },
  {
    id: 'ofertas-limitadas',
    type: 'pricing',
    style: { 
      bgType: 'image',
      bgImage: 'https://images.unsplash.com/photo-1620641788427-3e1909791271?q=80&w=2070&auto=format&fit=crop',
      bgColor: '#050505', 
      bgGradient: 'linear-gradient(180deg, #050505 0%, #0a0a0a 100%)', 
      titleColor: '#ffffff', 
      textColor: '#9ca3af', 
      highlightColor: '#EAB308', 
      isVisible: true,
      overlayColor: '#000000',
      overlayOpacity: 0.75
    },
    content: {
      sectionTitle: "Garanta Seu *Kit* com Desconto",
      kits: PRICING
    }
  },
  {
    id: 'faq-inflamax',
    type: 'faq',
    style: { 
      bgType: 'image',
      bgImage: 'https://images.unsplash.com/photo-1484807353310-d8c252d022d5?q=80&w=2070&auto=format&fit=crop',
      bgColor: '#050505', 
      titleColor: '#ffffff', 
      textColor: '#9ca3af', 
      highlightColor: '#EAB308', 
      isVisible: true,
      overlayColor: '#000000',
      overlayOpacity: 0.85
    },
    content: {
      title: "Dúvidas *Frequentes*",
      items: [
        { question: "Em quanto tempo sinto os efeitos?", answer: "Os primeiros alívios costumam ser sentidos entre 7 a 15 dias de uso contínuo." },
        { question: "Possui contraindicação?", answer: "Por ser natural, não possui efeitos colaterais. Gestantes devem consultar o médico." },
        { question: "Como devo tomar?", answer: "Recomenda-se ingerir 1 cápsula ao dia, preferencialmente após a refeição principal." }
      ]
    }
  },
  {
    id: 'garantia-blindada',
    type: 'guarantee',
    style: { 
      bgType: 'image',
      bgImage: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=2071&auto=format&fit=crop',
      bgColor: '#0a0a0a', 
      titleColor: '#ffffff', 
      textColor: '#d1d5db', 
      highlightColor: '#EAB308', 
      isVisible: true, 
      removeBg: true,
      overlayColor: '#000000',
      overlayOpacity: 0.85
    },
    content: {
      title: "Garantia de *Satisfação* Total",
      text: "Se você não sentir melhora nas suas dores em até 30 dias, devolvemos seu dinheiro. Risco zero para você.",
      ceoImage: ASSETS.ceo
    }
  }
];

const DEFAULT_DATA: SiteData = {
  general: {
    brandName: "PRÓLIPSI",
    brandNameGold: "RS",
    supportEmail: CONTACT.email,
    whatsapp: CONTACT.phone,
    whatsappDisplay: CONTACT.displayPhone,
    guaranteeDays: 30
  },
  menu: [
    { label: 'O Produto', href: '#hero-principal' },
    { label: 'Benefícios', href: '#beneficios-reais' },
    { label: 'Fórmula', href: '#formula-secreta' },
    { label: 'Ofertas', href: '#ofertas-limitadas', isButton: true },
  ],
  footer: {
    style: { bgColor: "#000000", textColor: "#666666", titleColor: "#ffffff", highlightColor: "#EAB308" },
    content: {
      brandDescription: "RS PRÓLIPSI: Especialistas em suplementação inteligente para regeneração física.",
      aboutTitle: "Sobre Nós",
      aboutText: "Focados em devolver a qualidade de vida através da nanotecnologia natural.",
      missionTitle: "Nossa Missão",
      missionText: "Eliminar a dor crônica da rotina de milhões de brasileiros.",
      certificationsTitle: "Certificações",
      certifications: [ { label: "Anvisa", image: "" }, { label: "Qualidade Premium", image: "" } ],
      socials: [ { platform: 'Instagram', url: '#' }, { platform: 'Facebook', url: '#' } ],
      quickLinks: [ { label: 'INÍCIO', href: '#' }, { label: 'BENEFÍCIOS', href: '#beneficios-reais' }, { label: 'FÓRMULA', href: '#formula-secreta' } ],
      contactItems: [ { label: 'Fone', value: CONTACT.displayPhone }, { label: 'Email', value: CONTACT.email } ],
      overviewItems: [ { label: 'FAQ' }, { label: 'Privacidade' } ],
      legalInfo: { title: 'AVISO LEGAL', description: 'Este produto não é um medicamento. Consulte seu médico antes de iniciar.' },
      bottomText: '2025 RS PRÓLIPSI. TODOS OS DIREITOS RESERVADOS.',
      rightsText: 'PAGAMENTO 100% SEGURO'
    }
  },
  social: { instagram: "#", facebook: "#", youtube: "" },
  sections: INITIAL_SECTIONS
};

export type AdminTab = 'structure' | 'edit' | 'create' | 'footer' | 'ai';

interface SiteContextType {
  data: SiteData;
  updateData: (newData: SiteData) => void;
  resetData: () => void;
  isAdminOpen: boolean;
  setAdminOpen: (open: boolean) => void;
  activeSectionId: string | null;
  setActiveSectionId: (id: string | null) => void;
  activeTab: AdminTab;
  setActiveTab: (tab: AdminTab) => void;
  moveSection: (id: string, direction: 'up' | 'down') => void;
  removeSection: (id: string) => void;
  addSection: (type: SectionType) => void;
  previewMode: 'desktop' | 'mobile';
  setPreviewMode: (mode: 'desktop' | 'mobile') => void;
}

const SiteContext = createContext<SiteContextType | undefined>(undefined);

export const SiteProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<SiteData>(DEFAULT_DATA);
  const [isAdminOpen, setAdminOpen] = useState(false);
  const [activeSectionId, setActiveSectionId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<AdminTab>('structure');
  const [previewMode, setPreviewMode] = useState<'desktop' | 'mobile'>('desktop');

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setData(JSON.parse(saved));
      } catch (e) { setData(DEFAULT_DATA); }
    }
  }, []);

  const updateData = (newData: SiteData) => {
    setData(newData);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
  };

  const addSection = (type: SectionType) => {
    const anchorId = `${type}-${Date.now()}`;
    const newSection: SectionBlock = {
      id: anchorId,
      type,
      style: {
        bgType: 'solid',
        bgColor: '#050505',
        bgImage: '',
        bgVideo: '',
        bgGradient: '',
        overlayColor: '#000000',
        overlayOpacity: 0.5,
        titleColor: '#ffffff',
        textColor: '#a1a1aa',
        highlightColor: '#EAB308',
        isVisible: true,
        layout: 'center',
        borderRadius: 24,
        itemRadius: 12
      },
      content: {
        title: "Título do Novo Bloco",
        subtitle: "Texto descritivo.",
        customHighlights: []
      }
    };

    switch(type) {
      case 'benefits':
        newSection.content.sectionTitle = "Mais Benefícios";
        newSection.content.items = BENEFITS;
        break;
      case 'pricing':
        newSection.content.sectionTitle = "Tabela de Ofertas";
        newSection.content.kits = PRICING;
        break;
      case 'ingredients':
        newSection.content.sectionTitle = "Nossa Fórmula";
        newSection.content.items = INGREDIENTS;
        break;
      case 'comparison':
        newSection.content.items = [{ before: { label: 'Antigo' }, after: { label: 'Novo' } }];
        break;
      case 'video':
        newSection.content.title = "Vídeos de Resultados";
        newSection.content.subtitle = "Veja o depoimento de quem já usa o Inflamax.";
        newSection.content.videoUrl = ""; 
        newSection.content.videos = [
          { url: "", title: "Depoimento 1" },
          { url: "", title: "Depoimento 2" },
          { url: "", title: "Depoimento 3" }
        ]; 
        newSection.style.layout = "grid-3"; // Opções: center, grid-2, grid-3, grid-4, grid-6
        break;
    }

    updateData({ ...data, sections: [...data.sections, newSection] });
    setActiveSectionId(anchorId);
    setActiveTab('edit');
  };

  const moveSection = (id: string, direction: 'up' | 'down') => {
    const index = data.sections.findIndex(s => s.id === id);
    if (index === -1) return;
    const newSections = [...data.sections];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newSections.length) return;
    [newSections[index], newSections[targetIndex]] = [newSections[targetIndex], newSections[index]];
    updateData({ ...data, sections: newSections });
  };

  const removeSection = (id: string) => {
    if (confirm("Deseja remover este bloco definitivamente?")) {
      updateData({ ...data, sections: data.sections.filter(s => s.id !== id) });
      if (activeSectionId === id) setActiveSectionId(null);
    }
  };

  const resetData = () => {
    if (confirm("Isso apagará todas as suas edições. Continuar?")) {
      setData(DEFAULT_DATA);
      localStorage.removeItem(STORAGE_KEY);
      window.location.reload();
    }
  };

  return (
    <SiteContext.Provider value={{ 
      data, updateData, resetData, isAdminOpen, setAdminOpen, 
      activeSectionId, setActiveSectionId, 
      activeTab, setActiveTab,
      moveSection, removeSection, addSection,
      previewMode, setPreviewMode
    }}>
      {children}
    </SiteContext.Provider>
  );
};

export const useSiteData = () => {
  const context = useContext(SiteContext);
  if (!context) throw new Error("useSiteData must be used within SiteProvider");
  return context;
};
