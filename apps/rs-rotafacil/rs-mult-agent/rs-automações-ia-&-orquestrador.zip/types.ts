
export type ViewState = 
  | 'LOGIN' 
  | 'DASHBOARD' 
  | 'AUTOMATIONS' 
  | 'CREATE_AI' 
  | 'MONITOR' 
  | 'TEMPLATES' 
  | 'WORKFLOWS' 
  | 'CREDENTIALS' 
  | 'ADMIN' 
  | 'SETTINGS';

export interface Automation {
  id: string;
  name: string;
  type: 'WhatsApp' | 'Payment' | 'CRM' | 'System';
  status: 'active' | 'inactive';
  lastRun: string;
  // Supabase/N8n specific fields
  tenant_id?: string;
  n8n_workflow_id?: string;
  created_at?: string;
  workflow_json?: string;
}

export interface AutomationParam {
  automation_id: string;
  key: string;
  value: string;
}

export interface ExecutionRecord {
  id: string;
  automation: string; // automation name
  automation_id?: string;
  n8n_execution_id?: string;
  status: 'success' | 'error';
  timestamp: string;
  duration: string;
  error_details?: string;
}

export interface Template {
  id: string;
  name: string;
  category: 'WhatsApp' | 'CRM' | 'Financeiro' | 'Sistema';
  description: string;
  longDescription?: string;
  features?: string[];
  connectors: string[];
  complexity: 'Básico' | 'Intermediário' | 'Avançado';
  configFields: {
    label: string;
    name: string;
    type: 'text' | 'password' | 'select';
    placeholder: string;
    options?: string[];
  }[];
}

export interface WorkflowVersion {
  id: string;
  version: string;
  createdAt: string;
  createdBy: string;
  notes: string;
  isActive: boolean;
}
