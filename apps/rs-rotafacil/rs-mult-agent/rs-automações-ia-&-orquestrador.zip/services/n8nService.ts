
import { Automation } from '../types';

// PROMPT A: Backend Connector n8n
// This service simulates the interaction with an N8n instance.
// In a real backend, this would use axios/fetch to call N8N_BASE_URL.

const N8N_BASE_URL = 'https://n8n.rsauto.com/api/v1'; // Mock URL
const N8N_AUTH = 'apikey-123456';

export const n8nService = {
  // Simulates creating a workflow in n8n
  async createWorkflow(json: string): Promise<{ id: string; name: string; active: boolean }> {
    console.log(`[N8N Connector] POST ${N8N_BASE_URL}/workflows`, JSON.parse(json));
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Return mock n8n response
    return {
      id: `n8n-wf-${Math.floor(Math.random() * 10000)}`,
      name: JSON.parse(json).name || "Untitled Workflow",
      active: false
    };
  },

  // Simulates updating a workflow
  async updateWorkflow(id: string, json: string): Promise<boolean> {
    console.log(`[N8N Connector] PUT ${N8N_BASE_URL}/workflows/${id}`, JSON.parse(json));
    await new Promise(resolve => setTimeout(resolve, 1000));
    return true;
  },

  // Simulates activating a workflow
  async activateWorkflow(id: string): Promise<boolean> {
    console.log(`[N8N Connector] POST ${N8N_BASE_URL}/workflows/${id}/activate`);
    await new Promise(resolve => setTimeout(resolve, 800));
    return true;
  },

  // Simulates deactivating a workflow
  async deactivateWorkflow(id: string): Promise<boolean> {
    console.log(`[N8N Connector] POST ${N8N_BASE_URL}/workflows/${id}/deactivate`);
    await new Promise(resolve => setTimeout(resolve, 800));
    return true;
  },

  // Simulates fetching executions
  async listExecutions(filters?: any): Promise<any[]> {
    console.log(`[N8N Connector] GET ${N8N_BASE_URL}/executions`, filters);
    // This connects to the mock data in ExecutionMonitor via the shared service layer
    return [];
  }
};
