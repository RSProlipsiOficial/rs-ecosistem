import { Automation, ExecutionRecord } from '../types';

// PROMPT B: Persistência Supabase
// This service mocks the database interactions.
// We use localStorage to persist data between reloads for the demo.

const DB_KEY_AUTOMATIONS = 'rs_automations_v1';
const DB_KEY_EXECUTIONS = 'rs_executions_v1';

// Seed initial data if empty
const seedData = () => {
  if (!localStorage.getItem(DB_KEY_AUTOMATIONS)) {
    const initialAutomations: Automation[] = [
      { id: '1', name: 'Triagem Inicial WhatsApp', type: 'WhatsApp', status: 'active', lastRun: '2 min atrás', tenant_id: 'tenant-01', n8n_workflow_id: 'n8n-101' },
      { id: '2', name: 'Cobrança Automática Stripe', type: 'Payment', status: 'active', lastRun: '1 hora atrás', tenant_id: 'tenant-01', n8n_workflow_id: 'n8n-102' },
      { id: '3', name: 'Sincronização CRM Hubspot', type: 'CRM', status: 'inactive', lastRun: '2 dias atrás', tenant_id: 'tenant-01', n8n_workflow_id: 'n8n-103' },
      { id: '4', name: 'Backup de Leads Supabase', type: 'System', status: 'active', lastRun: '15 min atrás', tenant_id: 'tenant-01', n8n_workflow_id: 'n8n-104' },
      { id: '5', name: 'Resposta Automática Suporte', type: 'WhatsApp', status: 'active', lastRun: 'Agora', tenant_id: 'tenant-01', n8n_workflow_id: 'n8n-105' },
    ];
    localStorage.setItem(DB_KEY_AUTOMATIONS, JSON.stringify(initialAutomations));
  }

  if (!localStorage.getItem(DB_KEY_EXECUTIONS)) {
    const initialExecutions: ExecutionRecord[] = [
        { id: '1', automation: 'WhatsApp Triagem', status: 'success', timestamp: `12:45:02 - ${new Date().toLocaleDateString('pt-BR')}`, duration: '1.2s' },
        { id: '2', automation: 'Criação Lead Supabase', status: 'success', timestamp: `12:44:50 - ${new Date().toLocaleDateString('pt-BR')}`, duration: '0.8s' },
        { id: '3', automation: 'Cobrança Stripe', status: 'error', timestamp: '12:40:12 - 14/10/2023', duration: '3.5s' },
    ];
    localStorage.setItem(DB_KEY_EXECUTIONS, JSON.stringify(initialExecutions));
  }
};

seedData();

export const supabaseService = {
  // --- Automations Table ---

  async listAutomations(tenantId: string = 'tenant-01'): Promise<Automation[]> {
    const data = JSON.parse(localStorage.getItem(DB_KEY_AUTOMATIONS) || '[]');
    // Simulate RLS (Row Level Security)
    return data.filter((a: Automation) => a.tenant_id === tenantId);
  },

  async createAutomation(automation: Omit<Automation, 'id' | 'created_at' | 'lastRun'>): Promise<Automation> {
    const data = JSON.parse(localStorage.getItem(DB_KEY_AUTOMATIONS) || '[]');
    const newAuth: Automation = {
      ...automation,
      id: Math.random().toString(36).substr(2, 9),
      created_at: new Date().toISOString(),
      lastRun: 'Nunca',
      tenant_id: 'tenant-01'
    };
    data.unshift(newAuth);
    localStorage.setItem(DB_KEY_AUTOMATIONS, JSON.stringify(data));
    return newAuth;
  },

  async updateAutomationStatus(id: string, status: 'active' | 'inactive'): Promise<void> {
    const data = JSON.parse(localStorage.getItem(DB_KEY_AUTOMATIONS) || '[]');
    const updated = data.map((a: Automation) => a.id === id ? { ...a, status } : a);
    localStorage.setItem(DB_KEY_AUTOMATIONS, JSON.stringify(updated));
  },

  async deleteAutomation(id: string): Promise<void> {
    const data = JSON.parse(localStorage.getItem(DB_KEY_AUTOMATIONS) || '[]');
    const filtered = data.filter((a: Automation) => a.id !== id);
    localStorage.setItem(DB_KEY_AUTOMATIONS, JSON.stringify(filtered));
  },

  // --- Executions Table ---

  async listExecutions(filters?: any): Promise<ExecutionRecord[]> {
    const data = JSON.parse(localStorage.getItem(DB_KEY_EXECUTIONS) || '[]');
    return data;
  },

  async logExecution(exec: Omit<ExecutionRecord, 'id'>): Promise<void> {
    const data = JSON.parse(localStorage.getItem(DB_KEY_EXECUTIONS) || '[]');
    const newExec = { ...exec, id: Math.random().toString(36).substr(2, 9) };
    data.unshift(newExec);
    localStorage.setItem(DB_KEY_EXECUTIONS, JSON.stringify(data));
  }
};