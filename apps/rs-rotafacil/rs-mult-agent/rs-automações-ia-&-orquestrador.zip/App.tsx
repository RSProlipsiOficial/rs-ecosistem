
import React, { useState } from 'react';
import { ViewState } from './types';
import Sidebar from './components/Sidebar';
import Dashboard from './views/Dashboard';
import Login from './views/Login';
import Automations from './views/Automations';
import CreateAutomationIA from './views/CreateAutomationIA';
import ExecutionMonitor from './views/ExecutionMonitor';
import Templates from './views/Templates';
import Workflows from './views/Workflows';
import Admin from './views/Admin';
import Credentials from './views/Credentials';
import Settings from './views/Settings';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('LOGIN');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  if (currentView === 'LOGIN') {
    return <Login onLogin={() => setCurrentView('DASHBOARD')} />;
  }

  const renderView = () => {
    switch (currentView) {
      case 'DASHBOARD': return <Dashboard onNavigate={setCurrentView} />;
      case 'AUTOMATIONS': return <Automations onNavigate={setCurrentView} />;
      case 'CREATE_AI': return <CreateAutomationIA />;
      case 'MONITOR': return <ExecutionMonitor />;
      case 'TEMPLATES': return <Templates />;
      case 'WORKFLOWS': return <Workflows onNavigate={setCurrentView} />;
      case 'CREDENTIALS': return <Credentials onNavigate={setCurrentView} />;
      case 'ADMIN': return <Admin />;
      case 'SETTINGS': return <Settings />;
      default: return <Dashboard onNavigate={setCurrentView} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-black text-zinc-100 selection:bg-[#d4af37] selection:text-black font-sans">
      <Sidebar 
        currentView={currentView} 
        setCurrentView={setCurrentView} 
        isOpen={isSidebarOpen} 
        toggle={() => setIsSidebarOpen(!isSidebarOpen)} 
      />
      
      <main className={`flex-1 transition-all duration-300 ${isSidebarOpen ? 'pl-64' : 'pl-20'}`}>
        <header className="h-16 border-b border-zinc-900 bg-[#050505]/80 backdrop-blur-md sticky top-0 z-40 flex items-center justify-between px-8">
          <div className="flex items-center gap-4">
             {/* Breadcrumbs or Title could go here */}
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
               <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]"></span>
               <span className="text-xs font-medium text-zinc-400">System Online</span>
            </div>
            <div className="h-6 w-px bg-zinc-800"></div>
            <button 
              onClick={() => setCurrentView('SETTINGS')}
              className="w-8 h-8 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-xs font-bold text-zinc-300 hover:border-[#d4af37] hover:text-[#d4af37] transition-all"
            >
              RS
            </button>
          </div>
        </header>
        
        <div className="p-6 max-w-[1600px] mx-auto w-full">
          {renderView()}
        </div>
      </main>
    </div>
  );
};

export default App;
