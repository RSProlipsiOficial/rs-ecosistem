
export type AutomationStatus = 'active' | 'inactive';
export type AutomationType = 'WhatsApp' | 'Payment' | 'CRM' | 'System';

export interface Automation {
  id: string;
  name: string;
  type: AutomationType;
  status: AutomationStatus;
  lastRun?: string;
  tenant_id?: string;
  n8n_workflow_id?: string;
  created_at?: string;
  workflow_json?: string;
}

export interface ExecutionRecord {
  id: string;
  automation_id: string;
  automation_name: string;
  status: 'success' | 'error';
  started_at: string;
  duration_ms: number;
  error_details?: string;
  payload_in?: Record<string, any>;
  payload_out?: Record<string, any>;
}

export interface Template {
  id: string;
  name: string;
  category: string;
  description: string;
  connectors: string[];
  complexity: 'Básico' | 'Intermediário' | 'Avançado';
  configSchema: Record<string, any>; // JSON Schema for form generation
}

export interface Credential {
  id: string;
  name: string;
  provider: string;
  key_hint: string; // e.g., "sk_live_...1234"
  created_at: string;
}

// Service Interfaces (Ports)
export interface IAutomationService {
  list(tenantId: string): Promise<Automation[]>;
  get(id: string): Promise<Automation>;
  create(data: Partial<Automation>): Promise<Automation>;
  update(id: string, data: Partial<Automation>): Promise<Automation>;
  delete(id: string): Promise<void>;
  toggleStatus(id: string, status: AutomationStatus): Promise<void>;
}

export interface IExecutionService {
  list(filters?: any): Promise<ExecutionRecord[]>;
  getLogs(executionId: string): Promise<string[]>;
}
