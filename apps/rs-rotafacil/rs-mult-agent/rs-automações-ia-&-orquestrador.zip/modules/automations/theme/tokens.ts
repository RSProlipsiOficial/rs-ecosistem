
export const tokens = {
  colors: {
    brand: {
      primary: '#d4af37', // Gold
      secondary: '#b8860b', // Dark Gold
      light: '#f9e29c', // Light Gold
      gradient: 'linear-gradient(135deg, #d4af37 0%, #f9e29c 50%, #b8860b 100%)',
    },
    background: {
      main: '#000000',
      surface: '#09090b',
      surfaceHover: '#18181b',
      overlay: 'rgba(0, 0, 0, 0.8)',
    },
    text: {
      primary: '#ffffff',
      secondary: '#a1a1aa', // zinc-400
      muted: '#52525b', // zinc-600
      accent: '#d4af37',
    },
    status: {
      success: '#10b981', // emerald-500
      error: '#ef4444', // red-500
      warning: '#f59e0b', // amber-500
      info: '#3b82f6', // blue-500
    },
    border: {
      default: '#27272a', // zinc-800
      active: '#d4af37',
    }
  },
  spacing: {
    sidebar: {
      expanded: '16rem', // 64
      collapsed: '5rem', // 20
    },
    header: '4rem', // 16
  },
  borderRadius: {
    card: '0.75rem', // xl
    button: '0.5rem', // lg
  }
};
