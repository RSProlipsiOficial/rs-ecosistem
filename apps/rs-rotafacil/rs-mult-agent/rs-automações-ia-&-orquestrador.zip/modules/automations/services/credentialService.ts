
import { api } from './apiClient';
import { Credential } from '../types';

export const credentialService = {
  async list(): Promise<Credential[]> {
    return api.get<Credential[]>('/credentials');
  },

  async create(data: Partial<Credential>): Promise<Credential> {
    return api.post<Credential>('/credentials', data);
  },

  async update(id: string, data: Partial<Credential>): Promise<Credential> {
    return api.put<Credential>(`/credentials/${id}`, data);
  },

  async delete(id: string): Promise<void> {
    return api.delete<void>(`/credentials/${id}`);
  }
};
