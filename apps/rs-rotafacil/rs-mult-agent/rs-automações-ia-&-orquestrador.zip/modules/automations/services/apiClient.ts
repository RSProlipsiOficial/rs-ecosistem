
interface RequestConfig extends RequestInit {
  params?: Record<string, string>;
}

class ApiClient {
  private baseURL: string;
  private headers: HeadersInit;

  constructor(baseURL: string) {
    this.baseURL = baseURL;
    this.headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
  }

  private getUrl(endpoint: string, params?: Record<string, string>): string {
    const url = new URL(`${this.baseURL}${endpoint}`);
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value) url.searchParams.append(key, value);
      });
    }
    return url.toString();
  }

  // Interceptor logic for Auth
  private async request<T>(endpoint: string, config: RequestConfig = {}): Promise<T> {
    const token = localStorage.getItem('auth_token'); // Or get from store/context
    
    const headers = {
      ...this.headers,
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...config.headers,
    };

    try {
      const response = await fetch(this.getUrl(endpoint, config.params), {
        ...config,
        headers,
      });

      if (!response.ok) {
        // Handle 401, 403, etc.
        const errorBody = await response.json().catch(() => ({}));
        throw new Error(errorBody.message || `API Error: ${response.status}`);
      }

      return await response.json() as T;
    } catch (error) {
      console.error('[API Client Error]', error);
      throw error;
    }
  }

  public get<T>(endpoint: string, params?: Record<string, string>) {
    return this.request<T>(endpoint, { method: 'GET', params });
  }

  public post<T>(endpoint: string, body: any) {
    return this.request<T>(endpoint, { method: 'POST', body: JSON.stringify(body) });
  }

  public put<T>(endpoint: string, body: any) {
    return this.request<T>(endpoint, { method: 'PUT', body: JSON.stringify(body) });
  }

  public delete<T>(endpoint: string) {
    return this.request<T>(endpoint, { method: 'DELETE' });
  }
}

// Export singleton instance based on ENV
export const api = new ApiClient(process.env.NEXT_PUBLIC_API_URL || (import.meta as any).env?.VITE_API_URL || 'http://localhost:3000/api');
