
import { api } from './apiClient';
import { IAutomationService, Automation, AutomationStatus } from '../types';

export const automationService: IAutomationService = {
  async list(tenantId: string) {
    // GET /automations?tenant_id=...
    return api.get<Automation[]>('/automations', { tenant_id: tenantId });
  },

  async get(id: string) {
    return api.get<Automation>(`/automations/${id}`);
  },

  async create(data: Partial<Automation>) {
    return api.post<Automation>('/automations', data);
  },

  async update(id: string, data: Partial<Automation>) {
    return api.put<Automation>(`/automations/${id}`, data);
  },

  async delete(id: string) {
    return api.delete<void>(`/automations/${id}`);
  },

  async toggleStatus(id: string, status: AutomationStatus) {
    // Specific endpoint for state change might trigger n8n hooks on backend
    return api.post<void>(`/automations/${id}/${status === 'active' ? 'activate' : 'deactivate'}`, {});
  }
};
