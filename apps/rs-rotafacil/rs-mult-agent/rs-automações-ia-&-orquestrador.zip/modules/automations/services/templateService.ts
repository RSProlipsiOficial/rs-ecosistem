
import { api } from './apiClient';
import { Template } from '../types';

export const templateService = {
  async list(category?: string): Promise<Template[]> {
    return api.get<Template[]>('/templates', category ? { category } : undefined);
  },

  async get(id: string): Promise<Template> {
    return api.get<Template>(`/templates/${id}`);
  },

  async install(templateId: string, config: Record<string, any>): Promise<{ workflowId: string }> {
    return api.post(`/templates/${templateId}/install`, config);
  }
};
