
import { api } from './apiClient';
import { ExecutionRecord } from '../types';

export const executionService = {
  async list(filters?: { status?: string; date?: string; search?: string }): Promise<ExecutionRecord[]> {
    return api.get<ExecutionRecord[]>('/executions', filters as any);
  },

  async getLogs(executionId: string): Promise<string[]> {
    return api.get<string[]>(`/executions/${executionId}/logs`);
  },

  async getStats(): Promise<{ active: number; execsToday: number; failures: number; messages: number }> {
    return api.get('/stats/summary');
  }
};
