
import React, { Suspense } from 'react';
import { Loader2 } from 'lucide-react';

// Lazy load pages to split bundles
const Dashboard = React.lazy(() => import('../../views/Dashboard'));
const AutomationsList = React.lazy(() => import('../../views/Automations'));
const CreateAI = React.lazy(() => import('../../views/CreateAutomationIA'));
const Monitor = React.lazy(() => import('../../views/ExecutionMonitor'));
const Workflows = React.lazy(() => import('../../views/Workflows'));

// Loading Fallback
const Loading = () => (
  <div className="flex items-center justify-center h-full w-full min-h-[400px]">
    <Loader2 className="animate-spin text-[#d4af37]" size={32} />
  </div>
);

export const AutomationRoutes = [
  {
    path: '/dashboard',
    element: <Suspense fallback={<Loading />}><Dashboard /></Suspense>,
    title: 'Dashboard'
  },
  {
    path: '/automations',
    element: <Suspense fallback={<Loading />}><AutomationsList /></Suspense>,
    title: 'Minhas Automações'
  },
  {
    path: '/automations/new',
    element: <Suspense fallback={<Loading />}><CreateAI /></Suspense>,
    title: 'Criar com IA'
  },
  {
    path: '/monitor',
    element: <Suspense fallback={<Loading />}><Monitor /></Suspense>,
    title: 'Monitor de Execuções'
  },
  {
    path: '/workflows/:id?',
    element: <Suspense fallback={<Loading />}><Workflows /></Suspense>,
    title: 'Editor de Workflow'
  }
];
