
import React from 'react';
import { 
  LayoutDashboard, 
  Zap, 
  PlusCircle, 
  Activity, 
  Layers, 
  FileCode, 
  Key, 
  ShieldCheck, 
  Settings,
  ChevronLeft,
  ChevronRight,
  LogOut
} from 'lucide-react';
import { ViewState } from '../types';

interface SidebarProps {
  currentView: ViewState;
  setCurrentView: (view: ViewState) => void;
  isOpen: boolean;
  toggle: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView, isOpen, toggle }) => {
  const menuItems = [
    { id: 'DASHBOARD', icon: LayoutDashboard, label: 'Dashboard', group: 'Geral' },
    { id: 'AUTOMATIONS', icon: Zap, label: 'Automações', group: 'Geral' },
    { id: 'CREATE_AI', icon: PlusCircle, label: 'Criar com IA', group: 'Geral' },
    { id: 'MONITOR', icon: Activity, label: 'Monitor', group: 'Geral' },
    { id: 'TEMPLATES', icon: Layers, label: 'Templates', group: 'Orquestrador' },
    { id: 'WORKFLOWS', icon: FileCode, label: 'Workflows', group: 'Orquestrador' },
    { id: 'CREDENTIALS', icon: Key, label: 'Credenciais', group: 'Orquestrador' },
    { id: 'ADMIN', icon: ShieldCheck, label: 'Admin', group: 'Admin' },
    { id: 'SETTINGS', icon: Settings, label: 'Configurações', group: 'Admin' },
  ];

  const groups = ['Geral', 'Orquestrador', 'Admin'];

  return (
    <aside className={`fixed left-0 top-0 h-full bg-[#050505] border-r border-zinc-900 transition-all duration-300 z-50 flex flex-col ${isOpen ? 'w-64' : 'w-20'}`}>
      <div className="h-16 flex items-center px-6 border-b border-zinc-900/50 shrink-0">
        {isOpen ? (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-[#d4af37] to-[#b8860b] rounded-lg flex items-center justify-center shadow-lg shadow-[#d4af37]/10">
               <Zap size={16} className="text-black fill-black" />
            </div>
            <span className="font-bold text-lg tracking-tight text-white">RS AUTO</span>
          </div>
        ) : (
          <div className="w-8 h-8 mx-auto bg-gradient-to-br from-[#d4af37] to-[#b8860b] rounded-lg flex items-center justify-center">
             <Zap size={16} className="text-black fill-black" />
          </div>
        )}
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-6 space-y-8 custom-scrollbar">
        {groups.map(group => (
          <div key={group}>
            {isOpen && <p className="text-[10px] uppercase font-bold text-zinc-600 mb-3 px-3 tracking-widest">{group}</p>}
            <ul className="space-y-1">
              {menuItems.filter(item => item.group === group).map(item => {
                const isActive = currentView === item.id;
                return (
                  <li key={item.id}>
                    <button
                      onClick={() => setCurrentView(item.id as ViewState)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group relative ${
                        isActive 
                          ? 'bg-[#d4af37]/10 text-[#d4af37]' 
                          : 'text-zinc-500 hover:text-zinc-200 hover:bg-zinc-900'
                      }`}
                    >
                      {isActive && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-6 bg-[#d4af37] rounded-r-full"></div>}
                      <item.icon size={18} className={`shrink-0 transition-colors ${isActive ? 'text-[#d4af37]' : 'text-zinc-500 group-hover:text-zinc-300'}`} />
                      {isOpen && <span className="text-sm font-medium tracking-wide">{item.label}</span>}
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      <div className="p-4 border-t border-zinc-900 shrink-0">
        <button
          onClick={toggle}
          className="w-full flex items-center justify-center p-2 rounded-lg text-zinc-600 hover:bg-zinc-900 hover:text-white transition-colors mb-2"
        >
          {isOpen ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
        </button>
        <button
          onClick={() => setCurrentView('LOGIN')}
          className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-red-500/5 transition-colors ${!isOpen && 'justify-center'}`}
        >
          <LogOut size={18} />
          {isOpen && <span className="text-sm font-medium">Sair</span>}
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
