
import React, { useState, useEffect } from 'react';
import { MoreHorizontal, Play, Power, Search, Plus, MessageSquare, CreditCard, Users, Database, Loader2, Clock, Trash2 } from 'lucide-react';
import { Automation } from '../modules/automations/types';
import { ViewState } from '../types';
import { automationService } from '../modules/automations/services/automationService';

const Automations: React.FC<{ onNavigate?: (view: ViewState) => void }> = ({ onNavigate }) => {
  const [automations, setAutomations] = useState<Automation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadAutomations();
  }, []);

  const loadAutomations = async () => {
    setIsLoading(true);
    try {
      const data = await automationService.list('tenant-default');
      setAutomations(data);
    } catch (e) {
      console.error("Failed to load automations in production mode");
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggle = async (id: string, status: 'active' | 'inactive') => {
    setProcessingId(id);
    try {
      const newStatus = status === 'active' ? 'inactive' : 'active';
      await automationService.toggleStatus(id, newStatus);
      setAutomations(prev => prev.map(a => a.id === id ? { ...a, status: newStatus } : a));
    } catch (e) {
      alert("Erro ao alterar status da automação. Verifique a conexão.");
    } finally {
      setProcessingId(null);
    }
  };

  const handleDelete = async (id: string) => {
    if(!confirm("Excluir permanentemente em produção?")) return;
    try {
      await automationService.delete(id);
      setAutomations(prev => prev.filter(a => a.id !== id));
    } catch (e) {
      alert("Falha ao excluir.");
    }
  };

  const filtered = automations.filter(a => a.name.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold text-white">Minhas Automações</h2>
          <p className="text-sm text-zinc-500 mt-1">Ambiente de produção RS Votafone.</p>
        </div>
        <button onClick={() => onNavigate?.('CREATE_AI')} className="gold-gradient text-black px-5 py-2.5 rounded-lg font-bold text-sm flex items-center gap-2">
          <Plus size={16} /> Novo Workflow
        </button>
      </div>

      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input 
          placeholder="Filtrar workflows..." 
          className="w-full bg-[#09090b] border border-zinc-800 rounded-lg py-2.5 pl-10 pr-4 text-sm"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      </div>

      {isLoading ? (
        <div className="py-20 flex justify-center"><Loader2 className="animate-spin text-[#d4af37]" /></div>
      ) : (
        <div className="bg-[#09090b] border border-zinc-800 rounded-xl">
          {filtered.map((auto) => (
            <div key={auto.id} className="p-5 flex items-center justify-between border-b border-zinc-800 last:border-0 hover:bg-zinc-900/40 transition-colors">
              <div className="flex items-center gap-4">
                <div className="p-2.5 bg-zinc-900 border border-zinc-800 rounded-lg">
                  {auto.type === 'WhatsApp' ? <MessageSquare className="text-emerald-500" size={18}/> : <Database className="text-zinc-500" size={18}/>}
                </div>
                <div>
                  <h3 className="font-bold text-zinc-200 text-sm">{auto.name}</h3>
                  <div className="flex items-center gap-3 text-[10px] text-zinc-500 font-mono mt-1">
                    <span>{auto.n8n_workflow_id || 'ID PENDENTE'}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1"><Clock size={10}/> {auto.lastRun || 'Nunca executado'}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                 <div className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${auto.status === 'active' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-zinc-800 text-zinc-500'}`}>
                    {auto.status}
                 </div>
                 <div className="flex gap-1">
                   <button onClick={() => handleToggle(auto.id, auto.status)} className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-400">
                     {processingId === auto.id ? <Loader2 size={16} className="animate-spin"/> : <Power size={16}/>}
                   </button>
                   <button onClick={() => handleDelete(auto.id)} className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-400 hover:text-red-500">
                     <Trash2 size={16}/>
                   </button>
                 </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Automations;
