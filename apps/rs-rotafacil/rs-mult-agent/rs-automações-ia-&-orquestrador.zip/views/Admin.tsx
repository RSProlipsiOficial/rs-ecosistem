
import React, { useState, useEffect, useRef } from 'react';
import { ShieldAlert, Cpu, HardDrive, Database, Server, Activity, Power, RefreshCw, Terminal, CheckCircle2, AlertTriangle, Zap, X, FileText, RotateCcw, Loader2 } from 'lucide-react';

const Admin: React.FC = () => {
  const [cpuUsage, setCpuUsage] = useState(12);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [processingAction, setProcessingAction] = useState<string | null>(null);
  
  const services = [
    { id: 1, name: 'n8n Orchestrator', version: '1.2.0', status: 'running', port: 5678 },
    { id: 2, name: 'PostgreSQL', version: '15.4', status: 'running', port: 5432 },
    { id: 3, name: 'Redis Cache', version: '7.0', status: 'running', port: 6379 },
    { id: 5, name: 'AI Gateway', version: '0.9.1', status: 'warning', port: 8080 },
  ];

  const logs = ["[10:42:01] INFO: System init...", "[10:42:05] INFO: Auth verified.", "[10:42:12] DEBUG: Syncing cluster...", "[10:42:15] INFO: DB Pool stable."];

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
           <h2 className="text-2xl font-bold tracking-tight text-white">Infraestrutura</h2>
           <p className="text-sm text-zinc-500 mt-1 flex items-center gap-2"><ShieldAlert size={14} className="text-red-500"/> Painel de Controle Root</p>
        </div>
        <div className="flex items-center gap-3">
           <span className="px-3 py-1 bg-green-500/10 border border-green-500/20 rounded-lg text-[10px] font-bold text-green-500 uppercase flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span> Sistema Saudável
           </span>
           <button onClick={() => setShowEmergencyModal(true)} className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/20 rounded-lg text-xs font-bold flex items-center gap-2 transition-all">
              <Zap size={14} /> Emergência
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
         {[
           { label: 'CPU', val: cpuUsage, icon: Cpu, color: 'text-[#d4af37]', bar: 'bg-[#d4af37]' },
           { label: 'RAM', val: 34, icon: HardDrive, color: 'text-blue-500', bar: 'bg-blue-500' },
           { label: 'IOPS', val: '842', icon: Database, color: 'text-green-500', bar: 'bg-green-500' },
           { label: 'NET', val: '42 MB/s', icon: Activity, color: 'text-purple-500', bar: 'bg-purple-500' }
         ].map((stat, i) => (
            <div key={i} className="bg-[#09090b] p-5 rounded-xl border border-zinc-800 relative overflow-hidden group">
               <div className={`absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity ${stat.color}`}><stat.icon size={48}/></div>
               <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1">{stat.label}</p>
               <h3 className="text-2xl font-black text-white mb-3">{stat.val}{typeof stat.val === 'number' ? '%' : ''}</h3>
               <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden"><div className={`h-full ${stat.bar}`} style={{ width: typeof stat.val === 'number' ? `${stat.val}%` : '60%' }}></div></div>
            </div>
         ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
         <div className="lg:col-span-2 bg-[#09090b] border border-zinc-800 rounded-xl overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-zinc-800 bg-zinc-900/30 flex justify-between items-center">
               <h3 className="font-bold flex items-center gap-2 text-sm text-zinc-200"><Server size={16} className="text-[#d4af37]" /> Cluster Services</h3>
               <button onClick={() => setIsRefreshing(true)} className="p-1.5 bg-zinc-800 rounded text-zinc-400 hover:text-white"><RefreshCw size={14} className={isRefreshing ? 'animate-spin' : ''}/></button>
            </div>
            <div className="divide-y divide-zinc-800/50">
               {services.map(s => (
                  <div key={s.id} className="p-4 flex items-center justify-between hover:bg-zinc-900/20 transition-colors">
                     <div className="flex items-center gap-3">
                        <div className={`w-2.5 h-2.5 rounded-full ${s.status === 'running' ? 'bg-green-500' : 'bg-orange-500'}`}></div>
                        <div>
                           <div className="flex items-center gap-2"><h4 className="font-bold text-sm text-zinc-200">{s.name}</h4><span className="text-[10px] text-zinc-600 bg-zinc-900 px-1 rounded border border-zinc-800">:{s.port}</span></div>
                           <p className="text-[10px] text-zinc-500">v{s.version}</p>
                        </div>
                     </div>
                     <div className="flex gap-2">
                        <button className="p-1.5 hover:bg-zinc-800 rounded text-zinc-500 hover:text-white"><FileText size={14}/></button>
                        <button className="p-1.5 hover:bg-zinc-800 rounded text-zinc-500 hover:text-[#d4af37]"><RotateCcw size={14}/></button>
                        <button className="p-1.5 hover:bg-zinc-800 rounded text-zinc-500 hover:text-red-500"><Power size={14}/></button>
                     </div>
                  </div>
               ))}
            </div>
         </div>

         <div className="bg-black border border-zinc-800 rounded-xl overflow-hidden flex flex-col h-[400px]">
            <div className="px-4 py-3 bg-zinc-900/50 border-b border-zinc-800 flex items-center gap-2">
               <Terminal size={14} className="text-zinc-500" />
               <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Logs</span>
            </div>
            <div className="flex-1 p-4 font-mono text-[10px] text-zinc-400 overflow-y-auto custom-scrollbar space-y-1 bg-[#050505]">
               {logs.map((log, i) => <div key={i}><span className="text-zinc-600 mr-2">$</span>{log}</div>)}
            </div>
         </div>
      </div>

      {showEmergencyModal && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="bg-[#09090b] w-full max-w-lg rounded-xl border border-zinc-800 shadow-2xl p-6 relative">
             <button onClick={() => setShowEmergencyModal(false)} className="absolute top-4 right-4 text-zinc-500 hover:text-white"><X size={20}/></button>
             <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2"><AlertTriangle size={24} className="text-red-500"/> Zona de Perigo</h3>
             <div className="space-y-3">
                <button disabled={!!processingAction} onClick={() => setProcessingAction('restart')} className="w-full p-4 bg-zinc-900/50 border border-zinc-800 rounded-xl flex items-center gap-4 hover:border-[#d4af37] hover:bg-[#d4af37]/5 transition-all text-left group">
                   <div className="p-2 bg-black rounded-lg text-[#d4af37] group-hover:scale-110 transition-transform border border-zinc-800">{processingAction === 'restart' ? <Loader2 size={20} className="animate-spin"/> : <RefreshCw size={20}/>}</div>
                   <div><h4 className="font-bold text-zinc-200 group-hover:text-[#d4af37]">Reiniciar Cluster</h4><p className="text-[10px] text-zinc-500">Soft restart de todos os serviços</p></div>
                </button>
                <button disabled={!!processingAction} onClick={() => setProcessingAction('shutdown')} className="w-full p-4 bg-zinc-900/50 border border-zinc-800 rounded-xl flex items-center gap-4 hover:border-red-500 hover:bg-red-500/5 transition-all text-left group">
                   <div className="p-2 bg-black rounded-lg text-red-500 group-hover:scale-110 transition-transform border border-zinc-800">{processingAction === 'shutdown' ? <Loader2 size={20} className="animate-spin"/> : <Power size={20}/>}</div>
                   <div><h4 className="font-bold text-zinc-200 group-hover:text-red-500">Shutdown Total</h4><p className="text-[10px] text-zinc-500">Desligamento forçado imediato</p></div>
                </button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Admin;
