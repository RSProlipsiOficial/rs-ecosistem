
import React, { useState, useMemo } from 'react';
import { 
  Key, 
  Plus, 
  RefreshCcw, 
  Search, 
  X, 
  Loader2, 
  MessageSquare, 
  Cpu, 
  Trash2,
  Edit2,
  Eye,
  EyeOff,
  Database,
  Server,
  CreditCard,
  Users
} from 'lucide-react';
import { ViewState } from '../types';

interface CredentialsProps {
  onNavigate?: (view: ViewState) => void;
}

const PROVIDER_CONFIGS: Record<string, { label: string; fields: string[]; icon: any; category: string }> = {
  'Google Gemini': { label: 'Google Gemini AI', fields: ['API Key'], icon: Cpu, category: 'AI' },
  'Evolution API': { label: 'Evolution API', fields: ['Base URL', 'Key'], icon: MessageSquare, category: 'Messaging' },
  'Supabase': { label: 'Supabase', fields: ['URL', 'Anon Key'], icon: Database, category: 'Database' },
  'Stripe': { label: 'Stripe', fields: ['Secret Key'], icon: CreditCard, category: 'Finance' },
};

const Credentials: React.FC<CredentialsProps> = ({ onNavigate }) => {
  const [creds, setCreds] = useState<any[]>([
    { id: 'CR-001', name: 'WhatsApp Produção', provider: 'Evolution API', status: 'connected', type: 'Messaging', lastUsed: '2 min atrás', fields: { 'Base URL': '...' } },
    { id: 'CR-002', name: 'Supabase Main DB', provider: 'Supabase', status: 'connected', type: 'Database', lastUsed: '1 hora atrás', fields: { 'Project URL': '...' } },
    { id: 'CR-003', name: 'Gemini Pro Key', provider: 'Google Gemini', status: 'connected', type: 'AI', lastUsed: 'Agora', fields: { 'API Key': '...' } },
  ]);

  const [isAdding, setIsAdding] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [visibleKeys, setVisibleKeys] = useState<Set<string>>(new Set());
  
  const [newCredName, setNewCredName] = useState('');
  const [selectedProvider, setSelectedProvider] = useState('Google Gemini');
  const [searchTerm, setSearchTerm] = useState('');

  const toggleKey = (id: string) => {
    const next = new Set(visibleKeys);
    if (next.has(id)) next.delete(id); else next.add(id);
    setVisibleKeys(next);
  };

  const filteredCreds = useMemo(() => {
    return creds.filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [creds, searchTerm]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white">Cofre de Credenciais</h2>
          <p className="text-sm text-zinc-500 mt-1">Gerenciamento seguro de chaves API.</p>
        </div>
        <div className="flex gap-3">
          <button onClick={() => setIsSyncing(true)} className="px-4 py-2 border border-zinc-800 text-zinc-400 rounded-lg text-xs font-bold hover:bg-zinc-900 transition-all flex items-center gap-2">
            <RefreshCcw size={14} className={isSyncing ? 'animate-spin' : ''}/> Sync
          </button>
          <button onClick={() => setIsAdding(true)} className="gold-gradient text-black px-5 py-2 rounded-lg font-bold text-xs flex items-center gap-2 hover:opacity-90">
            <Plus size={16} /> Nova Chave
          </button>
        </div>
      </div>

      <div className="relative w-full md:max-w-md">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input 
          type="text" 
          placeholder="Buscar credencial..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-[#09090b] border border-zinc-800 rounded-lg py-2.5 pl-10 pr-4 text-sm focus:outline-none focus:border-zinc-700 transition-colors"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCreds.map((cred) => {
            const ProviderIcon = PROVIDER_CONFIGS[cred.provider]?.icon || Key;
            return (
              <div key={cred.id} className="bg-[#09090b] border border-zinc-800 rounded-xl p-6 hover:border-zinc-700 transition-all group flex flex-col justify-between h-48">
                <div>
                  <div className="flex justify-between items-start mb-4">
                     <div className="p-2 bg-zinc-900 rounded-lg text-zinc-400 group-hover:text-[#d4af37] transition-colors">
                        <ProviderIcon size={20}/>
                     </div>
                     <span className="text-[10px] uppercase font-bold text-zinc-600 bg-zinc-900 px-2 py-1 rounded">{cred.type}</span>
                  </div>
                  <h3 className="font-bold text-zinc-200 mb-1">{cred.name}</h3>
                  <p className="text-xs text-zinc-500">{cred.provider}</p>
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t border-zinc-900">
                   <div className="flex items-center gap-2 text-zinc-500 text-xs font-mono bg-zinc-900/50 px-2 py-1 rounded">
                      <span>{visibleKeys.has(cred.id) ? 'sk_live_...' : '••••••••'}</span>
                      <button onClick={() => toggleKey(cred.id)} className="hover:text-white"><Eye size={12}/></button>
                   </div>
                   <div className="flex gap-2">
                      <button className="text-zinc-600 hover:text-white transition-colors"><Edit2 size={14}/></button>
                      <button className="text-zinc-600 hover:text-red-500 transition-colors"><Trash2 size={14}/></button>
                   </div>
                </div>
              </div>
            );
        })}
      </div>

      {isAdding && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-[150] flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="bg-[#09090b] w-full max-w-md rounded-2xl border border-zinc-800 shadow-2xl p-8">
             <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-white">Nova Conexão</h3>
                <button onClick={() => setIsAdding(false)} className="text-zinc-500 hover:text-white"><X size={20}/></button>
             </div>
             
             <div className="space-y-4 mb-8">
                <div>
                   <label className="text-xs font-bold text-zinc-500 mb-1 block">Nome</label>
                   <input className="w-full bg-black border border-zinc-800 rounded-lg p-3 text-white text-sm" placeholder="Ex: Prod DB" value={newCredName} onChange={e => setNewCredName(e.target.value)} />
                </div>
                <div>
                   <label className="text-xs font-bold text-zinc-500 mb-1 block">Provedor</label>
                   <select className="w-full bg-black border border-zinc-800 rounded-lg p-3 text-white text-sm" value={selectedProvider} onChange={e => setSelectedProvider(e.target.value)}>
                      {Object.keys(PROVIDER_CONFIGS).map(p => <option key={p} value={p}>{p}</option>)}
                   </select>
                </div>
             </div>

             <div className="flex gap-3">
                <button onClick={() => setIsAdding(false)} className="flex-1 py-3 bg-zinc-900 rounded-lg text-sm font-bold text-zinc-400 hover:text-white transition-colors">Cancelar</button>
                <button className="flex-1 py-3 gold-gradient text-black rounded-lg text-sm font-bold hover:opacity-90">Salvar</button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Credentials;
