
import React, { useState, useRef, useEffect } from 'react';
import { Layers, Save, Share2, Loader2, Copy, ExternalLink, History, User, RotateCcw, CheckCircle2, Terminal, Code2, Plus, Minus, Trash2, Settings2, Variable, AlertCircle, Maximize2, X, Play, Move, MousePointer2 } from 'lucide-react';
import { WorkflowVersion, ViewState } from '../types';

// Node Type Definition
interface NodeData {
  id: string;
  type: 'trigger' | 'action' | 'logic';
  x: number;
  y: number;
  label: string;
  subLabel: string;
  icon: any;
}

// Extracted ParamsPanel to prevent re-rendering issues
const ParamsPanel: React.FC<{
  params: { id: number; key: string; value: string }[];
  onUpdate: (id: number, field: 'key' | 'value', val: string) => void;
  onDelete: (id: number) => void;
  newParam: { key: string; value: string };
  onNewParamChange: (val: { key: string; value: string }) => void;
  onAdd: () => void;
}> = ({ params, onUpdate, onDelete, newParam, onNewParamChange, onAdd }) => (
    <div className="flex flex-col h-full">
        <div className="p-4 border-b border-zinc-800 flex items-center gap-2 bg-zinc-900/20 shrink-0">
           <Settings2 size={14} className="text-[#d4af37]" />
           <span className="text-xs font-bold text-white uppercase tracking-wider">Parâmetros</span>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
            <div className="space-y-3">
               {params.map(p => (
                  <div key={p.id} className="group p-3 bg-zinc-900/30 border border-zinc-800 rounded-lg hover:border-zinc-700 transition-colors">
                     <div className="flex justify-between items-center mb-2">
                        <div className="flex items-center gap-1.5 text-zinc-500">
                           <Variable size={12} />
                           <span className="text-[10px] font-bold uppercase">Chave</span>
                        </div>
                        <button onClick={() => onDelete(p.id)} className="text-zinc-600 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"><Trash2 size={12}/></button>
                     </div>
                     <input 
                        value={p.key} 
                        onChange={(e) => onUpdate(p.id, 'key', e.target.value)}
                        className="w-full bg-black border border-zinc-800 rounded px-2 py-1.5 text-xs text-[#d4af37] font-mono mb-2 focus:outline-none focus:border-[#d4af37] transition-colors"
                     />
                     <div className="flex items-center gap-1.5 text-zinc-500 mb-1">
                        <span className="text-[10px] font-bold uppercase">Valor</span>
                     </div>
                     <input 
                        value={p.value} 
                        onChange={(e) => onUpdate(p.id, 'value', e.target.value)}
                        className="w-full bg-black border border-zinc-800 rounded px-2 py-1.5 text-xs text-zinc-300 focus:outline-none focus:border-[#d4af37] transition-colors"
                     />
                  </div>
               ))}
            </div>
            
            <div className="p-3 bg-zinc-900/50 border border-zinc-800 border-dashed rounded-lg shrink-0">
               <p className="text-[10px] font-bold text-zinc-500 uppercase mb-2">Novo Parâmetro</p>
               <input 
                  placeholder="Chave (Ex: api_key)"
                  value={newParam.key}
                  onChange={(e) => onNewParamChange({...newParam, key: e.target.value})}
                  className="w-full bg-black border border-zinc-800 rounded px-2 py-1.5 text-xs text-white mb-2 focus:outline-none focus:border-[#d4af37] placeholder:text-zinc-700 transition-colors"
               />
               <input 
                  placeholder="Valor"
                  value={newParam.value}
                  onChange={(e) => onNewParamChange({...newParam, value: e.target.value})}
                  className="w-full bg-black border border-zinc-800 rounded px-2 py-1.5 text-xs text-white mb-2 focus:outline-none focus:border-[#d4af37] placeholder:text-zinc-700 transition-colors"
               />
               <button 
                  onClick={onAdd}
                  disabled={!newParam.key}
                  className="w-full py-1.5 bg-zinc-800 hover:bg-[#d4af37] text-zinc-400 hover:text-black rounded text-[10px] font-bold uppercase transition-all flex items-center justify-center gap-2 disabled:opacity-50"
               >
                  <Plus size={12} /> Adicionar
               </button>
            </div>
        </div>
    </div>
);

const Workflows: React.FC<{onNavigate?: (view: ViewState) => void}> = ({ onNavigate }) => {
  const [versions, setVersions] = useState<WorkflowVersion[]>([
    { id: 'V-8821', version: 'v4.2.1', createdAt: '24/10/2023 10:20', createdBy: 'Ricardo S.', notes: 'Fix evolution webhook', isActive: true },
    { id: 'V-8740', version: 'v4.2.0', createdAt: '23/10/2023 18:45', createdBy: 'Ricardo S.', notes: 'Supabase dynamic tables', isActive: false },
    { id: 'V-8512', version: 'v4.1.5', createdAt: '20/10/2023 09:15', createdBy: 'Ricardo S.', notes: 'Initial WhatsApp Integration', isActive: false },
  ]);
  const [activeTab, setActiveTab] = useState<'visual' | 'code'>('visual');
  const [isSaving, setIsSaving] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [restoringId, setRestoringId] = useState<string | null>(null);
  const [showToast, setShowToast] = useState<{ message: string, type: 'success' | 'info' } | null>(null);
  
  // --- Fullscreen Editor State ---
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [showFullScreenParams, setShowFullScreenParams] = useState(true);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isTestingFlow, setIsTestingFlow] = useState(false);
  const [isSavingLayout, setIsSavingLayout] = useState(false);
  
  // Interactive Nodes State
  const [nodes, setNodes] = useState<NodeData[]>([
    { id: '1', type: 'trigger', x: 100, y: 250, label: 'Webhook Start', subLabel: 'POST /webhook', icon: Terminal },
    { id: '2', type: 'logic', x: 500, y: 250, label: 'AI Process', subLabel: 'Gemini Flash 1.5', icon: Code2 },
    { id: '3', type: 'action', x: 900, y: 150, label: 'WhatsApp Reply', subLabel: 'Evolution API', icon: Share2 },
    { id: '4', type: 'action', x: 900, y: 350, label: 'Save Database', subLabel: 'Supabase Row', icon: Save }
  ]);

  // Dragging State
  const [isDraggingNode, setIsDraggingNode] = useState<string | null>(null);
  const [isPanning, setIsPanning] = useState(false);
  const [lastMousePos, setLastMousePos] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  // Parameter State
  const [params, setParams] = useState([
    { id: 1, key: 'whatsapp_instance', value: 'inst_01_main' },
    { id: 2, key: 'retry_count', value: '3' },
    { id: 3, key: 'supabase_table', value: 'leads_prod' }
  ]);
  const [newParam, setNewParam] = useState({ key: '', value: '' });

  const triggerToast = (message: string, type: 'success' | 'info' = 'success') => {
    setShowToast({ message, type });
    setTimeout(() => setShowToast(null), 3000);
  };

  const handleSnapshot = () => {
    setIsSaving(true);
    setTimeout(() => {
      const nextVer = `v4.2.${versions.length + 2}`;
      const newVersionId = `V-${Math.floor(Math.random() * 9000) + 1000}`;
      const newVersion: WorkflowVersion = {
        id: newVersionId,
        version: nextVer,
        createdAt: new Date().toLocaleString('pt-BR'),
        createdBy: 'Ricardo S.',
        notes: 'Snapshot manual',
        isActive: true
      };
      
      const updatedVersions = versions.map(v => ({ ...v, isActive: false }));
      setVersions([newVersion, ...updatedVersions]);
      setIsSaving(false);
      triggerToast(`Snapshot ${nextVer} criado e ativado!`);
    }, 1000);
  };

  const handlePublish = () => {
    setIsPublishing(true);
    setTimeout(() => {
      setIsPublishing(false);
      triggerToast("Workflow publicado em produção!", "success");
    }, 1500);
  };

  const handleRestore = (id: string, versionLabel: string) => {
    if(confirm(`Deseja reverter para a versão ${versionLabel}? A versão atual deixará de ser a ativa.`)) {
        setRestoringId(id);
        setTimeout(() => {
            setVersions(prev => prev.map(v => ({
                ...v,
                isActive: v.id === id
            })));
            setRestoringId(null);
            triggerToast(`Sistema revertido para versão ${versionLabel} com sucesso!`, "success");
        }, 1500);
    }
  };

  const handleAddParam = () => {
    if (!newParam.key) return;
    setParams([...params, { id: Date.now(), key: newParam.key, value: newParam.value }]);
    setNewParam({ key: '', value: '' });
    triggerToast("Parâmetro adicionado");
  };

  const handleDeleteParam = (id: number) => {
    setParams(params.filter(p => p.id !== id));
    triggerToast("Parâmetro removido", "info");
  };

  const handleUpdateParam = (id: number, field: 'key' | 'value', val: string) => {
    setParams(params.map(p => p.id === id ? { ...p, [field]: val } : p));
  };

  const handleCopyCode = () => {
     triggerToast("JSON copiado para a área de transferência", "info");
  };

  // --- INTERACTIVE EDITOR LOGIC ---

  const handleMouseDown = (e: React.MouseEvent, nodeId?: string) => {
    e.stopPropagation();
    if (nodeId) {
      setIsDraggingNode(nodeId);
    } else {
      setIsPanning(true);
    }
    setLastMousePos({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    const deltaX = e.clientX - lastMousePos.x;
    const deltaY = e.clientY - lastMousePos.y;
    setLastMousePos({ x: e.clientX, y: e.clientY });

    if (isDraggingNode) {
      setNodes(prev => prev.map(n => {
        if (n.id === isDraggingNode) {
          return { ...n, x: n.x + (deltaX / zoom), y: n.y + (deltaY / zoom) };
        }
        return n;
      }));
    } else if (isPanning) {
      setPan(prev => ({ x: prev.x + deltaX, y: prev.y + deltaY }));
    }
  };

  const handleMouseUp = () => {
    setIsDraggingNode(null);
    setIsPanning(false);
  };

  // Draw Bezier Curves between nodes
  const renderConnections = () => {
    // Logic: Connect 1 -> 2, then 2 -> 3, 2 -> 4 (Simple tree for demo)
    const connections = [
        { from: '1', to: '2' },
        { from: '2', to: '3' },
        { from: '2', to: '4' }
    ];

    return connections.map((conn, i) => {
        const startNode = nodes.find(n => n.id === conn.from);
        const endNode = nodes.find(n => n.id === conn.to);
        if (!startNode || !endNode) return null;

        // Calculate anchors (Right side of start, Left side of end)
        const startX = startNode.x + 240; // Width of node roughly
        const startY = startNode.y + 40;  // Half height roughly
        const endX = endNode.x;
        const endY = endNode.y + 40;

        // Cubic Bezier Control Points
        const cp1x = startX + 80;
        const cp1y = startY;
        const cp2x = endX - 80;
        const cp2y = endY;

        const pathData = `M ${startX} ${startY} C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${endX} ${endY}`;

        return (
            <g key={i}>
                <path d={pathData} stroke="#52525b" strokeWidth="2" fill="none" />
                <circle cx={endX} cy={endY} r="3" fill="#d4af37" />
            </g>
        );
    });
  };

  const handleAutoLayout = () => {
    setNodes([
        { id: '1', type: 'trigger', x: 100, y: 250, label: 'Webhook Start', subLabel: 'POST /webhook', icon: Terminal },
        { id: '2', type: 'logic', x: 500, y: 250, label: 'AI Process', subLabel: 'Gemini Flash 1.5', icon: Code2 },
        { id: '3', type: 'action', x: 900, y: 150, label: 'WhatsApp Reply', subLabel: 'Evolution API', icon: Share2 },
        { id: '4', type: 'action', x: 900, y: 350, label: 'Save Database', subLabel: 'Supabase Row', icon: Save }
    ]);
    setPan({ x: 0, y: 0 });
    setZoom(1);
    triggerToast("Layout resetado para o padrão");
  };

  const handleTestFlow = () => {
    setIsTestingFlow(true);
    setTimeout(() => {
      setIsTestingFlow(false);
      triggerToast("Teste executado com sucesso!", "success");
    }, 2000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20 relative">
      {/* Toast Notification */}
      {showToast && (
        <div className={`fixed top-24 right-8 z-[250] px-6 py-4 rounded-xl shadow-2xl border flex items-center gap-3 animate-in slide-in-from-right duration-300 ${
          showToast.type === 'success' ? 'bg-[#09090b] border-green-500/30 text-green-500' : 'bg-[#09090b] border-blue-500/30 text-blue-500'
        }`}>
          {showToast.type === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          <span className="text-sm font-bold text-white">{showToast.message}</span>
        </div>
      )}

      {/* Full Screen Editor Modal */}
      {isFullScreen && (
        <div className="fixed inset-0 z-[200] bg-[#050505] flex flex-col animate-in zoom-in-95 duration-300">
          <div className="h-16 border-b border-zinc-800 bg-[#09090b] px-6 flex items-center justify-between shadow-md relative z-20">
             <div className="flex items-center gap-3">
                <div className="p-2 bg-[#d4af37]/10 rounded-lg text-[#d4af37]">
                   <Layers size={20} />
                </div>
                <div>
                   <h3 className="font-bold text-white">Editor Visual Fullscreen</h3>
                   <p className="text-xs text-zinc-500 flex items-center gap-2">
                       {isPanning ? 'Movendo Canvas' : isDraggingNode ? 'Movendo Nó' : 'Modo Seleção'}
                   </p>
                </div>
             </div>
             <div className="flex items-center gap-3">
                 <div className="text-xs text-zinc-600 mr-4 font-mono hidden md:block">
                    X: {Math.round(pan.x)} Y: {Math.round(pan.y)} Z: {Math.round(zoom * 100)}%
                 </div>
                 <button 
                    onClick={() => setShowFullScreenParams(!showFullScreenParams)}
                    className={`p-2 rounded-lg transition-colors ${showFullScreenParams ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-white'}`}
                    title="Alternar Painel de Parâmetros"
                 >
                    <Settings2 size={20} />
                 </button>
                 <div className="w-px h-6 bg-zinc-800 mx-1"></div>
                 <button 
                    onClick={() => { setIsSavingLayout(true); setTimeout(() => {setIsSavingLayout(false); triggerToast("Layout Salvo")}, 1000) }}
                    disabled={isSavingLayout}
                    className="px-4 py-2 bg-zinc-900 border border-zinc-800 text-zinc-300 rounded-lg text-xs font-bold hover:text-white transition-all flex items-center gap-2 hover:bg-zinc-800"
                 >
                    {isSavingLayout ? <Loader2 size={16} className="animate-spin"/> : <Save size={16} />} 
                    Salvar Layout
                 </button>
                 <button onClick={() => setIsFullScreen(false)} className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-white transition-colors">
                    <X size={24} />
                 </button>
             </div>
          </div>
          
          <div className="flex-1 relative bg-[#050505] flex overflow-hidden">
             
             {/* Canvas Content */}
             <div 
                className="flex-1 relative overflow-hidden cursor-grab active:cursor-grabbing"
                onMouseDown={(e) => handleMouseDown(e)}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
                style={{ 
                    backgroundPosition: `${pan.x}px ${pan.y}px`,
                    backgroundImage: 'radial-gradient(#27272a 1px, transparent 1px)', 
                    backgroundSize: `${24 * zoom}px ${24 * zoom}px` 
                }}
             >
                 <div 
                    className="origin-top-left"
                    style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})` }}
                 >
                     {/* Connection Lines (SVG Layer) */}
                     <svg className="absolute top-0 left-0 overflow-visible pointer-events-none" style={{ width: '10000px', height: '10000px', zIndex: 0 }}>
                        {renderConnections()}
                     </svg>

                     {/* Nodes */}
                     {nodes.map(node => (
                         <div 
                            key={node.id}
                            onMouseDown={(e) => handleMouseDown(e, node.id)}
                            style={{ left: node.x, top: node.y }}
                            className={`absolute w-60 rounded-xl p-0 shadow-xl cursor-pointer hover:ring-2 hover:ring-[#d4af37]/50 transition-shadow group
                                ${node.type === 'trigger' ? 'bg-zinc-900 border border-emerald-500/30' : 
                                  node.type === 'logic' ? 'bg-zinc-900 border border-[#d4af37]/50 shadow-[0_0_15px_rgba(212,175,55,0.1)]' : 
                                  'bg-zinc-900 border border-blue-500/30'
                                }`}
                         >
                            {/* Header color strip */}
                            <div className={`h-1 w-full rounded-t-xl ${
                                 node.type === 'trigger' ? 'bg-emerald-500' : 
                                 node.type === 'logic' ? 'bg-[#d4af37]' : 
                                 'bg-blue-500'
                            }`}></div>
                            
                            <div className="p-4">
                                <div className="flex items-center gap-3 mb-2">
                                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center 
                                        ${node.type === 'trigger' ? 'bg-emerald-500/10 text-emerald-500' : 
                                          node.type === 'logic' ? 'bg-[#d4af37]/10 text-[#d4af37]' : 
                                          'bg-blue-500/10 text-blue-500'}`}>
                                        <node.icon size={18} />
                                    </div>
                                    <div>
                                        <span className="font-bold text-sm text-white block">{node.label}</span>
                                    </div>
                                </div>
                                <div className="text-[10px] text-zinc-500 font-mono bg-black/40 px-2 py-1 rounded border border-zinc-800/50 flex items-center justify-between">
                                    {node.subLabel}
                                    {node.type === 'logic' && <Move size={10} className="text-zinc-600"/>}
                                </div>
                            </div>

                            {/* IO Handles */}
                            {node.type !== 'trigger' && (
                                <div className="absolute top-1/2 -left-1.5 w-3 h-3 bg-zinc-600 rounded-full border-2 border-[#09090b] hover:bg-white transition-colors"></div>
                            )}
                            <div className="absolute top-1/2 -right-1.5 w-3 h-3 bg-zinc-600 rounded-full border-2 border-[#09090b] hover:bg-[#d4af37] transition-colors"></div>
                         </div>
                     ))}
                 </div>
                 
                 {/* Floating Controls */}
                 <div className="absolute bottom-8 left-1/2 -translate-x-1/2 bg-[#09090b] border border-zinc-800 rounded-full px-6 py-3 flex items-center gap-4 shadow-2xl z-50" onMouseDown={e => e.stopPropagation()}>
                    <button onClick={() => setZoom(z => Math.max(0.4, z - 0.1))} className="p-2 bg-zinc-800 rounded-full hover:bg-zinc-700 text-zinc-400 hover:text-white transition-colors"><Minus size={16}/></button>
                    <span className="text-xs font-mono text-zinc-500 w-12 text-center">{Math.round(zoom * 100)}%</span>
                    <button onClick={() => setZoom(z => Math.min(2, z + 0.1))} className="p-2 bg-zinc-800 rounded-full hover:bg-zinc-700 text-zinc-400 hover:text-white transition-colors"><Plus size={16}/></button>
                    
                    <div className="w-px h-6 bg-zinc-800 mx-2"></div>
                    
                    <button onClick={() => { setZoom(1); setPan({x:0, y:0}); }} className="text-xs font-bold text-zinc-400 hover:text-white transition-colors px-2">Fit View</button>
                    <button onClick={handleAutoLayout} className="text-xs font-bold text-zinc-400 hover:text-white transition-colors px-2">Auto Layout</button>
                    
                    <div className="w-px h-6 bg-zinc-800 mx-2"></div>
                    
                    <button 
                        onClick={handleTestFlow}
                        disabled={isTestingFlow}
                        className="flex items-center gap-2 px-4 py-2 bg-[#d4af37] text-black rounded-full text-xs font-bold hover:opacity-90 active:scale-95 transition-all disabled:opacity-50"
                    >
                        {isTestingFlow ? <Loader2 size={12} className="animate-spin"/> : <Play size={12} fill="currentColor"/>} 
                        {isTestingFlow ? 'Testando...' : 'Testar Fluxo'}
                    </button>
                 </div>
             </div>

             {/* Fullscreen Params Panel */}
             {showFullScreenParams && (
                 <div className="w-80 border-l border-zinc-800 bg-[#09090b] shadow-2xl z-50 animate-in slide-in-from-right duration-300">
                    <ParamsPanel 
                       params={params} 
                       onUpdate={handleUpdateParam} 
                       onDelete={handleDeleteParam}
                       newParam={newParam}
                       onNewParamChange={setNewParam}
                       onAdd={handleAddParam}
                    />
                 </div>
             )}
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white">Editor de Workflows</h2>
          <p className="text-sm text-zinc-500 mt-1">Gerenciamento avançado e versionamento.</p>
        </div>
        <div className="flex gap-3">
           <button 
             disabled={isSaving} 
             onClick={handleSnapshot} 
             className="px-4 py-2.5 bg-zinc-900 border border-zinc-800 text-zinc-300 rounded-lg text-xs font-bold hover:text-white hover:border-zinc-700 transition-all flex items-center gap-2 disabled:opacity-50"
           >
             {isSaving ? <Loader2 size={16} className="animate-spin"/> : <Save size={16}/>} Snapshot
           </button>
           <button 
             onClick={handlePublish}
             disabled={isPublishing}
             className="gold-gradient text-black px-5 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 hover:opacity-90 shadow-lg shadow-[#d4af37]/10 disabled:opacity-70 transition-all"
           >
             {isPublishing ? <Loader2 size={16} className="animate-spin"/> : <Share2 size={16}/>} Publicar
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
         <div className="xl:col-span-9 space-y-6">
            <div className="bg-[#09090b] border border-zinc-800 rounded-xl overflow-hidden flex flex-col h-[600px]">
               <div className="px-6 py-3 border-b border-zinc-800 bg-zinc-900/30 flex justify-between items-center">
                  <div className="flex bg-[#09090b] p-1 rounded-lg border border-zinc-800">
                     <button 
                        onClick={() => setActiveTab('visual')} 
                        className={`px-4 py-1.5 rounded-md text-[11px] font-bold uppercase tracking-wider transition-all flex items-center gap-2 ${activeTab === 'visual' ? 'bg-zinc-800 text-[#d4af37] shadow-sm border border-zinc-700' : 'text-zinc-500 hover:text-zinc-300'}`}
                     >
                        <Layers size={12} /> Visual
                     </button>
                     <button 
                        onClick={() => setActiveTab('code')} 
                        className={`px-4 py-1.5 rounded-md text-[11px] font-bold uppercase tracking-wider transition-all flex items-center gap-2 ${activeTab === 'code' ? 'bg-zinc-800 text-[#d4af37] shadow-sm border border-zinc-700' : 'text-zinc-500 hover:text-zinc-300'}`}
                     >
                        <Code2 size={12} /> Code
                     </button>
                  </div>
                  <div className="flex gap-2 text-zinc-500">
                     <button onClick={handleCopyCode} className="p-2 hover:bg-zinc-800 rounded hover:text-white transition-colors" title="Copiar"><Copy size={16}/></button>
                     <button className="p-2 hover:bg-zinc-800 rounded hover:text-white transition-colors" title="Abrir em nova aba"><ExternalLink size={16}/></button>
                  </div>
               </div>
               
               <div className="flex-1 relative bg-[#050505] flex overflow-hidden">
                  {activeTab === 'visual' ? (
                     <>
                        {/* Canvas Area (Preview Mode) */}
                        <div className="flex-1 relative flex items-center justify-center flex-col gap-6 text-zinc-600 bg-[radial-gradient(#27272a_1px,transparent_1px)] [background-size:16px_16px]">
                            <div className="absolute inset-0 bg-black/40 pointer-events-none"></div>
                            <div className="relative z-10 flex flex-col items-center animate-in zoom-in-95 duration-500">
                                <div className="p-4 rounded-xl border-2 border-dashed border-zinc-800 bg-zinc-900/80 backdrop-blur-sm mb-4 text-center">
                                  <div className="flex justify-center mb-3 text-zinc-500"><MousePointer2 size={32}/></div>
                                  <p className="text-xs font-mono text-zinc-400">Editor Interativo n8n</p>
                                  <p className="text-[10px] text-zinc-600 mt-1">Arraste, conecte e configure nós visualmente.</p>
                                </div>
                                <button 
                                  onClick={() => { setIsFullScreen(true); triggerToast("Modo Fullscreen Ativado - Use mouse para arrastar", "info"); }}
                                  className="text-xs font-bold text-[#d4af37] border border-[#d4af37]/30 px-6 py-2.5 rounded-lg hover:bg-[#d4af37]/10 transition-colors flex items-center gap-2 bg-black/50 hover:scale-105 active:scale-95 shadow-lg shadow-[#d4af37]/5"
                                >
                                  <Maximize2 size={14} /> Abrir Editor Interativo
                                </button>
                            </div>
                        </div>

                        {/* Config Panel */}
                        <div className="w-80 border-l border-zinc-800 bg-[#09090b] flex flex-col">
                           <ParamsPanel 
                              params={params} 
                              onUpdate={handleUpdateParam} 
                              onDelete={handleDeleteParam}
                              newParam={newParam}
                              onNewParamChange={setNewParam}
                              onAdd={handleAddParam}
                           />
                        </div>
                     </>
                  ) : (
                     <pre className="p-6 text-[11px] font-mono text-zinc-400 w-full overflow-auto custom-scrollbar select-text">
{`{
  "name": "My Workflow",
  "nodes": [
    {
      "parameters": {},
      "name": "Start",
      "type": "n8n-nodes-base.start",
      "typeVersion": 1,
      "position": [
        250,
        300
      ]
    },
    {
      "parameters": {
        "url": "https://api.stripe.com/v1/charges",
        "method": "POST"
      },
      "name": "Stripe Trigger",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 2,
      "position": [
        450,
        300
      ]
    }
  ],
  "connections": {}
}`}
                     </pre>
                  )}
               </div>
            </div>
         </div>

         <div className="xl:col-span-3 flex flex-col h-full bg-[#09090b] border border-zinc-800 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-zinc-800 bg-zinc-900/30 font-bold text-xs text-zinc-400 uppercase tracking-wider flex items-center gap-2">
               <History size={14} className="text-[#d4af37]" /> Histórico
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
               {versions.map(v => (
                  <div key={v.id} className={`p-4 rounded-lg border transition-all ${v.isActive ? 'bg-[#d4af37]/5 border-[#d4af37]/30' : 'bg-zinc-900/30 border-zinc-800 hover:border-zinc-700'}`}>
                     <div className="flex justify-between items-center mb-2">
                        <span className={`text-xs font-bold ${v.isActive ? 'text-[#d4af37]' : 'text-zinc-300'}`}>{v.version}</span>
                        {v.isActive && <span className="text-[9px] bg-[#d4af37] text-black px-1.5 py-0.5 rounded font-bold">ATIVO</span>}
                     </div>
                     <p className="text-[10px] text-zinc-500 mb-3 leading-relaxed">{v.notes}</p>
                     <div className="flex justify-between items-center border-t border-zinc-800/50 pt-2 text-[10px] text-zinc-600">
                        <span className="flex items-center gap-1"><User size={10}/> {v.createdBy}</span>
                        {!v.isActive && (
                            <button 
                                onClick={() => handleRestore(v.id, v.version)} 
                                disabled={restoringId === v.id}
                                className="hover:text-[#d4af37] transition-colors flex items-center gap-1 disabled:opacity-50" 
                                title="Restaurar versão"
                            >
                                {restoringId === v.id ? <Loader2 size={12} className="animate-spin"/> : <RotateCcw size={12}/>} Reverter
                            </button>
                        )}
                     </div>
                  </div>
               ))}
            </div>
         </div>
      </div>
    </div>
  );
};

export default Workflows;
