
import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  Play, 
  Settings2, 
  Terminal, 
  CheckCircle2, 
  X, 
  Wand2, 
  Rocket, 
  Loader2, 
  AlertCircle,
  Users,
  MessageCircle,
  Filter,
  Sliders
} from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { n8nService } from '../services/n8nService';
import { supabaseService } from '../services/supabaseService';

const CreateAutomationIA: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedFlow, setGeneratedFlow] = useState<string | null>(null);
  const [isAdjusting, setIsAdjusting] = useState(false);
  const [refinementPrompt, setRefinementPrompt] = useState('');
  const [isRefining, setIsRefining] = useState(false);
  const [isConfiguringRecipients, setIsConfiguringRecipients] = useState(false);
  const [selectedRecipients, setSelectedRecipients] = useState<string[]>([]);
  const [isTesting, setIsTesting] = useState(false);
  const [testStatus, setTestStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [isPublishing, setIsPublishing] = useState(false);
  const [showToast, setShowToast] = useState<{ message: string, type: 'success' | 'error' } | null>(null);
  
  // Param Editor State
  const [isEditingParams, setIsEditingParams] = useState(false);
  const [tempFlow, setTempFlow] = useState<any>(null);

  const examples = [
    "Responder automaticamente no WhatsApp e salvar lead no Supabase",
    "Enviar cobrança via WhatsApp após 3 dias de atraso no Stripe",
    "Notificar time comercial quando um novo lead for cadastrado",
    "Extrair dados de emails e salvar em planilha automaticamente"
  ];

  const triggerToast = (message: string, type: 'success' | 'error' = 'success') => {
    setShowToast({ message, type });
    setTimeout(() => setShowToast(null), 3000);
  };

  const handleGenerate = async () => {
    if (!prompt) return;
    setIsGenerating(true);
    setTestStatus('idle');
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const systemInstruction = "Você é um arquiteto de automações n8n. Gere um JSON estruturado representando um workflow baseado na descrição do usuário. O JSON deve ter as chaves 'name', 'trigger', 'version' e 'workflow' (uma lista de objetos com 'node', 'type' e opcionalmente 'params'). Não inclua markdown na resposta, apenas o JSON puro.";
      const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt, config: { systemInstruction } });
      const text = response.text || "";
      setGeneratedFlow(text.replace(/```json|```/g, "").trim());
    } catch (error) {
      setGeneratedFlow(`{ "name": "Automação WhatsApp & Supabase", "trigger": "WhatsApp Webhook", "version": "v1.0.0-ai-gen", "workflow": [ { "node": "Message Receiver", "type": "webhook" }, { "node": "AI Sentiment Analysis", "type": "gemini-flash" }, { "node": "WhatsApp Reply", "type": "whatsapp", "text": "Olá! Recebemos seu interesse..." } ] }`);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRefine = async () => {
    if (!refinementPrompt || !generatedFlow) return;
    setIsRefining(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const systemInstruction = "Você é um arquiteto de automações n8n. Atualize o workflow JSON baseado no pedido do usuário. Mantenha a estrutura.";
      const combinedPrompt = `Workflow Atual: ${generatedFlow}\n\nInstrução de Ajuste: ${refinementPrompt}`;
      const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: combinedPrompt, config: { systemInstruction } });
      setGeneratedFlow(response.text?.replace(/```json|```/g, "").trim() || generatedFlow);
      setIsAdjusting(false);
      setRefinementPrompt('');
      triggerToast("Automação ajustada com sucesso!");
    } catch (error) {
      triggerToast("Erro ao refinar automação.", "error");
    } finally {
      setIsRefining(false);
    }
  };

  const handleTest = () => {
    setIsTesting(true);
    setTimeout(() => { setIsTesting(false); setTestStatus('success'); triggerToast("Workflow validado com sucesso!"); }, 2500);
  };

  const handlePublish = async () => {
    if (!generatedFlow) return;
    setIsPublishing(true);
    try {
      const parsed = JSON.parse(generatedFlow);
      const n8nWorkflow = await n8nService.createWorkflow(generatedFlow);
      await supabaseService.createAutomation({
        name: parsed.name || "Nova Automação AI",
        type: 'WhatsApp',
        status: 'inactive',
        n8n_workflow_id: n8nWorkflow.id,
        workflow_json: generatedFlow
      });
      triggerToast("Workflow publicado e salvo!");
    } catch (error) {
      triggerToast("Erro ao publicar.", "error");
    } finally {
      setIsPublishing(false);
    }
  };

  // --- Param Editor Functions ---

  const openParamsEditor = () => {
    if (generatedFlow) {
      try {
        setTempFlow(JSON.parse(generatedFlow));
        setIsEditingParams(true);
      } catch (e) {
        triggerToast("Erro ao processar JSON.", "error");
      }
    }
  };

  const updateTempFlowRoot = (key: string, value: string) => {
    if (!tempFlow) return;
    setTempFlow({ ...tempFlow, [key]: value });
  };

  const updateTempFlowNode = (idx: number, key: string, value: string) => {
    if (!tempFlow) return;
    const newWorkflow = [...tempFlow.workflow];
    newWorkflow[idx] = { ...newWorkflow[idx], [key]: value };
    setTempFlow({ ...tempFlow, workflow: newWorkflow });
  };

  const updateTempFlowNodeParams = (idx: number, key: string, value: string) => {
    if (!tempFlow) return;
    const newWorkflow = [...tempFlow.workflow];
    newWorkflow[idx] = { 
        ...newWorkflow[idx], 
        params: { ...newWorkflow[idx].params, [key]: value } 
    };
    setTempFlow({ ...tempFlow, workflow: newWorkflow });
  };

  const handleSaveParams = () => {
    setGeneratedFlow(JSON.stringify(tempFlow, null, 2));
    setIsEditingParams(false);
    triggerToast("Parâmetros atualizados!");
  };

  const parsedFlow = generatedFlow ? JSON.parse(generatedFlow) : null;

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500 relative pb-20">
      {showToast && (
        <div className={`fixed bottom-8 right-8 z-[110] px-6 py-4 rounded-xl shadow-2xl border flex items-center gap-3 ${showToast.type === 'success' ? 'bg-[#09090b] border-green-500/30 text-green-500' : 'bg-[#09090b] border-red-500/30 text-red-500'}`}>
          {showToast.type === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          <span className="text-sm font-bold">{showToast.message}</span>
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
         <div>
            <h2 className="text-2xl font-bold tracking-tight text-white">Criar com IA</h2>
            <p className="text-sm text-zinc-500 mt-1">Descreva sua automação e o agente inteligente irá construí-la.</p>
         </div>
         {generatedFlow && (
            <div className="flex gap-3">
               <button onClick={() => setIsAdjusting(true)} className="px-4 py-2 bg-zinc-900 border border-zinc-800 text-zinc-300 rounded-lg text-xs font-bold hover:text-white hover:bg-zinc-800 transition-all flex items-center gap-2">
                  <Settings2 size={16}/> Ajustar
               </button>
               <button onClick={openParamsEditor} className="px-4 py-2 bg-zinc-900 border border-zinc-800 text-zinc-300 rounded-lg text-xs font-bold hover:text-white hover:bg-zinc-800 transition-all flex items-center gap-2">
                  <Sliders size={16}/> Editar Parâmetros
               </button>
               <button onClick={handleTest} className="px-4 py-2 bg-zinc-900 border border-zinc-800 text-zinc-300 rounded-lg text-xs font-bold hover:text-white hover:bg-zinc-800 transition-all flex items-center gap-2">
                  {isTesting ? <Loader2 size={16} className="animate-spin"/> : <Play size={16}/>} Testar
               </button>
               <button onClick={handlePublish} disabled={isPublishing} className="gold-gradient text-black px-6 py-2 rounded-lg font-bold text-xs flex items-center gap-2 hover:opacity-90 shadow-lg shadow-[#d4af37]/10">
                  {isPublishing ? <Loader2 size={16} className="animate-spin"/> : <Rocket size={16}/>} Publicar
               </button>
            </div>
         )}
      </div>

      <div className="bg-[#09090b] border border-zinc-800 rounded-xl p-6 shadow-sm">
        <div className="relative">
          <textarea
            className="w-full bg-transparent border-none text-lg placeholder:text-zinc-600 focus:outline-none min-h-[160px] resize-none pb-12 text-zinc-200"
            placeholder="Ex: Quando um cliente enviar 'quero saber mais' no WhatsApp, analise o perfil dele com IA e agende no Google Calendar..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />
          <div className="absolute bottom-0 right-0">
             <button 
               onClick={handleGenerate}
               disabled={isGenerating || !prompt}
               className="bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 px-4 py-2 rounded-lg font-bold text-xs flex items-center gap-2 disabled:opacity-50 transition-all"
             >
               {isGenerating ? <><Loader2 size={14} className="animate-spin" /> Gerando...</> : <><Sparkles size={14} /> Gerar Workflow</>}
             </button>
          </div>
        </div>
        <div className="mt-6 pt-6 border-t border-zinc-800/50">
          <div className="flex flex-wrap gap-2">
            {examples.map((ex, i) => (
              <button key={i} onClick={() => setPrompt(ex)} className="text-[11px] bg-zinc-900/50 hover:bg-zinc-900 border border-zinc-800 text-zinc-500 hover:text-zinc-300 px-3 py-1.5 rounded-full transition-all">
                {ex}
              </button>
            ))}
          </div>
        </div>
      </div>

      {generatedFlow && parsedFlow && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="bg-[#09090b] border border-zinc-800 rounded-xl p-6 flex flex-col h-[400px]">
             <div className="flex items-center justify-between mb-4 pb-2 border-b border-zinc-800">
                <div className="flex items-center gap-2 text-xs font-bold text-zinc-400 uppercase tracking-wider">
                   <Terminal size={14} /> Definição JSON
                </div>
                <button onClick={() => navigator.clipboard.writeText(generatedFlow)} className="text-[10px] text-[#d4af37] font-bold hover:underline">Copiar</button>
             </div>
             <pre className="flex-1 overflow-auto text-[11px] font-mono text-zinc-500 leading-relaxed custom-scrollbar bg-black/30 p-4 rounded-lg border border-zinc-800/50">{generatedFlow}</pre>
          </div>

          <div className="bg-[#09090b] border border-zinc-800 rounded-xl p-6 flex flex-col h-[400px] relative overflow-hidden">
             <div className="absolute top-0 right-0 w-64 h-64 bg-[#d4af37]/5 rounded-full blur-[80px]"></div>
             <div className="flex items-center gap-2 text-xs font-bold text-zinc-400 uppercase tracking-wider mb-6 relative z-10">
                <Wand2 size={14} className="text-[#d4af37]" /> Visual Preview
             </div>
             <div className="space-y-3 relative z-10 overflow-y-auto custom-scrollbar pr-2">
                {parsedFlow.workflow.map((node: any, i: number) => (
                  <div key={i} className="flex flex-col items-center">
                    <div className="w-full bg-zinc-900/80 p-3 rounded-lg border border-zinc-800 flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${node.type.includes('whatsapp') ? 'bg-green-500/10 text-green-500' : 'bg-zinc-800 text-zinc-400'}`}>
                        {node.type.includes('whatsapp') ? <MessageCircle size={14} /> : i + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-zinc-200 truncate">{node.node}</p>
                        <p className="text-[10px] text-zinc-500 uppercase truncate">{node.type}</p>
                      </div>
                    </div>
                    {i < parsedFlow.workflow.length - 1 && <div className="w-px h-3 bg-zinc-800 my-1"></div>}
                  </div>
                ))}
             </div>
          </div>
        </div>
      )}

      {/* Adjust Modal */}
      {isAdjusting && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="bg-[#09090b] w-full max-w-lg rounded-xl border border-zinc-800 shadow-2xl p-6 animate-in zoom-in-95 duration-300">
             <div className="flex justify-between items-center mb-6">
               <h3 className="text-lg font-bold text-white">Refinar Automação</h3>
               <button onClick={() => setIsAdjusting(false)} className="text-zinc-500 hover:text-white"><X size={18} /></button>
             </div>
             <textarea 
                className="w-full bg-black border border-zinc-800 rounded-lg p-4 text-sm text-white focus:outline-none focus:border-[#d4af37] transition-colors min-h-[120px] resize-none mb-6"
                placeholder="Descreva a alteração desejada..."
                value={refinementPrompt}
                onChange={(e) => setRefinementPrompt(e.target.value)}
              />
             <div className="flex gap-3">
                <button onClick={() => setIsAdjusting(false)} className="flex-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 py-2.5 rounded-lg font-bold text-xs transition-all">Cancelar</button>
                <button onClick={handleRefine} disabled={isRefining || !refinementPrompt} className="flex-1 gold-gradient text-black py-2.5 rounded-lg font-bold text-xs flex items-center justify-center gap-2 hover:opacity-90 transition-all disabled:opacity-50">
                  {isRefining ? <Loader2 size={14} className="animate-spin" /> : 'Aplicar Ajuste'}
                </button>
              </div>
          </div>
        </div>
      )}

      {/* Param Editor Modal */}
      {isEditingParams && tempFlow && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="bg-[#09090b] w-full max-w-2xl rounded-xl border border-zinc-800 shadow-2xl p-6 animate-in zoom-in-95 duration-300 flex flex-col max-h-[90vh]">
              <div className="flex justify-between items-center mb-6 border-b border-zinc-800 pb-4">
                <div>
                   <h3 className="text-lg font-bold text-white">Configuração de Parâmetros</h3>
                   <p className="text-xs text-zinc-500">Edite os valores técnicos dos nós do workflow.</p>
                </div>
                <button onClick={() => setIsEditingParams(false)} className="text-zinc-500 hover:text-white"><X size={18} /></button>
              </div>
              
              <div className="flex-1 overflow-y-auto custom-scrollbar space-y-6 pr-2">
                  {/* Global Settings */}
                  <div className="space-y-3">
                     <h4 className="text-xs font-bold text-[#d4af37] uppercase tracking-wider">Metadados</h4>
                     <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                           <label className="text-[10px] font-bold text-zinc-500 uppercase">Nome da Automação</label>
                           <input 
                              className="w-full bg-black border border-zinc-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-[#d4af37] transition-colors"
                              value={tempFlow?.name || ''}
                              onChange={(e) => updateTempFlowRoot('name', e.target.value)}
                           />
                        </div>
                         <div className="space-y-1">
                           <label className="text-[10px] font-bold text-zinc-500 uppercase">Gatilho (Trigger)</label>
                           <input 
                              className="w-full bg-black border border-zinc-800 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-[#d4af37] transition-colors"
                              value={tempFlow?.trigger || ''}
                              onChange={(e) => updateTempFlowRoot('trigger', e.target.value)}
                           />
                        </div>
                     </div>
                  </div>

                  <div className="border-t border-zinc-800 my-4"></div>

                  {/* Nodes */}
                  <div className="space-y-4">
                     <h4 className="text-xs font-bold text-[#d4af37] uppercase tracking-wider">Nós do Workflow</h4>
                     {tempFlow?.workflow?.map((node: any, idx: number) => (
                        <div key={idx} className="bg-zinc-900/30 border border-zinc-800 rounded-xl p-4">
                            <div className="flex items-center gap-2 mb-3">
                               <div className="w-6 h-6 rounded bg-zinc-800 flex items-center justify-center text-[10px] font-bold text-zinc-500">{idx + 1}</div>
                               <span className="text-sm font-bold text-zinc-200">{node.node}</span>
                               <span className="text-[10px] bg-zinc-800 text-zinc-500 px-2 py-0.5 rounded-full">{node.type}</span>
                            </div>
                            
                            <div className="grid grid-cols-1 gap-3 pl-8">
                                {/* Direct properties that are not node/type */}
                                {Object.keys(node).filter(k => !['node', 'type', 'params'].includes(k)).map(key => (
                                    <div key={key} className="space-y-1">
                                       <label className="text-[10px] font-bold text-zinc-500 uppercase">{key}</label>
                                       <input 
                                          className="w-full bg-black border border-zinc-800 rounded-lg p-2 text-sm text-zinc-300 focus:outline-none focus:border-[#d4af37] transition-colors"
                                          value={node[key]}
                                          onChange={(e) => updateTempFlowNode(idx, key, e.target.value)}
                                       />
                                    </div>
                                ))}
                                {/* Nested params object */}
                                {node.params && Object.keys(node.params).map(key => (
                                    <div key={key} className="space-y-1">
                                       <label className="text-[10px] font-bold text-zinc-500 uppercase">params.{key}</label>
                                       <input 
                                          className="w-full bg-black border border-zinc-800 rounded-lg p-2 text-sm text-zinc-300 focus:outline-none focus:border-[#d4af37] transition-colors"
                                          value={node.params[key]}
                                          onChange={(e) => updateTempFlowNodeParams(idx, key, e.target.value)}
                                       />
                                    </div>
                                ))}
                                {Object.keys(node).filter(k => !['node', 'type'].includes(k)).length === 0 && (!node.params || Object.keys(node.params).length === 0) && (
                                    <p className="text-xs text-zinc-600 italic">Nenhum parâmetro editável.</p>
                                )}
                            </div>
                        </div>
                     ))}
                  </div>
              </div>

              <div className="flex gap-3 mt-6 pt-4 border-t border-zinc-800">
                 <button onClick={() => setIsEditingParams(false)} className="flex-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 py-2.5 rounded-lg font-bold text-xs transition-all">Cancelar</button>
                 <button onClick={handleSaveParams} className="flex-1 gold-gradient text-black py-2.5 rounded-lg font-bold text-xs flex items-center justify-center gap-2 hover:opacity-90 transition-all">
                   Salvar Alterações
                 </button>
              </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CreateAutomationIA;
