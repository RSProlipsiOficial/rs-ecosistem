
import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { 
  Activity, 
  Zap, 
  AlertCircle, 
  MessageSquare, 
  ArrowUpRight, 
  ArrowDownRight, 
  Sparkles,
  RefreshCw,
  Terminal,
  ShieldCheck,
  ChevronRight,
  Loader2
} from 'lucide-react';
import { ViewState } from '../types';
import { GoogleGenAI } from '@google/genai';
import { executionService } from '../modules/automations/services/executionService';

const dataInitial = [
  { name: 'Seg', execs: 400 },
  { name: 'Ter', execs: 700 },
  { name: 'Qua', execs: 1200 },
  { name: 'Qui', execs: 900 },
  { name: 'Sex', execs: 1500 },
  { name: 'Sáb', execs: 800 },
  { name: 'Dom', execs: 600 },
];

const StatCard = ({ title, value, icon: Icon, trend, trendValue, onClick }: any) => (
  <div 
    onClick={onClick}
    className="bg-[#09090b] p-6 rounded-xl border border-zinc-800 hover:border-zinc-700 transition-all cursor-pointer group"
  >
    <div className="flex justify-between items-start mb-4">
      <div className="p-2.5 bg-zinc-900 rounded-lg text-zinc-400 group-hover:text-[#d4af37] transition-colors">
        <Icon size={20} />
      </div>
      {trend && (
        <div className={`flex items-center gap-1 text-xs font-medium ${trend === 'up' ? 'text-emerald-500' : 'text-red-500'}`}>
          {trend === 'up' ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
          {trendValue}
        </div>
      )}
    </div>
    <div className="space-y-1">
      <h3 className="text-2xl font-bold text-white tabular-nums tracking-tight">
        {typeof value === 'number' ? value.toLocaleString() : value}
      </h3>
      <p className="text-zinc-500 text-sm">{title}</p>
    </div>
  </div>
);

const Dashboard: React.FC<{ onNavigate?: (view: ViewState) => void }> = ({ onNavigate }) => {
  const [stats, setStats] = useState({ active: 0, execsToday: 0, failures: 0, messages: 0 });
  const [isLoading, setIsLoading] = useState(true);
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const [isGeneratingInsight, setIsGeneratingInsight] = useState(false);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        const summary = await executionService.getStats();
        setStats(summary);
      } catch (error) {
        console.error("Dashboard production error", error);
      } finally {
        setIsLoading(false);
      }
    };
    loadDashboardData();
  }, []);

  const generateAIInsight = async () => {
    setIsGeneratingInsight(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const prompt = `Como um consultor sênior de automações, analise estes dados: ${stats.active} ativas, ${stats.execsToday} execs hoje, ${stats.failures} falhas. Dê um insight curto estratégico (máximo 2 frases).`;
      const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
      setAiInsight(response.text);
    } catch (error) {
      setAiInsight("Analise de tráfego estável. Otimize os fluxos de WhatsApp para converter leads pendentes.");
    } finally {
      setIsGeneratingInsight(false);
    }
  };

  if (isLoading) return (
    <div className="h-[60vh] flex flex-col items-center justify-center gap-4">
      <Loader2 className="animate-spin text-[#d4af37]" size={40} />
      <p className="text-zinc-500 text-sm font-bold uppercase tracking-widest">Sincronizando Dados em Tempo Real...</p>
    </div>
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white">Dashboard</h2>
          <p className="text-sm text-zinc-500 mt-1">Dados consolidados do ambiente de produção.</p>
        </div>
        <button onClick={generateAIInsight} disabled={isGeneratingInsight} className="flex items-center gap-2 text-xs font-bold text-[#d4af37] hover:text-white transition-colors">
          {isGeneratingInsight ? <RefreshCw size={14} className="animate-spin"/> : <Sparkles size={14}/>}
          Insight com IA
        </button>
      </div>

      {(aiInsight || isGeneratingInsight) && (
        <div className="bg-[#09090b] border-l-2 border-[#d4af37] rounded-r-xl p-4 flex items-start gap-4">
           <Sparkles size={16} className="text-[#d4af37] shrink-0 mt-1" />
           <p className="text-sm text-zinc-300 italic">{aiInsight || "Analisando telemetria..."}</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Automações Ativas" value={stats.active} icon={Zap} trend="up" trendValue="+2" onClick={() => onNavigate?.('AUTOMATIONS')} />
        <StatCard title="Execuções Hoje" value={stats.execsToday} icon={Activity} trend="up" trendValue="15%" onClick={() => onNavigate?.('MONITOR')} />
        <StatCard title="Falhas (24h)" value={stats.failures} icon={AlertCircle} trend="down" trendValue="-5%" onClick={() => onNavigate?.('MONITOR')} />
        <StatCard title="Mensagens Processadas" value={stats.messages} icon={MessageSquare} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#09090b] p-6 rounded-xl border border-zinc-800 h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={dataInitial}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#27272a" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#71717a', fontSize: 11}} />
              <YAxis axisLine={false} tickLine={false} tick={{fill: '#71717a', fontSize: 11}} />
              <Tooltip contentStyle={{backgroundColor: '#09090b', border: '1px solid #27272a'}} />
              <Area type="monotone" dataKey="execs" stroke="#d4af37" fill="#d4af371a" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-[#09090b] border border-zinc-800 rounded-xl p-6 flex flex-col items-center justify-center text-center gap-4">
           <div className="p-4 bg-[#d4af37]/10 rounded-full"><ShieldCheck size={40} className="text-[#d4af37]" /></div>
           <h4 className="font-bold text-white uppercase tracking-tighter">Sistema Protegido</h4>
           <p className="text-xs text-zinc-500">Monitoramento 24/7 ativo. Backups sincronizados via RS Votafone Cloud.</p>
           <button onClick={() => onNavigate?.('ADMIN')} className="text-xs font-bold text-[#d4af37] hover:underline">Ver Infraestrutura</button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
