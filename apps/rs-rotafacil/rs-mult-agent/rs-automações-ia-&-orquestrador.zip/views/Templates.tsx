
import React, { useState, useMemo } from 'react';
import { Layers, Download, ExternalLink, Search, CheckCircle2, X, Loader2, ArrowRight, Settings, FileText, Code, Box } from 'lucide-react';

const templates = [
  { 
    id: '1', name: 'Atendimento WhatsApp + IA', category: 'WhatsApp', complexity: 'Intermediário',
    description: 'Fluxo inteligente que utiliza Gemini 1.5 Flash para responder dúvidas frequentes e triagem inicial.',
    connectors: ['WhatsApp', 'Gemini', 'n8n'],
    configFields: [{ label: 'Número da Instância', name: 'whatsapp_instance', type: 'text', placeholder: 'Ex: instance_01' }]
  },
  { 
    id: '2', name: 'Recuperação de Carrinho', category: 'Financeiro', complexity: 'Avançado',
    description: 'Identifica abandonos e dispara sequências de mensagens personalizadas.',
    connectors: ['Stripe', 'WhatsApp'],
    configFields: [{ label: 'Stripe Secret', name: 'stripe_secret', type: 'password', placeholder: 'whsec_...' }]
  },
  { 
    id: '3', name: 'Backup de Leads Supabase', category: 'CRM', complexity: 'Básico',
    description: 'Sincronização em tempo real de novos contatos capturados.',
    connectors: ['Supabase', 'n8n'],
    configFields: [{ label: 'Supabase URL', name: 'supabase_url', type: 'text', placeholder: 'https://...' }]
  },
  { 
    id: '4', name: 'Alertas via Telegram', category: 'Sistema', complexity: 'Básico',
    description: 'Monitora a saúde de seus workflows e envia alertas imediatos.',
    connectors: ['Telegram', 'System'],
    configFields: [{ label: 'Bot Token', name: 'bot_token', type: 'password', placeholder: 'Token...' }]
  },
];

const Templates: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [selectedTemplate, setSelectedTemplate] = useState<any | null>(null);
  const [installStep, setInstallStep] = useState<'config' | 'loading' | 'success'>('config');

  const filtered = useMemo(() => templates.filter(t => 
    (selectedCategory === 'Todos' || t.category === selectedCategory) && 
    (t.name.toLowerCase().includes(searchTerm.toLowerCase()) || t.description.toLowerCase().includes(searchTerm.toLowerCase()))
  ), [searchTerm, selectedCategory]);

  const handleInstall = () => {
    setInstallStep('loading');
    setTimeout(() => setInstallStep('success'), 2000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white">Templates</h2>
          <p className="text-sm text-zinc-500 mt-1">Acelere com estruturas pré-moldadas.</p>
        </div>
        <div className="flex bg-[#09090b] p-1 rounded-lg border border-zinc-800">
          {['Todos', 'WhatsApp', 'CRM', 'Financeiro', 'Sistema'].map(cat => (
            <button 
              key={cat} 
              onClick={() => setSelectedCategory(cat)} 
              className={`px-4 py-1.5 rounded-md text-[11px] font-bold uppercase tracking-wider transition-all ${
                selectedCategory === cat 
                 ? 'bg-zinc-800 text-[#d4af37] shadow-sm border border-zinc-700' 
                 : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="relative max-w-md">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input 
          className="w-full bg-[#09090b] border border-zinc-800 rounded-lg py-2.5 pl-10 pr-4 text-sm focus:outline-none focus:border-zinc-700 transition-colors placeholder:text-zinc-600" 
          placeholder="Buscar templates..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filtered.map(tpl => (
          <div key={tpl.id} className="bg-[#09090b] border border-zinc-800 rounded-xl p-6 hover:border-zinc-700 transition-all flex flex-col group">
            <div className="flex justify-between items-start mb-4">
               <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-zinc-900 border border-zinc-800 rounded-lg group-hover:border-[#d4af37]/30 group-hover:text-[#d4af37] transition-all text-zinc-400">
                     <Layers size={20}/>
                  </div>
                  <div>
                     <span className="text-[10px] font-bold text-zinc-500 uppercase">{tpl.category}</span>
                     <h3 className="text-lg font-bold text-white group-hover:text-[#d4af37] transition-colors">{tpl.name}</h3>
                  </div>
               </div>
               <span className="px-2 py-1 bg-zinc-900 rounded text-[10px] font-bold text-zinc-500 border border-zinc-800">{tpl.complexity}</span>
            </div>
            <p className="text-sm text-zinc-500 leading-relaxed mb-6 flex-1">{tpl.description}</p>
            <div className="flex items-center gap-2 mb-6">
               {tpl.connectors.map(c => <span key={c} className="px-2 py-1 bg-zinc-900 rounded text-[10px] text-zinc-400 border border-zinc-800">{c}</span>)}
            </div>
            <div className="flex gap-3">
               <button onClick={() => { setSelectedTemplate(tpl); setInstallStep('config'); }} className="flex-1 gold-gradient text-black py-2.5 rounded-lg font-bold text-xs hover:opacity-90 transition-all flex items-center justify-center gap-2">
                  <Download size={14}/> Instalar
               </button>
               <button 
                  onClick={() => { setSelectedTemplate(tpl); setInstallStep('config'); }}
                  className="px-4 py-2.5 bg-zinc-900 border border-zinc-800 text-zinc-400 rounded-lg text-xs font-bold hover:text-[#d4af37] hover:border-[#d4af37]/30 transition-all flex items-center gap-2"
                >
                  <FileText size={14} /> Detalhes
               </button>
            </div>
          </div>
        ))}
      </div>

      {selectedTemplate && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="bg-[#09090b] w-full max-w-lg rounded-xl border border-zinc-800 shadow-2xl p-6 animate-in zoom-in-95 duration-300">
              <div className="flex justify-between items-center mb-6">
                 <h3 className="text-lg font-bold text-white">Configurar Template</h3>
                 <button onClick={() => setSelectedTemplate(null)} className="text-zinc-500 hover:text-white"><X size={18}/></button>
              </div>
              
              {installStep === 'config' && (
                <div className="space-y-6">
                   <div className="p-4 bg-zinc-900/50 rounded-lg border border-zinc-800 text-xs text-zinc-400">
                      Configure as variáveis iniciais para o workflow <strong>{selectedTemplate.name}</strong>.
                   </div>
                   <div className="space-y-4">
                      {selectedTemplate.configFields.map((f: any, i: number) => (
                         <div key={i}>
                            <label className="text-[10px] font-bold text-zinc-500 uppercase mb-1 block">{f.label}</label>
                            <input className="w-full bg-black border border-zinc-800 rounded-lg p-3 text-sm text-white focus:outline-none focus:border-[#d4af37]" placeholder={f.placeholder} type={f.type} />
                         </div>
                      ))}
                   </div>
                   <div className="flex gap-3 pt-4">
                      <button onClick={() => setSelectedTemplate(null)} className="flex-1 bg-zinc-900 text-zinc-400 py-3 rounded-lg text-xs font-bold hover:text-white transition-all">Cancelar</button>
                      <button onClick={handleInstall} className="flex-1 gold-gradient text-black py-3 rounded-lg text-xs font-bold hover:opacity-90 transition-all flex items-center justify-center gap-2">Instalar <ArrowRight size={14}/></button>
                   </div>
                </div>
              )}

              {installStep === 'loading' && (
                 <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
                    <Loader2 size={32} className="text-[#d4af37] animate-spin" />
                    <p className="text-sm text-zinc-400">Provisionando recursos...</p>
                 </div>
              )}

              {installStep === 'success' && (
                 <div className="py-8 flex flex-col items-center justify-center text-center space-y-4">
                    <div className="p-4 bg-green-500/10 rounded-full text-green-500 mb-2"><CheckCircle2 size={32} /></div>
                    <div><h4 className="text-lg font-bold text-white">Sucesso!</h4><p className="text-xs text-zinc-500 mt-1">Workflow instalado e pronto para uso.</p></div>
                    <button onClick={() => setSelectedTemplate(null)} className="w-full gold-gradient text-black py-3 rounded-lg font-bold text-xs mt-4">Concluir</button>
                 </div>
              )}
           </div>
        </div>
      )}
    </div>
  );
};

export default Templates;
