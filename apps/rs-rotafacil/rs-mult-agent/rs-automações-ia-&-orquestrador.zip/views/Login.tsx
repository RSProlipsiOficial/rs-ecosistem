
import React, { useState } from 'react';
import { Zap, Shield, ArrowRight } from 'lucide-react';

interface LoginProps {
  onLogin: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  // Pre-filled credentials as requested: rsprolipsioficial@gmail.com / Yannis784512@
  const [email, setEmail] = useState('rsprolipsioficial@gmail.com');
  const [password, setPassword] = useState('Yannis784512@');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-[#d4af37]/5 rounded-full blur-[120px] -translate-y-1/2"></div>
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-[#d4af37]/5 rounded-full blur-[120px] translate-y-1/2"></div>
      
      <div className="w-full max-w-md z-10">
        <div className="flex flex-col items-center mb-12">
          <div className="w-16 h-16 gold-gradient rounded-2xl flex items-center justify-center shadow-2xl mb-6">
            <Zap size={32} className="text-black fill-black" />
          </div>
          <h1 className="text-4xl font-extrabold gold-text-gradient tracking-tighter mb-2 italic">RS AUTO</h1>
          <p className="text-zinc-500 font-medium">Automações Inteligentes Premium</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-zinc-900/50 backdrop-blur-xl p-8 rounded-3xl border border-zinc-800/50 gold-shadow space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-zinc-400 ml-1">Email</label>
            <input 
              type="email" 
              required
              className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors"
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-semibold text-zinc-400 ml-1">Senha</label>
            <input 
              type="password" 
              required
              className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button 
            type="submit"
            className="w-full gold-gradient py-4 rounded-xl text-black font-bold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
          >
            Acessar Plataforma <ArrowRight size={18} />
          </button>

          <div className="flex items-center justify-between text-xs text-zinc-500 pt-4">
            <label className="flex items-center gap-2 cursor-pointer hover:text-zinc-300">
              <input type="checkbox" className="rounded border-zinc-800 bg-black text-[#d4af37]" defaultChecked />
              Lembrar-me
            </label>
            <a href="#" className="hover:text-[#d4af37] transition-colors">Esqueci a senha</a>
          </div>
        </form>

        <p className="mt-8 text-center text-zinc-600 text-sm flex items-center justify-center gap-2">
          <Shield size={14} /> Enterprise Data Encryption Active
        </p>
      </div>
    </div>
  );
};

export default Login;
