
import React, { useState, useEffect } from 'react';
import { CheckCircle2, XCircle, Search, RefreshCw, Loader2, Terminal, Clock } from 'lucide-react';
import { ExecutionRecord } from '../modules/automations/types';
import { executionService } from '../modules/automations/services/executionService';

const ExecutionMonitor: React.FC = () => {
  const [logs, setLogs] = useState<ExecutionRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchLogs = async () => {
    setIsLoading(true);
    try {
      const data = await executionService.list();
      setLogs(data);
    } catch (e) {
      console.error("Monitor service failure");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => { fetchLogs(); }, []);

  const filtered = logs.filter(l => l.automation_name.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold text-white">Monitor de Execuções</h2>
          <p className="text-sm text-zinc-500 mt-1">Telemetria de produção RS Votafone.</p>
        </div>
        <button onClick={fetchLogs} className="px-4 py-2 border border-zinc-800 rounded-lg text-xs font-bold text-zinc-400 hover:text-white flex items-center gap-2">
          <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} /> Sincronizar
        </button>
      </div>

      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input 
          placeholder="Buscar nos logs..." 
          className="w-full bg-[#09090b] border border-zinc-800 rounded-lg py-2.5 pl-10 pr-4 text-sm"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      </div>

      {isLoading ? (
        <div className="py-20 flex justify-center"><Loader2 className="animate-spin text-[#d4af37]" /></div>
      ) : (
        <div className="bg-[#09090b] border border-zinc-800 rounded-xl overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-zinc-900/50 text-zinc-500 text-[10px] font-bold uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Automação</th>
                <th className="px-6 py-4">Horário</th>
                <th className="px-6 py-4">Duração</th>
                <th className="px-6 py-4 text-right">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/40">
              {filtered.map(log => (
                <tr key={log.id} className="hover:bg-zinc-900/20 transition-colors">
                  <td className="px-6 py-4">
                    {log.status === 'success' ? <span className="text-emerald-500 flex items-center gap-1.5 font-bold text-[10px] uppercase"><CheckCircle2 size={12}/> Sucesso</span> : <span className="text-red-500 flex items-center gap-1.5 font-bold text-[10px] uppercase"><XCircle size={12}/> Erro</span>}
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-zinc-200 block">{log.automation_name}</span>
                    <span className="text-[10px] text-zinc-600 font-mono">#{log.id.slice(0,8)}</span>
                  </td>
                  <td className="px-6 py-4 text-xs text-zinc-400 font-mono">{new Date(log.started_at).toLocaleString()}</td>
                  <td className="px-6 py-4 text-xs text-zinc-500 font-mono">{log.duration_ms}ms</td>
                  <td className="px-6 py-4 text-right">
                    <button className="p-2 hover:bg-zinc-800 rounded text-zinc-500"><Terminal size={14}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ExecutionMonitor;
