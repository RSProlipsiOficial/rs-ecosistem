
import React, { useState, useRef, useEffect } from 'react';
import { 
  User, 
  Bell, 
  Shield, 
  CreditCard, 
  Globe, 
  HelpCircle, 
  Copy, 
  Eye, 
  EyeOff, 
  RefreshCw, 
  CheckCircle2, 
  X, 
  Save, 
  Loader2,
  Mail,
  Smartphone,
  LogOut,
  ChevronRight,
  ChevronLeft,
  Upload,
  Download,
  CreditCard as CardIcon,
  QrCode,
  Smartphone as PhoneIcon,
  Lock,
  Book,
  MessageCircle,
  LifeBuoy,
  Send,
  ExternalLink,
  AlertCircle,
  FileText,
  Calendar,
  Users,
  Trash2,
  Plus,
  Check
} from 'lucide-react';

const Settings: React.FC = () => {
  const [activeModal, setActiveModal] = useState<string | null>(null);
  
  // View States
  const [securityView, setSecurityView] = useState<'main' | 'password' | '2fa'>('main');
  const [supportView, setSupportView] = useState<'main' | 'ticket'>('main');
  const [billingView, setBillingView] = useState<'main' | 'change-card' | 'invoices'>('main');
  
  const [showApiKey, setShowApiKey] = useState(false);
  const [apiKey, setApiKey] = useState('rs_live_723hd9237hd9237hd9237');
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isCopying, setIsCopying] = useState(false);
  const [showToast, setShowToast] = useState<{ msg: string, type: 'success' | 'info' | 'error' } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form States
  const [notifications, setNotifications] = useState({ email: true, push: false, whatsapp: true });
  const [profile, setProfile] = useState({ name: 'Ricardo S.', email: 'admin@rsauto.com', company: 'RS Enterprise' });
  
  // Workspace States
  const [workspace, setWorkspace] = useState({ name: 'RS Enterprise', slug: 'rs-enterprise', timezone: 'America/Sao_Paulo' });
  const [members, setMembers] = useState([
    { id: 1, name: 'Ricardo S.', email: 'admin@rsauto.com', role: 'Owner' },
    { id: 2, name: 'Suporte Técnico', email: 'suporte@rsauto.com', role: 'Editor' },
  ]);
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [newMemberRole, setNewMemberRole] = useState('Viewer');
  
  // Security Forms
  const [passwords, setPasswords] = useState({ current: '', new: '', confirm: '' });
  const [twoFaCode, setTwoFaCode] = useState('');

  // Support Form
  const [ticket, setTicket] = useState({ subject: '', priority: 'normal', message: '' });

  // Billing Forms
  const [cardData, setCardData] = useState({ number: '', holder: '', expiry: '', cvc: '' });

  // Mock Invoices
  const invoices = [
    { id: 'INV-2023-001', date: '24/10/2023', amount: 'R$ 499,00', status: 'paid' },
    { id: 'INV-2023-002', date: '24/09/2023', amount: 'R$ 499,00', status: 'paid' },
    { id: 'INV-2023-003', date: '24/08/2023', amount: 'R$ 499,00', status: 'paid' },
    { id: 'INV-2023-004', date: '24/07/2023', amount: 'R$ 299,00', status: 'paid' }, // Was probably on a lower plan
  ];

  const triggerToast = (msg: string, type: 'success' | 'info' | 'error' = 'success') => {
    setShowToast({ msg, type });
    setTimeout(() => setShowToast(null), 3000);
  };

  // Reset views when modal closes
  useEffect(() => {
    if (!activeModal) {
      setSecurityView('main');
      setPasswords({ current: '', new: '', confirm: '' });
      setTwoFaCode('');
      
      setSupportView('main');
      setTicket({ subject: '', priority: 'normal', message: '' });

      setBillingView('main');
      setCardData({ number: '', holder: '', expiry: '', cvc: '' });
    }
  }, [activeModal]);

  const handleCopyKey = async () => {
    try {
      await navigator.clipboard.writeText(apiKey);
      setIsCopying(true);
      triggerToast('API Key copiada para a área de transferência!');
      setTimeout(() => setIsCopying(false), 2000);
    } catch (err) {
      triggerToast('Erro ao copiar. Tente selecionar e copiar manualmente.', 'error');
    }
  };

  const handleRegenerateKey = () => {
    if (confirm("Tem certeza? A chave antiga deixará de funcionar imediatamente para todas as integrações.")) {
      setIsRegenerating(true);
      setTimeout(() => {
        setApiKey(`rs_live_${Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)}`);
        setIsRegenerating(false);
        triggerToast('Nova API Key gerada com sucesso.');
      }, 2000);
    }
  };

  const handleInvite = () => {
    if(!newMemberEmail) return;
    if(!newMemberEmail.includes('@')) {
        triggerToast('Email inválido', 'error');
        return;
    }
    setMembers([...members, { id: Date.now(), name: newMemberEmail.split('@')[0], email: newMemberEmail, role: newMemberRole }]);
    setNewMemberEmail('');
    triggerToast('Convite enviado com sucesso!');
  };

  const handleRemoveMember = (id: number) => {
    setMembers(members.filter(m => m.id !== id));
    triggerToast('Membro removido.');
  };

  const handleSave = () => {
    // Validation logic...
    // (Existing validation code remains the same)
    
    // Validation for Password Change
    if (activeModal === 'security' && securityView === 'password') {
       if (passwords.new !== passwords.confirm) {
         triggerToast('As senhas não conferem.', 'error');
         return;
       }
       if (passwords.new.length < 8) {
         triggerToast('A senha deve ter pelo menos 8 caracteres.', 'error');
         return;
       }
    }

    if (activeModal === 'security' && securityView === '2fa' && twoFaCode.length < 6) {
        triggerToast('Código de verificação inválido.', 'error');
        return;
    }

    if (activeModal === 'support' && supportView === 'ticket' && (!ticket.subject || !ticket.message)) {
        triggerToast('Por favor, preencha o assunto e a mensagem.', 'error');
        return;
    }

    if (activeModal === 'billing' && billingView === 'change-card' && (cardData.number.length < 16 || !cardData.holder || !cardData.expiry || !cardData.cvc)) {
        triggerToast('Preencha os dados do cartão corretamente.', 'error');
        return;
    }

    if (activeModal === 'workspace' && (!workspace.name || !workspace.slug)) {
        triggerToast('Preencha os dados da empresa.', 'error');
        return;
    }

    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      
      if (activeModal === 'security' && securityView !== 'main') {
          setSecurityView('main');
          triggerToast(securityView === 'password' ? 'Senha alterada com sucesso!' : '2FA ativado com sucesso!');
      } else if (activeModal === 'support' && supportView === 'ticket') {
           setSupportView('main');
           triggerToast(`Ticket #${Math.floor(Math.random() * 90000) + 10000} aberto com sucesso!`, 'success');
           setTicket({ subject: '', priority: 'normal', message: '' });
      } else if (activeModal === 'billing' && billingView === 'change-card') {
           setBillingView('main');
           triggerToast('Método de pagamento atualizado!', 'success');
           setCardData({ number: '', holder: '', expiry: '', cvc: '' });
      } else {
        setActiveModal(null);
        triggerToast('Alterações salvas com sucesso!');
      }
    }, 1500);
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      triggerToast(`Foto "${e.target.files[0].name}" carregada com sucesso!`);
    }
  };

  const sections = [
    { id: 'profile', icon: User, label: 'Perfil e Conta', desc: 'Dados pessoais, foto e preferências' },
    { id: 'workspace', icon: Globe, label: 'Workspace', desc: 'Configurações da empresa e multi-tenant' },
    { id: 'notifications', icon: Bell, label: 'Notificações', desc: 'Alertas de falhas e execuções críticas' },
    { id: 'billing', icon: CreditCard, label: 'Assinatura', desc: 'Plano Enterprise - 15.4k/50k msgs' },
    { id: 'security', icon: Shield, label: 'Segurança', desc: 'Autenticação em 2 fatores e logs de acesso' },
    { id: 'support', icon: HelpCircle, label: 'Suporte', desc: 'Documentação e atendimento especializado' },
  ];

  const renderModalContent = () => {
    // (Existing renderModalContent logic remains the same, abbreviating for clarity of the requested change)
    switch (activeModal) {
      case 'profile':
        return (
          <div className="space-y-6">
            <div className="flex items-center gap-6">
              <div onClick={handleUploadClick} className="w-24 h-24 rounded-full bg-zinc-800 border-2 border-dashed border-zinc-600 flex items-center justify-center cursor-pointer hover:border-[#d4af37] hover:bg-zinc-800/50 transition-all group relative">
                 <Upload size={24} className="text-zinc-500 group-hover:text-[#d4af37]" />
                 <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
              </div>
              <div>
                <h4 className="font-bold text-white text-lg">Foto de Perfil</h4>
                <p className="text-xs text-zinc-500 mb-3">Recomendado: 400x400px, JPG ou PNG.</p>
                <button onClick={handleUploadClick} className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 hover:border-zinc-600 rounded-lg text-xs font-bold text-zinc-300 transition-all">Carregar Nova Foto</button>
              </div>
            </div>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Nome Completo</label>
                <input type="text" value={profile.name} onChange={e => setProfile({...profile, name: e.target.value})} className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3.5 text-white focus:outline-none focus:border-[#d4af37] transition-colors" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase ml-1">Email Corporativo</label>
                <input type="email" value={profile.email} onChange={e => setProfile({...profile, email: e.target.value})} className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3.5 text-white focus:outline-none focus:border-[#d4af37] transition-colors" />
              </div>
            </div>
          </div>
        );
      case 'workspace':
        return (
          <div className="space-y-8 animate-in slide-in-from-right duration-300">
             <div className="space-y-5">
                <div className="flex items-center gap-2 pb-2 border-b border-zinc-800">
                   <Globe size={18} className="text-[#d4af37]" />
                   <h4 className="font-bold text-white text-sm uppercase tracking-wider">Identidade Corporativa</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                   <div className="space-y-2">
                      <label className="text-[10px] font-bold text-zinc-500 uppercase">Nome da Empresa</label>
                      <input type="text" value={workspace.name} onChange={e => setWorkspace({...workspace, name: e.target.value})} className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors" />
                   </div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-bold text-zinc-500 uppercase">URL Personalizada</label>
                      <div className="flex">
                         <span className="bg-zinc-900 border border-zinc-800 border-r-0 rounded-l-xl px-3 py-3 text-zinc-500 text-xs flex items-center">rsauto.com/</span>
                         <input type="text" value={workspace.slug} onChange={e => setWorkspace({...workspace, slug: e.target.value})} className="w-full bg-black border border-zinc-800 rounded-r-xl px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors" />
                      </div>
                   </div>
                </div>
                <div className="space-y-2">
                    <label className="text-[10px] font-bold text-zinc-500 uppercase">Fuso Horário Padrão</label>
                    <div className="relative">
                      <select value={workspace.timezone} onChange={e => setWorkspace({...workspace, timezone: e.target.value})} className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors appearance-none">
                          <option value="America/Sao_Paulo">Brasília (GMT-3)</option>
                          <option value="America/New_York">New York (GMT-4)</option>
                          <option value="Europe/London">London (GMT+1)</option>
                          <option value="Asia/Tokyo">Tokyo (GMT+9)</option>
                      </select>
                      <ChevronRight size={14} className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-500 rotate-90 pointer-events-none" />
                    </div>
                </div>
             </div>
             <div className="space-y-5">
                <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
                   <div className="flex items-center gap-2">
                      <Users size={18} className="text-[#d4af37]" />
                      <h4 className="font-bold text-white text-sm uppercase tracking-wider">Gestão de Equipe</h4>
                   </div>
                   <span className="text-[10px] font-bold bg-zinc-800 text-zinc-400 px-2 py-1 rounded-lg border border-zinc-700">{members.length} / 5 Assentos</span>
                </div>
                <div className="flex gap-2 p-1 bg-zinc-900/50 rounded-xl border border-zinc-800">
                   <input type="email" placeholder="email@colaborador.com" value={newMemberEmail} onChange={e => setNewMemberEmail(e.target.value)} className="flex-1 bg-transparent border-none px-4 text-sm text-white focus:outline-none placeholder:text-zinc-600" />
                   <div className="w-px bg-zinc-800 h-6 my-auto"></div>
                   <select value={newMemberRole} onChange={e => setNewMemberRole(e.target.value)} className="bg-transparent border-none text-xs font-bold text-zinc-400 focus:outline-none cursor-pointer hover:text-white">
                      <option value="Viewer">Viewer</option>
                      <option value="Editor">Editor</option>
                      <option value="Admin">Admin</option>
                   </select>
                   <button onClick={handleInvite} className="p-2 bg-zinc-800 hover:bg-[#d4af37] text-zinc-400 hover:text-black rounded-lg transition-all"><Plus size={16} /></button>
                </div>
                <div className="space-y-3 max-h-[200px] overflow-y-auto custom-scrollbar pr-1">
                   {members.map(member => (
                      <div key={member.id} className="flex items-center justify-between p-3 bg-zinc-900/20 border border-zinc-800/50 rounded-xl hover:border-zinc-700 transition-colors group">
                         <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-xs font-bold text-zinc-300">{member.name.substring(0,2).toUpperCase()}</div>
                            <div>
                               <p className="text-sm font-bold text-white">{member.name}</p>
                               <p className="text-[10px] text-zinc-500">{member.email}</p>
                            </div>
                         </div>
                         <div className="flex items-center gap-3">
                            <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded border ${member.role === 'Owner' ? 'bg-[#d4af37]/10 text-[#d4af37] border-[#d4af37]/20' : member.role === 'Admin' ? 'bg-purple-500/10 text-purple-500 border-purple-500/20' : 'bg-zinc-800 text-zinc-400 border-zinc-700'}`}>{member.role}</span>
                            {member.role !== 'Owner' && (
                               <button onClick={() => handleRemoveMember(member.id)} className="p-1.5 text-zinc-600 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all opacity-0 group-hover:opacity-100"><Trash2 size={14} /></button>
                            )}
                         </div>
                      </div>
                   ))}
                </div>
             </div>
          </div>
        );
      case 'notifications':
        return (
          <div className="space-y-4">
            <p className="text-sm text-zinc-400 mb-4 bg-zinc-900/30 p-4 rounded-xl border border-zinc-800/50">
              Escolha os canais onde você deseja receber alertas críticos sobre falhas em automações.
            </p>
            {[
              { key: 'email', label: 'Alertas por Email', icon: Mail },
              { key: 'push', label: 'Push Notifications', icon: Bell },
              { key: 'whatsapp', label: 'Avisos no WhatsApp', icon: Smartphone }
            ].map((item: any) => (
              <div key={item.key} className="flex items-center justify-between p-4 bg-black border border-zinc-800 rounded-2xl hover:border-zinc-700 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-zinc-900 rounded-xl"><item.icon size={18} className="text-zinc-400"/></div>
                  <span className="font-bold text-sm text-zinc-200">{item.label}</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" checked={(notifications as any)[item.key]} onChange={() => setNotifications({...notifications, [item.key]: !(notifications as any)[item.key]})} />
                  <div className="w-11 h-6 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#d4af37]"></div>
                </label>
              </div>
            ))}
          </div>
        );
      // ... (Billing and Security cases remain the same as previous) ...
      case 'billing':
        // Re-adding billing content for completeness as it was requested previously
        if (billingView === 'main') {
          return (
            <div className="space-y-6 animate-in slide-in-from-left duration-300">
              <div className="p-6 bg-gradient-to-br from-[#d4af37]/10 to-black rounded-3xl border border-[#d4af37]/30 text-center relative overflow-hidden">
                 <div className="absolute top-0 right-0 w-32 h-32 bg-[#d4af37]/10 blur-[40px] rounded-full"></div>
                 <h3 className="text-2xl font-black text-[#d4af37] mb-1 relative z-10">PLANO ENTERPRISE</h3>
                 <p className="text-[10px] text-[#d4af37]/70 uppercase font-bold tracking-widest relative z-10">Renovação em 24/11/2023</p>
              </div>
              <div className="space-y-3">
                 <div className="flex justify-between text-xs font-bold text-zinc-400 px-1">
                   <span>Consumo de Mensagens</span>
                   <span>15.420 / 50.000</span>
                 </div>
                 <div className="w-full h-3 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                   <div className="h-full bg-[#d4af37] w-[30%] shadow-[0_0_10px_rgba(212,175,55,0.5)]"></div>
                 </div>
              </div>
              <div className="pt-4 border-t border-zinc-800 space-y-3">
                 <div className="flex justify-between items-center p-3 bg-zinc-900/30 rounded-xl border border-zinc-800/50">
                   <div className="flex items-center gap-3">
                      <div className="p-2 bg-zinc-800 rounded-lg"><CardIcon size={16} className="text-zinc-400"/></div>
                      <span className="text-sm font-bold text-white">Cartão Final 4242</span>
                   </div>
                   <button onClick={() => setBillingView('change-card')} className="px-3 py-1.5 border border-[#d4af37]/30 text-[#d4af37] rounded-lg text-xs font-bold hover:bg-[#d4af37]/10 transition-all">Alterar</button>
                 </div>
                 <div className="flex justify-between items-center p-3 bg-zinc-900/30 rounded-xl border border-zinc-800/50">
                   <div className="flex items-center gap-3">
                      <div className="p-2 bg-zinc-800 rounded-lg"><Download size={16} className="text-zinc-400"/></div>
                      <span className="text-sm font-bold text-white">Faturas Anteriores</span>
                   </div>
                   <div className="flex gap-2">
                      <button onClick={() => setBillingView('invoices')} className="px-3 py-1.5 border border-zinc-700 text-zinc-400 rounded-lg text-xs font-bold hover:bg-zinc-800 hover:text-white transition-all">Histórico</button>
                      <button onClick={() => triggerToast("Baixando fatura mais recente...", "success")} className="px-3 py-1.5 border border-zinc-700 text-zinc-400 rounded-lg text-xs font-bold hover:bg-zinc-800 hover:text-white transition-all">Baixar PDF</button>
                   </div>
                 </div>
              </div>
            </div>
          );
        }
        if (billingView === 'change-card') {
             return (
            <div className="space-y-6 animate-in slide-in-from-right duration-300">
               <div className="flex items-center gap-2 mb-2">
                 <button onClick={() => setBillingView('main')} className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-white transition-colors"><ChevronLeft size={20} /></button>
                 <div><h4 className="font-bold text-white">Atualizar Pagamento</h4><p className="text-xs text-zinc-500">Insira os dados do seu novo cartão de crédito.</p></div>
               </div>
               <div className="space-y-4 bg-zinc-900/20 p-6 rounded-2xl border border-zinc-800/50">
                 <div className="space-y-2"><label className="text-[10px] font-bold text-zinc-500 uppercase">Número do Cartão</label><div className="relative"><input type="text" maxLength={19} placeholder="0000 0000 0000 0000" className="w-full bg-black border border-zinc-800 rounded-xl pl-10 pr-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors" value={cardData.number} onChange={e => setCardData({...cardData, number: e.target.value.replace(/\D/g, '')})} /><CardIcon size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" /></div></div>
                 <div className="space-y-2"><label className="text-[10px] font-bold text-zinc-500 uppercase">Nome no Cartão</label><input type="text" placeholder="COMO NO CARTAO" className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors uppercase" value={cardData.holder} onChange={e => setCardData({...cardData, holder: e.target.value})} /></div>
                 <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-2"><label className="text-[10px] font-bold text-zinc-500 uppercase">Validade</label><input type="text" maxLength={5} placeholder="MM/AA" className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors" value={cardData.expiry} onChange={e => setCardData({...cardData, expiry: e.target.value})} /></div>
                   <div className="space-y-2"><label className="text-[10px] font-bold text-zinc-500 uppercase">CVC</label><div className="relative"><input type="text" maxLength={3} placeholder="123" className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors" value={cardData.cvc} onChange={e => setCardData({...cardData, cvc: e.target.value})} /><Lock size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-600" /></div></div>
                 </div>
               </div>
               <div className="flex items-center gap-2 p-3 bg-[#d4af37]/5 rounded-xl border border-[#d4af37]/20"><Shield size={16} className="text-[#d4af37]" /><p className="text-[10px] text-zinc-400">Seus dados são criptografados e processados seguramente pela Stripe.</p></div>
            </div>
          );
        }
        if (billingView === 'invoices') {
             return (
            <div className="space-y-6 animate-in slide-in-from-right duration-300">
               <div className="flex items-center gap-2 mb-2"><button onClick={() => setBillingView('main')} className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-white transition-colors"><ChevronLeft size={20} /></button><div><h4 className="font-bold text-white">Histórico de Faturas</h4><p className="text-xs text-zinc-500">Visualize e baixe seus comprovantes de pagamento.</p></div></div>
               <div className="border border-zinc-800 rounded-2xl overflow-hidden"><div className="max-h-[300px] overflow-y-auto custom-scrollbar bg-black">{invoices.map((inv, i) => (<div key={inv.id} className={`flex items-center justify-between p-4 ${i !== invoices.length - 1 ? 'border-b border-zinc-900' : ''} hover:bg-zinc-900/40 transition-colors`}><div className="flex items-center gap-4"><div className="p-2 bg-zinc-900 rounded-lg text-zinc-400"><FileText size={18} /></div><div><p className="text-sm font-bold text-white">{inv.amount}</p><div className="flex items-center gap-2 text-[10px] text-zinc-500"><Calendar size={10} /> {inv.date}<span className="text-zinc-700">•</span><span>{inv.id}</span></div></div></div><div className="flex items-center gap-3"><span className="px-2 py-0.5 rounded text-[10px] font-bold bg-green-500/10 text-green-500 uppercase tracking-wide">Pago</span><button onClick={() => triggerToast(`Baixando fatura ${inv.id}...`)} className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-white transition-colors"><Download size={16} /></button></div></div>))}</div></div>
            </div>
          );
        }
        return null;

      case 'security':
        // (Security view content remains same as previous steps)
        if (securityView === 'main') {
           return (
             <div className="space-y-4 animate-in slide-in-from-left duration-300">
                <button onClick={() => setSecurityView('password')} className="w-full flex items-center justify-between p-5 bg-black rounded-2xl border border-zinc-800 hover:border-[#d4af37]/50 hover:bg-zinc-900 transition-all group text-left active:scale-[0.99]"><div className="flex items-center gap-4"><div className="p-2 bg-zinc-900 rounded-lg text-zinc-400 group-hover:text-white transition-colors"><Lock size={20} /></div><div><h4 className="font-bold text-white group-hover:text-[#d4af37] transition-colors">Alterar Senha</h4><p className="text-xs text-zinc-500">Última alteração há 90 dias</p></div></div><div className="p-2 bg-zinc-900 rounded-xl group-hover:bg-[#d4af37]/10 transition-colors"><ChevronRight size={18} className="text-zinc-600 group-hover:text-[#d4af37]" /></div></button>
                <button onClick={() => setSecurityView('2fa')} className="w-full flex items-center justify-between p-5 bg-black rounded-2xl border border-zinc-800 hover:border-[#d4af37]/50 hover:bg-zinc-900 transition-all group text-left active:scale-[0.99]"><div className="flex items-center gap-4"><div className="p-2 bg-zinc-900 rounded-lg text-zinc-400 group-hover:text-white transition-colors"><Smartphone size={20} /></div><div><h4 className="font-bold text-[#d4af37] group-hover:text-[#d4af37] transition-colors">Autenticação de 2 Fatores (2FA)</h4><p className="text-xs text-green-500 flex items-center gap-1 font-bold"><CheckCircle2 size={12} /> Ativado via Authy</p></div></div><div className="p-2 bg-zinc-900 rounded-xl group-hover:bg-[#d4af37]/10 transition-colors"><ChevronRight size={18} className="text-zinc-600 group-hover:text-[#d4af37]" /></div></button>
                <div className="pt-4 mt-4 border-t border-zinc-800"><button onClick={() => triggerToast("Todas as outras sessões foram encerradas.", "info")} className="w-full p-4 border border-red-500/20 bg-red-500/5 hover:bg-red-500/10 rounded-2xl text-red-500 font-bold flex items-center justify-center gap-2 transition-all active:scale-[0.98]"><LogOut size={18} /> Encerrar Outras Sessões</button></div>
             </div>
           );
        }
        if (securityView === 'password') {
            return (
             <div className="space-y-6 animate-in slide-in-from-right duration-300">
                <div className="flex items-center gap-2 mb-2"><button onClick={() => setSecurityView('main')} className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-white transition-colors"><ChevronLeft size={20} /></button><div><h4 className="font-bold text-white">Alterar Senha</h4><p className="text-xs text-zinc-500">Crie uma senha forte com letras, números e símbolos.</p></div></div>
                <div className="space-y-4 bg-zinc-900/20 p-6 rounded-2xl border border-zinc-800/50">
                  <div className="space-y-2"><label className="text-[10px] font-bold text-zinc-500 uppercase">Senha Atual</label><input type="password" className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors" value={passwords.current} onChange={e => setPasswords({...passwords, current: e.target.value})} /></div>
                  <div className="h-px bg-zinc-800/50 my-2"></div>
                  <div className="space-y-2"><label className="text-[10px] font-bold text-zinc-500 uppercase">Nova Senha</label><input type="password" className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors" value={passwords.new} onChange={e => setPasswords({...passwords, new: e.target.value})} /></div>
                  <div className="space-y-2"><label className="text-[10px] font-bold text-zinc-500 uppercase">Confirmar Nova Senha</label><input type="password" className={`w-full bg-black border rounded-xl px-4 py-3 text-white focus:outline-none transition-colors ${passwords.confirm && passwords.new !== passwords.confirm ? 'border-red-500 focus:border-red-500' : 'border-zinc-800 focus:border-[#d4af37]'}`} value={passwords.confirm} onChange={e => setPasswords({...passwords, confirm: e.target.value})} />{passwords.confirm && passwords.new !== passwords.confirm && (<p className="text-[10px] text-red-500 font-bold">As senhas não conferem</p>)}</div>
                </div>
             </div>
            );
        }
        if (securityView === '2fa') {
            return (
             <div className="space-y-6 animate-in slide-in-from-right duration-300">
                <div className="flex items-center gap-2 mb-2"><button onClick={() => setSecurityView('main')} className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-white transition-colors"><ChevronLeft size={20} /></button><div><h4 className="font-bold text-white">Configurar 2FA</h4><p className="text-xs text-zinc-500">Aumente a segurança da sua conta usando um app autenticador.</p></div></div>
                <div className="flex flex-col items-center justify-center p-8 bg-zinc-900/30 border border-zinc-800 rounded-3xl">
                   <div className="bg-white p-4 rounded-xl mb-6"><QrCode size={120} className="text-black" /></div>
                   <p className="text-xs text-zinc-400 text-center max-w-xs mb-6">Escaneie este QR Code com seu aplicativo (Google Authenticator, Authy ou 1Password).</p>
                   <div className="w-full max-w-xs space-y-2"><label className="text-[10px] font-bold text-zinc-500 uppercase text-center block">Código de Verificação</label><div className="flex gap-2 justify-center"><input type="text" maxLength={6} placeholder="000 000" className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-center text-xl tracking-[0.5em] font-mono text-white focus:outline-none focus:border-[#d4af37] transition-colors" value={twoFaCode} onChange={e => setTwoFaCode(e.target.value.replace(/\D/g, ''))} /></div></div>
                </div>
             </div>
            );
        }
        return null;

      case 'support':
        // (Support view content remains same as previous steps)
        if (supportView === 'main') {
           return (
             <div className="space-y-4 animate-in slide-in-from-left duration-300">
               <button onClick={() => window.open('#', '_blank')} className="w-full flex items-center justify-between p-5 bg-black rounded-2xl border border-zinc-800 hover:border-[#d4af37]/50 hover:bg-zinc-900 transition-all group text-left active:scale-[0.99]"><div className="flex items-center gap-4"><div className="p-2 bg-zinc-900 rounded-lg text-zinc-400 group-hover:text-white transition-colors"><Book size={20} /></div><div><h4 className="font-bold text-white group-hover:text-[#d4af37] transition-colors">Documentação</h4><p className="text-xs text-zinc-500">Tutoriais, referências de API e guias.</p></div></div><div className="p-2 bg-zinc-900 rounded-xl group-hover:bg-[#d4af37]/10 transition-colors"><ExternalLink size={18} className="text-zinc-600 group-hover:text-[#d4af37]" /></div></button>
               <button onClick={() => window.open('#', '_blank')} className="w-full flex items-center justify-between p-5 bg-black rounded-2xl border border-zinc-800 hover:border-[#d4af37]/50 hover:bg-zinc-900 transition-all group text-left active:scale-[0.99]"><div className="flex items-center gap-4"><div className="p-2 bg-zinc-900 rounded-lg text-zinc-400 group-hover:text-green-500 transition-colors"><MessageCircle size={20} /></div><div><h4 className="font-bold text-white group-hover:text-green-500 transition-colors">Atendimento WhatsApp</h4><p className="text-xs text-zinc-500">Fale diretamente com nosso time comercial.</p></div></div><div className="p-2 bg-zinc-900 rounded-xl group-hover:bg-green-500/10 transition-colors"><ExternalLink size={18} className="text-zinc-600 group-hover:text-green-500" /></div></button>
               <button onClick={() => setSupportView('ticket')} className="w-full flex items-center justify-between p-5 bg-black rounded-2xl border border-zinc-800 hover:border-[#d4af37]/50 hover:bg-zinc-900 transition-all group text-left active:scale-[0.99]"><div className="flex items-center gap-4"><div className="p-2 bg-zinc-900 rounded-lg text-zinc-400 group-hover:text-white transition-colors"><LifeBuoy size={20} /></div><div><h4 className="font-bold text-white group-hover:text-[#d4af37] transition-colors">Abrir Chamado</h4><p className="text-xs text-zinc-500">Relatar bugs ou solicitar ajuda técnica.</p></div></div><div className="p-2 bg-zinc-900 rounded-xl group-hover:bg-[#d4af37]/10 transition-colors"><ChevronRight size={18} className="text-zinc-600 group-hover:text-[#d4af37]" /></div></button>
             </div>
           );
        }
        if (supportView === 'ticket') {
            return (
             <div className="space-y-6 animate-in slide-in-from-right duration-300">
               <div className="flex items-center gap-2 mb-2"><button onClick={() => setSupportView('main')} className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-white transition-colors"><ChevronLeft size={20} /></button><div><h4 className="font-bold text-white">Novo Chamado</h4><p className="text-xs text-zinc-500">Descreva seu problema com detalhes.</p></div></div>
               <div className="space-y-4">
                 <div className="space-y-2"><label className="text-[10px] font-bold text-zinc-500 uppercase">Assunto</label><input type="text" placeholder="Ex: Erro ao conectar com Stripe" className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors" value={ticket.subject} onChange={e => setTicket({...ticket, subject: e.target.value})} /></div>
                 <div className="space-y-2"><label className="text-[10px] font-bold text-zinc-500 uppercase">Prioridade</label><div className="grid grid-cols-3 gap-2">{['low', 'normal', 'high'].map(p => (<button key={p} onClick={() => setTicket({...ticket, priority: p})} className={`py-3 rounded-xl text-xs font-bold capitalize border transition-all ${ticket.priority === p ? (p === 'high' ? 'bg-red-500/10 border-red-500 text-red-500' : p === 'normal' ? 'bg-[#d4af37]/10 border-[#d4af37] text-[#d4af37]' : 'bg-green-500/10 border-green-500 text-green-500') : 'bg-black border-zinc-800 text-zinc-500 hover:bg-zinc-900'}`}>{p === 'low' ? 'Baixa' : p === 'normal' ? 'Normal' : 'Urgente'}</button>))}</div></div>
                 <div className="space-y-2"><label className="text-[10px] font-bold text-zinc-500 uppercase">Mensagem</label><textarea placeholder="Descreva o que aconteceu..." className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#d4af37] transition-colors min-h-[120px] resize-none" value={ticket.message} onChange={e => setTicket({...ticket, message: e.target.value})} /></div>
               </div>
             </div>
            );
        }
        return null;

      default:
        return <div className="p-8 text-center text-zinc-500">Selecione uma opção</div>;
    }
  };

  return (
    <div className="max-w-4xl space-y-8 animate-in fade-in duration-500 relative pb-20">
      
      {/* Toast */}
      {showToast && (
        <div className={`fixed top-24 right-8 z-[150] px-6 py-4 rounded-2xl shadow-2xl border flex items-center gap-3 animate-in slide-in-from-right duration-300 ${
          showToast.type === 'success' ? 'bg-zinc-900 border-green-500/30 text-green-500' : 
          showToast.type === 'error' ? 'bg-zinc-900 border-red-500/30 text-red-500' :
          'bg-zinc-900 border-blue-500/30 text-blue-500'
        }`}>
          {showToast.type === 'success' ? <CheckCircle2 size={18} /> : showToast.type === 'error' ? <AlertCircle size={18} /> : <Shield size={18} />}
          <span className="text-sm font-bold text-white">{showToast.msg}</span>
        </div>
      )}

      <div>
        <h2 className="text-2xl font-bold">Configurações</h2>
        <p className="text-zinc-500 text-sm">Gerencie sua experiência na RS Automações.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sections.map((section) => (
          <button 
            key={section.id} 
            onClick={() => setActiveModal(section.id)}
            className="flex items-start gap-4 p-6 bg-zinc-900/40 border border-zinc-800 rounded-2xl hover:gold-border transition-all text-left group active:scale-[0.98]"
          >
            <div className="p-3 bg-zinc-800 rounded-xl group-hover:bg-[#d4af37]/10 transition-colors">
              <section.icon size={24} className="text-[#d4af37]" />
            </div>
            <div>
              <h4 className="font-bold mb-1 text-white group-hover:text-[#d4af37] transition-colors">{section.label}</h4>
              <p className="text-xs text-zinc-500">{section.desc}</p>
            </div>
          </button>
        ))}
      </div>

      <div className="p-8 bg-zinc-900/40 border border-zinc-800 rounded-3xl space-y-6">
         <div className="flex justify-between items-start">
           <div>
             <h3 className="text-lg font-bold flex items-center gap-2">
               API Key da Plataforma
               <span className="text-[10px] bg-green-500/10 text-green-500 px-2 py-0.5 rounded border border-green-500/20 uppercase">Ativa</span>
             </h3>
             <p className="text-sm text-zinc-500 mt-1">Use esta chave para integrar RS Automações com outros sistemas via Webhook.</p>
           </div>
           <button 
              onClick={handleRegenerateKey}
              disabled={isRegenerating}
              className="text-xs text-zinc-500 hover:text-red-400 font-bold flex items-center gap-1 transition-colors disabled:opacity-50"
           >
              {isRegenerating ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />}
              Rotacionar Chave
           </button>
         </div>
         
         <div className="flex gap-2">
            <div className="flex-1 relative">
              <input 
                type={showApiKey ? "text" : "password"} 
                readOnly 
                value={apiKey} 
                className="w-full bg-black border border-zinc-800 rounded-xl pl-4 pr-12 py-3 font-mono text-sm text-zinc-300 focus:outline-none focus:border-[#d4af37] transition-colors" 
              />
              <button 
                onClick={() => setShowApiKey(!showApiKey)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
              >
                {showApiKey ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            <button 
              onClick={handleCopyKey}
              className="gold-gradient text-black px-6 py-2 rounded-xl font-bold text-sm flex items-center justify-center gap-2 hover:opacity-90 active:scale-95 transition-all w-32"
            >
              {isCopying ? <CheckCircle2 size={16} /> : <Copy size={16} />} 
              {isCopying ? 'Copiado' : 'Copiar'}
            </button>
         </div>
      </div>

      {/* Dynamic Modal */}
      {activeModal && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="bg-[#0a0a0a] w-full max-w-lg rounded-[32px] border border-zinc-800 gold-shadow flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-300">
              <div className="p-8 border-b border-zinc-800 flex justify-between items-center bg-zinc-900/20">
                 <div className="flex items-center gap-3">
                    {(() => {
                      const CurrentIcon = sections.find(s => s.id === activeModal)?.icon || HelpCircle;
                      return (
                        <div className="p-3 bg-[#d4af37]/10 rounded-xl text-[#d4af37] border border-[#d4af37]/20">
                           <CurrentIcon size={24} />
                        </div>
                      );
                    })()}
                    <h3 className="text-xl font-bold text-white tracking-tight">{sections.find(s => s.id === activeModal)?.label}</h3>
                 </div>
                 <button onClick={() => setActiveModal(null)} className="p-2 text-zinc-500 hover:text-white transition-colors bg-zinc-900 rounded-xl border border-zinc-800 hover:border-zinc-700">
                    <X size={20} />
                 </button>
              </div>

              <div className="p-8 overflow-y-auto custom-scrollbar">
                 {renderModalContent()}
              </div>

              <div className="p-6 border-t border-zinc-800 bg-zinc-900/30 flex gap-3 rounded-b-[32px]">
                 <button onClick={() => setActiveModal(null)} className="flex-1 py-3.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 font-bold rounded-xl transition-all border border-zinc-800 hover:border-zinc-700">
                   Cancelar
                 </button>
                 <button 
                   onClick={handleSave} 
                   disabled={isSaving}
                   className="flex-1 py-3.5 gold-gradient text-black font-bold rounded-xl flex items-center justify-center gap-2 hover:opacity-90 active:scale-95 transition-all disabled:opacity-50 shadow-lg shadow-[#d4af37]/10"
                 >
                   {isSaving ? <Loader2 size={18} className="animate-spin" /> : 
                     (activeModal === 'support' && supportView === 'ticket') ? <Send size={18} /> : <Save size={18} />}
                   {activeModal === 'security' && securityView !== 'main' ? 'Confirmar' : 
                    activeModal === 'billing' && billingView === 'change-card' ? 'Atualizar Cartão' :
                    activeModal === 'support' && supportView === 'ticket' ? 'Enviar Ticket' : 'Salvar Alterações'}
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Settings;
