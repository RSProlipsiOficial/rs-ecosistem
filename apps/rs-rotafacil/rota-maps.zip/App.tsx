
import React, { useState, useMemo } from 'react';
import MapView from './components/MapView';
import GeminiAssistant from './components/GeminiAssistant';
import RoutePlanner from './components/RoutePlanner';
import Sidebar from './components/Sidebar';
import StudentList from './components/StudentList';
import RouteHistory from './components/RouteHistory';
import { MOCK_STUDENTS, MOCK_HISTORY } from './constants';
import { VanLocation, AddressPoint } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'live' | 'planner' | 'students' | 'history'>('live');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [mapEmbedUrl, setMapEmbedUrl] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isChecklistOpen, setIsChecklistOpen] = useState(true);
  const [showRouteDetails, setShowRouteDetails] = useState(false);
  const [shareFeedback, setShareFeedback] = useState(false);
  
  const [routePoints, setRoutePoints] = useState<AddressPoint[]>([]);
  const [completedStops, setCompletedStops] = useState<Set<string>>(new Set());

  const [vanLocation, setVanLocation] = useState<VanLocation>({
    lat: -23.5617,
    lng: -46.6560,
    speed: 32,
    lastUpdate: new Date().toLocaleTimeString(),
    currentStopIndex: 1,
    address: 'Av. Paulista, 1000',
    neighborhood: 'Bela Vista'
  });

  const routeTelemetry = useMemo(() => {
    if (routePoints.length < 2) return null;
    const segments = routePoints.length - 1;
    const estimatedKm = (segments * 3.5).toFixed(1);
    const estimatedMinutes = segments * 12;
    const now = new Date();
    const arrivalTime = new Date(now.getTime() + estimatedMinutes * 60000);
    const eta = arrivalTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const hours = Math.floor(estimatedMinutes / 60);
    const mins = estimatedMinutes % 60;
    const duration = hours > 0 ? `${hours}h ${mins}min` : `${mins} min`;

    return {
      distance: estimatedKm,
      duration,
      eta,
      traffic: estimatedMinutes > 30 ? 'INTENSO' : 'MODERADO'
    };
  }, [routePoints]);

  const toggleStopCompletion = (id: string) => {
    const newCompleted = new Set(completedStops);
    if (newCompleted.has(id)) newCompleted.delete(id);
    else newCompleted.add(id);
    setCompletedStops(newCompleted);
  };

  const handleActivateRoute = (points: AddressPoint[], embedUrl: string) => {
    setRoutePoints(points);
    setMapEmbedUrl(embedUrl);
    setActiveTab('live');
    setIsChecklistOpen(true);
    setShowRouteDetails(true);
  };

  const handleAISync = async (extracted: {cep: string, number: string}[]) => {
    const newPoints: AddressPoint[] = [];
    for (const item of extracted) {
      try {
        const response = await fetch(`https://viacep.com.br/ws/${item.cep}/json/`);
        const data = await response.json();
        newPoints.push({
          id: Math.random().toString(),
          cep: item.cep,
          number: item.number,
          fullAddress: data.erro ? 'CEP Inválido' : `${data.logradouro}, ${data.bairro}, ${data.localidade}`,
          loading: false
        });
      } catch {
        newPoints.push({
          id: Math.random().toString(),
          cep: item.cep,
          number: item.number,
          fullAddress: 'Erro de Conexão',
          loading: false
        });
      }
    }
    setRoutePoints(newPoints);
    const valid = newPoints.filter(p => !p.fullAddress.includes('Erro') && !p.fullAddress.includes('Inválido'));
    if (valid.length >= 2) {
      const origin = encodeURIComponent(`${valid[0].fullAddress}, ${valid[0].number}`);
      const destination = encodeURIComponent(`${valid[valid.length-1].fullAddress}, ${valid[valid.length-1].number}`);
      const waypoints = valid.slice(1, -1).map(p => encodeURIComponent(`${p.fullAddress}, ${p.number}`)).join('|');
      const embedUrl = `https://www.google.com/maps?saddr=${origin}&daddr=${destination}${waypoints ? '&waypoints=' + waypoints : ''}&output=embed&layer=t`;
      handleActivateRoute(newPoints, embedUrl);
    }
  };

  const handleShareStatus = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!routeTelemetry) return;
    
    const text = `Rota-Maps | Status em Tempo Real\nChegada Prevista: ${routeTelemetry.eta}\nDistância: ${routeTelemetry.distance} km\nTempo Restante: ${routeTelemetry.duration}`;
    
    setShareFeedback(true);
    setTimeout(() => setShareFeedback(false), 2000);

    const shareData: ShareData = {
      title: 'Status da Rota Escolar',
      text: text,
    };

    // Só anexa a URL se for uma URL web válida (evita erro Invalid URL em sandboxes)
    if (window.location.href.startsWith('http')) {
      shareData.url = window.location.href;
    }

    try {
      if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(text);
      }
    } catch (error) {
      console.warn('Share API falhou, usando clipboard:', error);
      await navigator.clipboard.writeText(text);
    }
  };

  return (
    <div className={`h-screen w-screen bg-black text-white overflow-hidden flex flex-col relative ${isFullscreen ? 'fixed inset-0 z-[9999]' : ''}`}>
      <Sidebar 
        isOpen={isSidebarOpen} 
        onClose={() => setIsSidebarOpen(false)} 
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          setIsSidebarOpen(false);
        }}
      />

      <header className="absolute top-6 left-6 z-[1000]">
        <button 
          onClick={() => setIsSidebarOpen(true)}
          className="w-14 h-14 rounded-2xl bg-black/80 backdrop-blur-xl border border-white/10 flex items-center justify-center text-[#D4AF37] hover:scale-110 active:scale-95 transition-all shadow-2xl"
        >
          <i className="fas fa-bars text-xl"></i>
        </button>
      </header>

      <div className="absolute top-6 left-1/2 -translate-x-1/2 z-[1000] w-full max-w-2xl px-4 pointer-events-none">
        <div className="pointer-events-auto">
          <GeminiAssistant onApplyRoute={handleAISync} />
        </div>
      </div>

      <main className="absolute inset-0 z-0">
        <MapView 
          vanLocation={vanLocation} 
          embedUrl={mapEmbedUrl} 
          routePoints={routePoints}
          completedStops={completedStops}
        />
      </main>

      {activeTab !== 'live' && (
        <div className="absolute inset-0 z-[2000] bg-black/40 backdrop-blur-md flex items-center justify-center p-8 animate-fade-in">
          <div className="bg-zinc-900/90 border border-white/10 w-full max-w-4xl h-[85vh] rounded-[3rem] shadow-2xl overflow-hidden flex flex-col relative">
            <button 
              onClick={() => setActiveTab('live')}
              className="absolute top-6 right-8 z-[10] w-12 h-12 bg-black/50 rounded-full flex items-center justify-center text-zinc-500 hover:text-white transition-all"
            >
              <i className="fas fa-times"></i>
            </button>
            <div className="p-10 overflow-y-auto h-full scrollbar-hide">
              {activeTab === 'planner' && <RoutePlanner onRouteActivate={handleActivateRoute} initialPoints={routePoints} />}
              {activeTab === 'students' && <StudentList students={MOCK_STUDENTS} />}
              {activeTab === 'history' && <RouteHistory history={MOCK_HISTORY} />}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'live' && routePoints.length > 0 && (
        <div className={`absolute bottom-0 left-1/2 -translate-x-1/2 z-[1000] w-full max-w-3xl transition-all duration-500 ${isChecklistOpen ? 'translate-y-0' : 'translate-y-[calc(100%-60px)]'}`}>
          <div className="bg-black/80 backdrop-blur-3xl border-t border-x border-white/10 rounded-t-[3rem] shadow-[0_-20px_50px_rgba(0,0,0,0.5)] overflow-hidden">
            <button 
              onClick={() => setIsChecklistOpen(!isChecklistOpen)}
              className="w-full py-4 flex flex-col items-center gap-2 hover:bg-white/5 transition-colors group"
            >
              <div className="w-12 h-1.5 bg-zinc-800 rounded-full group-hover:bg-[#D4AF37] transition-colors"></div>
              <span className="text-[10px] font-black gold-text uppercase tracking-[0.3em]">Ordem de Serviço • {completedStops.size}/{routePoints.length}</span>
            </button>
            <div className="px-8 pb-10 max-h-[400px] overflow-y-auto scrollbar-hide">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {routePoints.map((p, idx) => (
                  <div key={p.id} className={`p-5 rounded-3xl border flex items-center gap-4 transition-all ${completedStops.has(p.id) ? 'bg-emerald-500/5 border-emerald-500/20 opacity-40' : 'bg-zinc-900/50 border-zinc-800 hover:border-[#D4AF37]/40'}`}>
                    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-black text-xs ${completedStops.has(p.id) ? 'bg-emerald-500 text-black' : 'gold-gradient text-black'}`}>
                      {idx + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[11px] font-bold text-white truncate">{p.fullAddress.split(',')[0]}</p>
                      <p className="text-[9px] text-zinc-500 uppercase">Nº {p.number} • CEP {p.cep}</p>
                    </div>
                    <button 
                      onClick={() => toggleStopCompletion(p.id)}
                      className="w-12 h-12 rounded-2xl border border-zinc-800 flex items-center justify-center text-zinc-500 hover:text-emerald-500 hover:border-emerald-500 transition-all"
                    >
                      <i className={`fas ${completedStops.has(p.id) ? 'fa-check-double text-emerald-400' : 'fa-check'}`}></i>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="absolute bottom-10 right-8 z-[1500] flex flex-col items-end gap-4 pointer-events-none">
        
        {routeTelemetry && showRouteDetails && (
          <div className="pointer-events-auto bg-[#1A1A1A]/95 backdrop-blur-2xl border border-white/5 p-6 rounded-[2rem] shadow-[0_30px_60px_rgba(0,0,0,0.8)] w-72 mb-2 animate-fade-in-up">
            <div className="flex items-center justify-between mb-6 border-b border-white/5 pb-3">
              <h3 className="text-[11px] font-black text-[#D4AF37] uppercase tracking-[0.2em]">Resumo do Trajeto</h3>
              <button onClick={() => setShowRouteDetails(false)} className="text-zinc-600 hover:text-white transition-colors">
                <i className="fas fa-times text-sm"></i>
              </button>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 text-zinc-500">
                  <i className="fas fa-road text-sm"></i>
                  <span className="text-[10px] font-black uppercase tracking-widest">Distância</span>
                </div>
                <span className="text-sm font-black text-white">{routeTelemetry.distance} km</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 text-zinc-500">
                  <i className="fas fa-hourglass-half text-sm"></i>
                  <span className="text-[10px] font-black uppercase tracking-widest">Tempo</span>
                </div>
                <span className="text-sm font-black text-white">{routeTelemetry.duration}</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 text-zinc-500">
                  <i className="fas fa-flag-checkered text-sm"></i>
                  <span className="text-[10px] font-black uppercase tracking-widest">Chegada</span>
                </div>
                <span className="text-sm font-black text-[#D4AF37]">{routeTelemetry.eta}</span>
              </div>
               
               <div className="mt-4 pt-4 border-t border-white/5 flex items-center gap-3 justify-center">
                  <div className={`w-2 h-2 rounded-full ${routeTelemetry.traffic === 'INTENSO' ? 'bg-[#FF3B30] shadow-[0_0_8px_#FF3B30]' : 'bg-[#34C759] shadow-[0_0_8px_#34C759]'}`}></div>
                  <span className="text-[9px] uppercase font-black text-zinc-500 tracking-[0.1em]">Tráfego {routeTelemetry.traffic}</span>
               </div>

               <button 
                  onClick={handleShareStatus}
                  className={`w-full mt-4 py-4 rounded-2xl flex items-center justify-center gap-4 group transition-all duration-300 border ${shareFeedback ? 'bg-[#34C759] border-[#34C759] text-black' : 'bg-black/40 border-white/5 hover:bg-black/60 text-white active:scale-95 cursor-pointer pointer-events-auto'}`}
                >
                  <i className={`fas ${shareFeedback ? 'fa-check' : 'fa-share-nodes'} ${shareFeedback ? 'text-black' : 'text-[#D4AF37]'} group-hover:scale-110 transition-transform`}></i>
                  <span className={`text-[10px] font-black uppercase tracking-[0.2em] ${shareFeedback ? 'text-black' : 'text-zinc-200'} group-hover:text-white transition-colors`}>
                    {shareFeedback ? 'Status Copiado!' : 'Compartilhar Rota'}
                  </span>
                </button>
            </div>
          </div>
        )}

        {routeTelemetry && (
          <button 
            onClick={() => setShowRouteDetails(!showRouteDetails)}
            className={`pointer-events-auto w-14 h-14 rounded-2xl backdrop-blur-xl border flex items-center justify-center transition-all shadow-2xl ${showRouteDetails ? 'bg-[#D4AF37] text-black border-[#D4AF37]' : 'bg-black/60 text-white border-white/10 hover:text-[#D4AF37]'}`}
          >
            <i className="fas fa-info-circle text-xl"></i>
          </button>
        )}

        <button 
          onClick={() => setIsFullscreen(!isFullscreen)}
          className="pointer-events-auto w-14 h-14 rounded-2xl bg-black/60 backdrop-blur-xl border border-white/10 flex items-center justify-center text-white hover:text-[#D4AF37] transition-all shadow-2xl"
        >
          <i className={`fas ${isFullscreen ? 'fa-compress' : 'fa-expand'}`}></i>
        </button>
      </div>
    </div>
  );
};

export default App;
