
import React, { useState, useRef, useEffect } from 'react';
import { getSmartTransportInsights } from '../services/geminiService';

interface GeminiAssistantProps {
  onApplyRoute?: (points: {cep: string, number: string}[]) => void;
}

const GeminiAssistant: React.FC<GeminiAssistantProps> = ({ onApplyRoute }) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{explanation: string, points: any[]} | null>(null);
  const [showResult, setShowResult] = useState(false);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    setLoading(true);
    const data = await getSmartTransportInsights(input);
    setResult({ explanation: data.explanation, points: data.extractedPoints });
    setLoading(false);
    setShowResult(true);
    setInput('');
  };

  return (
    <div className="relative w-full">
      {/* Barra de Input Estilo Comando */}
      <div className="bg-black/60 backdrop-blur-3xl border border-white/10 rounded-full p-2 flex items-center gap-3 shadow-[0_20px_60px_rgba(0,0,0,0.6)]">
        <div className="w-12 h-12 gold-gradient rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
          <i className="fas fa-magic text-black"></i>
        </div>
        <input 
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Cole CEPs e números para sincronizar..."
          className="flex-1 bg-transparent border-none outline-none text-sm text-white placeholder:text-zinc-600 font-medium px-2"
        />
        <button 
          onClick={handleSend}
          disabled={loading || !input.trim()}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${loading ? 'bg-zinc-800' : 'bg-white/5 hover:bg-white/10 text-[#D4AF37]'}`}
        >
          {loading ? (
            <i className="fas fa-circle-notch animate-spin"></i>
          ) : (
            <i className="fas fa-arrow-right"></i>
          )}
        </button>
      </div>

      {/* Card de Resultado Suspenso */}
      {showResult && result && (
        <div className="absolute top-20 left-0 right-0 bg-zinc-900/95 backdrop-blur-3xl border border-[#D4AF37]/30 rounded-[2.5rem] p-6 shadow-2xl animate-fade-in-down">
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-[10px] font-black gold-text uppercase tracking-widest mb-1">IA de Logística</p>
              <p className="text-xs text-zinc-300 font-medium">{result.explanation}</p>
            </div>
            <button onClick={() => setShowResult(false)} className="text-zinc-500 hover:text-white">
              <i className="fas fa-times"></i>
            </button>
          </div>

          <div className="flex flex-wrap gap-2 mb-6 max-h-32 overflow-y-auto scrollbar-hide">
            {result.points.map((p, i) => (
              <div key={i} className="bg-black/50 border border-zinc-800 px-3 py-2 rounded-xl text-[9px] font-mono flex items-center gap-2">
                <span className="text-zinc-500">CEP:</span> {p.cep} 
                <span className="text-zinc-500">Nº:</span> <span className="text-[#D4AF37]">{p.number}</span>
              </div>
            ))}
          </div>

          <button 
            onClick={() => {
              onApplyRoute?.(result.points);
              setShowResult(false);
            }}
            className="w-full py-4 gold-gradient text-black rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] shadow-lg hover:scale-[1.02] active:scale-95 transition-all"
          >
            Sincronizar Monitoramento Agora
          </button>
        </div>
      )}
    </div>
  );
};

export default GeminiAssistant;
