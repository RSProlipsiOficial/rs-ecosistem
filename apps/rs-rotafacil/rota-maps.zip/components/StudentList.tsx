
import React from 'react';
import { Student, StudentStatus } from '../types';

interface StudentListProps {
  students: Student[];
}

const StudentList: React.FC<StudentListProps> = ({ students }) => {
  const getStatusConfig = (status: StudentStatus) => {
    switch (status) {
      case StudentStatus.TRANSIT:
        return { 
          color: 'text-yellow-500', 
          bg: 'bg-yellow-500/10', 
          label: 'Em Trânsito',
          dot: 'bg-yellow-500',
          glow: 'shadow-[0_0_10px_rgba(212,175,55,0.4)]'
        };
      case StudentStatus.SCHOOL:
        return { 
          color: 'text-emerald-400', 
          bg: 'bg-emerald-400/10', 
          label: 'Na Escola',
          dot: 'bg-emerald-400',
          glow: 'shadow-[0_0_10px_rgba(52,211,153,0.4)]'
        };
      case StudentStatus.HOME:
        return { 
          color: 'text-sky-400', 
          bg: 'bg-sky-400/10', 
          label: 'Em Casa',
          dot: 'bg-sky-400',
          glow: 'shadow-[0_0_10px_rgba(56,189,248,0.4)]'
        };
      default:
        return { 
          color: 'text-zinc-500', 
          bg: 'bg-zinc-500/10', 
          label: 'Indisponível',
          dot: 'bg-zinc-500',
          glow: ''
        };
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between border-b border-zinc-800/50 pb-4">
        <h2 className="text-xl font-black gold-text italic tracking-wider flex items-center gap-3">
          <i className="fas fa-user-graduate"></i>
          ALUNOS
        </h2>
        <div className="bg-zinc-900 px-3 py-1 rounded-full border border-zinc-800">
          <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">
            {students.length} Monitorados
          </span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 gap-5">
        {students.map(student => {
          const config = getStatusConfig(student.status);
          return (
            <div 
              key={student.id} 
              className="group relative bg-gradient-to-br from-zinc-900 to-black border border-zinc-800/80 p-6 rounded-[2.5rem] flex items-center gap-6 hover:border-yellow-500/40 transition-all duration-500 shadow-xl"
            >
              {/* Efeito de brilho sutil no fundo ao passar o mouse */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/5 blur-[50px] rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
              
              {/* Container da Foto de Luxo */}
              <div className="relative flex-shrink-0">
                <div className="w-20 h-20 rounded-full p-[3px] bg-gradient-to-tr from-yellow-700 via-yellow-300 to-yellow-800 shadow-[0_8px_20px_rgba(0,0,0,0.5)] group-hover:scale-105 transition-transform duration-500">
                  <div className="w-full h-full rounded-full border-[3px] border-black overflow-hidden relative">
                    <img 
                      src={student.photo} 
                      alt={student.name} 
                      className="w-full h-full object-cover grayscale-[20%] group-hover:grayscale-0 transition-all duration-700 scale-100 group-hover:scale-110" 
                    />
                    {/* Overlay sutil na imagem */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                  </div>
                </div>
                {/* Indicador de status elegante */}
                <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full border-4 border-black ${config.dot} ${config.glow} z-10 animate-pulse`}></div>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <h3 className="text-lg font-black text-zinc-100 group-hover:text-yellow-500 transition-colors duration-300 truncate">
                    {student.name}
                  </h3>
                  <div className={`flex-shrink-0 px-3 py-1 rounded-full ${config.bg} ${config.color} border border-current/20`}>
                    <span className="text-[9px] font-black uppercase tracking-[0.15em]">{config.label}</span>
                  </div>
                </div>
                
                <div className="flex flex-wrap items-center gap-4 text-zinc-500">
                  <div className="flex items-center gap-1.5">
                    <i className="far fa-clock text-[10px] text-yellow-500/70"></i>
                    <span className="text-[10px] font-medium uppercase tracking-wider">Visto às {student.lastUpdated}</span>
                  </div>
                  <div className="w-1 h-1 bg-zinc-700 rounded-full"></div>
                  <div className="flex items-center gap-1.5">
                    <i className="fas fa-map-marker-alt text-[10px] text-yellow-500/70"></i>
                    <span className="text-[10px] font-medium uppercase tracking-wider">Rota Padrão</span>
                  </div>
                </div>
              </div>

              <button className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-600 hover:text-yellow-500 hover:border-yellow-500/50 hover:bg-black transition-all group/btn shadow-inner">
                <i className="fas fa-chevron-right text-sm group-hover/btn:translate-x-0.5 transition-transform"></i>
              </button>
            </div>
          );
        })}
      </div>

      <div className="relative group">
        <div className="absolute -inset-0.5 bg-gradient-to-r from-yellow-700 to-yellow-400 rounded-2xl blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>
        <button className="relative w-full py-5 bg-black border border-zinc-800 rounded-2xl text-[10px] font-black uppercase tracking-[0.4em] text-yellow-500/80 hover:text-yellow-400 transition-all flex items-center justify-center gap-3">
          <span>Relatório Detalhado de Frequência</span>
          <i className="fas fa-external-link-alt text-[10px] opacity-50 group-hover:translate-y-[-2px] group-hover:translate-x-[2px] transition-transform"></i>
        </button>
      </div>
    </div>
  );
};

export default StudentList;
