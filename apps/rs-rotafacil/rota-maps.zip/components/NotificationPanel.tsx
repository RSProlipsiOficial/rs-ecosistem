
import React from 'react';
import { Notification } from '../types';

interface NotificationPanelProps {
  notifications: Notification[];
}

const NotificationPanel: React.FC<NotificationPanelProps> = ({ notifications }) => {
  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-2xl overflow-hidden">
      <h3 className="text-xl font-bold gold-text mb-4 flex items-center gap-2">
        <i className="fas fa-bell"></i>
        Atividade Recente
      </h3>
      <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2 scrollbar-hide">
        {notifications.length === 0 && (
          <p className="text-zinc-500 text-sm italic text-center py-4">Nenhuma atividade registrada.</p>
        )}
        {notifications.map((n) => (
          <div key={n.id} className="relative pl-6 border-l border-yellow-500/30 pb-4 last:pb-0">
            <div className="absolute left-[-5px] top-0 w-2.5 h-2.5 rounded-full bg-yellow-500 shadow-[0_0_8px_rgba(212,175,55,0.8)]"></div>
            <div className="text-[10px] text-zinc-500 font-bold uppercase mb-1">{n.time}</div>
            <div className="bg-black/40 p-3 rounded-xl border border-zinc-800 hover:border-yellow-500/30 transition-colors">
              <h4 className="text-sm font-bold text-white">{n.title}</h4>
              <p className="text-xs text-zinc-400 mt-1">{n.message}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NotificationPanel;
