
import React from 'react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: string;
  setActiveTab: (tab: any) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'live', label: 'Monitoramento', icon: 'fa-tower-broadcast' },
    { id: 'planner', label: 'Otimizar Rota', icon: 'fa-route' },
    { id: 'history', label: 'Histórico Logístico', icon: 'fa-clock-rotate-left' },
    { id: 'students', label: 'Gestão de Alunos', icon: 'fa-user-graduate' },
  ];

  const handleSelect = (id: string) => {
    setActiveTab(id);
    onClose();
  };

  return (
    <>
      {/* Overlay com Z-Index altíssimo */}
      <div 
        className={`fixed inset-0 bg-black/80 backdrop-blur-md z-[8000] transition-opacity duration-500 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />
      
      {/* Sidebar Drawer com Z-Index altíssimo */}
      <div className={`fixed top-0 left-0 h-full w-80 bg-black border-r border-zinc-800 z-[8001] transition-transform duration-500 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-8 flex flex-col h-full">
          <div className="flex items-center justify-between mb-12">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 gold-gradient rounded-xl flex items-center justify-center">
                <i className="fas fa-bus text-black"></i>
              </div>
              <span className="text-xl font-black gold-text italic tracking-tighter">ROTA-MAPS</span>
            </div>
            <button onClick={onClose} className="text-zinc-500 hover:text-[#D4AF37] transition-colors">
              <i className="fas fa-xmark text-2xl"></i>
            </button>
          </div>

          <nav className="flex-1 space-y-4">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id)}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all group ${
                  activeTab === item.id 
                    ? 'bg-zinc-900 border border-[#D4AF37]/30 text-[#D4AF37]' 
                    : 'text-zinc-500 hover:bg-zinc-900/50 hover:text-zinc-300'
                }`}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                  activeTab === item.id ? 'bg-[#D4AF37] text-black shadow-lg shadow-[#D4AF37]/20' : 'bg-zinc-900 text-zinc-600 group-hover:text-[#D4AF37]'
                }`}>
                  <i className={`fas ${item.icon}`}></i>
                </div>
                <span className="font-black text-[10px] uppercase tracking-[0.2em]">{item.label}</span>
              </button>
            ))}
          </nav>

          <div className="mt-auto pt-8 border-t border-zinc-800">
            <div className="flex items-center gap-4 bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800">
               <div className="w-12 h-12 rounded-full gold-gradient p-0.5">
                  <img src="https://i.pravatar.cc/150?u=carlos" className="w-full h-full rounded-full border-2 border-black object-cover" />
               </div>
               <div>
                  <p className="text-[8px] text-zinc-500 font-black uppercase tracking-widest">Premium Partner</p>
                  <p className="text-xs font-black text-white italic">Carlos Eduardo</p>
               </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
