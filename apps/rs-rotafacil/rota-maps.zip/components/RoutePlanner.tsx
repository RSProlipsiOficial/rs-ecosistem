
import React, { useState } from 'react';
import { AddressPoint } from '../types';

interface RoutePlannerProps {
  onRouteActivate?: (newPoints: AddressPoint[], embedUrl: string) => void;
  initialPoints?: AddressPoint[];
}

const RoutePlanner: React.FC<RoutePlannerProps> = ({ onRouteActivate, initialPoints = [] }) => {
  const [points, setPoints] = useState<AddressPoint[]>(
    initialPoints.length > 0 ? initialPoints : [
      { id: '1', cep: '', number: '', fullAddress: '', loading: false },
      { id: '2', cep: '', number: '', fullAddress: '', loading: false }
    ]
  );

  const fetchAddress = async (index: number, cep: string) => {
    const cleanCep = cep.replace(/\D/g, '');
    if (cleanCep.length !== 8) return;

    const newPoints = [...points];
    newPoints[index].loading = true;
    setPoints(newPoints);

    try {
      const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
      const data = await response.json();
      
      if (!data.erro) {
        const updatedPoints = [...points];
        updatedPoints[index].fullAddress = `${data.logradouro}, ${data.bairro}, ${data.localidade}`;
        updatedPoints[index].loading = false;
        setPoints(updatedPoints);
      } else {
        const updatedPoints = [...points];
        updatedPoints[index].loading = false;
        setPoints(updatedPoints);
      }
    } catch (error) {
      console.error('Erro CEP:', error);
      const updatedPoints = [...points];
      updatedPoints[index].loading = false;
      setPoints(updatedPoints);
    }
  };

  const addPoint = () => {
    const newPoint = { id: Math.random().toString(), cep: '', number: '', fullAddress: '', loading: false };
    setPoints([...points, newPoint]);
  };
  
  const updatePoint = (index: number, field: keyof AddressPoint, value: string) => {
    const newPoints = [...points];
    (newPoints[index] as any)[field] = value;
    setPoints(newPoints);

    if (field === 'cep' && value.replace(/\D/g, '').length === 8) {
      fetchAddress(index, value);
    }
  };

  const removePoint = (index: number) => {
    if (points.length > 2) {
      setPoints(points.filter((_, i) => i !== index));
    }
  };

  const handleApply = () => {
    const validPoints = points.filter(p => p.fullAddress && p.number);
    if (validPoints.length < 2) {
      alert('Insira ao menos 2 endereços completos (CEP + Número).');
      return;
    }
    
    // Simulação da rota no Google Maps para o iframe
    const origin = encodeURIComponent(`${validPoints[0].fullAddress}, ${validPoints[0].number}`);
    const destination = encodeURIComponent(`${validPoints[validPoints.length-1].fullAddress}, ${validPoints[validPoints.length-1].number}`);
    const waypoints = validPoints.slice(1, -1).map(p => encodeURIComponent(`${p.fullAddress}, ${p.number}`)).join('|');
    const embedUrl = `https://www.google.com/maps?saddr=${origin}&daddr=${destination}${waypoints ? '&waypoints=' + waypoints : ''}&output=embed&layer=t`;
    
    onRouteActivate?.(validPoints, embedUrl);
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="space-y-4">
        {points.map((p, idx) => (
          <div key={p.id} className="p-5 bg-black/40 border border-zinc-800 rounded-3xl relative group hover:border-[#D4AF37]/40 transition-all shadow-inner">
            <div className="flex items-center justify-between mb-4">
              <span className="text-[9px] font-black gold-text uppercase tracking-widest">
                {idx === 0 ? 'Ponto de Partida' : idx === points.length - 1 ? 'Ponto Final' : `Parada ${idx + 1}`}
              </span>
              {points.length > 2 && (
                <button onClick={() => removePoint(idx)} className="w-6 h-6 rounded-lg bg-zinc-900 flex items-center justify-center text-zinc-600 hover:text-red-500 transition-colors">
                  <i className="fas fa-trash text-[8px]"></i>
                </button>
              )}
            </div>
            
            <div className="grid grid-cols-5 gap-3">
              <div className="col-span-3">
                <input
                  type="text"
                  placeholder="CEP"
                  maxLength={8}
                  value={p.cep}
                  onChange={(e) => updatePoint(idx, 'cep', e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl px-4 py-3 text-[10px] text-[#D4AF37] font-mono focus:border-[#D4AF37] outline-none transition-all placeholder:text-zinc-700"
                />
              </div>
              <div className="col-span-2">
                <input
                  type="text"
                  placeholder="Nº"
                  value={p.number}
                  onChange={(e) => updatePoint(idx, 'number', e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl px-4 py-3 text-[10px] text-white focus:border-[#D4AF37] outline-none placeholder:text-zinc-700"
                />
              </div>
            </div>
            
            <div className="mt-3 min-h-[1rem]">
              {p.loading ? (
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-[#D4AF37] rounded-full animate-pulse"></div>
                  <span className="text-[8px] text-zinc-600 uppercase font-black">Localizando Endereço...</span>
                </div>
              ) : (
                <p className="text-[9px] text-zinc-500 italic truncate font-medium">
                  {p.fullAddress || 'Aguardando CEP válido...'}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      <button 
        onClick={addPoint}
        className="w-full py-5 border-2 border-dashed border-zinc-800 rounded-3xl text-zinc-600 hover:text-[#D4AF37] hover:border-[#D4AF37]/50 transition-all flex items-center justify-center gap-3 text-[10px] font-black uppercase tracking-widest bg-zinc-950/50"
      >
        <i className="fas fa-plus-circle"></i> Novo Endereço
      </button>

      <div className="pt-4 sticky bottom-0 bg-transparent">
        <button
          onClick={handleApply}
          className="w-full py-6 gold-gradient text-black rounded-[2.5rem] font-black text-[12px] uppercase tracking-[0.2em] shadow-[0_15px_40px_rgba(212,175,55,0.3)] hover:scale-[1.02] active:scale-95 transition-all"
        >
          <i className="fas fa-satellite-dish mr-3"></i>
          Atualizar Central
        </button>
      </div>
    </div>
  );
};

export default RoutePlanner;
