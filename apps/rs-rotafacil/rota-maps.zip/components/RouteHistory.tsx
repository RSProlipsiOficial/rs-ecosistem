
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { RouteHistoryEntry, RouteStop } from '../types';

interface RouteHistoryProps {
  history: RouteHistoryEntry[];
}

type FilterType = 'all' | 'today' | 'yesterday' | 'week';

const RouteHistoryMap: React.FC<{ entry: RouteHistoryEntry }> = ({ entry }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const L = (window as any).L;
    
    mapRef.current = L.map(containerRef.current, {
      center: [entry.stops[0].lat, entry.stops[0].lng],
      zoom: 14,
      scrollWheelZoom: false,
      attributionControl: false
    });

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png').addTo(mapRef.current);

    const coords = entry.stops.map(s => [s.lat, s.lng]);
    
    // Rota percorrida
    L.polyline(coords, {
      color: '#D4AF37',
      weight: 4,
      opacity: 0.8
    }).addTo(mapRef.current);

    // Marcadores das paradas
    entry.stops.forEach((stop, i) => {
      const isFirst = i === 0;
      const isLast = i === entry.stops.length - 1;
      
      const dotIcon = L.divIcon({
        html: `
          <div class="w-3 h-3 bg-${isFirst ? 'green-500' : isLast ? 'red-500' : 'yellow-500'} rounded-full border border-black shadow-lg"></div>
        `,
        className: '',
        iconSize: [12, 12]
      });

      L.marker([stop.lat, stop.lng], { icon: dotIcon }).addTo(mapRef.current);
    });

    // Ajusta o mapa para caber a rota
    const bounds = L.polyline(coords).getBounds();
    mapRef.current.fitBounds(bounds, { padding: [30, 30] });

    return () => {
      if (mapRef.current) mapRef.current.remove();
    };
  }, [entry]);

  return <div ref={containerRef} className="w-full h-full"></div>;
};

const RouteHistory: React.FC<RouteHistoryProps> = ({ history }) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  const filteredHistory = useMemo(() => {
    switch (activeFilter) {
      case 'today': return history.filter(h => h.date === "15 Mai 2024");
      case 'yesterday': return history.filter(h => h.date === "14 Mai 2024");
      default: return history;
    }
  }, [history, activeFilter]);

  const handleShareEntry = async (entry: RouteHistoryEntry) => {
    const text = `Rota-Maps | Relatório de ${entry.date}\nHistórico da rota escolar do dia ${entry.date} (${entry.startTime} - ${entry.endTime}).`;
    
    const shareData: ShareData = {
      title: `Rota-Maps | Relatório de ${entry.date}`,
      text: text,
    };

    // Validação de URL
    if (window.location.href.startsWith('http')) {
      shareData.url = window.location.href;
    }

    try {
      if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(text);
        setCopyFeedback(entry.id);
        setTimeout(() => setCopyFeedback(null), 3000);
      }
    } catch (err) {
      console.warn('Erro ao compartilhar rota, usando fallback:', err);
      await navigator.clipboard.writeText(text);
      setCopyFeedback(entry.id);
      setTimeout(() => setCopyFeedback(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-2">
        <h2 className="text-2xl font-black italic gold-text tracking-tighter uppercase">Histórico Logístico</h2>
        <div className="flex gap-2 p-1 bg-zinc-900 border border-zinc-800 rounded-2xl">
          {(['all', 'today', 'yesterday'] as FilterType[]).map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${activeFilter === f ? 'bg-[#D4AF37] text-black shadow-lg' : 'text-zinc-500 hover:text-white'}`}
            >
              {f === 'all' ? 'Ver Tudo' : f === 'today' ? 'Hoje' : 'Ontem'}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {filteredHistory.map((entry) => (
          <div key={entry.id} className={`group bg-zinc-900/30 border ${expandedId === entry.id ? 'border-[#D4AF37]/50' : 'border-zinc-800'} rounded-[2.5rem] overflow-hidden transition-all duration-500 shadow-xl`}>
            <div className="p-8 cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-6" onClick={() => setExpandedId(expandedId === entry.id ? null : entry.id)}>
              <div className="flex items-center gap-6">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${expandedId === entry.id ? 'gold-gradient text-black shadow-lg' : 'bg-black text-[#D4AF37]'}`}>
                  <i className="fas fa-clock-rotate-left"></i>
                </div>
                <div>
                  <div className="text-lg font-black text-white">{entry.date}</div>
                  <div className="text-[9px] text-zinc-500 font-black uppercase tracking-widest">{entry.startTime} às {entry.endTime}</div>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <div className="text-[8px] text-zinc-600 uppercase font-black tracking-widest">Distância</div>
                  <div className="text-sm font-black text-white">{entry.distance}</div>
                </div>
                <button className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${expandedId === entry.id ? 'rotate-180 bg-[#D4AF37] text-black' : 'bg-zinc-800 text-zinc-500'}`}>
                  <i className="fas fa-chevron-down"></i>
                </button>
              </div>
            </div>

            {expandedId === entry.id && (
              <div className="px-8 pb-8 pt-2 border-t border-zinc-800/50 animate-fade-in">
                <div className="relative w-full h-64 bg-black rounded-3xl overflow-hidden border border-zinc-800 mb-8">
                  <RouteHistoryMap entry={entry} />
                  <div className="absolute top-4 left-4 z-[1000] bg-black/60 backdrop-blur-md border border-zinc-800 px-3 py-1 rounded-full">
                    <span className="text-[7px] font-black text-[#D4AF37] uppercase tracking-widest">Replay da Trajetória</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <h4 className="text-[9px] font-black uppercase tracking-widest text-zinc-500">Log de Paradas</h4>
                    <div className="space-y-3">
                      {entry.stops.map((stop, idx) => (
                        <div key={idx} className="flex items-center justify-between p-3 bg-black/40 border border-zinc-800 rounded-2xl hover:border-[#D4AF37]/30 transition-colors">
                          <div className="flex items-center gap-3">
                            <div className="w-2 h-2 rounded-full bg-[#D4AF37]"></div>
                            <span className="text-xs font-bold text-zinc-300">{stop.name}</span>
                          </div>
                          <span className="text-[10px] font-black text-[#D4AF37]/70 font-mono">{stop.time}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-3xl flex flex-col justify-between shadow-inner">
                    <div>
                      <h4 className="text-[9px] font-black uppercase tracking-widest text-zinc-500 mb-4">Métricas de Performance</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-3 bg-black/50 rounded-2xl border border-zinc-800">
                          <div className="text-[7px] text-zinc-600 font-black uppercase mb-1">Pontualidade</div>
                          <div className="text-sm font-black text-emerald-400">98%</div>
                        </div>
                        <div className="p-3 bg-black/50 rounded-2xl border border-zinc-800">
                          <div className="text-[7px] text-zinc-600 font-black uppercase mb-1">Condução</div>
                          <div className="text-sm font-black text-[#D4AF37]">Premium</div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex flex-col gap-3 mt-8">
                      <button 
                        onClick={() => handleShareEntry(entry)}
                        className={`w-full py-5 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] transition-all duration-300 flex items-center justify-center gap-4 shadow-xl relative overflow-hidden group/share
                          ${copyFeedback === entry.id 
                            ? 'bg-emerald-500 text-black' 
                            : 'gold-gradient text-black hover:scale-[1.03] hover:shadow-[#D4AF37]/30 active:scale-95'}`}
                      >
                        <div className="absolute inset-0 bg-white/10 opacity-0 group-hover/share:opacity-100 transition-opacity duration-300"></div>
                        {copyFeedback === entry.id ? (
                          <>
                            <i className="fas fa-check text-sm"></i>
                            Link Copiado com Sucesso
                          </>
                        ) : (
                          <>
                            <i className="fas fa-share-nodes text-lg"></i>
                            <span className="relative z-10">Compartilhar Rota Escolar</span>
                          </>
                        )}
                      </button>
                      <button className="w-full py-4 bg-zinc-800/50 hover:bg-zinc-800 border border-zinc-700 text-zinc-400 hover:text-white font-black text-[10px] uppercase tracking-widest rounded-2xl transition-all active:scale-98">
                        Exportar Relatório Detalhado
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default RouteHistory;
