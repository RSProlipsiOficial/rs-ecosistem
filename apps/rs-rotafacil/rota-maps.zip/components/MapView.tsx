
import React, { useEffect, useRef, useMemo } from 'react';
import { VanLocation, AddressPoint } from '../types';

interface MapViewProps {
  vanLocation: VanLocation;
  embedUrl?: string | null;
  routePoints?: AddressPoint[];
  completedStops?: Set<string>;
}

const MapView: React.FC<MapViewProps> = ({ vanLocation, embedUrl, routePoints = [], completedStops = new Set() }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const vanMarkerRef = useRef<any>(null);
  const routeMarkersRef = useRef<Map<string, any>>(new Map());
  const isFirstRender = useRef(true);

  // Calcula os próximos 3 pontos pendentes
  const nextStops = useMemo(() => {
    return routePoints.filter(p => !completedStops.has(p.id)).slice(0, 3);
  }, [routePoints, completedStops]);

  useEffect(() => {
    if (embedUrl || !mapContainerRef.current || mapRef.current) return;

    const L = (window as any).L;
    
    mapRef.current = L.map(mapContainerRef.current, {
      center: [vanLocation.lat, vanLocation.lng],
      zoom: 16,
      zoomControl: false,
      attributionControl: false,
    });

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      maxZoom: 20,
    }).addTo(mapRef.current);

    const vanIcon = L.divIcon({
      html: `
        <div class="van-marker-wrapper relative">
          <div class="absolute -inset-6 bg-[#D4AF37]/10 rounded-full animate-ping"></div>
          <div class="w-16 h-16 bg-black border-[3px] border-[#D4AF37] rounded-full flex items-center justify-center shadow-[0_0_40px_rgba(212,175,55,0.5)]">
            <i class="fas fa-bus text-[#D4AF37] text-2xl"></i>
          </div>
        </div>
      `,
      className: 'van-marker-icon',
      iconSize: [64, 64],
      iconAnchor: [32, 32]
    });

    vanMarkerRef.current = L.marker([vanLocation.lat, vanLocation.lng], { 
      icon: vanIcon,
      zIndexOffset: 1000 
    }).addTo(mapRef.current);

    return () => {
      if (mapRef.current) mapRef.current.remove();
    };
  }, [embedUrl]);

  useEffect(() => {
    if (mapRef.current && !embedUrl) {
      const L = (window as any).L;
      
      routeMarkersRef.current.forEach((marker, id) => {
        if (!routePoints.find(p => p.id === id)) {
          marker.remove();
          routeMarkersRef.current.delete(id);
        }
      });

      routePoints.forEach((point, idx) => {
        const isCompleted = completedStops.has(point.id);
        
        const latOffset = 0.005 * (idx + 1);
        const lngOffset = 0.002 * (idx + 1);
        const lat = vanLocation.lat + latOffset;
        const lng = vanLocation.lng + lngOffset;

        const stopIcon = L.divIcon({
          html: `
            <div class="relative flex flex-col items-center transition-all duration-700 ${isCompleted ? 'opacity-40 scale-75' : 'scale-100'}">
              <div class="w-10 h-10 ${isCompleted ? 'bg-zinc-800 border-zinc-700' : 'gold-gradient border-black'} rounded-2xl border-2 flex items-center justify-center shadow-2xl font-black ${isCompleted ? 'text-zinc-600' : 'text-black'} text-[10px]">
                ${isCompleted ? '<i class="fas fa-check"></i>' : idx + 1}
              </div>
              <div class="bg-black/95 backdrop-blur-xl px-3 py-1.5 border ${isCompleted ? 'border-zinc-800' : 'border-[#D4AF37]/40'} rounded-xl mt-2 whitespace-nowrap shadow-2xl">
                <span class="text-[8px] font-black ${isCompleted ? 'text-zinc-700' : 'text-white'} uppercase italic">
                  ${point.fullAddress.split(',')[0]}
                </span>
              </div>
            </div>
          `,
          className: '',
          iconSize: [80, 80],
          iconAnchor: [40, 50]
        });

        if (routeMarkersRef.current.has(point.id)) {
          routeMarkersRef.current.get(point.id).setIcon(stopIcon);
        } else {
          const marker = L.marker([lat, lng], { icon: stopIcon }).addTo(mapRef.current);
          routeMarkersRef.current.set(point.id, marker);
        }
      });
    }
  }, [routePoints, completedStops, embedUrl]);

  useEffect(() => {
    if (!embedUrl && vanMarkerRef.current && mapRef.current) {
      const newPos = [vanLocation.lat, vanLocation.lng];
      vanMarkerRef.current.setLatLng(newPos);
      if (isFirstRender.current) {
        mapRef.current.setView(newPos, 16);
        isFirstRender.current = false;
      }
    }
  }, [vanLocation.lat, vanLocation.lng, embedUrl]);

  return (
    <div className="w-full h-full bg-black relative">
      {embedUrl ? (
        <iframe
          src={`${embedUrl}&dark=1`}
          className="w-full h-full border-none grayscale contrast-125"
          allowFullScreen
          loading="lazy"
        ></iframe>
      ) : (
        <div ref={mapContainerRef} className="w-full h-full"></div>
      )}

      {/* Painel Discreto de Próximas Paradas */}
      {!embedUrl && nextStops.length > 0 && (
        <div className="absolute top-8 right-8 z-[1000] w-64 pointer-events-none animate-fade-in-right">
          <div className="bg-black/80 backdrop-blur-2xl border border-white/5 rounded-[2rem] p-5 shadow-[0_20px_50px_rgba(0,0,0,0.5)] pointer-events-auto">
            <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-2">
              <i className="fas fa-list-ul text-[#D4AF37] text-[10px]"></i>
              <span className="text-[9px] font-black gold-text uppercase tracking-[0.2em]">Próximas Paradas</span>
            </div>
            <div className="space-y-4">
              {nextStops.map((stop, idx) => (
                <div key={stop.id} className="flex items-start gap-4 group">
                  <div className="flex flex-col items-center">
                    <div className="w-5 h-5 rounded-lg gold-gradient flex items-center justify-center text-[8px] font-black text-black shadow-sm">
                      {routePoints.indexOf(stop) + 1}
                    </div>
                    {idx < nextStops.length - 1 && (
                      <div className="w-px h-4 bg-zinc-800 my-1"></div>
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[10px] font-bold text-zinc-100 truncate group-hover:text-[#D4AF37] transition-colors">
                      {stop.fullAddress.split(',')[0]}
                    </p>
                    <p className="text-[8px] text-zinc-500 uppercase font-medium">Nº {stop.number}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {!embedUrl && (
        <div className="absolute top-1/2 -translate-y-1/2 right-10 z-[1000] flex flex-col gap-4">
          <button onClick={() => mapRef.current.zoomIn()} className="w-14 h-14 bg-black/60 backdrop-blur-2xl border border-white/10 rounded-3xl text-[#D4AF37] flex items-center justify-center hover:bg-[#D4AF37] hover:text-black transition-all shadow-2xl">
            <i className="fas fa-plus text-lg"></i>
          </button>
          <button onClick={() => mapRef.current.zoomOut()} className="w-14 h-14 bg-black/60 backdrop-blur-2xl border border-white/10 rounded-3xl text-[#D4AF37] flex items-center justify-center hover:bg-[#D4AF37] hover:text-black transition-all shadow-2xl">
            <i className="fas fa-minus text-lg"></i>
          </button>
          <div className="h-px bg-white/10 my-2"></div>
          <button onClick={() => mapRef.current.flyTo([vanLocation.lat, vanLocation.lng], 17)} className="w-14 h-14 gold-gradient text-black rounded-3xl flex items-center justify-center shadow-2xl hover:scale-110 active:scale-90 transition-all">
            <i className="fas fa-crosshairs text-xl"></i>
          </button>
        </div>
      )}
    </div>
  );
};

export default MapView;
