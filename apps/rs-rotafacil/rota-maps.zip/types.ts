
export enum StudentStatus {
  HOME = 'Em Casa',
  TRANSIT = 'No Transporte',
  SCHOOL = 'Na Escola',
  ABSENT = 'Faltou'
}

export interface AddressPoint {
  id: string;
  cep: string;
  number: string;
  fullAddress: string;
  loading: boolean;
}

export interface Student {
  id: string;
  name: string;
  status: StudentStatus;
  photo: string;
  lastUpdated: string;
}

export interface VanLocation {
  lat: number;
  lng: number;
  speed: number;
  lastUpdate: string;
  currentStopIndex: number;
  address?: string;
  neighborhood?: string;
}

export interface RouteStop {
  id: string;
  name: string;
  lat: number;
  lng: number;
  type: 'pickup' | 'school' | 'dropoff';
  time?: string;
}

export interface RouteHistoryEntry {
  id: string;
  date: string;
  startTime: string;
  endTime: string;
  stops: RouteStop[];
  distance: string;
  status: 'concluido' | 'cancelado';
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'info' | 'success' | 'warning';
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
  feedback?: 'positive' | 'negative' | null;
}
