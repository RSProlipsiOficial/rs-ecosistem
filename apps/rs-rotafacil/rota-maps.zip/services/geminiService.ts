
import { GoogleGenAI, Type } from "@google/genai";

export const getSmartTransportInsights = async (userPrompt: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: userPrompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            explanation: {
              type: Type.STRING,
              description: "Explicação de como a rota foi otimizada e qual bairro vem primeiro."
            },
            extractedPoints: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  cep: { type: Type.STRING, description: "CEP formatado (8 dígitos)." },
                  number: { type: Type.STRING, description: "Número da residência." }
                },
                required: ["cep", "number"]
              }
            }
          },
          required: ["explanation", "extractedPoints"]
        },
        systemInstruction: `Você é o Especialista em Logística da Rota-Maps.
        Sua tarefa:
        1. Extrair CEP e Número do texto do usuário.
        2. ORGANIZAR os pontos em uma ordem lógica de percurso. 
        3. Agrupe CEPs que começam com os mesmos números (mesma região).
        4. O último ponto deve ser sempre o que parece ser a escola ou o ponto de destino final.
        5. Na explicação, diga brevemente: "Rota otimizada por proximidade de bairros".`
      },
    });

    const result = JSON.parse(response.text || "{}");
    return result;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return { 
      explanation: "Erro ao otimizar rota. Verifique a conexão.",
      extractedPoints: []
    };
  }
};
