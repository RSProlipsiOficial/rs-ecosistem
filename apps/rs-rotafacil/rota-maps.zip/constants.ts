
import { Student, StudentStatus, RouteStop, RouteHistoryEntry } from './types';

export const COLORS = {
  black: '#000000',
  gold: '#D4AF37',
  goldLight: '#F9E27D',
  goldDark: '#B8860B',
  gray: '#1A1A1A',
};

// Coordenadas reais em São Paulo para efeito profissional
export const MOCK_STOPS: RouteStop[] = [
  { id: 's1', name: 'Garagem Central', lat: -23.5617, lng: -46.6560, type: 'pickup' },
  { id: 's2', name: 'Residencial Jardins', lat: -23.5685, lng: -46.6620, type: 'pickup' },
  { id: 's3', name: 'Colégio Dante Alighieri', lat: -23.5640, lng: -46.6530, type: 'school' },
  { id: 's4', name: 'Ponto de Retorno', lat: -23.5580, lng: -46.6610, type: 'dropoff' },
];

export const MOCK_HISTORY: RouteHistoryEntry[] = [
  {
    id: 'h1',
    date: '15 Mai 2024',
    startTime: '06:45',
    endTime: '07:30',
    distance: '4.2 km',
    status: 'concluido',
    stops: [
      { id: 'p1', name: 'Residencial Jardins', time: '06:55', lat: -23.5685, lng: -46.6620, type: 'pickup' },
      { id: 'p2', name: 'Av. Paulista', time: '07:10', lat: -23.5615, lng: -46.6550, type: 'pickup' },
      { id: 'p3', name: 'Colégio Dante', time: '07:30', lat: -23.5640, lng: -46.6530, type: 'school' },
    ]
  },
  {
    id: 'h2',
    date: '14 Mai 2024',
    startTime: '12:30',
    endTime: '13:15',
    distance: '3.8 km',
    status: 'concluido',
    stops: [
      { id: 'p4', name: 'Colégio Dante', time: '12:30', lat: -23.5640, lng: -46.6530, type: 'school' },
      { id: 'p5', name: 'Residencial Jardins', time: '13:15', lat: -23.5685, lng: -46.6620, type: 'dropoff' },
    ]
  }
];

export const MOCK_STUDENTS: Student[] = [
  {
    id: '1',
    name: 'Enzo Oliveira',
    status: StudentStatus.TRANSIT,
    photo: 'https://i.pravatar.cc/150?u=enzo',
    lastUpdated: '07:12',
  },
  {
    id: '2',
    name: 'Valentina Silva',
    status: StudentStatus.SCHOOL,
    photo: 'https://i.pravatar.cc/150?u=valentina',
    lastUpdated: '07:35',
  },
  {
    id: '3',
    name: 'Arthur Santos',
    status: StudentStatus.HOME,
    photo: 'https://i.pravatar.cc/150?u=arthur',
    lastUpdated: '13:20',
  }
];
