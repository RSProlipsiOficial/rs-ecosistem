import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Aluno, AlunoFormData } from '@/types/alunos';
import { useToast } from '@/hooks/use-toast';
import { usePlanLimits } from '@/hooks/usePlanLimits';

export function useAlunos(vanId?: string) {
  const [alunos, setAlunos] = useState<Aluno[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { limits, refetch: refetchLimits } = usePlanLimits();

  const fetchAlunos = async () => {
    try {
      setLoading(true);
      let query = supabase
        .from('alunos')
        .select('*')
        .eq('ativo', true)
        .order('nome_completo');

      if (vanId) {
        query = query.eq('van_id', vanId);
      }

      const { data, error } = await query;

      if (error) throw error;
      setAlunos(data as Aluno[] || []);
    } catch (error) {
      console.error('Erro ao buscar alunos:', error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar os alunos.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const createAluno = async (alunoData: AlunoFormData) => {
    try {
      // Check plan limits BEFORE creating student
      if (limits && !limits.canAddStudent) {
        toast({
          variant: "destructive",
          title: "Limite Atingido",
          description: `Você atingiu o limite de ${limits.max_alunos} alunos do plano ${limits.planName}. Faça upgrade para adicionar mais alunos.`,
        });
        return null;
      }

      const { data: { session } } = await supabase.auth.getSession();

      if (!session) {
        throw new Error("Usuário não autenticado. Faça login para adicionar alunos.");
      }

      // Sanitize data: remove empty strings for optional UUID fields or numbers
      // Temporarily removing cpf and email as they might be missing in DB
      const { cpf, email, dia_vencimento, ...restData } = alunoData;

      const payload = {
        ...restData,
        dia_vencimento: dia_vencimento || 10,
        van_id: alunoData.van_id || null, // Convert empty string to null for UUID
        user_id: session.user.id
      };

      const { data, error } = await supabase
        .from('alunos')
        .insert([payload])
        .select()
        .single();

      if (error) throw error;

      setAlunos(prev => [...prev, data as Aluno]);

      // Auto-generate payment for current month
      try {
        const today = new Date();
        const mesAtual = today.getMonth() + 1;
        const anoAtual = today.getFullYear();

        // Calculate due date (day from form or default 10)
        const diaVencimento = payload.dia_vencimento || 10;
        const dataVencimento = new Date(anoAtual, mesAtual - 1, diaVencimento);

        const totalValor = Number(payload.valor_mensalidade) + Number(payload.valor_letalidade || 0);

        await supabase.from('pagamentos_mensais').insert({
          aluno_id: data.id,
          mes: mesAtual,
          ano: anoAtual,
          valor: totalValor,
          status: 'nao_pago',
          user_id: session.user.id,
          data_vencimento: dataVencimento.toISOString().split('T')[0]
        });

        toast({
          title: "Financeiro",
          description: "Mensalidade do mês atual gerada automaticamente!",
        });
      } catch (finError) {
        console.error("Erro ao gerar mensalidade inicial:", finError);
        // Don't throw logic error here to not block student creation
      }

      toast({
        title: "Sucesso",
        description: "Aluno adicionado com sucesso!",
      });
      return data;
    } catch (error: any) {
      console.error('Erro ao criar aluno:', error);
      const detail = error.message || error.error_description || "Não foi possível adicionar o aluno.";
      toast({
        title: "Erro de Cadastro",
        description: detail,
        variant: "destructive",
      });
      throw error;
    }
  };

  const updateAluno = async (id: string, alunoData: Partial<AlunoFormData>) => {
    try {
      const { cpf, email, ...safeData } = alunoData;
      const { data, error } = await supabase
        .from('alunos')
        .update(safeData)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      // If fee was updated, propagate to unpaid monthly payments
      if (alunoData.valor_mensalidade !== undefined || alunoData.valor_letalidade !== undefined) {
        const totalNovo = Number(data.valor_mensalidade || 0) + Number(data.valor_letalidade || 0);

        await supabase
          .from('pagamentos_mensais')
          .update({ valor: totalNovo })
          .eq('aluno_id', id)
          .neq('status', 'pago');
        // Trigger tr_sync_payment_to_ledger will handle lancamentos_financeiros
      }

      setAlunos(prev => prev.map(aluno => aluno.id === id ? data as Aluno : aluno));
      toast({
        title: "Sucesso",
        description: "Aluno e pagamentos pendentes atualizados!",
      });
      return data;
    } catch (error) {
      console.error('Erro ao atualizar aluno:', error);
      toast({
        title: "Erro",
        description: "Não foi possível atualizar o aluno.",
        variant: "destructive",
      });
      throw error;
    }
  };

  const deleteAluno = async (id: string) => {
    try {
      const { error } = await supabase
        .from('alunos')
        .update({ ativo: false })
        .eq('id', id);

      if (error) throw error;

      setAlunos(prev => prev.filter(aluno => aluno.id !== id));
      toast({
        title: "Sucesso",
        description: "Aluno removido com sucesso!",
      });
    } catch (error) {
      console.error('Erro ao remover aluno:', error);
      toast({
        title: "Erro",
        description: "Não foi possível remover o aluno.",
        variant: "destructive",
      });
      throw error;
    }
  };

  useEffect(() => {
    fetchAlunos();
  }, [vanId]);

  return {
    alunos,
    loading,
    createAluno,
    updateAluno,
    deleteAluno,
    refetch: fetchAlunos,
  };
}