import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { PresencaDiaria, AlunoComPresenca, ResumoGeralPresenca, ResumoColegioTurnoPresenca } from '@/types/presenca';

export function usePresenca(customUserId?: string) {
  const [presencas, setPresencas] = useState<PresencaDiaria[]>([]);
  const [alunosComPresenca, setAlunosComPresenca] = useState<AlunoComPresenca[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchPresencasEAlunos = async (data?: string) => {
    try {
      setLoading(true);
      const dataConsulta = data || new Date().toISOString().split('T')[0];

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      let userId = customUserId || user.id;
      let vanId = user.user_metadata?.van_id;

      // Determine user role for internal logic
      const meta = user.user_metadata;
      const role = meta?.tipo_usuario || meta?.user_type || 'usuario';

      // If not a custom ID, check if the user is team (motorista/monitora)
      if (!customUserId) {
        if (role === 'motorista' || role === 'monitora') {
          // Try to get sponsor ID from metadata first (more reliable)
          const sponsorId = meta?.sponsor_id || meta?.boss_id;

          if (sponsorId) {
            userId = sponsorId;
          } else {
            // Fallback to usuarios table
            const { data: profile } = await supabase
              .from('usuarios')
              .select('patrocinador_id')
              .eq('id', user.id)
              .maybeSingle();

            if (profile?.patrocinador_id) {
              userId = profile.patrocinador_id;
            }
          }
        }
      }

      // Buscar todos os alunos vinculados ao dono da conta
      let query = supabase
        .from('alunos')
        .select('*')
        .eq('user_id', userId)
        .eq('ativo', true);

      // Se for equipe e tiver uma van vinculada, filtrar estritamente por essa van
      if (vanId) {
        query = query.eq('van_id', vanId);
      }

      const { data: alunos, error: alunosError } = await query;

      if (alunosError) throw alunosError;

      // Buscar presenças do dia para todos os alunos (simplificado, RLS deve cuidar do acesso)
      const { data: presencasData, error: presencasError } = await supabase
        .from('lista_presenca')
        .select('*')
        .eq('data', dataConsulta);

      if (presencasError) throw presencasError;

      // Combinar alunos com suas presenças
      const alunosComPresencaData: AlunoComPresenca[] = (alunos || []).map(aluno => {
        const presenca = presencasData?.find(p => p.aluno_id === aluno.id);
        return {
          ...aluno,
          presenca: presenca as PresencaDiaria
        };
      });

      setPresencas((presencasData || []) as PresencaDiaria[]);
      setAlunosComPresenca(alunosComPresencaData);
    } catch (error) {
      console.error('Erro ao buscar presenças e alunos:', error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar os dados de presença.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const marcarPresenca = async (alunoId: string, status: 'presente' | 'ausente', data?: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error("Usuário não autenticado");
      }

      const userId = customUserId || session.user.id;
      const dataPresenca = data || new Date().toISOString().split('T')[0];

      // Verificar se já existe presença para este aluno nesta data
      const { data: presencaExistente } = await supabase
        .from('lista_presenca')
        .select('id')
        .eq('aluno_id', alunoId)
        .eq('data', dataPresenca)
        // .eq('user_id', userId) // Removed as table doesn't have it
        .single();

      if (presencaExistente) {
        // Atualizar presença existente
        const { data, error } = await supabase
          .from('lista_presenca')
          .update({
            status,
            // horario_marcacao and marcado_por removed
          })
          .eq('id', presencaExistente.id)
          .select()
          .single();

        if (error) throw error;

        // Atualizar estado local
        setPresencas(prev => prev.map(p =>
          p.id === presencaExistente.id ? data as PresencaDiaria : p
        ));

        setAlunosComPresenca(prev => prev.map(aluno =>
          aluno.id === alunoId ? { ...aluno, presenca: data as PresencaDiaria } : aluno
        ));
      } else {
        // Criar nova presença
        const { data, error } = await supabase
          .from('lista_presenca')
          .insert([{
            aluno_id: alunoId,
            data: dataPresenca,
            status,
            turno: 'manha', // Defaulting to manha, ideally should come from aluno or input
            user_id: userId // Ensure user_id is passed if RLS requires it. If table doesn't have it, this might fail, but checking schema... presenca usually links to aluno which has user_id, or has its own. Assuming it needs it based on pattern.
          }])
          .select()
          .single();

        if (error) throw error;

        // Atualizar estado local
        setPresencas(prev => [...prev, data as PresencaDiaria]);

        setAlunosComPresenca(prev => prev.map(aluno =>
          aluno.id === alunoId ? { ...aluno, presenca: data as PresencaDiaria } : aluno
        ));
      }

      toast({
        title: "Sucesso",
        description: `Presença marcada como ${status === 'presente' ? 'presente' : 'ausente'}.`,
      });

    } catch (error: any) {
      console.error('Erro ao marcar presença:', error);
      toast({
        title: "Erro",
        description: error.message || "Não foi possível marcar a presença.",
        variant: "destructive",
      });
      throw error;
    }
  };

  const getResumoPresencas = async (data?: string): Promise<ResumoGeralPresenca> => {
    const dataConsulta = data || new Date().toISOString().split('T')[0];

    // Verificar se há checklist do motorista para hoje
    const { data: { user } } = await supabase.auth.getUser();
    const userId = customUserId || user?.id || '00000000-0000-0000-0000-000000000000';

    const { data: checklistHoje } = await supabase
      .from('checklists_frota')
      .select('data_checklist')
      .eq('motorista_id', userId)
      .eq('data_checklist', dataConsulta)
      .maybeSingle(); // Use maybeSingle to avoid error if not found

    // Agrupar alunos por colégio + turno
    const alunosPorColegioTurno = alunosComPresenca.reduce((acc, aluno) => {
      const chave = `${aluno.nome_colegio} - ${aluno.turno.charAt(0).toUpperCase() + aluno.turno.slice(1)}`;
      if (!acc[chave]) {
        acc[chave] = [];
      }
      acc[chave].push(aluno);
      return acc;
    }, {} as Record<string, AlunoComPresenca[]>);

    // Calcular resumo por colégio + turno
    const resumoPorColegioTurno: ResumoColegioTurnoPresenca[] = Object.entries(alunosPorColegioTurno).map(([chave, alunos]) => {
      const presentes = alunos.filter(a => a.presenca?.status === 'presente').length;
      const ausentes = alunos.filter(a => a.presenca?.status === 'ausente').length;

      // Extrair colégio e turno da chave
      const [nome_colegio, turno] = chave.split(' - ');

      return {
        nome_colegio,
        turno: turno.toLowerCase(),
        nome_completo: chave,
        total_alunos: alunos.length,
        presentes,
        ausentes,
        alunos,
      };
    }).sort((a, b) => a.nome_completo.localeCompare(b.nome_completo));

    // Calcular totais gerais
    const total_alunos = alunosComPresenca.length;
    const total_presentes = alunosComPresenca.filter(a => a.presenca?.status === 'presente').length;
    const total_ausentes = alunosComPresenca.filter(a => a.presenca?.status === 'ausente').length;

    return {
      total_alunos,
      total_presentes,
      total_ausentes,
      por_colegio_turno: resumoPorColegioTurno,
      checklist_motorista_feito: !!checklistHoje,
      horario_checklist: checklistHoje?.data_checklist,
    };
  };

  useEffect(() => {
    fetchPresencasEAlunos();
  }, []);

  return {
    presencas,
    alunosComPresenca,
    loading,
    marcarPresenca,
    getResumoPresencas,
    refetch: fetchPresencasEAlunos,
  };
}