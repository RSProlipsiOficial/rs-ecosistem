import { useAuth } from "@/hooks/useAuth";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { Loader2 } from "lucide-react";

interface ProtectedRouteProps {
    onlyAdmin?: boolean;
}

const ProtectedRoute = ({ onlyAdmin = false }: ProtectedRouteProps) => {
    const { loading, isAuthenticated, user } = useAuth({ requireAuth: false });
    const location = useLocation();

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-[#0d0e12]">
                <div className="text-center">
                    <Loader2 className="w-10 h-10 animate-spin text-[#fbbf24] mx-auto mb-4" />
                    <p className="text-[#94a3b8] font-medium animate-pulse">Verificando credenciais...</p>
                </div>
            </div>
        );
    }

    if (!isAuthenticated) {
        // Redirect to auth page but save the attempt location
        return <Navigate to="/auth" state={{ from: location }} replace />;
    }

    // Admin and Master roles can access admin routes
    const isAdmin = user?.user_metadata?.user_type === 'admin' || user?.user_metadata?.user_type === 'master';

    if (onlyAdmin && !isAdmin) {
        console.warn("Access denied: User is not an admin", user?.user_metadata?.user_type);
        return <Navigate to="/app" replace />;
    }

    return <Outlet />;
};

export default ProtectedRoute;
