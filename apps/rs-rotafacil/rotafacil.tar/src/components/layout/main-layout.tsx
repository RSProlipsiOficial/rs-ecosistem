
import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/ui/header";
import { Sidebar } from "@/components/layout/sidebar";
import { TrialCountdownBanner } from "@/components/trial/trial-countdown-banner";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { FloatingChat } from "@/components/ai/floating-chat";


interface MainLayoutProps {
  children: React.ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState<string | null>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    const checkAuthAndSubscription = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();

        if (!session) {
          navigate("/auth");
          return;
        }

        // Check both 'tipo_usuario' (new format) and 'user_type' (legacy/auth)
        const tipoUsuario = session.user.user_metadata?.tipo_usuario;
        const userType = session.user.user_metadata?.user_type || 'usuario';

        // Determine effective role
        const effectiveRole = tipoUsuario || userType;
        setUserRole(effectiveRole);

        // Bypass checks for Admin and Team Members
        // Fix: Check for 'colaborador' OR specific roles
        const isAdmin = session.user.email === 'rsprolipsioficial@gmail.com' || userType === 'admin';
        const isTeam = effectiveRole === 'motorista' || effectiveRole === 'monitora' || userType === 'colaborador';

        if (isAdmin || isTeam) {
          setIsAuthenticated(true);
          setIsLoading(false);

          // If a team member lands on upgrade page or generic app, send them to their dashboard
          // IMPORTANT: Allow ADMINS to stay on /upgrade
          if (!isAdmin && (location.pathname === '/upgrade' || location.pathname === '/app')) {
            const dest = effectiveRole === 'motorista' ? '/motorista' : (effectiveRole === 'monitora' ? '/monitora' : '/app');
            if (dest !== location.pathname) navigate(dest);
          }
          return;
        }

        // Check Subscription for standard users
        const { data: subscription } = await supabase
          .from('user_subscriptions')
          .select('status, expires_at')
          .eq('user_id', session.user.id)
          .maybeSingle();

        const isActive = subscription?.status === 'active' &&
          (!subscription.expires_at || new Date(subscription.expires_at) > new Date());

        if (!isActive && location.pathname !== '/upgrade') {
          console.log("Subscription inactive, redirecting to upgrade");
          navigate("/upgrade");
          setIsAuthenticated(true);
          setIsLoading(false);
          return;
        }

        setIsAuthenticated(true);
      } catch (error) {
        console.error("Error checking auth:", error);
        navigate("/auth");
      } finally {
        setIsLoading(false);
      }
    };

    checkAuthAndSubscription();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_OUT' || !session) {
        setIsAuthenticated(false);
        navigate("/auth");
      } else if (event === 'SIGNED_IN' && session) {
        checkAuthAndSubscription();
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate, location.pathname]);

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) return null;



  // Otherwise (Owner/Admin), ALWAYS show the full Admin Dashboard.
  return (
    <div className="min-h-screen bg-background text-foreground">
      <TrialCountdownBanner />
      <div className="flex">
        <Sidebar collapsed={sidebarCollapsed} onToggle={toggleSidebar} />
        <div className="flex-1 flex flex-col min-h-screen">
          <Header />
          <main className="flex-1 p-6 overflow-auto">
            <div className="max-w-7xl mx-auto">
              {children}
            </div>
          </main>
        </div>
      </div>
      <FloatingChat />
    </div>
  );
}