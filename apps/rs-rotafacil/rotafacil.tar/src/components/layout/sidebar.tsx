import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useNotificacoes } from "@/hooks/useNotificacoes";
import {
  Users,
  Brain,
  DollarSign,
  CreditCard,
  Car,
  UserCheck,
  GraduationCap,
  PlayCircle,
  MessageSquare,
  Upload,
  Gift,
  Crown,
  Headphones,
  User,
  ChevronDown,
  Menu,
  Bus,
  Monitor,
  Bell,
  Smartphone
} from "lucide-react";

const menuItems = [
  { id: "dashboard", label: "Dashboard", icon: Brain, hasSubmenu: false, path: "/app" },
  { id: "alunos", label: "Alunos", icon: Users, hasSubmenu: false, path: "/alunos" },
  { id: "financeiro", label: "Financeiro", icon: DollarSign, hasSubmenu: false, path: "/financeiro" },
  { id: "mensalidades", label: "Mensalidades", icon: CreditCard, hasSubmenu: false, path: "/mensalidades" },
  { id: "equipe", label: "Colaboradores", icon: UserCheck, hasSubmenu: false, path: "/equipe" },
  { id: "motorista", label: "Motorista", icon: Car, hasSubmenu: false, path: "/motorista" },
  { id: "monitora", label: "Monitora", icon: Monitor, hasSubmenu: false, path: "/monitora" },
  { id: "whatsapp", label: "Conectar WhatsApp", icon: Smartphone, hasSubmenu: false, path: "/whatsapp" },
  { id: "central_treinamentos", label: "Central de Treinamentos", icon: GraduationCap, hasSubmenu: false, path: "/treinamentos" },

  { id: "upgrade", label: "Upgrade de Plano", icon: Crown, hasSubmenu: false, path: "/upgrade" },
  { id: "importar", label: "Importar/Exportar", icon: Upload, hasSubmenu: false, path: "/importar" },
  { id: "indicacao", label: "Ganhar com Indicação", icon: Gift, hasSubmenu: false, path: "/indicacao" },
  { id: "suporte", label: "Suporte", icon: Headphones, hasSubmenu: false, path: "/suporte" }, // Renamed per user request
  { id: "perfil", label: "Perfil", icon: User, hasSubmenu: false, path: "/perfil" },
];

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

export function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const [openItems, setOpenItems] = useState<string[]>([]);
  const [userRole, setUserRole] = useState<string | null>(null);
  const { notificacoes } = useNotificacoes();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const getUserRole = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      // Prioritize 'tipo_usuario' if available (for motorista/monitora), otherwise 'user_type'
      const type = user?.user_metadata?.tipo_usuario || user?.user_metadata?.user_type || 'usuario';
      setUserRole(type);
    };
    getUserRole();
  }, []);

  const toggleItem = (itemId: string) => {
    setOpenItems(prev =>
      prev.includes(itemId)
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const handleItemClick = (item: any, subItem?: any) => {
    if (subItem) {
      navigate(subItem.path);
    } else if (item.path) {
      navigate(item.path);
    }

    // Auto-close sidebar on mobile/smaller screens or if requested by user for all screens
    // User requested "feche na hora que eu clicar" specifically to clear the view
    // Auto-close sidebar on mobile only
    if (window.innerWidth < 1024) {
      if (!collapsed) {
        onToggle();
      }
    }
  };

  const filteredItems = menuItems.filter(item => {
    const role = userRole ? userRole.toLowerCase() : '';

    if (!role) return true;
    if (role === 'admin' || role === 'master') return true;

    // STRICT RULES for Motorista and Monitora
    if (role === 'motorista') {
      // Motorista access: Motorista Dashboard, Monitora Panel (Check-in), Profile, Support
      return ['motorista', 'monitora', 'perfil', 'suporte'].includes(item.id);
    }

    if (role === 'monitora') {
      // Monitora access: Monitora Panel (Check-in), Profile, Support
      return ['monitora', 'perfil', 'suporte'].includes(item.id);
    }

    if (role === 'consultor' || role === 'usuario') {
      return !['admin_only', 'admin_automacao_whatsapp', 'motorista', 'monitora'].includes(item.id);
    }

    // Default fallback (e.g. Plan Owners) - Show everything except Admin Only
    // This duplicates the user behavior but acts as a catch-all
    return !['admin_only'].includes(item.id);
  });

  return (
    <div className={cn(
      "bg-gradient-black border-r border-sidebar-border flex flex-col transition-all duration-300 shadow-elegant h-screen sticky top-0",
      collapsed ? "w-16" : "w-72"
    )}>
      {/* Logo and Toggle */}
      <div className="p-4 border-b border-sidebar-border flex items-center justify-between flex-shrink-0">
        {!collapsed && (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-gold rounded-lg flex items-center justify-center">
              <Bus className="w-5 h-5 text-black-primary" />
            </div>
            <span className="font-bold text-xl text-gold">RotaFácil</span>
          </div>
        )}
        <div className="flex items-center gap-2">
          {/* Botão de Notificações com Popover */}
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="hover:bg-sidebar-accent relative"
                title={`${notificacoes.total} pendências`}
              >
                <Bell className={cn(
                  "w-4 h-4",
                  notificacoes.total > 0 && "text-yellow-500 animate-pulse"
                )} />
                {notificacoes.total > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[8px] font-black rounded-full flex items-center justify-center">
                    {notificacoes.total > 9 ? '9+' : notificacoes.total}
                  </span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 p-0" align="end">
              <div className="bg-card border border-border rounded-lg shadow-xl">
                <div className="p-4 border-b border-border">
                  <h3 className="font-bold text-sm text-foreground">Notificações</h3>
                  <p className="text-xs text-muted-foreground">{notificacoes.total} pendência(s)</p>
                </div>
                <ScrollArea className="max-h-96">
                  <div className="p-2">
                    {notificacoes.mensalidadesAtrasadas.length > 0 && (
                      <div className="mb-4">
                        <h4 className="text-xs font-bold text-muted-foreground uppercase px-2 mb-2">
                          Mensalidades Atrasadas ({notificacoes.mensalidadesAtrasadas.length})
                        </h4>
                        {notificacoes.mensalidadesAtrasadas.map((item: any) => (
                          <button
                            key={item.id}
                            onClick={() => navigate(`/financeiro?openItem=${item.id}&tipo=mensalidade`)}
                            className="w-full text-left p-2 rounded-lg hover:bg-muted/50 transition-colors mb-1"
                          >
                            <div className="flex items-start gap-2">
                              <div className="w-2 h-2 bg-red-500 rounded-full mt-1.5 flex-shrink-0" />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-foreground truncate">
                                  {item.aluno?.nome_completo || 'Aluno'}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  Vencimento: {item.data_evento ? new Date(item.data_evento).toLocaleDateString('pt-BR') : '-'}
                                </p>
                                <p className="text-xs font-bold text-red-500">
                                  {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(item.valor)}
                                </p>
                              </div>
                            </div>
                          </button>
                        ))}
                      </div>
                    )}

                    {notificacoes.despesasVencidas.length > 0 && (
                      <div>
                        <h4 className="text-xs font-bold text-muted-foreground uppercase px-2 mb-2">
                          Despesas Vencidas ({notificacoes.despesasVencidas.length})
                        </h4>
                        {notificacoes.despesasVencidas.map((item: any) => (
                          <button
                            key={item.id}
                            onClick={() => navigate(`/financeiro?openItem=${item.id}&tipo=despesa`)}
                            className="w-full text-left p-2 rounded-lg hover:bg-muted/50 transition-colors mb-1"
                          >
                            <div className="flex items-start gap-2">
                              <div className="w-2 h-2 bg-orange-500 rounded-full mt-1.5 flex-shrink-0" />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-foreground truncate">
                                  {item.descricao}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  Vencimento: {item.data_vencimento ? new Date(item.data_vencimento).toLocaleDateString('pt-BR') : '-'}
                                </p>
                                <p className="text-xs font-bold text-orange-500">
                                  {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(item.valor)}
                                </p>
                              </div>
                            </div>
                          </button>
                        ))}
                      </div>
                    )}

                    {notificacoes.total === 0 && (
                      <div className="p-8 text-center">
                        <Bell className="w-12 h-12 mx-auto text-muted-foreground/30 mb-2" />
                        <p className="text-sm text-muted-foreground">Nenhuma notificação</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </div>
            </PopoverContent>
          </Popover>

          {/* Botão de Toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggle}
            className="hover:bg-sidebar-accent"
          >
            <Menu className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Menu Items */}
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto scrollbar-thin scrollbar-thumb-gold/20 scrollbar-track-transparent" translate="no">
        {filteredItems.map((item) => {
          const Icon = item.icon;
          const isUpgrade = item.id === 'upgrade';
          const hasNotifications = notificacoes.total > 0;

          return (
            <div key={item.id} className="relative">
              <Button
                variant="ghost"
                onClick={() => handleItemClick(item)}
                className={cn(
                  "w-full justify-start hover:bg-sidebar-accent text-sidebar-foreground transition-smooth group",
                  collapsed && "justify-center px-2",
                  location.pathname === item.path && "bg-sidebar-accent text-gold"
                )}
              >
                <Icon className="w-5 h-5 flex-shrink-0 group-hover:text-gold transition-colors" />
                {!collapsed && (
                  <div className="ml-3 flex-1 flex items-center justify-between">
                    <span className="text-left">{item.label}</span>
                    {item.id === 'indicacao' && (
                      <span className="text-[10px] bg-gold/20 text-gold px-1.5 py-0.5 rounded border border-gold/30 font-bold">
                        NOVO
                      </span>
                    )}
                  </div>
                )}
              </Button>

            </div>
          );
        })}
      </nav>
    </div>
  );
}