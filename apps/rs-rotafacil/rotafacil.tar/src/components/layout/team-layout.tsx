
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Loader2, LogOut, Bus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TeamLayoutProps {
    children: React.ReactNode;
    title?: string;
}

export function TeamLayout({ children, title }: TeamLayoutProps) {
    const [isLoading, setIsLoading] = useState(true);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const navigate = useNavigate();
    const { toast } = useToast();

    useEffect(() => {
        const checkAuth = async () => {
            try {
                const { data: { session } } = await supabase.auth.getSession();

                if (!session) {
                    navigate("/auth");
                    return;
                }

                setIsAuthenticated(true);
            } catch (error) {
                console.error("Error checking auth:", error);
                navigate("/auth");
            } finally {
                setIsLoading(false);
            }
        };

        checkAuth();
    }, [navigate]);

    const handleLogout = async () => {
        await supabase.auth.signOut();
        navigate("/auth");
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-[#0A0A0B] flex items-center justify-center">
                <div className="text-center">
                    <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-yellow-500" />
                    <p className="text-muted-foreground">Carregando...</p>
                </div>
            </div>
        );
    }

    if (!isAuthenticated) return null;

    return (
        <div className="min-h-screen bg-[#0A0A0B] text-white flex flex-col">
            {/* Header Simplificado */}
            <header className="sticky top-0 z-50 bg-[#121214] border-b border-white/5 px-4 h-16 flex items-center justify-between shadow-lg">
                <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-yellow-400 rounded-lg flex items-center justify-center">
                        <Bus className="w-5 h-5 text-black" />
                    </div>
                    <span className="font-bold text-lg text-yellow-400 tracking-tight">RotaFácil</span>
                    {title && <span className="text-white/40 mx-2">|</span>}
                    {title && <span className="font-medium text-white/80">{title}</span>}
                </div>

                <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleLogout}
                    className="text-white/60 hover:text-white hover:bg-white/5"
                >
                    <LogOut className="h-4 w-4 mr-2" />
                    Sair
                </Button>
            </header>

            {/* Conteúdo Principal */}
            <main className="flex-1 p-4 overflow-auto">
                <div className="max-w-xl mx-auto">
                    {children}
                </div>
            </main>

            {/* Footer Mobile (Opcional) */}
            <footer className="p-4 text-center text-xs text-white/20 flex flex-col gap-2">
                <p>RotaFácil &copy; {new Date().getFullYear()} - Sistema de Gestão</p>
                <div className="flex justify-center gap-4">
                    <a href="/termos-de-uso" className="hover:text-white/40 transition-colors">Termos</a>
                    <a href="/politica-privacidade" className="hover:text-white/40 transition-colors">Privacidade</a>
                </div>
            </footer>
        </div>
    );
}
