
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { AlunoComPresenca } from '@/types/presenca';
import { AlertCircle, History, Send, MessageSquare } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface OcorrenciasManagerProps {
    alunos: AlunoComPresenca[];
    loadingAlunos: boolean;
}

export function OcorrenciasManager({ alunos, loadingAlunos }: OcorrenciasManagerProps) {
    const [titulo, setTitulo] = useState('');
    const [descricao, setDescricao] = useState('');
    const [alunoId, setAlunoId] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);
    const [ocorrencias, setOcorrencias] = useState<any[]>([]);
    const [loadingHistorico, setLoadingHistorico] = useState(true);
    const { toast } = useToast();

    const fetchHistorico = async () => {
        try {
            setLoadingHistorico(true);
            const { data: { user } } = await supabase.auth.getUser();
            if (!user) return;

            const { data, error } = await supabase
                .from('ocorrencias')
                .select(`
          *,
          aluno:alunos(nome_completo)
        `)
                .order('created_at', { ascending: false });

            if (error) throw error;
            setOcorrencias(data || []);
        } catch (error) {
            console.error('Erro ao buscar histórico de ocorrências:', error);
        } finally {
            setLoadingHistorico(false);
        }
    };

    useEffect(() => {
        fetchHistorico();
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!titulo || !descricao) {
            toast({
                title: "Campos obrigatórios",
                description: "Por favor, preencha o título e a descrição da ocorrência.",
                variant: "destructive",
            });
            return;
        }

        try {
            setLoading(true);
            const { data: { user } } = await supabase.auth.getUser();
            if (!user) throw new Error("Usuário não autenticado");

            const meta = user.user_metadata;
            const sponsorId = meta?.sponsor_id || meta?.boss_id;

            if (!sponsorId) {
                toast({
                    title: "Erro de Configuração",
                    description: "Não foi possível identificar o gestor da sua conta. Contate o suporte.",
                    variant: "destructive",
                });
                return;
            }

            const { error } = await supabase
                .from('ocorrencias')
                .insert([{
                    user_id: user.id,
                    sponsor_id: sponsorId,
                    aluno_id: alunoId === 'none' ? null : alunoId,
                    titulo,
                    descricao,
                    status: 'pendente'
                }]);

            if (error) throw error;

            toast({
                title: "Sucesso",
                description: "Sua reclamação foi enviada com sucesso ao gestor.",
            });

            setTitulo('');
            setDescricao('');
            setAlunoId(null);
            fetchHistorico();
        } catch (error: any) {
            console.error('Erro ao enviar ocorrência:', error);
            toast({
                title: "Erro",
                description: error.message || "Não foi possível enviar a ocorrência.",
                variant: "destructive",
            });
        } finally {
            setLoading(false);
        }
    };

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'resolvido': return 'bg-green-500';
            case 'em_analise': return 'bg-yellow-500';
            default: return 'bg-blue-500';
        }
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Formulário de Envio */}
            <Card className="lg:col-span-1 bg-black/20 border-white/5">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-white italic uppercase">
                        <AlertCircle className="h-5 w-5 text-yellow-500" />
                        Nova Reclamação
                    </CardTitle>
                    <CardDescription className="text-gray-400">
                        Relate qualquer briga, reclamação de pais ou incidentes na rota.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="titulo" className="text-gray-300">Título / Assunto</Label>
                            <Input
                                id="titulo"
                                placeholder="Ex: Briga no banco de trás"
                                value={titulo}
                                onChange={(e) => setTitulo(e.target.value)}
                                className="bg-black/40 border-white/10 text-white"
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="aluno" className="text-gray-300">Aluno Envolvido (Opcional)</Label>
                            <Select onValueChange={setAlunoId} value={alunoId || undefined}>
                                <SelectTrigger className="bg-black/40 border-white/10 text-white">
                                    <SelectValue placeholder="Selecione um aluno..." />
                                </SelectTrigger>
                                <SelectContent className="bg-zinc-900 border-white/10 text-white">
                                    <SelectItem value="none">Nenhum aluno específico</SelectItem>
                                    {(alunos || []).map((aluno) => (
                                        <SelectItem key={aluno.id} value={aluno.id}>
                                            {aluno.nome_completo}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="descricao" className="text-gray-300">Relato Detalhado</Label>
                            <Textarea
                                id="descricao"
                                placeholder="Descreva o que aconteceu..."
                                rows={5}
                                value={descricao}
                                onChange={(e) => setDescricao(e.target.value)}
                                className="bg-black/40 border-white/10 text-white"
                            />
                        </div>

                        <Button
                            type="submit"
                            disabled={loading}
                            className="w-full bg-yellow-400 text-black hover:bg-yellow-500 font-bold uppercase gap-2 py-6"
                        >
                            <Send className="h-4 w-4" />
                            {loading ? 'Enviando...' : 'Enviar ao Gestor'}
                        </Button>
                    </form>
                </CardContent>
            </Card>

            {/* Histórico Recente */}
            <Card className="lg:col-span-2 bg-black/20 border-white/5">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-white italic uppercase">
                        <History className="h-5 w-5 text-yellow-500" />
                        Minhas Reclamações Recentes
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {loadingHistorico ? (
                            <p className="text-center text-gray-500 py-8">Carregando histórico...</p>
                        ) : ocorrencias.length === 0 ? (
                            <div className="flex flex-col items-center justify-center py-12 text-center">
                                <MessageSquare className="h-12 w-12 text-gray-600 mb-4" />
                                <p className="text-gray-500">Nenhuma reclamação enviada ainda.</p>
                            </div>
                        ) : (
                            ocorrencias.map((oc) => (
                                <div key={oc.id} className="p-4 rounded-lg bg-black/40 border border-white/5 space-y-2">
                                    <div className="flex justify-between items-start">
                                        <h3 className="font-bold text-white uppercase tracking-tight">{oc.titulo}</h3>
                                        <Badge className={`${getStatusColor(oc.status)} text-white border-0`}>
                                            {oc.status.replace('_', ' ').toUpperCase()}
                                        </Badge>
                                    </div>
                                    <p className="text-sm text-gray-400 line-clamp-2">{oc.descricao}</p>
                                    <div className="flex items-center gap-4 mt-2 text-[10px] text-gray-500 uppercase font-bold">
                                        <span>📅 {format(new Date(oc.created_at), "dd 'de' MMMM", { locale: ptBR })}</span>
                                        {oc.aluno && <span className="text-yellow-500/80">👤 Aluno: {oc.aluno.nome_completo}</span>}
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
