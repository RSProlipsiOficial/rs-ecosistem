import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/integrations/supabase/client';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  HeadphonesIcon,
  MessageCircle,
  PhoneCall,
  Video,
  Search,
  Play,
  Bot,
  User,
  Send,
  Youtube,
  BookOpen,
  HelpCircle,
  MessageSquare,
  Plus,
  Edit,
  Trash2,
  Copy,
  CheckCircle,
  Truck,
  Sun,
  Moon,
  Users,
  Sparkles,
  ExternalLink,
  Loader2,
  Smartphone,
  Save
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Tutorial {
  id: string;
  titulo: string;
  descricao: string;
  categoria: string;
  youtube_url: string;
  thumbnail: string;
  duracao: string;
}

interface ChatMessage {
  id: string;
  tipo: 'user' | 'ia';
  conteudo: string;
  timestamp: Date;
}

interface MensagemPronta {
  id: string;
  titulo: string;
  conteudo: string;
  categoria: string;
  ativa: boolean;
  created_at: Date;
}

export default function SuporteIndex() {
  const [mensagemChat, setMensagemChat] = useState('');
  const [mensagensChat, setMensagensChat] = useState<ChatMessage[]>([
    {
      id: '1',
      tipo: 'ia',
      conteudo: 'Olá! Sou a RS-IA, sua assistente de suporte. Como posso ajudar você hoje?',
      timestamp: new Date()
    }
  ]);
  const [buscaTutorial, setBuscaTutorial] = useState('');
  const [categoriaFiltro, setCategoriaFiltro] = useState('Todos');

  // Estados para Mensagens Prontas
  const [mensagensProntas, setMensagensProntas] = useState<MensagemPronta[]>([
    {
      id: '1',
      titulo: 'Bom dia - Início da rota',
      conteudo: 'Bom dia! Espero que esteja bem. Estamos saindo para buscar os alunos. Horário previsto de chegada na sua residência em breve.',
      categoria: 'Rotina',
      ativa: true,
      created_at: new Date()
    },
    {
      id: '2',
      titulo: 'Atraso na rota',
      conteudo: 'Olá! Informo que a van está com um pequeno atraso de aproximadamente 10-15 minutos devido ao trânsito. Já estamos a caminho e chegaremos o quanto antes.',
      categoria: 'Avisos',
      ativa: true,
      created_at: new Date()
    },
    {
      id: '3',
      titulo: 'Lembrete - Mensalidade',
      conteudo: 'Olá! Este é um lembrete amigável sobre o vencimento da mensalidade escolar. Caso já tenha realizado o pagamento, por favor desconsidere. Obrigado!',
      categoria: 'Cobrança',
      ativa: true,
      created_at: new Date()
    }
  ]);

  const [novaMensagem, setNovaMensagem] = useState({ titulo: '', conteudo: '', categoria: 'Rotina' });
  const [editandoMensagem, setEditandoMensagem] = useState<string | null>(null);

  // Novos Estados para Van e Filtros
  const [vans, setVans] = useState<any[]>([]);
  const [selectedVanId, setSelectedVanId] = useState<string>('all');
  const [selectedShift, setSelectedShift] = useState<string>('all');
  const [alunos, setAlunos] = useState<any[]>([]);
  const [isImprovingAI, setIsImprovingAI] = useState<string | null>(null);
  const [isLoadingAlunos, setIsLoadingAlunos] = useState(false);

  // Custom Support Config
  const [ownerSupportConfig, setOwnerSupportConfig] = useState<{
    whatsapp_number: string;
    support_name: string;
    welcome_message: string;
  } | null>(null);

  const [whatsappSupport, setWhatsappSupport] = useState('5511999999999');
  const [supportName, setSupportName] = useState('Suporte via WhatsApp');
  const [whatsappMessage, setWhatsappMessage] = useState('Olá! Preciso de suporte com o app RotaFácil.');
  const [aiSystemPrompt, setAiSystemPrompt] = useState('Você é um assistente profissional de transporte escolar. Seu objetivo é tornar a mensagem mais clara, gentil e profissional, sem alterar o sentido original. Mantenha curto.');
  const [userRole, setUserRole] = useState<string | null>(null);
  const [isOwner, setIsOwner] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('');
  const [hasLoadedConfig, setHasLoadedConfig] = useState(false);
  const [isLoadingProfile, setIsLoadingProfile] = useState(true);
  const [savingConfig, setSavingConfig] = useState(false);

  const { toast } = useToast();

  useEffect(() => {
    checkRoleAndFetchData();
    fetchTutoriais();
    fetchSettings();
  }, []);

  const checkRoleAndFetchData = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    // Fetch profile to get sponsor_id
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('sponsor_id')
      .eq('user_id', user.id)
      .maybeSingle() as any;

    if (!profile && !user.user_metadata?.sponsor_id) {
      // If no profile yet and no metadata either, it might still be loading or first time
      setIsLoadingProfile(false);
      return;
    }

    const role = user.user_metadata?.tipo_usuario || user.user_metadata?.user_type || 'usuario';
    const sponsor_id = profile?.sponsor_id || user.user_metadata?.sponsor_id;
    const roleLower = role.toLowerCase();
    const isStaff = ['motorista', 'monitora'].includes(roleLower);
    const isActuallyOwner = !isStaff;

    setUserRole(role);
    setIsOwner(isActuallyOwner);
    setIsLoadingProfile(false);

    // Set initial active tab
    if (!activeTab) {
      setActiveTab(isActuallyOwner ? "mensagens" : "contato");
    }

    if (hasLoadedConfig) return;

    if (isActuallyOwner) {
      fetchVans();
      const { data } = await supabase
        .from('owner_support_config' as any)
        .select('*')
        .eq('owner_id', user.id)
        .maybeSingle() as any;

      if (data) {
        setOwnerSupportConfig({
          whatsapp_number: data.whatsapp_number,
          support_name: data.support_name,
          welcome_message: data.welcome_message
        });
        if (data.whatsapp_number) setWhatsappSupport(data.whatsapp_number);
        if (data.support_name) setSupportName(data.support_name);
        if (data.welcome_message) setWhatsappMessage(data.welcome_message);
      }
      setHasLoadedConfig(true);
    } else if (sponsor_id) {
      const { data } = await supabase
        .from('owner_support_config' as any)
        .select('*')
        .eq('owner_id', sponsor_id)
        .maybeSingle() as any;

      if (data) {
        if (data.whatsapp_number) setWhatsappSupport(data.whatsapp_number);
        if (data.support_name) setSupportName(data.support_name);
        if (data.welcome_message) setWhatsappMessage(data.welcome_message);
      }
      setHasLoadedConfig(true);
    }
  };

  const saveSupportConfig = async () => {
    try {
      setSavingConfig(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({ title: "Erro", description: "Usuário não autenticado.", variant: "destructive" });
        return;
      }

      console.log('Iniciando upsert de suporte:', {
        owner_id: user.id,
        whatsapp_number: whatsappSupport,
        support_name: supportName,
        welcome_message: whatsappMessage
      });

      const { error: upsertError } = await supabase
        .from('owner_support_config' as any)
        .upsert({
          owner_id: user.id,
          whatsapp_number: whatsappSupport,
          support_name: supportName,
          welcome_message: whatsappMessage,
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'owner_id'
        });

      if (upsertError) {
        console.error('Erro no upsert do Supabase:', upsertError);
        throw upsertError;
      }

      toast({
        title: "Sucesso!",
        description: "Configuração de suporte salva com sucesso.",
      });

      // Atualizar cache local
      setHasLoadedConfig(false);
      checkRoleAndFetchData();
    } catch (error: any) {
      console.error('Catch error saving support config:', error);
      toast({
        title: "Erro ao Salvar",
        description: error.message || "Não foi possível salvar a configuração.",
        variant: "destructive"
      });
    } finally {
      setSavingConfig(false);
    }
  };

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('value')
        .eq('key', 'support_config')
        .single();

      if (data?.value) {
        const config = data.value as any;
        // Solo aplicar se não houver config específica do owner ou se for admin do sistema
        if (config.ai_prompt) setAiSystemPrompt(config.ai_prompt);
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    }
  };

  useEffect(() => {
    if (selectedVanId && isOwner) {
      fetchAlunos();
    }
  }, [selectedVanId, selectedShift, isOwner]);

  const fetchVans = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('vans')
        .select('*')
        .eq('user_id', user.id);

      if (error) throw error;
      setVans(data || []);
    } catch (error) {
      console.error('Error fetching vans:', error);
    }
  };

  const fetchAlunos = async () => {
    setIsLoadingAlunos(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      let query = supabase.from('alunos').select('*').eq('user_id', user.id);

      if (selectedVanId && selectedVanId !== 'all') {
        query = query.eq('van_id', selectedVanId);
      }

      if (selectedShift && selectedShift !== 'all') {
        query = query.eq('turno', selectedShift);
      }

      const { data, error } = await query;
      if (error) throw error;
      setAlunos(data || []);
    } catch (error) {
      console.error('Error fetching alunos:', error);
    } finally {
      setIsLoadingAlunos(false);
    }
  };

  const [tutoriais, setTutoriais] = useState<Tutorial[]>([]);
  const [loadingTutoriais, setLoadingTutoriais] = useState(true);

  const fetchTutoriais = async () => {
    try {
      const { data, error } = await supabase
        .from('tutoriais')
        .select('*')
        .eq('ativo', true)
        .order('ordem', { ascending: true });

      if (error) throw error;

      if (data && data.length > 0) {
        const formatted: Tutorial[] = data.map(t => ({
          id: t.id,
          titulo: t.titulo,
          descricao: t.descricao || '',
          categoria: (t as any).categoria || 'Geral',
          youtube_url: t.link_tutorial,
          thumbnail: '/placeholder.svg',
          duracao: ''
        }));
        setTutoriais(formatted);
      }
    } catch (error) {
      console.error('Error fetching tutoriais:', error);
    } finally {
      setLoadingTutoriais(false);
    }
  };

  const melhorarComIA = async (msgId: string, originalContent: string) => {
    setIsImprovingAI(msgId);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/openrouter-chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`
        },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: aiSystemPrompt },
            { role: 'user', content: `Melhore esta mensagem para os pais dos alunos: "${originalContent}"` }
          ]
        })
      });

      const data = await response.json();
      if (data.message) {
        setMensagensProntas(prev => prev.map(m =>
          m.id === msgId ? { ...m, conteudo: data.message } : m
        ));
        toast({ title: "IA: Mensagem Melhorada", description: "O conteúdo foi refinado com sucesso!" });
      }
    } catch (error) {
      toast({ title: "Erro", description: "Falha ao usar IA para melhorar a mensagem.", variant: "destructive" });
    } finally {
      setIsImprovingAI(null);
    }
  };

  const enviarParaTodos = async (conteudo: string) => {
    const validAlunos = alunos.filter(a => a.whatsapp_responsavel);
    if (validAlunos.length === 0) {
      toast({ title: "Nenhum contato", description: "Não há alunos com WhatsApp cadastrado para este filtro.", variant: "destructive" });
      return;
    }

    validAlunos.forEach((aluno, index) => {
      setTimeout(() => {
        const text = conteudo.replace(/{aluno}/g, aluno.nome_completo || aluno.nome_responsavel);
        const url = `https://wa.me/${aluno.whatsapp_responsavel.replace(/\D/g, '')}?text=${encodeURIComponent(text)}`;
        window.open(url, '_blank');
      }, index * 1000);
    });
  };

  const abrirWhatsApp = () => {
    const url = `https://wa.me/${whatsappSupport.replace(/\D/g, '')}?text=${encodeURIComponent(whatsappMessage)}`;
    window.open(url, '_blank');
  };

  const adicionarMensagem = () => {
    if (!novaMensagem.titulo || !novaMensagem.conteudo) {
      toast({ title: "Erro", description: "Preencha o título e conteúdo.", variant: "destructive" });
      return;
    }

    const mensagem: MensagemPronta = {
      id: Date.now().toString(),
      ...novaMensagem,
      ativa: true,
      created_at: new Date()
    };

    setMensagensProntas(prev => [...prev, mensagem]);
    setNovaMensagem({ titulo: '', conteudo: '', categoria: 'Rotina' });
  };

  const removerMensagem = (id: string) => {
    setMensagensProntas(prev => prev.filter(msg => msg.id !== id));
  };

  const copiarMensagem = (conteudo: string) => {
    navigator.clipboard.writeText(conteudo);
    toast({ title: "Copiado!", description: "Mensagem copiada para a área de transferência." });
  };

  const enviarParaGrupo = (vanId: string, conteudo: string) => {
    const van = vans.find(v => v.id === vanId);
    if (van?.whatsapp_group_url) {
      const url = `${van.whatsapp_group_url}?text=${encodeURIComponent(conteudo)}`;
      window.open(url, '_blank');
    } else {
      toast({ title: "Link não configurado", description: "O link do grupo desta van não foi cadastrado.", variant: "destructive" });
    }
  }

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="bg-[#121212] border border-white/5 rounded-[24px] p-8 shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl group-hover:bg-primary/10 transition-colors duration-500" />

          <div className="relative flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex-1 text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-3 mb-4">
                <div className="p-3 bg-gradient-gold rounded-2xl shadow-lg transform group-hover:scale-110 transition-transform duration-300">
                  <HeadphonesIcon className="h-8 w-8 text-black" />
                </div>
                <h1 className="text-3xl font-black text-white tracking-tight">Central de Suporte</h1>
              </div>
              <p className="text-gray-400 text-lg max-w-2xl leading-relaxed">
                {isOwner
                  ? "Gerencie seu canal de atendimento e modelos de mensagens para sua equipe e clientes."
                  : "Precisa de ajuda? Entre em contato com o responsável pela sua empresa."}
              </p>
            </div>

            <div className="flex flex-col gap-3 min-w-[240px]">
              <Button
                onClick={abrirWhatsApp}
                className="bg-green-500 hover:bg-green-600 text-white font-bold h-14 rounded-2xl gap-3 shadow-[0_8px_16px_rgba(34,197,94,0.3)] hover:translate-y-[-2px] transition-all"
              >
                <div className="p-2 bg-white/20 rounded-lg">
                  <MessageCircle className="h-5 w-5" />
                </div>
                Falar com {supportName}
              </Button>
            </div>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6 relative z-10">
          <TabsList className="bg-[#121212] border border-white/5 p-1 h-14 rounded-2xl">
            {isOwner && (
              <>
                <TabsTrigger value="mensagens" className="rounded-xl data-[state=active]:bg-gradient-gold data-[state=active]:text-black font-bold gap-2 transition-all">
                  <MessageSquare className="h-4 w-4" />
                  Mensagens Prontas
                </TabsTrigger>
                <TabsTrigger value="config" className="rounded-xl data-[state=active]:bg-gradient-gold data-[state=active]:text-black font-bold gap-2 transition-all">
                  <Bot className="h-4 w-4" />
                  Configurar Atendimento
                </TabsTrigger>
              </>
            )}
            {!isOwner && (
              <TabsTrigger value="contato" className="rounded-xl data-[state=active]:bg-gradient-gold data-[state=active]:text-black font-bold gap-2 transition-all">
                <Smartphone className="h-4 w-4" />
                Contato Direto
              </TabsTrigger>
            )}
          </TabsList>

          {/* Tab: Configuração (Só para Dono) */}
          {isOwner && (
            <TabsContent value="config" className="relative z-[100] outline-none">
              <Card className="bg-[#121212] border-white/5 rounded-[24px] overflow-visible shadow-2xl">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <HeadphonesIcon className="h-5 w-5 text-gold" />
                    Canal de Suporte da sua Empresa
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Defina para onde seus motoristas e monitoras serão direcionados ao pedir ajuda.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label className="text-gray-300">WhatsApp de Atendimento</Label>
                      <input
                        type="tel"
                        id="whatsappSupport"
                        autoFocus
                        value={whatsappSupport}
                        onChange={(e) => setWhatsappSupport(e.target.value)}
                        placeholder="Ex: 5511999999999"
                        className="w-full bg-[#1A1A1A] border border-white/20 text-white h-12 px-4 rounded-xl focus:border-gold focus:ring-2 focus:ring-gold/20 placeholder:text-gray-500 relative z-[110] cursor-text pointer-events-auto"
                        autoComplete="off"
                      />
                      <p className="text-[10px] text-gray-500">Inclua o código do país e DDD (apenas números).</p>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-gray-300">Nome de Exibição</Label>
                      <input
                        type="text"
                        id="supportName"
                        value={supportName}
                        onChange={(e) => setSupportName(e.target.value)}
                        placeholder="Ex: Suporte RS RotaFácil"
                        className="w-full bg-[#1A1A1A] border border-white/20 text-white h-12 px-4 rounded-xl focus:border-gold focus:ring-2 focus:ring-gold/20 placeholder:text-gray-500 relative z-[110] cursor-text pointer-events-auto"
                        autoComplete="off"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-gray-300">Mensagem de Boas-vindas</Label>
                    <textarea
                      id="whatsappMessage"
                      value={whatsappMessage}
                      onChange={(e) => setWhatsappMessage(e.target.value)}
                      placeholder="Mensagem que chegará para você quando clicarem no botão..."
                      className="w-full bg-[#1A1A1A] border border-white/20 text-white min-h-[100px] p-4 rounded-xl focus:border-gold focus:ring-2 focus:ring-gold/20 placeholder:text-gray-500 relative z-[110] cursor-text pointer-events-auto"
                    />
                  </div>

                  <Button
                    onClick={saveSupportConfig}
                    disabled={savingConfig}
                    className="bg-gradient-gold text-black font-bold h-12 px-8 rounded-xl hover:scale-105 transition-transform relative z-20 pointer-events-auto"
                  >
                    {savingConfig ? "Salvando..." : "Salvar Configurações"}
                    <Save className="h-4 w-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {/* Tab: Mensagens Prontas (Só para Dono) */}
          {isOwner && (
            <TabsContent value="mensagens">
              <div className="space-y-6">
                <Card className="bg-[#121212] border-white/5 rounded-[24px] overflow-hidden">
                  <CardHeader className="pb-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-xl flex items-center gap-2 text-white">
                          <Users className="h-5 w-5 text-gold" />
                          Público Alvo
                        </CardTitle>
                        <CardDescription className="text-gray-400">
                          Selecione os destinatários para o envio rápido
                        </CardDescription>
                      </div>
                      {alunos.length > 0 && (
                        <Badge className="bg-gold/10 text-gold border-gold/20 font-black">
                          {alunos.length} ALUNOS
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <Label className="text-gray-300 flex items-center gap-2">
                          <Truck className="h-4 w-4 text-gold" />
                          Van Específica
                        </Label>
                        <select
                          className="w-full h-12 px-4 bg-[#0A0A0A] border border-white/10 rounded-xl text-white outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/20 transition-colors relative z-30 pointer-events-auto"
                          value={selectedVanId}
                          onChange={(e) => setSelectedVanId(e.target.value)}
                        >
                          <option value="all">Todas as Vans</option>
                          {vans.map(van => (
                            <option key={van.id} value={van.id}>{van.nome}</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-3">
                        <Label className="text-gray-300 flex items-center gap-2">
                          <Sun className="h-4 w-4 text-gold" />
                          Turno de Atendimento
                        </Label>
                        <div className="flex gap-2">
                          <Button
                            variant={selectedShift === 'all' ? 'default' : 'outline'}
                            onClick={() => setSelectedShift('all')}
                            className={`flex-1 h-12 rounded-xl font-bold ${selectedShift === 'all' ? 'bg-gold text-black' : 'border-white/10 text-white'}`}
                          >
                            Todos
                          </Button>
                          <Button
                            variant={selectedShift === 'manha' ? 'default' : 'outline'}
                            onClick={() => setSelectedShift('manha')}
                            className={`flex-1 h-12 rounded-xl font-bold gap-2 ${selectedShift === 'manha' ? 'bg-gold text-black' : 'border-white/10 text-white'}`}
                          >
                            <Sun className="h-4 w-4" /> Manhã
                          </Button>
                          <Button
                            variant={selectedShift === 'tarde' ? 'default' : 'outline'}
                            onClick={() => setSelectedShift('tarde')}
                            className={`flex-1 h-12 rounded-xl font-bold gap-2 ${selectedShift === 'tarde' ? 'bg-gold text-black' : 'border-white/10 text-white'}`}
                          >
                            <Moon className="h-4 w-4" /> Tarde
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-black text-white flex items-center gap-2">
                    <Sparkles className="h-6 w-6 text-gold" />
                    Modelos de Mensagens
                  </h3>
                  <Button onClick={adicionarMensagem} className="bg-gradient-gold text-black font-bold rounded-xl h-10 px-6">
                    <Plus className="h-4 w-4 mr-2" /> Novo Modelo
                  </Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {mensagensProntas.map((mensagem) => (
                    <Card key={mensagem.id} className="bg-[#121212] border-white/5 hover:border-gold/30 transition-all duration-300 rounded-[24px] overflow-hidden group">
                      <CardHeader className="p-6 pb-2">
                        <div className="flex items-center justify-between">
                          <Badge variant="secondary" className="bg-gold/5 text-gold border-gold/10 text-[10px] uppercase font-black">
                            {mensagem.categoria}
                          </Badge>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-white/50 hover:text-gold hover:bg-gold/10"
                              onClick={() => melhorarComIA(mensagem.id, mensagem.conteudo)}
                              disabled={isImprovingAI === mensagem.id}
                            >
                              {isImprovingAI === mensagem.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-white/50 hover:text-red-500 hover:bg-red-500/10"
                              onClick={() => removerMensagem(mensagem.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <CardTitle className="text-white mt-2 font-bold">{mensagem.titulo}</CardTitle>
                      </CardHeader>
                      <CardContent className="p-6">
                        <div className="bg-black/40 border border-white/5 rounded-2xl p-4 mb-4 relative group/content">
                          <p className="text-gray-400 text-sm italic leading-relaxed line-clamp-3">"{mensagem.conteudo}"</p>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="absolute top-2 right-2 h-8 w-8 opacity-0 group-hover/content:opacity-100 text-white/50 hover:text-gold"
                            onClick={() => copiarMensagem(mensagem.conteudo)}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <Button onClick={() => enviarParaTodos(mensagem.conteudo)} className="bg-green-500 hover:bg-green-600 text-white font-bold rounded-xl h-12 text-xs gap-2">
                            <Smartphone className="h-4 w-4" /> Enviar p/ Todos
                          </Button>
                          <Button onClick={() => enviarParaGrupo(selectedVanId, mensagem.conteudo)} variant="outline" className="border-white/10 text-white hover:bg-white/5 font-bold rounded-xl h-12 text-xs gap-2">
                            <MessageCircle className="h-4 w-4" /> Grupo da Van
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>
          )}

          {/* Tab: Contato para Equipe */}
          {!isOwner && (
            <TabsContent value="contato">
              <Card className="bg-[#121212] border-white/5 rounded-[24px] overflow-hidden p-8 text-center space-y-8">
                <div className="w-24 h-24 bg-gradient-gold rounded-full flex items-center justify-center mx-auto shadow-2xl">
                  <HeadphonesIcon className="h-12 w-12 text-black" />
                </div>
                <div className="space-y-4">
                  <h2 className="text-3xl font-black text-white">Central de Atendimento</h2>
                  <p className="text-gray-400 text-lg max-w-md mx-auto">
                    Precisa de suporte ou reportar um problema? Entre em contato agora mesmo com seu gestor via WhatsApp.
                  </p>
                </div>
                <Button
                  onClick={abrirWhatsApp}
                  className="bg-green-500 hover:bg-green-600 text-white font-black h-16 px-12 rounded-[24px] text-xl gap-4 shadow-[0_12px_24px_rgba(34,197,94,0.4)] hover:translate-y-[-4px] transition-all"
                >
                  <MessageCircle className="h-6 w-6" />
                  Falar com {supportName}
                </Button>
                <div className="pt-8 border-t border-white/5">
                  <p className="text-gray-500 text-sm">
                    Horário de atendimento definido pelo seu gestor.
                  </p>
                </div>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </div>
    </MainLayout>
  );
}