import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Users, Mail, Phone, User, MapPin } from 'lucide-react';

export default function PublicIndicacao() {
    const { codigo } = useParams();
    const { toast } = useToast();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const [indicador, setIndicador] = useState<{ name: string; id: string } | null>(null);

    const [formData, setFormData] = useState({
        nome_completo: '',
        email: '',
        telefone: '',
        whatsapp: '',
        cidade: '',
        estado: ''
    });

    useEffect(() => {
        const fetchIndicador = async () => {
            if (!codigo) return;

            const { data, error } = await supabase
                .from('consultores')
                .select('user_id, nome')
                .eq('username', codigo)
                .maybeSingle();

            if (data) {
                setIndicador({
                    name: data.nome,
                    id: data.user_id
                });
            }
        };

        fetchIndicador();
    }, [codigo]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            // Cadastrar na tabela 'indicados' (leads)
            const { error } = await supabase.from('indicados').insert({
                nome_completo: formData.nome_completo,
                email: formData.email,
                telefone: formData.telefone,
                whatsapp: formData.whatsapp,
                cidade: formData.cidade,
                estado: formData.estado,
                indicado_por_id: indicador?.id,
                indicado_por_nome: indicador?.name,
                codigo_indicacao: codigo,
                origem: 'site',
                status: 'novo'
            });

            if (error) {
                if (error.code === '23505') {
                    throw new Error('Este email já foi cadastrado como indicação.');
                }
                throw error;
            }

            toast({
                title: '✅ Cadastro Realizado!',
                description: `Obrigado ${formData.nome_completo}! Recebemos seu interesse e entraremos em contato em breve.`,
            });

            // Limpar formulário
            setFormData({
                nome_completo: '',
                email: '',
                telefone: '',
                whatsapp: '',
                cidade: '',
                estado: ''
            });

        } catch (error: any) {
            toast({
                title: 'Erro',
                description: error.message || 'Não foi possível realizar o cadastro',
                variant: 'destructive',
            });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-dark-deep flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 pointer-events-none"></div>

            <Card className="max-w-md w-full bg-dark-lighter border-gold/20 shadow-2xl relative z-10">
                <CardHeader className="text-center">
                    <div className="flex items-center justify-center mb-4">
                        <div className="p-3 rounded-full bg-gold/10 border border-gold/20">
                            <Users className="w-10 h-10 text-gold" />
                        </div>
                    </div>
                    <CardTitle className="text-2xl font-bold text-white">Oportunidade RotaFácil</CardTitle>
                    <CardDescription className="text-gray-400">
                        {indicador ? (
                            <>Você foi indicado por <span className="text-gold font-semibold">{indicador.name}</span></>
                        ) : (
                            <>Cadastre seu interesse e conheça o sistema</>
                        )}
                    </CardDescription>
                </CardHeader>

                <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="nome_completo" className="text-gray-300">Nome Completo *</Label>
                            <div className="relative">
                                <User className="absolute left-3 top-3 h-4 w-4 text-gold/50" />
                                <Input
                                    id="nome_completo"
                                    placeholder="Seu nome completo"
                                    value={formData.nome_completo}
                                    onChange={(e) => setFormData({ ...formData, nome_completo: e.target.value })}
                                    className="pl-10 bg-dark-deep border-gold/20 text-white focus:border-gold"
                                    required
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="email" className="text-gray-300">Email *</Label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-3 h-4 w-4 text-gold/50" />
                                    <Input
                                        id="email"
                                        type="email"
                                        placeholder="seu@email.com"
                                        value={formData.email}
                                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                        className="pl-10 bg-dark-deep border-gold/20 text-white focus:border-gold"
                                        required
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="whatsapp" className="text-gray-300">WhatsApp *</Label>
                                <div className="relative">
                                    <Phone className="absolute left-3 top-3 h-4 w-4 text-gold/50" />
                                    <Input
                                        id="whatsapp"
                                        placeholder="(00) 00000-0000"
                                        value={formData.whatsapp}
                                        onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                                        className="pl-10 bg-dark-deep border-gold/20 text-white focus:border-gold"
                                        required
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="cidade" className="text-gray-300">Cidade</Label>
                                <div className="relative">
                                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-gold/50" />
                                    <Input
                                        id="cidade"
                                        placeholder="Sua cidade"
                                        value={formData.cidade}
                                        onChange={(e) => setFormData({ ...formData, cidade: e.target.value })}
                                        className="pl-10 bg-dark-deep border-gold/20 text-white focus:border-gold"
                                    />
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="estado" className="text-gray-300">UF</Label>
                                <Input
                                    id="estado"
                                    placeholder="PR"
                                    maxLength={2}
                                    value={formData.estado}
                                    onChange={(e) => setFormData({ ...formData, estado: e.target.value.toUpperCase() })}
                                    className="bg-dark-deep border-gold/20 text-white focus:border-gold"
                                />
                            </div>
                        </div>

                        <Button
                            type="submit"
                            className="w-full bg-gold hover:bg-gold/80 text-black font-bold h-12 mt-4"
                            disabled={loading}
                        >
                            {loading ? 'Processando...' : 'QUERO CONHECER O SISTEMA'}
                        </Button>

                        <p className="text-[10px] text-center text-gray-500 mt-4 uppercase tracking-widest">
                            RS PRÓLIPSI • SISTEMA ROTA FÁCIL
                        </p>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}
