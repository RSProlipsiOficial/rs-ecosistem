import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  User,
  Sparkles,
  Crown,
  Mail,
  Gift,
  Share2,
  Copy,
  TrendingUp,
  Target,
  ExternalLink,
  Building2,
  Link as LinkIcon,
  CheckCircle2,
  Users,
  Calendar,
  Phone,
  MessageCircle,
  MapPin,
  Clock,
  Loader2
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function IndicacaoIndex() {
  const [codigoRef, setCodigoRef] = useState('');
  const [linkGerado, setLinkGerado] = useState('');
  const [loading, setLoading] = useState(true);
  const [salvando, setSalvando] = useState(false);
  const [indicados, setIndicados] = useState<any[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    carregarDadosConsultor();
  }, []);

  useEffect(() => {
    if (codigoRef) {
      // Use the current domain or fallback to production
      const domain = typeof window !== 'undefined' ? window.location.origin : 'https://rotafacil.rsprolipsi.com.br';
      setLinkGerado(`${domain}/indicacao/${codigoRef}`);
    } else {
      setLinkGerado('');
    }
  }, [codigoRef]);

  const carregarDadosConsultor = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        setLoading(false);
        return;
      }

      // 1. Carregar dados do consultor
      const { data: consultor } = await supabase
        .from('consultores')
        .select('user_id, username, email')
        .eq('user_id', user.id)
        .maybeSingle();

      if (consultor) {
        const codigo = consultor.username || consultor.email.split('@')[0];
        setCodigoRef(codigo);
      }

      // 2. Carregar indicados (leads)
      const { data: leads, error: leadsError } = await supabase
        .from('indicados')
        .select('*')
        .eq('indicado_por_id', user.id)
        .order('created_at', { ascending: false });

      if (leadsError) {
        console.error('Erro ao carregar indicados:', leadsError);
      } else {
        setIndicados(leads || []);
      }

    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar seus dados.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const salvarCodigoRef = async () => {
    if (!codigoRef || codigoRef.length < 3) {
      toast({
        title: "Código inválido",
        description: "O código deve ter pelo menos 3 caracteres.",
        variant: "destructive",
      });
      return;
    }

    setSalvando(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        toast({
          title: "Erro",
          description: "Você precisa estar logado.",
          variant: "destructive",
        });
        return;
      }

      const { error } = await supabase
        .from('consultores')
        .update({ username: codigoRef })
        .eq('user_id', user.id);

      if (error) throw error;

      toast({
        title: "Sucesso!",
        description: "Seu código de indicação foi salvo.",
      });
    } catch (error: any) {
      console.error('Erro ao salvar código:', error);
      toast({
        title: "Erro",
        description: error.message || "Não foi possível salvar o código.",
        variant: "destructive",
      });
    } finally {
      setSalvando(false);
    }
  };

  const copiarLink = () => {
    if (!linkGerado) {
      toast({
        title: "Aviso",
        description: "Digite um código primeiro para gerar o link.",
        variant: "destructive",
      });
      return;
    }

    navigator.clipboard.writeText(linkGerado);
    toast({
      title: "Link copiado!",
      description: "O link foi copiado para a área de transferência.",
    });
  };

  const compartilharWhatsApp = () => {
    if (!linkGerado) {
      toast({
        title: "Aviso",
        description: "Digite um código primeiro para gerar o link.",
        variant: "destructive",
      });
      return;
    }

    const mensagem = `🚌 *Conheça o RotaFácil*\n\nSistema completo para gestão de transporte escolar!\n\n✅ Controle de alunos e mensalidades\n✅ Gestão financeira\n✅ Checklist de segurança\n✅ Integração WhatsApp\n✅ E muito mais!\n\n🎁 Cadastre-se usando meu link:\n${linkGerado}`;

    const url = `https://wa.me/?text=${encodeURIComponent(mensagem)}`;
    window.open(url, '_blank');
  };

  const redirecionarRSProlipsi = () => {
    const codigo = codigoRef || 'ROTAFACIL';
    const linkRSProlipsi = `https://rsprolipsi.com/cadastro?ref=${codigo}`;
    window.open(linkRSProlipsi, '_blank');
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center space-y-4">
            <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto" />
            <p className="text-muted-foreground">Carregando painel de indicações...</p>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-6 animate-in fade-in duration-500">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-card border rounded-xl p-8 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-xl border border-primary/20">
              <Gift className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground">Sistema de Indicações</h1>
              <p className="text-muted-foreground mt-1">
                Compartilhe o RotaFácil e acompanhe seus indicados em tempo real.
              </p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="bg-muted p-4 rounded-xl text-center min-w-[100px] border">
              <p className="text-muted-foreground text-[10px] uppercase font-bold mb-1">Total Leads</p>
              <p className="text-2xl font-bold text-foreground">{indicados.length}</p>
            </div>
            <div className="bg-muted p-4 rounded-xl text-center min-w-[100px] border">
              <p className="text-muted-foreground text-[10px] uppercase font-bold mb-1">Convertidos</p>
              <p className="text-2xl font-bold text-green-600">
                {indicados.filter(i => i.status === 'convertido').length}
              </p>
            </div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Link Generation Card */}
          <Card className="lg:col-span-2 shadow-sm border-none bg-card">
            <CardHeader className="border-b bg-muted/30">
              <div className="flex items-center gap-2">
                <LinkIcon className="h-5 w-5 text-primary" />
                <CardTitle>Seu Link de Indicação</CardTitle>
              </div>
              <CardDescription>
                Personalize seu código para deixar seus links mais profissionais.
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div className="space-y-3">
                <Label htmlFor="codigo" className="text-sm font-bold">
                  Código da sua rede:
                </Label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="codigo"
                      value={codigoRef}
                      onChange={(e) => setCodigoRef(e.target.value.toLowerCase().replace(/[^a-z0-9]/g, ''))}
                      placeholder="seu-codigo"
                      className="pl-10 h-12 font-medium bg-background"
                      maxLength={20}
                    />
                  </div>
                  <Button
                    onClick={salvarCodigoRef}
                    disabled={salvando || !codigoRef}
                    className="h-12 px-6 font-bold"
                  >
                    {salvando ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Salvar'}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Dica: Use apenas letras minúsculas e números.
                </p>
              </div>

              {linkGerado && (
                <div className="border rounded-xl p-5 bg-secondary/30 border-primary/20 space-y-4">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-500" />
                    <span className="text-sm font-bold text-green-600">Link configurado e pronto!</span>
                  </div>
                  <div className="bg-background border rounded-lg p-3 text-sm font-mono break-all text-foreground/80">
                    {linkGerado}
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={copiarLink} variant="outline" className="flex-1 h-10 border-primary/20">
                      <Copy className="h-4 w-4 mr-2" />
                      Copiar
                    </Button>
                    <Button onClick={compartilharWhatsApp} className="flex-1 h-10 bg-[#25D366] hover:bg-[#128C7E] text-white">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      WhatsApp
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Stats Card */}
          <Card className="shadow-sm border-none bg-card">
            <CardHeader className="border-b bg-muted/30">
              <CardTitle>Resumo de Performance</CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-amber-500/10 rounded-xl border border-amber-500/20">
                  <Crown className="h-6 w-6 text-amber-500" />
                </div>
                <div>
                  <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Nível Atual</p>
                  <p className="text-lg font-bold">Consultor Bronze</p>
                </div>
              </div>

              <div className="space-y-4 pt-4 border-t border-dashed border-muted-foreground/30">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground font-medium">Conversão</span>
                  <span className="font-bold">
                    {indicados.length > 0 ? ((indicados.filter(i => i.status === 'convertido').length / indicados.length) * 100).toFixed(0) : 0}%
                  </span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground font-medium">Leads (Mês)</span>
                  <span className="font-bold">
                    {indicados.filter(i => {
                      const date = new Date(i.created_at);
                      const now = new Date();
                      return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
                    }).length}
                  </span>
                </div>
              </div>

              <Button
                variant="outline"
                onClick={redirecionarRSProlipsi}
                className="w-full mt-4 h-11 border-primary/20 hover:bg-primary/5 text-primary font-bold"
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Central RS Prólipsi
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Lead List Table */}
        <Card className="shadow-sm overflow-hidden border-none bg-card">
          <CardHeader className="bg-muted/30 border-b border-muted">
            <CardTitle className="text-xl">Gestão de Indicados</CardTitle>
            <CardDescription>Acompanhe todos os leads capturados pelo seu link.</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {indicados.length === 0 ? (
              <div className="p-12 text-center text-muted-foreground italic">
                Sua lista de indicados está vazia. Comece a compartilhar seu link!
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-muted text-muted-foreground text-[10px] uppercase font-bold tracking-widest border-b border-muted">
                    <tr>
                      <th className="px-6 py-4">Nome / Email</th>
                      <th className="px-6 py-4">Data</th>
                      <th className="px-6 py-4">Contato</th>
                      <th className="px-6 py-4">Status</th>
                      <th className="px-6 py-4 text-right">Ação</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-muted text-sm">
                    {indicados.map((indicado) => (
                      <tr key={indicado.id} className="hover:bg-muted/30 transition-colors">
                        <td className="px-6 py-4">
                          <div className="font-bold text-foreground">{indicado.nome_completo}</div>
                          <div className="text-xs text-muted-foreground">{indicado.email}</div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-1.5 font-medium">
                            <Calendar className="h-3.5 w-3.5 text-primary" />
                            {indicado.created_at ? format(new Date(indicado.created_at), 'dd/MM/yyyy', { locale: ptBR }) : '-'}
                          </div>
                        </td>
                        <td className="px-6 py-4 font-medium text-foreground/80">
                          {indicado.whatsapp || indicado.telefone || '-'}
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${indicado.status === 'convertido' ? 'bg-green-500/10 text-green-500' :
                              indicado.status === 'contatado' ? 'bg-blue-500/10 text-blue-500' :
                                indicado.status === 'perdido' ? 'bg-red-500/10 text-red-500' :
                                  'bg-amber-500/10 text-amber-500'
                            }`}>
                            {indicado.status || 'novo'}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <Button variant="ghost" size="sm" asChild className="text-green-500 hover:text-green-600 hover:bg-green-500/10">
                            <a href={`https://wa.me/${indicado.whatsapp?.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer">
                              <MessageCircle className="h-4 w-4" />
                            </a>
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Tips Section */}
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: MessageCircle, title: "Fale rápido", desc: "Contate seu lead em menos de 10 minutos para converter mais." },
            { icon: TrendingUp, title: "Seja claro", desc: "Explique os benefícios de automação do RotaFácil." },
            { icon: Share2, title: "Use Stories", desc: "Mostre o sistema funcionando no seu dia a dia." }
          ].map((item, i) => (
            <Card key={i} className="border-dashed bg-muted/20 border-muted">
              <CardContent className="p-6 flex items-start gap-4">
                <item.icon className="h-6 w-6 text-primary shrink-0" />
                <div>
                  <h4 className="font-bold text-sm text-foreground">{item.title}</h4>
                  <p className="text-xs text-muted-foreground mt-1">{item.desc}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </MainLayout>
  );
}
