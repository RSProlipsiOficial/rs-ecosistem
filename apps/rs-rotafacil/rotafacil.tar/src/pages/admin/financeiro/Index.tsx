import { useState, useEffect } from "react";
import { AdminLayout } from "@/components/layout/admin-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { DollarSign, TrendingUp, Users, ArrowUpRight, ArrowDownRight, Activity } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

export default function AdminFinanceiroIndex() {
    const [summary, setSummary] = useState<any>(null);
    const [subscriptions, setSubscriptions] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const { toast } = useToast();

    useEffect(() => {
        loadBillingSummary();
    }, []);

    const loadBillingSummary = async () => {
        try {
            const { data, error } = await supabase.rpc('get_admin_billing_summary');
            if (error) throw error;
            setSummary(data);

            // Carregar últimas assinaturas
            const { data: subData, error: subError } = await supabase
                .from('user_subscriptions')
                .select(`
                    id,
                    status,
                    created_at,
                    expires_at,
                    user_id,
                    plan:subscription_plans(name, price)
                `)
                .order('created_at', { ascending: false })
                .limit(10);

            if (subError) throw subError;

            // Buscar nomes dos usuários (em lote para performance)
            const userIds = subData.map(s => s.user_id);
            const { data: userData } = await supabase
                .from('user_profiles')
                .select('user_id, nome_completo')
                .in('user_id', userIds);

            const subsWithUsers = subData.map(s => ({
                ...s,
                user_name: userData?.find(u => u.user_id === s.user_id)?.nome_completo || 'Usuário Desconhecido'
            }));

            setSubscriptions(subsWithUsers);
        } catch (error) {
            console.error("Erro ao carregar faturamento:", error);
            toast({
                title: "Erro",
                description: "Não foi possível carregar o resumo financeiro.",
                variant: "destructive"
            });
        } finally {
            setLoading(false);
        }
    };

    if (loading) return <AdminLayout>Carregando...</AdminLayout>;

    return (
        <AdminLayout>
            <div className="space-y-6">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">Faturamento e Assinaturas</h1>
                    <p className="text-muted-foreground">Gestão financeira centralizada do ecossistema Rota Fácil</p>
                </div>

                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">MRR (Recorrência Mensal)</CardTitle>
                            <DollarSign className="h-4 w-4 text-green-600" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">R$ {summary?.mrr?.toFixed(2) || "0.00"}</div>
                            <p className="text-xs text-muted-foreground">Receita vinda de assinaturas ativas</p>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Receita de IA</CardTitle>
                            <Activity className="h-4 w-4 text-purple-600" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">R$ {summary?.ia_revenue?.toFixed(2) || "0.00"}</div>
                            <p className="text-xs text-muted-foreground">Venda de créditos e planos IA</p>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Assinaturas Ativas</CardTitle>
                            <Users className="h-4 w-4 text-blue-600" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{summary?.active_subscriptions || 0}</div>
                            <p className="text-xs text-muted-foreground">Clientes pagantes atuais</p>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium">Taxa de Churn (30d)</CardTitle>
                            <TrendingUp className="h-4 w-4 text-red-600" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{summary?.churn_rate?.toFixed(1) || 0}%</div>
                            <p className="text-xs text-muted-foreground">Cancelamentos no último mês</p>
                        </CardContent>
                    </Card>
                </div>

                <Card>
                    <CardHeader>
                        <CardTitle>Últimas Assinaturas</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Usuário</TableHead>
                                    <TableHead>Plano</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Data</TableHead>
                                    <TableHead className="text-right">Valor</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {subscriptions.length > 0 ? (
                                    subscriptions.map((sub) => (
                                        <TableRow key={sub.id}>
                                            <TableCell className="font-medium">{sub.user_name}</TableCell>
                                            <TableCell>{sub.plan?.name}</TableCell>
                                            <TableCell>
                                                <Badge variant={sub.status === 'active' ? "default" : "secondary"}>
                                                    {sub.status === 'active' ? 'Ativo' : sub.status}
                                                </Badge>
                                            </TableCell>
                                            <TableCell>{new Date(sub.created_at).toLocaleDateString('pt-BR')}</TableCell>
                                            <TableCell className="text-right">
                                                R$ {sub.plan?.price?.toFixed(2) || "0,00"}
                                            </TableCell>
                                        </TableRow>
                                    ))
                                ) : (
                                    <TableRow>
                                        <TableCell colSpan={5} className="text-center py-4 text-muted-foreground">
                                            Nenhuma assinatura encontrada.
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>
        </AdminLayout>
    );
}
