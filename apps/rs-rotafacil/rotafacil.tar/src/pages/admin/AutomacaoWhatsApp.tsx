import { useState, useEffect } from "react";
import { AdminLayout } from "@/components/layout/admin-layout";
import { supabase } from "@/integrations/supabase/client";
import { Workflow, AlertTriangle, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const AutomacaoWhatsApp = () => {
    const n8nUrl = "http://localhost:5678";

    return (
        <AdminLayout>
            <div className="space-y-6">
                <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                        <Workflow className="w-8 h-8 text-gold" />
                        <h1 className="text-3xl font-bold text-gold">Automação WhatsApp (n8n)</h1>
                    </div>
                    <p className="text-muted-foreground italic">
                        Gerenciamento centralizado de fluxos de automação. Apenas administradores têm acesso a esta área.
                    </p>
                </div>

                <Alert variant="destructive" className="bg-red-900/20 border-red-900/50 text-red-200">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Atenção</AlertTitle>
                    <AlertDescription>
                        Alterações nos fluxos do n8n impactam todos os tenants. Certifique-se de que o multi-tenancy está configurado corretamente nos nós de requisição.
                    </AlertDescription>
                </Alert>

                <div className="grid gap-6">
                    <div className="bg-black-lighter border border-gold/10 rounded-xl p-6">
                        <h2 className="text-xl font-semibold text-gold mb-4 flex items-center gap-2">
                            Status do Servidor n8n
                        </h2>
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                                <div className="flex items-center gap-2">
                                    <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                                    <span className="text-sm">n8n está pronto em: <strong>{n8nUrl}</strong></span>
                                </div>
                            </div>
                            <Button
                                variant="outline"
                                className="border-gold/50 text-gold hover:bg-gold/10"
                                onClick={() => window.open(n8nUrl, '_blank')}
                            >
                                <ExternalLink className="w-4 h-4 mr-2" />
                                Abrir em Nova Aba
                            </Button>
                        </div>
                    </div>

                    <div className="border border-gold/10 rounded-xl overflow-hidden bg-black-lighter min-h-[800px]">
                        <div className="p-4 bg-black/40 border-b border-gold/10 flex justify-between items-center">
                            <span className="text-sm font-medium text-gold/80 flex items-center gap-2">
                                <Workflow className="w-4 h-4" />
                                Editor de Fluxos do Administrador
                            </span>
                            <span className="text-[10px] text-muted-foreground uppercase tracking-widest">
                                Ambiente de Produção
                            </span>
                        </div>
                        <iframe
                            src={n8nUrl}
                            className="w-full h-[750px] border-none"
                            title="n8n Admin Editor"
                        />
                    </div>
                </div>
            </div>
        </AdminLayout>
    );
};

export default AutomacaoWhatsApp;
