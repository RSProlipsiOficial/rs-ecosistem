import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Users, Edit3, Save, X, Key, Mail, Phone, User, Plus, UserPlus, ChevronRight, Folder, Home, RefreshCw, Search, BadgeCheck, Package, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { AdminLayout } from "@/components/layout/admin-layout";
import { useNavigate } from "react-router-dom";
import { z } from "zod";

interface Usuario {
  id: string;
  nome: string;
  email: string;
  telefone?: string;
  status: string;
  tipo_usuario: string;
  created_at: string;
  updated_at: string;
  ultimo_login?: string;
}

export default function AdminUsuariosIndex() {
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [teamUsage, setTeamUsage] = useState<Record<string, { motoristas: number, monitoras: number, alunos: number }>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editingUser, setEditingUser] = useState<Usuario | null>(null);
  const [showPasswordForm, setShowPasswordForm] = useState<string | null>(null);
  const [breadcrumbs, setBreadcrumbs] = useState<{ id: string | null, nome: string }[]>([{ id: null, nome: "Geral" }]);
  const [currentParentId, setCurrentParentId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [plans, setPlans] = useState<{ id: string, name: string }[]>([]);
  const { toast } = useToast();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    telefone: "",
    status: "ativo",
    tipo_usuario: "usuario"
  });

  const [passwordData, setPasswordData] = useState({
    newPassword: "",
    confirmPassword: ""
  });

  const [showNewUserForm, setShowNewUserForm] = useState(false);
  const [newUserData, setNewUserData] = useState({
    nome: "",
    email: "",
    password: "",
    confirmPassword: "",
    telefone: "",
    status: "ativo",
    tipo_usuario: "usuario"
  });

  const newUserSchema = z.object({
    nome: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
    email: z.string().email("Email inválido"),
    password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
    confirmPassword: z.string(),
  }).refine((data) => data.password === data.confirmPassword, {
    message: "Senhas não coincidem",
    path: ["confirmPassword"]
  });

  useEffect(() => {
    loadUsuarios();
    loadPlans();
  }, [currentParentId]);

  const loadPlans = async () => {
    const { data } = await supabase.from('subscription_plans').select('id, name');
    if (data) setPlans(data);
  };

  const loadUsuarios = async () => {
    try {
      setLoading(true);
      const { data: rpcData, error: rpcError } = await supabase.rpc('get_admin_users_v2', {
        p_parent_id: currentParentId
      });

      let finalUsers = [];
      if (rpcError) {
        console.error("Erro RPC v2 ao carregar usuários:", rpcError);
        // Fallback para v1 se v2 falhar (compatibilidade)
        const { data: v1Data } = await supabase.rpc('get_admin_users_list', { p_parent_id: currentParentId });
        finalUsers = v1Data || [];
      } else {
        finalUsers = rpcData || [];
      }

      const { data: usageData } = await supabase.rpc('get_admin_user_team_usage');

      setTeamUsage(usageData || {});
      setUsuarios(finalUsers);
    } catch (error) {
      console.error('Erro ao carregar usuários:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível carregar os usuários.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredUsuarios = usuarios.filter(u =>
    u.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSave = async () => {
    if (!editingUser) return;

    setSaving(true);
    try {
      const { data, error } = await supabase.rpc('admin_update_user_v2', {
        p_user_id: editingUser.id,
        p_nome: formData.nome,
        p_telefone: formData.telefone,
        p_tipo_usuario: formData.tipo_usuario,
        p_plan_id: formData.plan_id || null,
        p_status: formData.status
      });

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Usuário atualizado com sucesso!",
      });

      setEditingUser(null);
      loadUsuarios(); // Reload to get updated stats and metadata
    } catch (error: any) {
      console.error("Erro ao salvar:", error);
      toast({
        title: "Erro ao salvar",
        description: error.message || "Tente novamente mais tarde.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async (userId: string) => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        title: "Erro",
        description: "As senhas não coincidem.",
        variant: "destructive",
      });
      return;
    }

    if (passwordData.newPassword.length < 6) {
      toast({
        title: "Erro",
        description: "A senha deve ter pelo menos 6 caracteres.",
        variant: "destructive",
      });
      return;
    }

    try {
      // Here you would implement the password change via Supabase Admin API
      // For example:
      const { data, error } = await supabase.functions.invoke('admin-users', {
        method: 'PUT',
        body: {
          userId: userId,
          password: passwordData.newPassword,
        },
      });

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Senha alterada com sucesso!",
      });

      setShowPasswordForm(null);
      setPasswordData({ newPassword: "", confirmPassword: "" });
    } catch (error) {
      console.error('Erro ao alterar senha:', error);
      toast({
        title: "Erro",
        description: "Não foi possível alterar a senha.",
        variant: "destructive",
      });
    }
  };

  const handleEdit = (usuario: Usuario) => {
    setEditingUser(usuario);
    setFormData({
      nome: usuario.nome,
      email: usuario.email,
      telefone: usuario.telefone || "",
      status: usuario.status,
      tipo_usuario: usuario.tipo_usuario,
      plan_id: usuario.plan_id || "", // Set plan_id
      van_id: usuario.van_id || "", // Set van_id
      senha: "" // Clear password field on edit
    });
  };

  const resetForm = () => {
    setFormData({
      nome: "",
      email: "",
      telefone: "",
      status: "ativo",
      tipo_usuario: "usuario",
      plan_id: "",
      van_id: "",
      senha: ""
    });
    setEditingUser(null);
  };

  const resetNewUserForm = () => {
    setNewUserData({
      nome: "",
      email: "",
      password: "",
      confirmPassword: "",
      telefone: "",
      status: "ativo",
      tipo_usuario: "usuario"
    });
    setShowNewUserForm(false);
  };
  const handleNavigateToUser = (usuario: Usuario) => {
    // Only drill down if it's not a driver/monitor (which don't usually have sub-teams in this context)
    // or if they have usage > 0
    const usage = teamUsage[usuario.id];
    const hasTeam = (usage?.motoristas || 0) > 0 || (usage?.monitoras || 0) > 0 || (usage?.alunos || 0) > 0;

    if (hasTeam || usuario.tipo_usuario === 'admin' || usuario.tipo_usuario === 'master') {
      setCurrentParentId(usuario.id);
      setBreadcrumbs(prev => [...prev, { id: usuario.id, nome: usuario.nome }]);
    }
  };

  const navigateToBreadcrumb = (index: number) => {
    const item = breadcrumbs[index];
    const newBreadcrumbs = breadcrumbs.slice(0, index + 1);
    setBreadcrumbs(newBreadcrumbs);
    setCurrentParentId(item.id);
  };

  const handleCreateUser = async () => {
    setSaving(true);
    try {
      const validation = newUserSchema.parse(newUserData);

      const { data, error } = await supabase.functions.invoke('admin-users', {
        method: 'POST',
        body: {
          nome: validation.nome,
          email: validation.email,
          password: validation.password,
          telefone: newUserData.telefone,
          tipo_usuario: newUserData.tipo_usuario,
        },
      });
      if (error) throw error;

      toast({ title: 'Sucesso', description: 'Usuário criado com sucesso!' });
      resetNewUserForm();
      await loadUsuarios();
    } catch (error: any) {
      console.error('Erro ao criar usuário:', error);
      if (error instanceof z.ZodError) {
        toast({ title: 'Erro de validação', description: error.errors[0].message, variant: 'destructive' });
      } else {
        toast({ title: 'Erro', description: error?.message || 'Não foi possível criar o usuário.', variant: 'destructive' });
      }
    } finally {
      setSaving(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ativo": return "bg-green-100 text-green-800";
      case "inativo": return "bg-red-100 text-red-800";
      case "pendente": return "bg-yellow-100 text-yellow-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getTipoColor = (tipo: string) => {
    switch (tipo) {
      case "admin": return "bg-purple-100 text-purple-800";
      case "consultor": return "bg-blue-100 text-blue-800";
      case "motorista": return "bg-orange-100 text-orange-800";
      case "monitora": return "bg-pink-100 text-pink-800";
      case "usuario": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center min-h-[50vh]">
          <p className="text-muted-foreground">Carregando usuários...</p>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex-1 w-full relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome ou email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12 bg-card border-border/50 focus:border-primary transition-all text-lg"
            />
          </div>
          <div className="flex gap-2 w-full md:w-auto">
            <Button
              variant="outline"
              onClick={loadUsuarios}
              disabled={loading}
              className="h-12 px-4"
              title="Recarregar usuários"
            >
              <RefreshCw className={`w-5 h-5 ${loading ? "animate-spin" : ""}`} />
            </Button>
            <Button
              onClick={() => setShowNewUserForm(true)}
              className="h-12 px-6 text-base font-semibold"
            >
              <UserPlus className="w-5 h-5 mr-2" />
              Cadastrar Novo Usuário
            </Button>
          </div>
        </div>

        {/* Breadcrumbs */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/30 p-3 rounded-lg border border-border/50">
          {breadcrumbs.map((bc, index) => (
            <div key={bc.id || 'root'} className="flex items-center gap-2">
              <button
                onClick={() => navigateToBreadcrumb(index)}
                className={`hover:text-primary transition-colors flex items-center gap-1 ${index === breadcrumbs.length - 1 ? "text-primary font-bold pointer-events-none" : ""}`}
              >
                {index === 0 && <Home className="w-4 h-4" />}
                {bc.nome}
              </button>
              {index < breadcrumbs.length - 1 && <ChevronRight className="w-4 h-4" />}
            </div>
          ))}
        </nav>

        {/* Formulário de Novo Usuário */}
        {showNewUserForm && (
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserPlus className="w-5 h-5" />
                Cadastrar Novo Usuário
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6 p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="new-nome" className="text-base font-semibold text-foreground">
                    Nome Completo *
                  </Label>
                  <Input
                    id="new-nome"
                    value={newUserData.nome}
                    onChange={(e) => setNewUserData(prev => ({ ...prev, nome: e.target.value }))}
                    placeholder="Digite o nome completo"
                    className="h-12 text-base bg-background border-2 border-border focus:border-primary"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="new-email" className="text-base font-semibold text-foreground">
                    Email *
                  </Label>
                  <Input
                    id="new-email"
                    type="email"
                    value={newUserData.email}
                    onChange={(e) => setNewUserData(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="email@exemplo.com"
                    className="h-12 text-base bg-background border-2 border-border focus:border-primary"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="new-password" className="text-base font-semibold text-foreground">
                    Senha *
                  </Label>
                  <Input
                    id="new-password"
                    type="password"
                    value={newUserData.password}
                    onChange={(e) => setNewUserData(prev => ({ ...prev, password: e.target.value }))}
                    placeholder="Digite a senha"
                    className="h-12 text-base bg-background border-2 border-border focus:border-primary"
                  />
                  <p className="text-sm text-muted-foreground">Mínimo 6 caracteres</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="new-confirm-password" className="text-base font-semibold text-foreground">
                    Confirmar Senha *
                  </Label>
                  <Input
                    id="new-confirm-password"
                    type="password"
                    value={newUserData.confirmPassword}
                    onChange={(e) => setNewUserData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                    placeholder="Confirme a senha"
                    className="h-12 text-base bg-background border-2 border-border focus:border-primary"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="new-telefone" className="text-base font-semibold text-foreground">
                    Telefone
                  </Label>
                  <Input
                    id="new-telefone"
                    value={newUserData.telefone}
                    onChange={(e) => setNewUserData(prev => ({ ...prev, telefone: e.target.value }))}
                    placeholder="(11) 99999-9999"
                    className="h-12 text-base bg-background border-2 border-border focus:border-primary"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="new-status" className="text-base font-semibold text-foreground">
                    Status do Usuário
                  </Label>
                  <Select value={newUserData.status} onValueChange={(value) => setNewUserData(prev => ({ ...prev, status: value }))}>
                    <SelectTrigger className="h-12 text-base bg-background border-2 border-border focus:border-primary">
                      <SelectValue placeholder="Selecione o status" />
                    </SelectTrigger>
                    <SelectContent className="bg-popover border-border z-50">
                      <SelectItem value="ativo" className="text-base">✅ Ativo</SelectItem>
                      <SelectItem value="inativo" className="text-base">❌ Inativo</SelectItem>
                      <SelectItem value="pendente" className="text-base">⏳ Pendente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="new-tipo_usuario" className="text-base font-semibold text-foreground">
                    Tipo de Usuário
                  </Label>
                  <Select value={newUserData.tipo_usuario} onValueChange={(value) => setNewUserData(prev => ({ ...prev, tipo_usuario: value }))}>
                    <SelectTrigger className="h-12 text-base bg-background border-2 border-border focus:border-primary">
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent className="bg-popover border-border z-50">
                      <SelectItem value="usuario" className="text-base">👤 Usuário</SelectItem>
                      <SelectItem value="consultor" className="text-base">💼 Consultor</SelectItem>
                      <SelectItem value="motorista" className="text-base">🚐 Motorista</SelectItem>
                      <SelectItem value="monitora" className="text-base">👩‍🏫 Monitora</SelectItem>
                      <SelectItem value="admin" className="text-base">🔧 Administrador</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-border">
                <Button
                  onClick={handleCreateUser}
                  disabled={saving}
                  className="h-12 px-6 text-base font-semibold"
                >
                  <UserPlus className="w-5 h-5 mr-2" />
                  {saving ? "Criando..." : "Criar Usuário"}
                </Button>
                <Button
                  variant="outline"
                  onClick={resetNewUserForm}
                  className="h-12 px-6 text-base font-semibold border-2"
                >
                  <X className="w-5 h-5 mr-2" />
                  Cancelar
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Formulário de Edição */}
        {editingUser && (
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Edit3 className="w-5 h-5" />
                Editando Usuário: <span className="font-bold">{editingUser.nome}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6 p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="nome" className="text-base font-semibold text-foreground">
                    Nome Completo *
                  </Label>
                  <Input
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData(prev => ({ ...prev, nome: e.target.value }))}
                    placeholder="Digite o nome completo"
                    className="h-12 text-base bg-background border-2 border-border focus:border-primary"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-base font-semibold text-foreground">
                    Email *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="email@exemplo.com"
                    className="h-12 text-base bg-background border-2 border-border focus:border-primary"
                    disabled // Email usually not editable directly
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="telefone" className="text-base font-semibold text-foreground">
                    Telefone
                  </Label>
                  <Input
                    id="telefone"
                    value={formData.telefone}
                    onChange={(e) => setFormData(prev => ({ ...prev, telefone: e.target.value }))}
                    placeholder="(11) 99999-9999"
                    className="h-12 text-base bg-background border-2 border-border focus:border-primary"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tipo_usuario" className="text-base font-semibold text-foreground">
                    Tipo de Usuário
                  </Label>
                  <Select value={formData.tipo_usuario} onValueChange={(value) => setFormData(prev => ({ ...prev, tipo_usuario: value }))}>
                    <SelectTrigger className="h-12 text-base bg-background border-2 border-border focus:border-primary">
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent className="bg-popover border-border z-50">
                      <SelectItem value="usuario" className="text-base">👤 Usuário</SelectItem>
                      <SelectItem value="consultor" className="text-base">💼 Consultor</SelectItem>
                      <SelectItem value="motorista" className="text-base">🚐 Motorista</SelectItem>
                      <SelectItem value="monitora" className="text-base">👩‍🏫 Monitora</SelectItem>
                      <SelectItem value="admin" className="text-base">🔧 Administrador</SelectItem>
                      <SelectItem value="master" className="text-base">👑 Master</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-base font-semibold text-foreground">Kit / Plano do Sistema</Label>
                    <Select
                      value={formData.plan_id}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, plan_id: value }))}
                    >
                      <SelectTrigger className="h-12 text-base bg-background border-2 border-border focus:border-primary">
                        <SelectValue placeholder="Selecione o Plano (Kit)" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover border-border z-50">
                        {plans.map(p => (
                          <SelectItem key={p.id} value={p.id} className="text-base">{p.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-muted-foreground">
                      Alterar o Kit atualizará imediatamente o limite de alunos e frotas do usuário.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-base font-semibold text-foreground">Status do Usuário</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
                    >
                      <SelectTrigger className="h-12 text-base bg-background border-2 border-border focus:border-primary">
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover border-border z-50">
                        <SelectItem value="ativo" className="text-base">✅ Ativo</SelectItem>
                        <SelectItem value="inativo" className="text-base">❌ Inativo</SelectItem>
                        <SelectItem value="pendente" className="text-base">⏳ Pendente</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center pt-6 border-t border-border/50">
                <div className="flex gap-3">
                  <Button onClick={handleSave} disabled={saving} className="h-12 px-6 text-base font-semibold bg-primary hover:bg-primary/90 gap-2">
                    {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                    {saving ? "Salvando..." : "Salvar Alterações"}
                  </Button>
                  <Button variant="outline" onClick={resetForm} disabled={saving} className="h-12 px-6 text-base font-semibold border-2 gap-2">
                    <X className="w-5 h-5" />
                    Cancelar
                  </Button>
                </div>

                <Button
                  variant="outline"
                  onClick={() => setShowPasswordForm(editingUser.id)}
                  className="h-12 px-6 text-base font-semibold border-primary/20 hover:bg-primary/5 text-primary gap-2"
                >
                  <Key className="w-5 h-5" />
                  Alterar Senha
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Formulário de Alteração de Senha */}
        {showPasswordForm && (
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="w-5 h-5" />
                Alterar Senha do Usuário
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6 p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="newPassword" className="text-base font-semibold text-foreground">
                    Nova Senha *
                  </Label>
                  <Input
                    id="newPassword"
                    type="password"
                    value={passwordData.newPassword}
                    onChange={(e) => setPasswordData(prev => ({ ...prev, newPassword: e.target.value }))}
                    placeholder="Digite a nova senha"
                    className="h-12 text-base bg-background border-2 border-border focus:border-primary"
                  />
                  <p className="text-sm text-muted-foreground">Mínimo 6 caracteres</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword" className="text-base font-semibold text-foreground">
                    Confirmar Nova Senha *
                  </Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                    placeholder="Confirme a nova senha"
                    className="h-12 text-base bg-background border-2 border-border focus:border-primary"
                  />
                  <p className="text-sm text-muted-foreground">Deve ser igual à senha acima</p>
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-border">
                <Button
                  onClick={() => handleChangePassword(showPasswordForm)}
                  className="h-12 px-6 text-base font-semibold bg-orange-500 hover:bg-orange-600"
                >
                  <Key className="w-5 h-5 mr-2" />
                  Confirmar Alteração
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowPasswordForm(null);
                    setPasswordData({ newPassword: "", confirmPassword: "" });
                  }}
                  className="h-12 px-6 text-base font-semibold border-2"
                >
                  <X className="w-5 h-5 mr-2" />
                  Cancelar
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Lista de Usuários */}
        <div className="grid gap-4">
          {filteredUsuarios.map((usuario) => (
            <Card key={usuario.id} className="border-border/50 bg-card hover:border-primary/30 transition-all group relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1 h-full bg-primary opacity-0 group-hover:opacity-100 transition-opacity" />
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div
                      className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center cursor-pointer hover:scale-105 transition-transform"
                      onClick={() => handleNavigateToUser(usuario)}
                    >
                      {(usuario.tipo_usuario === 'admin' || usuario.tipo_usuario === 'master') ? (
                        <Folder className="w-6 h-6 text-white" />
                      ) : (
                        <User className="w-6 h-6 text-white" />
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-lg">{usuario.nome}</h3>
                        <Badge variant="outline" className={`capitalize ${usuario.tipo_usuario === 'admin' ? "bg-red-500/10 text-red-500 border-red-500/20" :
                          usuario.tipo_usuario === 'master' ? "bg-primary/10 text-primary border-primary/20" :
                            "bg-muted text-muted-foreground"
                          }`}>
                          {usuario.tipo_usuario === 'admin' ? 'Super Admin' :
                            usuario.tipo_usuario === 'master' ? 'Master / Folder' :
                              usuario.tipo_usuario}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Mail className="w-4 h-4" />
                          {usuario.email}
                        </div>
                        {usuario.telefone && (
                          <div className="flex items-center gap-1">
                            <Phone className="w-4 h-4" />
                            {usuario.telefone}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-4 mt-2">
                        <div className="flex items-center gap-1 text-[10px] bg-muted px-2 py-0.5 rounded-full">
                          <span className="font-bold">Equipe:</span>
                          <span>{teamUsage[usuario.id]?.motoristas || 0} Motoristas</span>
                          <span className="text-muted-foreground mx-1">|</span>
                          <span>{teamUsage[usuario.id]?.monitoras || 0} Monitoras</span>
                          <span className="text-muted-foreground mx-1">|</span>
                          <span className="text-primary font-bold">{teamUsage[usuario.id]?.alunos || 0} Alunos</span>
                        </div>

                        {(teamUsage[usuario.id]?.motoristas > 0 || teamUsage[usuario.id]?.alunos > 0) && (
                          <Badge variant="outline" className="text-[10px] border-primary/50 text-primary">
                            Conta Master / Empresa
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {((teamUsage[usuario.id]?.motoristas || 0) > 0 || (teamUsage[usuario.id]?.alunos || 0) > 0) && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-primary hover:text-primary-foreground hover:bg-primary transition-all font-semibold border border-primary/20"
                        onClick={() => handleNavigateToUser(usuario)}
                      >
                        <Folder className="w-4 h-4 mr-2" />
                        Ver Equipe
                        <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    )}
                    {(usuario.tipo_usuario === 'motorista' || usuario.tipo_usuario === 'monitora') && (
                      <Button
                        size="sm"
                        variant="secondary"
                        className="bg-yellow-400 hover:bg-yellow-500 text-black font-semibold"
                        onClick={() => navigate(`/admin/usuarios/${usuario.id}/visualizar`, { state: { type: usuario.tipo_usuario } })}
                      >
                        <User className="w-4 h-4 mr-2" />
                        Ver Painel
                      </Button>
                    )}
                    <Button size="sm" variant="outline" onClick={() => handleEdit(usuario)}>
                      <Edit3 className="w-4 h-4 mr-2" />
                      Editar
                    </Button>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-4 pt-4 border-t text-xs text-muted-foreground">
                  <span>Cadastrado: {new Date(usuario.created_at).toLocaleString('pt-BR')}</span>
                  {usuario.ultimo_login && (
                    <span>Último login: {new Date(usuario.ultimo_login).toLocaleString('pt-BR')}</span>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {usuarios.length === 0 && !loading && (
          <Card>
            <CardContent className="p-12 text-center">
              <div className="w-20 h-20 bg-muted/50 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="w-10 h-10 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-bold mb-2">Nenhum usuário nesta pasta</h3>
              <p className="text-muted-foreground mb-6 max-w-sm mx-auto">
                {currentParentId
                  ? "Esta equipe ainda não possui colaboradores cadastrados."
                  : "Nenhuma conta Master ou Admin encontrada no nível geral."}
              </p>
              <Button onClick={loadUsuarios} variant="outline" className="gap-2">
                <RefreshCw className="w-4 h-4" />
                Recarregar Lista
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  );
}