import { useState, useEffect } from "react";
import { AdminLayout } from "@/components/layout/admin-layout";
import { WhatsAppManager } from "@/components/whatsapp/whatsapp-manager";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MessageSquare, Workflow, AlertTriangle, ExternalLink, Smartphone, LayoutDashboard, Settings2, RefreshCcw } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";

const AdminWhatsAppIndex = () => {
    const n8nUrl = "http://localhost:5678";
    const [apiPort, setApiPort] = useState("4433");
    const advansUrl = `http://localhost:${apiPort}`;
    const [advansView, setAdvansView] = useState<'simple' | 'full'>('simple');
    const [isOffline, setIsOffline] = useState(false);

    useEffect(() => {
        const checkConnection = async () => {
            try {
                const res = await fetch(`http://localhost:${apiPort}`, { mode: 'no-cors' });
                setIsOffline(false);
            } catch (e) {
                setIsOffline(true);
            }
        };
        checkConnection();
        const timer = setInterval(checkConnection, 10000);
        return () => clearInterval(timer);
    }, [apiPort]);

    return (
        <AdminLayout>
            <div className="space-y-6">
                <div className="flex flex-col gap-2">
                    <h1 className="text-3xl font-bold text-gold flex items-center gap-3">
                        <Smartphone className="h-8 w-8" />
                        WhatsApp Admin (Advans)
                    </h1>
                    <p className="text-muted-foreground italic">
                        Gerencie as conexões mestras e os fluxos globais de automação.
                    </p>
                </div>

                <Tabs defaultValue="advans" className="w-full">
                    <TabsList className="grid w-full grid-cols-2 max-w-md bg-black-lighter border border-gold/20">
                        <TabsTrigger value="advans" className="flex items-center gap-2 data-[state=active]:bg-gold data-[state=active]:text-black">
                            <Smartphone className="w-4 h-4" />
                            WhatsApp Web
                        </TabsTrigger>
                        <TabsTrigger value="workflow" className="flex items-center gap-2 data-[state=active]:bg-gold data-[state=active]:text-black">
                            <Workflow className="w-4 h-4" />
                            Automação (n8n)
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="advans" className="mt-6 space-y-4">
                        <div className="flex items-center justify-between bg-black/40 p-4 border border-gold/10 rounded-xl">
                            <div className="flex items-center gap-2">
                                <LayoutDashboard className="w-5 h-5 text-gold" />
                                <span className="text-sm font-semibold text-gold">Modo de Visualização</span>
                            </div>
                            <div className="flex bg-black-lighter p-1 rounded-lg border border-gold/20">
                                <button
                                    onClick={() => setAdvansView('simple')}
                                    className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all ${advansView === 'simple' ? 'bg-gold text-black' : 'text-gold hover:bg-gold/10'}`}
                                >
                                    GERENCIADOR SIMPLES
                                </button>
                                <button
                                    onClick={() => setAdvansView('full')}
                                    className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all ${advansView === 'full' ? 'bg-gold text-black' : 'text-gold hover:bg-gold/10'}`}
                                >
                                    PAINEL COMPLETO (API)
                                </button>
                            </div>
                        </div>

                        {advansView === 'simple' ? (
                            <WhatsAppManager />
                        ) : (
                            <div className="space-y-4">
                                <Alert className="bg-gold/10 border-gold/20 text-gold">
                                    <Settings2 className="h-4 w-4" />
                                    <AlertTitle>Painel Evolution API (Advans)</AlertTitle>
                                    <AlertDescription>
                                        Aqui você tem acesso a todas as configurações de nível baixo da API. Use para debug e configurações avançadas.
                                    </AlertDescription>
                                </Alert>
                                {isOffline && (
                                    <Alert variant="destructive" className="bg-red-950 border-red-500 text-white mb-6 animate-pulse">
                                        <AlertTriangle className="h-4 w-4" />
                                        <AlertTitle className="font-bold">Servidor Offline!</AlertTitle>
                                        <AlertDescription>
                                            O Gerenciador de WhatsApp não está rodando na porta {apiPort}.
                                            <br />
                                            <span className="font-bold">Como resolver:</span> Execute o arquivo <code className="bg-black/50 px-1 rounded">start-whatsapp-env.bat</code> localizado na pasta raiz do projeto no seu PC.
                                        </AlertDescription>
                                    </Alert>
                                )}

                                <div className="border border-gold/10 rounded-xl overflow-hidden bg-black-lighter min-h-[750px] relative">
                                    <div className="p-4 bg-black/40 border-b border-gold/10 flex justify-between items-center">
                                        <div className="flex items-center gap-4">
                                            <div className="flex items-center gap-2">
                                                <div className={`w-2 h-2 rounded-full animate-pulse ${isOffline ? 'bg-red-500' : 'bg-green-500'}`} />
                                                <span className="text-xs text-gold/80 font-mono">localhost:{apiPort} {isOffline && '(Offline)'}</span>
                                            </div>
                                            <div className="flex items-center gap-2 border-l border-gold/20 pl-4 ml-2">
                                                <span className="text-[10px] text-gold/60 uppercase font-bold">Porta:</span>
                                                <select
                                                    value={apiPort}
                                                    onChange={(e) => setApiPort(e.target.value)}
                                                    className="bg-black/50 text-gold text-[10px] border border-gold/30 rounded px-1 focus:outline-none focus:border-gold"
                                                >
                                                    <option value="4433">4433</option>
                                                    <option value="8081">8081</option>
                                                    <option value="8080">8080</option>
                                                    <option value="3000">3000</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Button
                                                variant="outline"
                                                size="sm"
                                                className="h-8 border-gold/30 text-gold hover:bg-gold/10"
                                                onClick={() => window.location.reload()}
                                            >
                                                <RefreshCcw className="w-3 h-3 mr-2" />
                                                Recarregar
                                            </Button>
                                            <Button
                                                variant="ghost"
                                                size="sm"
                                                className="h-8 text-[10px] text-gold hover:bg-gold/10 uppercase tracking-widest"
                                                onClick={() => window.open(advansUrl, '_blank')}
                                            >
                                                <ExternalLink className="w-3 h-3 mr-2" />
                                                Abrir em nova aba
                                            </Button>
                                        </div>
                                    </div>
                                    <iframe
                                        src={advansUrl}
                                        className="w-full h-[700px] border-none"
                                        title="Advans Manager Panel"
                                    />
                                </div>
                            </div>
                        )}
                    </TabsContent>

                    <TabsContent value="workflow" className="mt-6 space-y-6">
                        <Alert variant="destructive" className="bg-red-900/20 border-red-900/50 text-red-200">
                            <AlertTriangle className="h-4 w-4" />
                            <AlertTitle>Ambiente do Administrador</AlertTitle>
                            <AlertDescription>
                                Estes fluxos afetam o sistema global. Use com cautela.
                            </AlertDescription>
                        </Alert>

                        <div className="bg-black-lighter border border-gold/10 rounded-xl p-6">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                    <div className="flex items-center gap-2">
                                        <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                                        <span className="text-sm">Servidor n8n ativo em: <strong>{n8nUrl}</strong></span>
                                    </div>
                                    <div className="h-4 w-px bg-gold/20 mx-2" />
                                    <Button
                                        variant="link"
                                        size="sm"
                                        className="text-gold p-0 h-auto font-bold flex items-center gap-1 hover:no-underline"
                                        onClick={() => {
                                            const tabTrigger = document.querySelector('[value="advans"]') as HTMLButtonElement;
                                            if (tabTrigger) tabTrigger.click();
                                        }}
                                    >
                                        <Smartphone className="w-4 h-4" />
                                        Abrir WhatsApp Web
                                    </Button>
                                </div>
                                <Button
                                    variant="outline"
                                    size="sm"
                                    className="border-gold/50 text-gold hover:bg-gold/10"
                                    onClick={() => window.open(n8nUrl, '_blank')}
                                >
                                    <ExternalLink className="w-4 h-4 mr-2" />
                                    Abrir Editor Externo
                                </Button>
                            </div>
                        </div>

                        <div className="border border-gold/10 rounded-xl overflow-hidden bg-black-lighter min-h-[700px]">
                            <div className="p-4 bg-black/40 border-b border-gold/10 flex justify-between items-center">
                                <span className="text-sm font-medium text-gold/80 flex items-center gap-2">
                                    <Workflow className="w-4 h-4" />
                                    Editor de Fluxos do Sistema
                                </span>
                                <span className="text-[10px] text-muted-foreground uppercase tracking-widest">
                                    Powered by n8n.io
                                </span>
                            </div>
                            <iframe
                                src={n8nUrl}
                                className="w-full h-[650px] border-none"
                                title="n8n Workflow Editor"
                            />
                        </div>
                    </TabsContent>
                </Tabs>
            </div>
        </AdminLayout >
    );
};

export default AdminWhatsAppIndex;
