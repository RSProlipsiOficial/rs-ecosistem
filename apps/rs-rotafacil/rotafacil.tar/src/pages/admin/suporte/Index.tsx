import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { MessageCircle, Save, Loader2, Bot, Type } from "lucide-react";
import { AdminLayout } from "@/components/layout/admin-layout";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export default function SupportIndex() {
  const [whatsapp, setWhatsapp] = useState("");
  const [aiPrompt, setAiPrompt] = useState("");
  const [supportName, setSupportName] = useState("");
  const [whatsappMessage, setWhatsappMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('value')
        .eq('key', 'support_config')
        .maybeSingle();

      if (error) throw error;

      if (data?.value) {
        const config = data.value as any;
        setWhatsapp(config.whatsapp || "");
        setAiPrompt(config.ai_prompt || "");
        setSupportName(config.support_name || "Suporte Rota Fácil");
        setWhatsappMessage(config.whatsapp_message || "Olá! Gostaria de falar com o suporte.");
      } else {
        setAiPrompt("Você é o assistente inteligente da plataforma Rota Fácil. Sua missão é ajudar os usuários (transportadores escolares) com dúvidas sobre alunos, vans e financeiro. Seja cordial, direto e use os dados do sistema para dar respostas precisas.");
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
      toast({
        title: "Erro ao carregar",
        description: "Não foi possível carregar as configurações.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (saving) return;
    setSaving(true);

    try {
      const config = {
        whatsapp,
        ai_prompt: aiPrompt,
        support_name: supportName,
        whatsapp_message: whatsappMessage
      };

      const { error } = await supabase
        .from('app_settings')
        .upsert({
          key: 'support_config',
          value: config as any
        });

      if (error) throw error;

      toast({
        title: "Sucesso!",
        description: "Configurações atualizadas.",
        className: "bg-green-600 text-white border-none",
      });
    } catch (error: any) {
      console.error('CRITICAL SAVE ERROR:', error);
      toast({
        title: "Erro ao salvar",
        description: error.message || "Ocorreu um erro inesperado.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex justify-center items-center h-[calc(100vh-200px)]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-8 max-w-4xl p-4 md:p-6 mx-auto">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-amber-500" translate="no">Suporte</h1>
          <p className="text-muted-foreground mt-2">
            Gerencie o contato de suporte e o comportamento da IA.
          </p>
        </div>

        <div className="grid gap-6">
          <Card className="bg-slate-900/50 border-slate-800 shadow-xl overflow-hidden">
            <CardHeader className="bg-slate-800/50 border-b border-slate-700/50">
              <CardTitle className="flex items-center gap-2 text-slate-100 uppercase tracking-wider text-base">
                <MessageCircle className="w-5 h-5 text-green-500" />
                WhatsApp de Suporte
              </CardTitle>
              <CardDescription className="text-slate-400">
                Configure o número e a identificação do suporte.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="supportName" className="text-slate-200">Nome de Exibição</Label>
                  <Input
                    id="supportName"
                    placeholder="Ex: Roberto - Rota Fácil"
                    value={supportName}
                    onChange={(e) => setSupportName(e.target.value)}
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="whatsapp" className="text-slate-200">Número do WhatsApp (com DDD)</Label>
                  <Input
                    id="whatsapp"
                    placeholder="5511999999999"
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="whatsappMessage" className="text-slate-200">Mensagem Inicial</Label>
                <Input
                  id="whatsappMessage"
                  placeholder="Olá! Como posso ajudar?"
                  value={whatsappMessage}
                  onChange={(e) => setWhatsappMessage(e.target.value)}
                  className="bg-slate-800 border-slate-700 text-white"
                />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 shadow-xl overflow-hidden border-teal-500/30">
            <CardHeader className="bg-teal-500/10 border-b border-teal-500/20">
              <CardTitle className="flex items-center gap-2 text-teal-100 uppercase tracking-wider text-base">
                <Bot className="w-5 h-5 text-teal-400" />
                Regras de Inteligência (Base do Sistema)
              </CardTitle>
              <CardDescription className="text-teal-200/60">
                Estas instruções são a base fixa que garante o funcionamento das ferramentas e navegação.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 font-mono text-[11px] leading-relaxed text-slate-300">
                <p>VOCÊ É O CÉREBRO SUPREMO E CONSULTOR ESTRATÉGICO DA PLATAFORMA ROTA FÁCIL.</p>
                <br />
                <p>DIFERENCIAÇÃO CONCEITUAL:</p>
                <p>- ALUNOS: São seus CLIENTES (Fonte de Renda).</p>
                <p>- COLABORADORES: São seus FUNCIONÁRIOS (Motoristas/Monitoras).</p>
                <br />
                <p>MAPA DO ECOSSISTEMA (12 MÓDULOS):</p>
                <p>1. Painel | 2. Alunos | 3. Financeiro | 4. Mensalidades | 5. Colaboradores | 6. Frota/Vans | 7. Treinamentos | 8. Upgrade | 9. Importar | 10. Indicações | 11. Suporte | 12. Perfil</p>
                <br />
                <p>REGRAS DE FERRAMENTAS (SUPER IA):</p>
                <p>- Alunos/Mensalidades/Inadimplentes: 'get_student_info', 'get_overdue_analysis'</p>
                <p>- Fluxo de Caixa Diário: 'get_daily_cashflow'</p>
                <p>- Frota (Vans, Manutenções, Checklists): 'get_fleet_details'</p>
                <p>- Treinamentos (Vídeos, Módulos): 'get_training_status'</p>
                <p>- Planos & Upgrade: 'get_plans_and_billing'</p>
                <p>- Colaboradores (Motoristas/Monitoras): 'get_team_members'</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/50 border-slate-800 shadow-xl overflow-hidden">
            <CardHeader className="bg-slate-800/50 border-b border-slate-700/50">
              <CardTitle className="flex items-center gap-2 text-slate-100 uppercase tracking-wider text-base">
                <Type className="w-5 h-5 text-amber-500" />
                Sua Instrução Personalizada (Complemento)
              </CardTitle>
              <CardDescription className="text-slate-400">
                O "Toque Final". Defina aqui a personalidade, girias ou regras específicas do seu negócio.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="prompt" className="text-slate-200 italic text-xs">Estas instruções serão somadas à base acima:</Label>
                <Textarea
                  id="prompt"
                  placeholder="Ex: Responda de forma alegre e chame os alunos de 'passageiros mirins'..."
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  className="min-h-[200px] bg-slate-800 border-slate-700 text-white font-mono text-sm leading-relaxed focus:border-amber-500/50"
                />
                <div className="bg-amber-500/10 border border-amber-500/20 p-3 rounded-lg mt-2">
                  <p className="text-[11px] text-amber-200 leading-tight">
                    <strong>Dica:</strong> A IA lê o bloco base primeiro (links e ferramentas) e depois lê as suas instruções para decidir como falar.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end pt-4" key={saving ? 'saving' : 'idle'}>
            <Button
              onClick={handleSave}
              disabled={saving}
              className="w-full md:w-auto min-w-[200px] bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold gap-2"
            >
              {saving ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="h-5 w-5" />
                  Salvar Configurações
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}