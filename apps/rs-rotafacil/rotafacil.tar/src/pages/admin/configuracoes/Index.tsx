import { useState, useEffect } from "react";
import { AdminLayout } from "@/components/layout/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Settings, CreditCard, Save, Lock } from "lucide-react";

export default function AdminConfiguracoesIndex() {
    const [loading, setLoading] = useState(false);
    const [mercadoPagoConfig, setMercadoPagoConfig] = useState({
        access_token: "",
        public_key: ""
    });
    const { toast } = useToast();

    useEffect(() => {
        loadSettings();
    }, []);

    const loadSettings = async () => {
        try {
            setLoading(true);
            const { data, error } = await supabase
                .from('app_settings')
                .select('*')
                .eq('key', 'mercado_pago')
                .maybeSingle();

            if (error) throw error;

            if (data && data.value) {
                setMercadoPagoConfig({
                    access_token: (data.value as any).access_token || "",
                    public_key: (data.value as any).public_key || ""
                });
            }
        } catch (error) {
            console.error("Erro ao carregar configurações:", error);
            toast({
                title: "Erro",
                description: "Não foi possível carregar as configurações.",
                variant: "destructive"
            });
        } finally {
            setLoading(false);
        }
    };

    const handleSave = async () => {
        try {
            setLoading(true);

            const { data: { user } } = await supabase.auth.getUser();

            const { error } = await supabase
                .from('app_settings')
                .upsert({
                    key: 'mercado_pago',
                    value: mercadoPagoConfig,
                    updated_by: user?.id
                });

            if (error) throw error;

            toast({
                title: "Sucesso",
                description: "Configurações salvas com sucesso!",
            });
        } catch (error: any) {
            console.error("Erro ao salvar:", error);
            toast({
                title: "Erro",
                description: error.message || "Erro ao salvar configurações",
                variant: "destructive"
            });
        } finally {
            setLoading(false);
        }
    };

    return (
        <AdminLayout>
            <div className="space-y-6">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">Configurações do Sistema</h1>
                    <p className="text-muted-foreground">Gerencie as integrações e chaves de API globais</p>
                </div>

                <div className="grid gap-6">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <CreditCard className="h-5 w-5 text-blue-500" />
                                Mercado Pago (Checkout Transparente)
                            </CardTitle>
                            <CardDescription>
                                Configure as credenciais da conta Mercado Pago que receberá os pagamentos dos planos (Upgrades/Assinaturas).
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="public_key">Public Key (Chave Pública)</Label>
                                <div className="relative">
                                    <Lock className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                                    <Input
                                        id="public_key"
                                        placeholder="APP_USR-..."
                                        value={mercadoPagoConfig.public_key}
                                        onChange={(e) => setMercadoPagoConfig({ ...mercadoPagoConfig, public_key: e.target.value })}
                                        className="pl-9"
                                    />
                                </div>
                                <p className="text-xs text-muted-foreground">Usada no frontend para tokenizar cartões.</p>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="access_token">Access Token (Chave Privada de Produção)</Label>
                                <div className="relative">
                                    <Lock className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                                    <Input
                                        id="access_token"
                                        type="password"
                                        placeholder="APP_USR-..."
                                        value={mercadoPagoConfig.access_token}
                                        onChange={(e) => setMercadoPagoConfig({ ...mercadoPagoConfig, access_token: e.target.value })}
                                        className="pl-9"
                                    />
                                </div>
                                <p className="text-xs text-muted-foreground">Usada no backend para criar pagamentos. Mantenha em segredo.</p>
                            </div>

                            <div className="pt-4 flex justify-end">
                                <Button onClick={handleSave} disabled={loading} className="gap-2">
                                    <Save className="h-4 w-4" />
                                    {loading ? "Salvando..." : "Salvar Configurações"}
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </AdminLayout>
    );
}
