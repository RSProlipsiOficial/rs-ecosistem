import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { User, MapPin, Phone, CreditCard, CheckCircle2, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { Header } from "@/components/ui/header";

interface RegistrationData {
    user: {
        id: string;
        nome: string;
        avatar_url?: string;
    };
    vans: Array<{
        id: string;
        nome: string;
    }>;
}

export default function PublicCadastro() {
    const { identifier } = useParams();
    const navigate = useNavigate();

    const [fetchingData, setFetchingData] = useState(true);
    const [registrationData, setRegistrationData] = useState<RegistrationData | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState(false);
    const [createdAlunoId, setCreatedAlunoId] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);
    const [cepLoading, setCepLoading] = useState(false);

    const [formData, setFormData] = useState({
        nome_completo: "",
        nome_responsavel: "",
        cpf: "",
        email: "",
        turno: "manha",
        serie: "",
        nome_colegio: "",
        endereco_rua: "",
        endereco_numero: "",
        endereco_bairro: "",
        endereco_cidade: "",
        endereco_estado: "",
        endereco_cep: "",
        tipo_residencia: "casa",
        whatsapp_responsavel: "",
        valor_mensalidade: 0,
        dia_vencimento: 10,
        van_id: ""
    });

    useEffect(() => {
        async function loadRegistrationData() {
            if (!identifier) return;

            try {
                setFetchingData(true);
                setError(null);

                const { data, error } = await (supabase.rpc as any)('get_public_registration_data', {
                    p_identifier: identifier
                });

                if (error) throw error;
                if ((data as any).error) throw new Error((data as any).error);

                const user = (data as any).user;
                const vans = (data as any).vans || [];

                setRegistrationData({ user, vans });

                if (vans.length === 1) {
                    setFormData(prev => ({ ...prev, van_id: vans[0].id }));
                }
            } catch (err: any) {
                console.error("Erro ao carregar dados:", err);
                setError(err.message || "Erro ao carregar dados do transportador.");
            } finally {
                setFetchingData(false);
            }
        }

        loadRegistrationData();
    }, [identifier]);

    const handleCepBlur = async () => {
        const cep = formData.endereco_cep.replace(/\D/g, "");
        if (cep.length === 8) {
            setCepLoading(true);
            try {
                const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
                const data = await response.json();
                if (!data.erro) {
                    setFormData(prev => ({
                        ...prev,
                        endereco_rua: data.logradouro,
                        endereco_bairro: data.bairro,
                        endereco_cidade: data.localidade,
                        endereco_estado: data.uf
                    }));
                }
            } catch (err) {
                console.error("Erro ao buscar CEP:", err);
            } finally {
                setCepLoading(false);
            }
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.van_id) {
            toast({
                title: "Selecione uma van",
                description: "É necessário selecionar para qual van o aluno será cadastrado.",
                variant: "destructive"
            });
            return;
        }

        try {
            setLoading(true);
            const { data, error } = await (supabase.rpc as any)('create_aluno_public', {
                p_aluno_data: formData
            });

            if (error) throw error;

            if (data && (data as any).success) {
                setCreatedAlunoId((data as any).aluno_id || "ID Pendente");
                setSuccess(true);
                toast({
                    title: "Cadastro realizado!",
                    description: "Seu cadastro foi enviado com sucesso.",
                    className: "bg-green-500 text-white"
                });
            } else {
                throw new Error((data as any)?.message || "Erro ao processar cadastro.");
            }
        } catch (err: any) {
            console.error("Erro ao cadastrar:", err);
            toast({
                title: "Erro no cadastro",
                description: err.message || "Não foi possível completar o cadastro. Tente novamente.",
                variant: "destructive"
            });
        } finally {
            setLoading(false);
        }
    };

    if (fetchingData) {
        return (
            <div className="min-h-screen bg-black-primary flex items-center justify-center">
                <div className="flex flex-col items-center gap-4">
                    <div className="w-12 h-12 border-4 border-gold border-t-transparent rounded-full animate-spin" />
                    <p className="text-gold font-medium">Carregando formulário...</p>
                </div>
            </div>
        );
    }

    if (error || !registrationData) {
        return (
            <div className="min-h-screen bg-black-primary flex items-center justify-center p-4">
                <Card className="max-w-md w-full border-red-500/50 bg-black-secondary shadow-2xl shadow-red-500/10">
                    <CardHeader className="text-center">
                        <div className="mx-auto w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mb-4">
                            <AlertCircle className="w-8 h-8 text-red-500" />
                        </div>
                        <CardTitle className="text-2xl text-red-500">Link Inválido ou Expirado</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6 text-center">
                        <p className="text-muted-foreground">
                            {error || "O link que você seguiu pode estar incorreto ou não existe mais."}
                        </p>
                        <Button
                            onClick={() => window.location.reload()}
                            className="w-full bg-red-500 hover:bg-red-600 font-semibold"
                        >
                            Tentar Novamente
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }

    if (success) {
        return (
            <div className="min-h-screen bg-black-primary flex items-center justify-center p-4">
                <Card className="max-w-md w-full border-gold/50 bg-black-secondary shadow-2xl shadow-gold/10">
                    <CardHeader className="text-center">
                        <div className="mx-auto w-20 h-20 bg-gold/10 rounded-full flex items-center justify-center mb-4 animate-bounce">
                            <CheckCircle2 className="w-12 h-12 text-gold" />
                        </div>
                        <CardTitle className="text-3xl font-bold bg-gradient-gold bg-clip-text text-transparent italic">
                            Cadastro Finalizado!
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6 text-center">
                        <div className="p-4 bg-background/50 rounded-xl border border-gold/20">
                            <p className="text-sm text-gold font-medium mb-1 uppercase tracking-widest">ID do Aluno</p>
                            <p className="text-4xl font-mono text-white font-black tracking-tighter">{createdAlunoId}</p>
                        </div>
                        <div className="space-y-2">
                            <p className="text-white font-medium">Parabéns!</p>
                            <p className="text-muted-foreground text-sm">
                                Os dados foram enviados para <strong>{registrationData.user.nome}</strong>.
                                O transportador entrará em contato em breve através do WhatsApp cadastrado.
                            </p>
                        </div>
                        <Button
                            onClick={() => window.location.reload()}
                            className="w-full h-12 bg-white text-black font-bold rounded-full hover:bg-gold transition-colors"
                        >
                            Nova Matrícula
                        </Button>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-black-primary pb-12">
            <Header />

            <div className="max-w-4xl mx-auto px-4 pt-12">
                {/* Header do Transportador */}
                <div className="mb-8 flex items-center gap-6 p-6 rounded-3xl bg-black-secondary border border-gold/20 shadow-xl">
                    {registrationData.user.avatar_url ? (
                        <img
                            src={registrationData.user.avatar_url}
                            alt={registrationData.user.nome}
                            className="w-20 h-20 rounded-2xl object-cover border-2 border-gold shadow-lg"
                        />
                    ) : (
                        <div className="w-20 h-20 rounded-2xl bg-gradient-gold flex items-center justify-center shadow-lg">
                            <User className="w-10 h-10 text-black" />
                        </div>
                    )}
                    <div>
                        <h2 className="text-2xl font-black text-white leading-tight">
                            {registrationData.user.nome}
                        </h2>
                        <p className="text-gold font-medium flex items-center gap-1 opacity-80 mt-1 uppercase text-xs tracking-widest">
                            <CheckCircle2 className="w-3 h-3" /> Transportador Verificado
                        </p>
                    </div>
                </div>

                <Card className="border-gold/20 bg-black-secondary overflow-hidden rounded-3xl shadow-2xl">
                    <CardHeader className="bg-gradient-gold p-6">
                        <CardTitle className="text-black flex items-center gap-3">
                            <div className="p-2 bg-black/10 rounded-lg">
                                <User className="w-6 h-6 text-black" />
                            </div>
                            Matrícula Escolar Online
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                        <form onSubmit={handleSubmit} className="divide-y divide-border/30">
                            {/* Seleção de Van */}
                            {registrationData.vans.length > 1 && (
                                <div className="p-8 space-y-4 bg-gold/5">
                                    <h3 className="text-lg font-bold text-gold flex items-center gap-2">
                                        Selecione o Veículo *
                                    </h3>
                                    <div className="grid grid-cols-1 gap-4">
                                        <div className="space-y-1">
                                            <Label className="text-xs text-muted-foreground uppercase tracking-widest pl-1">Vans Disponíveis</Label>
                                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                                {registrationData.vans.map(van => (
                                                    <button
                                                        key={van.id}
                                                        type="button"
                                                        onClick={() => setFormData({ ...formData, van_id: van.id })}
                                                        className={cn(
                                                            "p-4 rounded-xl border-2 text-left transition-all duration-300 transform active:scale-95 flex items-center gap-3",
                                                            formData.van_id === van.id
                                                                ? "border-gold bg-gold/20 shadow-lg shadow-gold/10"
                                                                : "border-border/30 bg-black-secondary hover:border-gold/50"
                                                        )}
                                                    >
                                                        <div className={cn(
                                                            "w-4 h-4 rounded-full border-2 flex items-center justify-center",
                                                            formData.van_id === van.id ? "border-gold" : "border-muted-foreground"
                                                        )}>
                                                            {formData.van_id === van.id && <div className="w-2 h-2 rounded-full bg-gold" />}
                                                        </div>
                                                        <span className={cn(
                                                            "font-bold",
                                                            formData.van_id === van.id ? "text-gold" : "text-white"
                                                        )}>{van.nome}</span>
                                                    </button>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}

                            <div className="p-8 space-y-8">
                                <div className="space-y-6">
                                    {/* Seção 1: Dados do Aluno */}
                                    <div className="space-y-4">
                                        <h3 className="text-lg font-semibold text-foreground flex items-center gap-2 border-l-4 border-gold pl-3">
                                            <User className="w-4 h-4 text-gold" /> Dados do Aluno
                                        </h3>

                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div className="space-y-2">
                                                <Label htmlFor="nome_completo">Nome Completo do Aluno *</Label>
                                                <Input
                                                    id="nome_completo"
                                                    required
                                                    value={formData.nome_completo}
                                                    onChange={(e) => setFormData({ ...formData, nome_completo: e.target.value })}
                                                    className="bg-background/50 border-gold/30 focus:border-gold"
                                                />
                                            </div>

                                            <div className="space-y-2">
                                                <Label htmlFor="serie">Série *</Label>
                                                <select
                                                    id="serie"
                                                    required
                                                    className="flex h-10 w-full items-center justify-between rounded-md border border-gold/30 bg-dark-lighter px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-gold focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 text-white font-medium"
                                                    style={{
                                                        background: '#1a1b23',
                                                        color: '#ffffff'
                                                    }}
                                                    value={formData.serie}
                                                    onChange={(e) => setFormData({ ...formData, serie: e.target.value })}
                                                >
                                                    <option value="" disabled style={{ background: '#1a1b23', color: '#9ca3af' }}>Selecione a série</option>
                                                    <optgroup label="Educação Infantil" style={{ background: '#1a1b23', color: '#fbbf24', fontWeight: 'bold' }}>
                                                        <option value="Berçário" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>Berçário</option>
                                                        <option value="Maternal" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>Maternal</option>
                                                        <option value="Infantil 2" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>Infantil 2</option>
                                                        <option value="Infantil 3" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>Infantil 3</option>
                                                        <option value="Infantil 4" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>Infantil 4</option>
                                                        <option value="Jardim" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>Jardim</option>
                                                    </optgroup>
                                                    <optgroup label="Ensino Fundamental" style={{ background: '#1a1b23', color: '#60a5fa', fontWeight: 'bold' }}>
                                                        <option value="1º Ano" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>1º Ano</option>
                                                        <option value="2º Ano" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>2º Ano</option>
                                                        <option value="3º Ano" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>3º Ano</option>
                                                        <option value="4º Ano" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>4º Ano</option>
                                                        <option value="5º Ano" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>5º Ano</option>
                                                        <option value="6º Ano" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>6º Ano</option>
                                                        <option value="7º Ano" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>7º Ano</option>
                                                        <option value="8º Ano" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>8º Ano</option>
                                                        <option value="9º Ano" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>9º Ano</option>
                                                    </optgroup>
                                                    <optgroup label="Ensino Médio" style={{ background: '#1a1b23', color: '#34d399', fontWeight: 'bold' }}>
                                                        <option value="1º Médio" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>1º Médio</option>
                                                        <option value="2º Médio" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>2º Médio</option>
                                                        <option value="3º Médio" style={{ background: '#1a1b23', color: '#ffffff', paddingLeft: '1rem' }}>3º Médio</option>
                                                    </optgroup>
                                                </select>
                                            </div>

                                            <div className="space-y-2">
                                                <Label htmlFor="nome_colegio">Nome do Colégio *</Label>
                                                <Input
                                                    id="nome_colegio"
                                                    required
                                                    placeholder="Ex: Colégio São Lucas, Escola ABC"
                                                    value={formData.nome_colegio}
                                                    onChange={(e) => setFormData({ ...formData, nome_colegio: e.target.value })}
                                                    className="bg-background/50 border-gold/30 focus:border-gold"
                                                />
                                            </div>

                                            <div className="space-y-2">
                                                <Label htmlFor="turno">Turno *</Label>
                                                <select
                                                    id="turno"
                                                    className="flex h-10 w-full items-center justify-between rounded-md border border-gold/30 bg-dark-lighter px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-gold focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 text-white font-medium"
                                                    style={{
                                                        background: '#1a1b23',
                                                        color: '#ffffff'
                                                    }}
                                                    value={formData.turno}
                                                    onChange={(e) => setFormData({ ...formData, turno: e.target.value })}
                                                    required
                                                >
                                                    <option value="manha" style={{ background: '#1a1b23', color: '#ffffff' }}>Manhã</option>
                                                    <option value="tarde" style={{ background: '#1a1b23', color: '#ffffff' }}>Tarde</option>
                                                    <option value="integral" style={{ background: '#1a1b23', color: '#ffffff' }}>Integral</option>
                                                    <option value="noite" style={{ background: '#1a1b23', color: '#ffffff' }}>Noite</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Seção 2: Endereço */}
                                    <div className="space-y-4 pt-4 border-t border-border/50">
                                        <h3 className="text-lg font-semibold text-foreground flex items-center gap-2 border-l-4 border-gold pl-3">
                                            <MapPin className="w-4 h-4 text-gold" /> Endereço Residencial
                                        </h3>

                                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                            <div className="md:col-span-2">
                                                <Label htmlFor="rua">Rua *</Label>
                                                <Input
                                                    id="rua"
                                                    required
                                                    value={formData.endereco_rua}
                                                    onChange={(e) => setFormData({ ...formData, endereco_rua: e.target.value })}
                                                    className="bg-background/50 border-gold/30 focus:border-gold"
                                                />
                                            </div>

                                            <div className="space-y-2">
                                                <Label htmlFor="numero">Número *</Label>
                                                <Input
                                                    id="numero"
                                                    required
                                                    value={formData.endereco_numero}
                                                    onChange={(e) => setFormData({ ...formData, endereco_numero: e.target.value })}
                                                    className="bg-background/50 border-gold/30 focus:border-gold"
                                                />
                                            </div>

                                            <div className="space-y-2">
                                                <Label htmlFor="bairro">Bairro *</Label>
                                                <Input
                                                    id="bairro"
                                                    required
                                                    value={formData.endereco_bairro}
                                                    onChange={(e) => setFormData({ ...formData, endereco_bairro: e.target.value })}
                                                    className="bg-background/50 border-gold/30 focus:border-gold"
                                                />
                                            </div>

                                            <div className="space-y-2">
                                                <Label htmlFor="cidade">Cidade *</Label>
                                                <Input
                                                    id="cidade"
                                                    required
                                                    value={formData.endereco_cidade}
                                                    onChange={(e) => setFormData({ ...formData, endereco_cidade: e.target.value })}
                                                    className="bg-background/50 border-gold/30 focus:border-gold"
                                                />
                                            </div>

                                            <div className="space-y-2">
                                                <Label htmlFor="estado">Estado *</Label>
                                                <Input
                                                    id="estado"
                                                    required
                                                    placeholder="Ex: SP, RJ, MG"
                                                    value={formData.endereco_estado}
                                                    onChange={(e) => setFormData({ ...formData, endereco_estado: e.target.value })}
                                                    className="bg-background/50 border-gold/30 focus:border-gold"
                                                />
                                            </div>

                                            <div className="space-y-2">
                                                <Label htmlFor="cep">CEP *</Label>
                                                <div className="relative">
                                                    <Input
                                                        id="cep"
                                                        required
                                                        placeholder="00000-000"
                                                        value={formData.endereco_cep}
                                                        onChange={(e) => {
                                                            const value = e.target.value.replace(/\D/g, "");
                                                            const formatted = value.replace(/^(\d{5})(\d{3})/, "$1-$2");
                                                            setFormData({ ...formData, endereco_cep: formatted });
                                                        }}
                                                        onBlur={handleCepBlur}
                                                        maxLength={9}
                                                        className={cn("bg-background/50 border-gold/30 focus:border-gold", cepLoading && "opacity-50")}
                                                    />
                                                    {cepLoading && <div className="absolute right-3 top-2.5 w-4 h-4 border-2 border-gold border-t-transparent rounded-full animate-spin" />}
                                                </div>
                                            </div>

                                            <div className="space-y-2">
                                                <Label htmlFor="tipo_residencia">Tipo de Residência</Label>
                                                <select
                                                    id="tipo_residencia"
                                                    className="flex h-10 w-full items-center justify-between rounded-md border border-gold/30 bg-background/50 px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 text-foreground"
                                                    value={formData.tipo_residencia}
                                                    onChange={(e) => setFormData({ ...formData, tipo_residencia: e.target.value })}
                                                >
                                                    <option value="casa">Casa</option>
                                                    <option value="apartamento">Apartamento</option>
                                                    <option value="outro">Outro</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Seção 3: Responsável */}
                                    <div className="space-y-4 pt-4 border-t border-border/50">
                                        <h3 className="text-lg font-semibold text-foreground flex items-center gap-2 border-l-4 border-gold pl-3">
                                            <Phone className="w-4 h-4 text-gold" /> Dados do Responsável
                                        </h3>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div className="space-y-2">
                                                <Label htmlFor="nome_responsavel">Nome do Responsável *</Label>
                                                <Input
                                                    id="nome_responsavel"
                                                    required
                                                    value={formData.nome_responsavel}
                                                    onChange={(e) => setFormData({ ...formData, nome_responsavel: e.target.value })}
                                                    className="bg-background/50 border-gold/30 focus:border-gold"
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="cpf">CPF do Responsável *</Label>
                                                <Input
                                                    id="cpf"
                                                    required
                                                    placeholder="000.000.000-00"
                                                    value={formData.cpf}
                                                    onChange={(e) => {
                                                        const value = e.target.value.replace(/\D/g, "");
                                                        const formatted = value.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
                                                        setFormData({ ...formData, cpf: formatted });
                                                    }}
                                                    maxLength={14}
                                                    className="bg-background/50 border-gold/30 focus:border-gold"
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="email">Email do Responsável *</Label>
                                                <Input
                                                    id="email"
                                                    type="email"
                                                    placeholder="exemplo@email.com"
                                                    required
                                                    value={formData.email}
                                                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                                    className="bg-background/50 border-gold/30 focus:border-gold"
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="whatsapp">WhatsApp do Responsável *</Label>
                                                <Input
                                                    id="whatsapp"
                                                    required
                                                    type="tel"
                                                    placeholder="(00) 00000-0000"
                                                    value={formData.whatsapp_responsavel}
                                                    onChange={(e) => setFormData({ ...formData, whatsapp_responsavel: e.target.value })}
                                                    className="bg-background/50 border-gold/30 focus:border-gold"
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    {/* Seção 4: Financeiro */}
                                    <div className="space-y-4 pt-4 border-t border-border/50">
                                        <h3 className="text-lg font-semibold text-foreground flex items-center gap-2 border-l-4 border-gold pl-3">
                                            <CreditCard className="w-4 h-4 text-gold" /> Contato e Financeiro
                                        </h3>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div className="space-y-2">
                                                <Label htmlFor="valor_mensalidade">Valor da Mensalidade *</Label>
                                                <div className="relative">
                                                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">R$</span>
                                                    <Input
                                                        id="valor_mensalidade"
                                                        className="pl-9 bg-background/50 border-gold/30 focus:border-gold"
                                                        value={formData.valor_mensalidade.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                                        onChange={(e) => {
                                                            const value = e.target.value.replace(/\D/g, "");
                                                            const numberValue = parseFloat(value) / 100;
                                                            setFormData({ ...formData, valor_mensalidade: numberValue });
                                                        }}
                                                        required
                                                    />
                                                </div>
                                            </div>
                                            <div className="space-y-2">
                                                <Label htmlFor="dia_vencimento">Dia de Vencimento *</Label>
                                                <Input
                                                    id="dia_vencimento"
                                                    type="number"
                                                    min="1"
                                                    max="31"
                                                    value={formData.dia_vencimento || ""}
                                                    onChange={(e) => setFormData({ ...formData, dia_vencimento: parseInt(e.target.value) || 0 })}
                                                    placeholder="Dia (1-31)"
                                                    required
                                                    className="bg-background/50 border-gold/30 focus:border-gold"
                                                />
                                                <p className="text-xs text-muted-foreground mt-1">Dia do mês para vencimento da fatura</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="pt-6">
                                        <Button
                                            type="submit"
                                            className="w-full h-12 text-lg bg-gradient-gold text-black-primary font-bold hover:opacity-90 transition-all shadow-lg hover:shadow-gold/20"
                                            disabled={loading}
                                        >
                                            {loading ? (
                                                <span className="flex items-center gap-2">
                                                    <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                                                    Processando Cadastro...
                                                </span>
                                            ) : (
                                                "Confirmar Cadastro"
                                            )}
                                        </Button>
                                        <p className="text-center text-xs text-muted-foreground mt-4">
                                            Ao confirmar, você concorda com o envio destes dados para o responsável pelo transporte escolar.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
