import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { MainLayout } from "@/components/layout/main-layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, Bus } from "lucide-react";
import { VanManager } from "@/components/alunos/van-manager";
import { AlunoManager } from "@/components/alunos/aluno-manager";
import { usePlanLimits } from "@/hooks/usePlanLimits";
import { PlanLimitWarning } from "@/components/common/plan-limit-warning";

export default function AlunosIndex() {
  const { limits } = usePlanLimits();
  const [userRole, setUserRole] = useState<string | null>(null);

  useEffect(() => {
    const getUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const role = session?.user?.user_metadata?.tipo_usuario || session?.user?.user_metadata?.user_type || 'usuario';
      setUserRole(role);
    };
    getUser();
  }, []);

  const isTeam = userRole === 'motorista' || userRole === 'monitora';

  return (
    <MainLayout>
      <div className="min-h-screen bg-gradient-dark text-foreground p-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2 text-gold">Gerenciamento de Alunos</h1>
            <p className="text-muted-foreground">
              {isTeam ? "Visualize seus alunos e informações de rota" : "Gerencie suas vans e alunos de forma organizada"}
            </p>
          </div>

          <Tabs defaultValue={isTeam ? "alunos" : "vans"} className="space-y-6">
            <TabsList className={`grid w-full ${isTeam ? "grid-cols-1" : "grid-cols-2"} max-w-md`}>
              {!isTeam && (
                <TabsTrigger value="vans" className="flex items-center gap-2">
                  <Bus className="w-4 h-4" />
                  Vans
                </TabsTrigger>
              )}
              <TabsTrigger value="alunos" className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                Alunos
              </TabsTrigger>
            </TabsList>

            {!isTeam && (
              <TabsContent value="vans">
                {limits?.nearVanLimit && (
                  <PlanLimitWarning
                    type="van"
                    current={limits.currentUsage.vans}
                    max={limits.max_vans!}
                    planName={limits.planName}
                  />
                )}
                <VanManager />
              </TabsContent>
            )}

            <TabsContent value="alunos">
              {limits?.nearStudentLimit && (
                <PlanLimitWarning
                  type="student"
                  current={limits.currentUsage.students}
                  max={limits.max_alunos!}
                  planName={limits.planName}
                />
              )}
              <AlunoManager />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </MainLayout>
  );
}