import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Brain, Save, ArrowLeft, Sparkles, MessageSquare, Bell } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';

const AIConfigPage = () => {
    const { toast } = useToast();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    const [config, setConfig] = useState({
        system_prompt: '',
        ai_memory: '',
        auto_greeting_enabled: false,
        holiday_messages_enabled: false,
        ecosystem_billing_active: false,
        ecosystem_auto_reply_active: false,
        ecosystem_last_scan: null as string | null
    });

    useEffect(() => {
        loadConfig();
    }, []);

    const loadConfig = async () => {
        try {
            const { data: { user } } = await supabase.auth.getUser();
            if (!user) return;

            const { data, error } = await supabase
                .from('ai_configuration')
                .select('*')
                .eq('user_id', user.id)
                .maybeSingle();

            if (error) throw error;

            if (data) {
                setConfig({
                    system_prompt: data.system_prompt || '',
                    ai_memory: data.ai_memory || '',
                    auto_greeting_enabled: data.auto_greeting_enabled || false,
                    holiday_messages_enabled: data.holiday_messages_enabled || false,
                    ecosystem_billing_active: data.ecosystem_billing_active || false,
                    ecosystem_auto_reply_active: data.ecosystem_auto_reply_active || false,
                    ecosystem_last_scan: data.ecosystem_last_scan || null
                });
            }
        } catch (error) {
            console.error('Erro ao carregar configuração:', error);
            toast({
                title: "Erro",
                description: "Não foi possível carregar as configurações da IA.",
                variant: "destructive",
            });
        } finally {
            setLoading(false);
        }
    };

    const handleSave = async () => {
        setSaving(true);
        try {
            const { data: { user } } = await supabase.auth.getUser();
            if (!user) return;

            const { error } = await supabase
                .from('ai_configuration')
                .upsert({
                    user_id: user.id,
                    ...config,
                    updated_at: new Date().toISOString()
                });

            if (error) throw error;

            toast({
                title: "Sucesso",
                description: "Configurações da IA salvas com sucesso!",
            });
        } catch (error) {
            console.error('Erro ao salvar configuração:', error);
            toast({
                title: "Erro",
                description: "Não foi possível salvar as configurações.",
                variant: "destructive",
            });
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <p className="text-muted-foreground">Carregando configurações...</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-background p-4 md:p-8">
            <div className="max-w-4xl mx-auto space-y-6">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <Button variant="ghost" size="icon" onClick={() => navigate('/ia')}>
                            <ArrowLeft className="h-5 w-5" />
                        </Button>
                        <div>
                            <h1 className="text-3xl font-bold flex items-center gap-2">
                                <Brain className="h-8 w-8 text-primary" />
                                Cérebro da RS-IA
                            </h1>
                            <p className="text-muted-foreground">
                                Personalize como a sua inteligência artificial se comporta e o que ela lembra
                            </p>
                        </div>
                    </div>
                    <Button onClick={handleSave} disabled={saving} className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                        <Save className="h-4 w-4 mr-2" />
                        {saving ? "Salvando..." : "Salvar Alterações"}
                    </Button>
                </div>

                <div className="grid gap-6">
                    <Card className="border-primary/20 shadow-lg">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Sparkles className="h-5 w-5 text-yellow-500" />
                                Personalidade e Instruções
                            </CardTitle>
                            <CardDescription>
                                Defina o tom de voz e as regras gerais que a IA deve seguir
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="prompt">Prompt do Sistema (O que eu sou?)</Label>
                                <Textarea
                                    id="prompt"
                                    placeholder="Ex: Você é um assistente simpático para a Van do Tio João. Seja sempre educado e use emojis."
                                    value={config.system_prompt}
                                    onChange={(e) => setConfig(prev => ({ ...prev, system_prompt: e.target.value }))}
                                    className="min-h-[120px] resize-none"
                                />
                                <p className="text-xs text-muted-foreground italic">
                                    Isso define o comportamento básico da IA em todas as conversas.
                                </p>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="memory">Memória da IA (Informações Fixas)</Label>
                                <Textarea
                                    id="memory"
                                    placeholder="Ex: Minha chave PIX é o celular 11999999999. Atendo as escolas Objetivo e Anglo. Minha van é amarela."
                                    value={config.ai_memory}
                                    onChange={(e) => setConfig(prev => ({ ...prev, ai_memory: e.target.value }))}
                                    className="min-h-[150px] resize-none"
                                />
                                <p className="text-xs text-muted-foreground italic">
                                    Informações importantes que a IA deve sempre saber sobre o seu negócio.
                                </p>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="border-border shadow-md">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <Bell className="h-5 w-5 text-blue-500" />
                                Automações Inteligentes
                            </CardTitle>
                            <CardDescription>
                                Configure envios automáticos baseados em IA
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            <div className="flex items-center justify-between">
                                <div className="space-y-0.5">
                                    <div className="flex items-center gap-2">
                                        <MessageSquare className="h-4 w-4 text-muted-foreground" />
                                        <Label className="text-base font-semibold">Saudações Automáticas</Label>
                                    </div>
                                    <p className="text-sm text-muted-foreground">
                                        Enviar Bom dia/Boa tarde personalizado para os pais
                                    </p>
                                </div>
                                <Switch
                                    checked={config.auto_greeting_enabled}
                                    onCheckedChange={(checked) => setConfig(prev => ({ ...prev, auto_greeting_enabled: checked }))}
                                />
                            </div>

                            <div className="flex items-center justify-between">
                                <div className="space-y-0.5">
                                    <div className="flex items-center gap-2">
                                        <Sparkles className="h-4 w-4 text-muted-foreground" />
                                        <Label className="text-base font-semibold">Datas Festivas</Label>
                                    </div>
                                    <p className="text-sm text-muted-foreground">
                                        A IA enviará mensagens em aniversários, Natal, Páscoa, etc.
                                    </p>
                                </div>
                                <Switch
                                    checked={config.holiday_messages_enabled}
                                    onCheckedChange={(checked) => setConfig(prev => ({ ...prev, holiday_messages_enabled: checked }))}
                                />
                            </div>

                            <div className="border-t border-primary/10 pt-6">
                                <h3 className="text-sm font-medium text-primary mb-4 flex items-center gap-2">
                                    <Sparkles className="h-4 w-4" />
                                    Ecossistema RS-IA (Beta)
                                </h3>

                                <div className="space-y-6">
                                    <div className="flex items-center justify-between">
                                        <div className="space-y-0.5">
                                            <div className="flex items-center gap-2">
                                                <Label className="text-base font-semibold">Cobrança Automática Inteligente</Label>
                                            </div>
                                            <p className="text-sm text-muted-foreground">
                                                O robô enviará cobranças com PIX automaticamente via WhatsApp.
                                            </p>
                                        </div>
                                        <Switch
                                            checked={config.ecosystem_billing_active}
                                            onCheckedChange={(checked) => setConfig(prev => ({ ...prev, ecosystem_billing_active: checked }))}
                                        />
                                    </div>

                                    <div className="flex items-center justify-between">
                                        <div className="space-y-0.5">
                                            <div className="flex items-center gap-2">
                                                <Label className="text-base font-semibold">Resposta Automática aos Pais</Label>
                                            </div>
                                            <p className="text-sm text-muted-foreground">
                                                A IA responderá dúvidas de pais no WhatsApp usando os dados do sistema.
                                            </p>
                                        </div>
                                        <Switch
                                            checked={config.ecosystem_auto_reply_active}
                                            onCheckedChange={(checked) => setConfig(prev => ({ ...prev, ecosystem_auto_reply_active: checked }))}
                                        />
                                    </div>

                                    {config.ecosystem_last_scan && (
                                        <p className="text-[10px] text-muted-foreground text-right italic">
                                            Última varredura: {new Date(config.ecosystem_last_scan).toLocaleString('pt-BR')}
                                        </p>
                                    )}
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <div className="bg-muted/50 p-4 rounded-lg flex items-start gap-3">
                    <Brain className="h-5 w-5 text-primary mt-0.5" />
                    <div className="text-sm text-muted-foreground">
                        <strong>Dica:</strong> Quanto mais detalhes você colocar na "Memória da IA", mais precisas e humanas serão as respostas. Você pode incluir horários, regras de cobrança e até curiosidades sobre as rotas.
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AIConfigPage;
