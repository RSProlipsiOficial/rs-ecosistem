import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MainLayout } from "@/components/layout/main-layout";
import { FinancialSummary } from "@/components/dashboard/financial-summary";
import { QuickAccessCards } from "@/components/dashboard/quick-access-cards";
import { supabase } from '@/integrations/supabase/client';

const Index = () => {
  const navigate = useNavigate();

  useEffect(() => {
    let mounted = true;

    // Check if user is authenticated and redirect to correct portal
    const checkAuthAndRedirect = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!mounted) return;

      if (!session?.user) {
        navigate('/auth');
        return;
      }

      const userType = session.user.user_metadata?.user_type || 'usuario';

      if (!mounted) return;

      if (userType === 'motorista') {
        navigate('/motorista');
        return;
      } else if (userType === 'monitora') {
        navigate('/monitora');
        return;
      } else if (userType === 'admin') {
        navigate('/admin');
        return;
      }

      // Consultor/Usuario stays on /app
      // No redirection needed if we are already at /app (which Index.tsx is)
      // For consultants/others, stay on /app
    };

    checkAuthAndRedirect();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        if (!mounted) return;
        if (!session?.user) {
          navigate('/auth');
        } else if (event === 'SIGNED_IN') {
          // Re-check redirection on sign in
          const userType = session.user.user_metadata?.user_type || 'usuario';
          if (!mounted) return;
          if (userType === 'motorista') navigate('/motorista');
          else if (userType === 'monitora') navigate('/monitora');
          else if (userType === 'admin') navigate('/admin');
        }
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [navigate]);

  return (
    <MainLayout>
      <div className="space-y-8 animate-fade-in">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold text-foreground">
            Bem-vindo ao <span className="text-gold">RotaFácil</span> <span className="text-xs bg-gold/20 text-gold px-2 py-1 rounded">v4.0</span>
          </h1>
          <p className="text-muted-foreground text-lg">
            Sistema completo de gestão de transporte escolar (Versão Atualizada)
          </p>
        </div>

        <FinancialSummary />
        <QuickAccessCards />
      </div>
    </MainLayout>
  );
};

export default Index;
