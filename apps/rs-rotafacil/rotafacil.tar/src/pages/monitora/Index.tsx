
import { useState, useEffect } from 'react';
import { MainLayout } from "@/components/layout/main-layout";
import { ListaPresenca } from '@/components/monitora/lista-presenca';
import { ResumoPresencas } from '@/components/monitora/resumo-presencas';
import { OcorrenciasManager } from '@/components/monitora/ocorrencias-manager';
import { usePresenca } from '@/hooks/usePresenca';
import { ResumoGeralPresenca } from '@/types/presenca';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, BarChart3, RefreshCw, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface MonitoraIndexProps {
  customUserId?: string;
}

export default function MonitoraIndex({ customUserId }: MonitoraIndexProps = {}) {
  const {
    alunosComPresenca,
    loading,
    marcarPresenca,
    getResumoPresencas,
    refetch,
  } = usePresenca(customUserId);

  const [resumo, setResumo] = useState<ResumoGeralPresenca | null>(null);
  const [dataSelected, setDataSelected] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  const handleMarcarPresenca = async (alunoId: string, status: 'presente' | 'ausente') => {
    await marcarPresenca(alunoId, status, dataSelected);
    await atualizarResumo();
  };

  const atualizarResumo = async () => {
    const novoResumo = await getResumoPresencas(dataSelected);
    setResumo(novoResumo);
  };

  const handleAtualizarLista = async () => {
    await refetch(dataSelected);
    await atualizarResumo();
  };

  useEffect(() => {
    if (alunosComPresenca.length > 0) {
      atualizarResumo();
    }
  }, [alunosComPresenca]);

  useEffect(() => {
    refetch(dataSelected);
  }, [dataSelected]);

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-white italic uppercase">Lista da Monitora</h1>
            <p className="text-gray-400">Controle de presença diária dos alunos</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleAtualizarLista}
            className="bg-black/40 border-white/10 hover:bg-yellow-400 hover:text-black gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            Sincronizar
          </Button>
        </div>

        <Tabs defaultValue="lista" className="space-y-6">
          <TabsList className="bg-black/40 border border-white/5 p-1 h-auto flex gap-1">
            <TabsTrigger value="lista" className="flex-1 gap-2 py-3 data-[state=active]:bg-yellow-400 data-[state=active]:text-black">
              <Users className="h-4 w-4" />
              <span className="font-bold uppercase text-[10px]">Lista de Presença</span>
            </TabsTrigger>
            <TabsTrigger value="resumo" className="flex-1 gap-2 py-3 data-[state=active]:bg-yellow-400 data-[state=active]:text-black">
              <BarChart3 className="h-4 w-4" />
              <span className="font-bold uppercase text-[10px]">Resumo Geral</span>
            </TabsTrigger>
            <TabsTrigger value="ocorrencias" className="flex-1 gap-2 py-3 data-[state=active]:bg-yellow-400 data-[state=active]:text-black">
              <AlertCircle className="h-4 w-4" />
              <span className="font-bold uppercase text-[10px]">Reclamação</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="lista" className="animate-in fade-in slide-in-from-bottom-2 duration-400">
            <ListaPresenca
              alunos={alunosComPresenca}
              loading={loading}
              onMarcarPresenca={handleMarcarPresenca}
              onAtualizarLista={handleAtualizarLista}
              dataSelected={dataSelected}
              onDataChange={setDataSelected}
            />
          </TabsContent>

          <TabsContent value="resumo" className="animate-in fade-in duration-400">
            {resumo && (
              <ResumoPresencas
                resumo={resumo}
                dataSelected={dataSelected}
                loading={loading}
              />
            )}
          </TabsContent>

          <TabsContent value="ocorrencias" className="animate-in fade-in slide-in-from-bottom-2 duration-400">
            <OcorrenciasManager
              alunos={alunosComPresenca}
              loadingAlunos={loading}
            />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}