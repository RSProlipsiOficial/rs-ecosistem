
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { Phone, Mail, Instagram, Facebook, Youtube, Send, ShieldCheck, Target, Info } from 'lucide-react';
import FormattedText from './FormattedText';

const Footer: React.FC = () => {
  const { data, isAdminOpen, setActiveSectionId, setActiveTab, setAdminOpen } = useSiteData();
  const f = data?.footer;

  if (!f) return null;

  const renderSocialIcon = (platform: string) => {
    switch(platform) {
      case 'Instagram': return <Instagram size={18} />;
      case 'Facebook': return <Facebook size={18} />;
      case 'Youtube': return <Youtube size={18} />;
      case 'Whatsapp': return <Phone size={18} />;
      default: return <Send size={18} />;
    }
  };

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    if (!targetId || targetId.startsWith('http')) return;
    e.preventDefault();
    const cleanId = targetId.startsWith('#') ? targetId.substring(1) : targetId;
    const element = document.getElementById(cleanId);
    if (element) {
      window.scrollTo({ top: element.getBoundingClientRect().top + window.scrollY - 80, behavior: 'smooth' });
    }
  };

  const handleFooterClick = (e: React.MouseEvent) => {
    if (isAdminOpen) {
      e.stopPropagation();
      setActiveSectionId(null);
      setActiveTab('footer');
    }
  };

  return (
    <footer 
      onClick={handleFooterClick}
      className={`pt-16 md:pt-24 pb-12 border-t transition-all cursor-pointer relative z-10 ${isAdminOpen ? 'hover:border-yellow-500 border-2 border-dashed border-zinc-800 bg-zinc-950' : 'border-zinc-900'}`} 
      style={{ backgroundColor: f.style?.bgColor || '#000' }}
    >
      <div className="container mx-auto px-4">
        {/* Módulos Superiores ajustados para grid-cols-1 no mobile */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16 md:mb-20">
          <div id="sobre" className="bg-zinc-900/30 p-6 md:p-8 rounded-[2rem] border border-zinc-800/50 backdrop-blur-sm group hover:border-yellow-500/30 transition-all scroll-mt-32">
             <div className="flex items-center gap-3 mb-4 md:mb-5">
               <div className="p-2.5 bg-yellow-500/10 rounded-xl text-yellow-500"><Info size={20}/></div>
               <h4 className="font-black uppercase text-xs md:text-sm tracking-widest" style={{ color: f.style?.titleColor }}>
                 <FormattedText text={f.content.aboutTitle} highlightColor={f.style.highlightColor} />
               </h4>
             </div>
             <p className="text-[10px] md:text-[11px] leading-relaxed opacity-60 font-medium" style={{ color: f.style?.textColor }}>
                <FormattedText text={f.content.aboutText} highlightColor={f.style.highlightColor} />
             </p>
          </div>

          <div id="missao" className="bg-zinc-900/30 p-6 md:p-8 rounded-[2rem] border border-zinc-800/50 backdrop-blur-sm group hover:border-yellow-500/30 transition-all scroll-mt-32">
             <div className="flex items-center gap-3 mb-4 md:mb-5">
               <div className="p-2.5 bg-yellow-500/10 rounded-xl text-yellow-500"><Target size={20}/></div>
               <h4 className="font-black uppercase text-xs md:text-sm tracking-widest" style={{ color: f.style?.titleColor }}>
                 <FormattedText text={f.content.missionTitle} highlightColor={f.style.highlightColor} />
               </h4>
             </div>
             <p className="text-[10px] md:text-[11px] leading-relaxed opacity-60 font-medium" style={{ color: f.style?.textColor }}>
                <FormattedText text={f.content.missionText} highlightColor={f.style.highlightColor} />
             </p>
          </div>

          <div id="certificacoes" className="bg-zinc-900/30 p-6 md:p-8 rounded-[2rem] border border-zinc-800/50 backdrop-blur-sm group hover:border-yellow-500/30 transition-all scroll-mt-32 md:col-span-2 lg:col-span-1">
             <div className="flex items-center gap-3 mb-4 md:mb-5">
               <div className="p-2.5 bg-yellow-500/10 rounded-xl text-yellow-500"><ShieldCheck size={20}/></div>
               <h4 className="font-black uppercase text-xs md:text-sm tracking-widest" style={{ color: f.style?.titleColor }}>
                 <FormattedText text={f.content.certificationsTitle} highlightColor={f.style.highlightColor} />
               </h4>
             </div>
             <div className="flex flex-wrap gap-3 md:gap-4">
               {(f.content.certifications || []).map((cert, i) => (
                 <div key={i} className="flex flex-col items-center gap-2">
                    <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-black border border-zinc-800 flex items-center justify-center p-2">
                      {cert.image ? (
                        <img src={cert.image} alt={cert.label} className="w-full h-full object-contain grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all" />
                      ) : (
                        <ShieldCheck size={16} className="text-zinc-700" />
                      )}
                    </div>
                    <span className="text-[7px] md:text-[8px] font-black uppercase opacity-40 text-center" style={{ color: f.style.textColor }}>{cert.label}</span>
                 </div>
               ))}
             </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-10 md:gap-12 mb-16 md:mb-20 border-t border-zinc-900 pt-16 md:pt-20">
          <div className="lg:col-span-2">
             <div className="text-2xl md:text-3xl font-black tracking-tighter mb-5 md:mb-6 italic uppercase">
               <span style={{ color: f.style?.highlightColor }}>{data.general.brandNameGold}</span>{' '}
               <span style={{ color: f.style?.titleColor }}>{data.general.brandName}</span>
             </div>
             <p className="text-xs leading-relaxed opacity-60 mb-6 md:mb-8 max-w-sm" style={{ color: f.style?.textColor }}>
               {f.content.brandDescription}
             </p>
             <div className="flex gap-3">
               {f.content.socials.map((social, i) => (
                 <a key={i} href={social.url} target="_blank" className="hover:scale-110 transition-transform p-3 bg-zinc-900 rounded-xl border border-zinc-800 text-yellow-500 shadow-lg">
                   {renderSocialIcon(social.platform)}
                 </a>
               ))}
             </div>
          </div>

          <div>
            <h4 className="font-black text-[10px] uppercase tracking-widest mb-6 md:mb-8 text-white">Navegação</h4>
            <ul className="space-y-3 md:space-y-4 text-xs font-bold uppercase tracking-tighter" style={{ color: f.style?.textColor }}>
              {f.content.quickLinks.map((link, i) => (
                <li key={i}><a href={link.href} onClick={(e) => handleLinkClick(e, link.href)} className="hover:text-yellow-500 transition-colors">{link.label}</a></li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-black text-[10px] uppercase tracking-widest mb-6 md:mb-8 text-white">Contato</h4>
            <ul className="space-y-4 md:space-y-5 text-xs font-bold" style={{ color: f.style?.textColor }}>
              {f.content.contactItems.map((item, i) => (
                <li key={i} className="flex items-center gap-3">
                  <span className="text-yellow-500 bg-yellow-500/10 p-2 rounded-lg">
                    {item.label === 'Fone' ? <Phone size={14} /> : <Mail size={14} />}
                  </span>
                  {item.value}
                </li>
              ))}
            </ul>
          </div>

          <div>
             <h4 className="font-black text-[10px] uppercase tracking-widest mb-6 md:mb-8 text-white italic">{f.content.legalInfo.title}</h4>
             <p className="text-[10px] leading-relaxed opacity-40 font-medium" style={{ color: f.style?.textColor }}>
               {f.content.legalInfo.description}
             </p>
          </div>
        </div>

        <div className="pt-8 md:pt-10 border-t border-zinc-900 flex flex-col md:flex-row justify-between items-center gap-5 md:gap-6">
          <p className="text-[9px] md:text-[10px] font-black opacity-30 uppercase tracking-[0.2em] md:tracking-[0.3em]" style={{ color: f.style?.textColor }}>
            &copy; {f.content.bottomText}
          </p>
          <div className="flex items-center gap-2 text-[9px] md:text-[10px] font-black uppercase tracking-widest bg-yellow-500/5 px-4 py-2 rounded-full border border-yellow-500/10" style={{ color: f.style?.highlightColor }}>
             <ShieldCheck size={12} /> {f.content.rightsText}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
