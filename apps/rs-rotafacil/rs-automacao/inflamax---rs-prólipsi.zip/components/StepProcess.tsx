
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import FormattedText from './FormattedText';

const StepProcess: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;

  if (!style.isVisible) return null;

  const steps = Array.isArray(content.steps) ? content.steps : [];

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-20 relative group cursor-pointer border-2 transition-all ${activeSectionId === section.id ? 'border-yellow-500' : 'border-transparent'}`}
      style={{ backgroundColor: style.bgColor }}
    >
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-12">
          {steps.map((step: any, idx: number) => (
            <div key={idx} className="relative p-10 bg-white/5 border border-white/10 rounded-[2.5rem] flex flex-col items-center text-center">
              <div className="absolute -top-6 w-12 h-12 rounded-full flex items-center justify-center font-black text-black" style={{ backgroundColor: style.highlightColor }}>
                {idx + 1}
              </div>
              <h4 className="text-xl font-black uppercase mb-4 mt-2" style={{ color: style.titleColor }}>{step.title}</h4>
              <p className="text-sm opacity-70" style={{ color: style.textColor }}>{step.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StepProcess;
