
import React, { useState, useRef, useEffect } from 'react';
import { useSiteData } from '../context/SiteContext';
import { 
  X, Save, Layers, Settings, Monitor, Smartphone, 
  ArrowUp, ArrowDown, Trash2, Edit3, Image as ImageIcon, 
  Plus, PlusCircle, Wand2, Hash, Copy, Sparkles, Loader2, Send, 
  Mic, Paperclip, FileText, File as FileIcon, MicOff, Palette, Box, Image, Video, Camera, AlertCircle, Link as LinkIcon
} from 'lucide-react';
import { SectionType } from '../types';
import { GoogleGenAI } from "@google/genai";

interface AttachedFile {
  data: string; // base64
  mimeType: string;
  name: string;
  preview?: string;
}

const AdminPanel: React.FC = () => {
  const { 
    data, updateData, isAdminOpen, setAdminOpen,
    activeSectionId, setActiveSectionId, 
    activeTab, setActiveTab,
    moveSection, removeSection, addSection,
    previewMode, setPreviewMode
  } = useSiteData();
  
  const [editMode, setEditMode] = useState<'content' | 'style'>('content');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const aiFileInputRef = useRef<HTMLInputElement>(null);
  const [uploadPath, setUploadPath] = useState<string>('');
  
  // Estados da IA
  const [aiPrompt, setAiPrompt] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [aiMessages, setAiMessages] = useState<{role: 'user' | 'assistant', text: string}[]>([]);
  const [attachments, setAttachments] = useState<AttachedFile[]>([]);
  
  // Estados do Microfone
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    if (activeSectionId && activeTab !== 'edit') {
      setActiveTab('edit');
    }
  }, [activeSectionId]);

  const takeScreenshot = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ 
        video: { displaySurface: "browser" } 
      });
      
      const video = document.createElement('video');
      video.srcObject = stream;
      await video.play();

      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      const base64Full = canvas.toDataURL('image/png');
      const base64 = base64Full.split(',')[1];
      
      setAttachments(prev => [...prev, {
        data: base64,
        mimeType: 'image/png',
        name: `print_${Date.now()}.png`,
        preview: base64Full
      }]);

      stream.getTracks().forEach(track => track.stop());
    } catch (err: any) {
      console.warn("Navegador impediu captura direta:", err);
      const isPermissionError = err.name === 'NotAllowedError' || err.message.includes('Permissions policy');
      
      setAiMessages(prev => [...prev, { 
        role: 'assistant', 
        text: isPermissionError 
          ? "⚠️ O navegador bloqueou a captura automática por segurança. DICA: Tire um print (PrintScreen) e aperte Ctrl+V aqui dentro para me enviar!" 
          : "Não consegui capturar a tela. Tente anexar uma foto ou colar com Ctrl+V." 
      }]);
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    const items = e.clipboardData.items;
    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf("image") !== -1) {
        const file = items[i].getAsFile();
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const fullBase64 = event.target?.result as string;
            const base64 = fullBase64.split(',')[1];
            setAttachments(prev => [...prev, {
              data: base64,
              mimeType: file.type,
              name: `print_colado_${Date.now()}.png`,
              preview: fullBase64
            }]);
          };
          reader.readAsDataURL(file);
        }
      }
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64 = (reader.result as string).split(',')[1];
          setAttachments(prev => [...prev, {
            data: base64,
            mimeType: 'audio/webm',
            name: 'comando_voz.webm'
          }]);
        };
        reader.readAsDataURL(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Erro ao acessar microfone", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleAIUpdate = async (customPrompt?: string) => {
    const finalPrompt = customPrompt || aiPrompt;
    if (!finalPrompt.trim() && attachments.length === 0) return;
    setIsAiLoading(true);
    const newMessages = [...aiMessages, { role: 'user' as const, text: finalPrompt || "(Anexo Enviado)" }];
    setAiMessages(newMessages);
    setAiPrompt('');
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const systemInstruction = `Você é o 'Inflamax Builder AI'. Altere o JSON conforme o pedido do usuário (texto, imagem, print ou voz). Analise prints colados para replicar cores ou layouts. Retorne APENAS o JSON SiteData completo e válido.`;
      
      const parts: any[] = [{ text: `PEDIDO: "${finalPrompt}"\n\nJSON ATUAL: ${JSON.stringify(data)}` }];
      attachments.forEach(att => parts.push({ inlineData: { data: att.data, mimeType: att.mimeType } }));
      
      const response = await ai.models.generateContent({
        model: "gemini-3-pro-preview",
        contents: { parts },
        config: { systemInstruction, responseMimeType: "application/json" },
      });
      
      const result = JSON.parse(response.text);
      if (result) {
        updateData(result);
        setAiMessages([...newMessages, { role: 'assistant', text: "Comando processado! Atualizei o site com base no seu pedido e nos arquivos enviados." }]);
        setAttachments([]);
      }
    } catch (error) {
      setAiMessages([...newMessages, { role: 'assistant', text: "Erro ao processar. Certifique-se de que a IA pode ver os arquivos e tente novamente." }]);
    } finally {
      setIsAiLoading(false);
    }
  };

  const setNestedValue = (obj: any, path: string, value: any) => {
    const keys = path.split('.');
    let current = obj;
    for (let i = 0; i < keys.length - 1; i++) {
      if (!current[keys[i]]) current[keys[i]] = {};
      current = current[keys[i]];
    }
    current[keys[keys.length - 1]] = value;
    return { ...obj };
  };

  const updateRoot = (path: string, value: any) => {
    const newData = JSON.parse(JSON.stringify(data));
    const finalData = setNestedValue(newData, path, value);
    updateData(finalData);
  };

  const updateSectionPart = (id: string, type: 'content' | 'style' | 'root', path: string, value: any) => {
    const newSections = data.sections.map(s => {
      if (s.id !== id) return s;
      const ns = JSON.parse(JSON.stringify(s));
      if (type === 'root') {
        ns[path] = value;
      } else {
        setNestedValue(ns[type], path, value);
      }
      return ns;
    });
    updateData({ ...data, sections: newSections });
  };

  const triggerUpload = (path: string) => {
    setUploadPath(path);
    fileInputRef.current?.click();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && uploadPath) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (uploadPath.startsWith('sections.')) {
           const parts = uploadPath.split('.');
           updateSectionPart(parts[1], parts[2] as any, parts.slice(3).join('.'), reader.result);
        } else {
           updateRoot(uploadPath, reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const renderRecursive = (obj: any, base: string, rootType: 'sections' | 'footer' | 'general') => {
    if (!obj) return null;
    return Object.keys(obj).map(key => {
      const val = obj[key];
      const currentPath = base ? `${base}.${key}` : key;
      const isImg = /image|img|icon|logo|bgImage|ceoImage|foto/.test(key);
      const isVideoField = /bgVideo|fileVideo/.test(key); 
      const isUrlField = /url|link|href|checkoutUrl/i.test(key) && !isImg && !isVideoField;
      const isColor = /color|bg/.test(key) && !/bgType|bgGradient|bgImage|bgVideo/.test(key);
      const isSelect = key === 'bgType';
      const updater = (v: any) => rootType === 'sections' ? updateSectionPart(activeSectionId!, editMode as any, currentPath, v) : updateRoot(`${rootType}.${currentPath}`, v);

      if (key === 'customHighlights') return null;

      if (isSelect) {
        return (
          <div key={key} className="mb-6">
            <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest block mb-3">Estilo de Fundo</label>
            <div className="grid grid-cols-4 gap-2 bg-zinc-900 p-1.5 rounded-2xl border border-zinc-800">
              {[
                {id: 'solid', icon: Palette, label: 'Cor'},
                {id: 'gradient', icon: Box, label: 'Grad'},
                {id: 'image', icon: Image, label: 'Foto'},
                {id: 'video', icon: Video, label: 'Vídeo'}
              ].map(opt => (
                <button 
                  key={opt.id} 
                  type="button"
                  onClick={(e) => { e.stopPropagation(); updater(opt.id); }}
                  className={`flex flex-col items-center gap-1.5 py-3 rounded-xl transition-all ${val === opt.id ? 'bg-yellow-600 text-black shadow-lg font-bold' : 'text-zinc-600 hover:text-zinc-400'}`}
                >
                  <opt.icon size={16} />
                  <span className="text-[7px] font-black uppercase">{opt.label}</span>
                </button>
              ))}
            </div>
          </div>
        );
      }

      if (Array.isArray(val)) {
        return (
          <div key={key} className="pt-8 border-t border-zinc-900 mt-8 mb-4">
            <div className="flex justify-between items-center mb-6">
               <span className="text-[10px] font-black text-yellow-500 uppercase tracking-widest">{key}</span>
               <button type="button" onClick={() => updater([...val, val.length > 0 ? JSON.parse(JSON.stringify(val[0])) : {}])} className="text-[9px] font-black bg-yellow-600 text-black px-4 py-2 rounded-xl flex items-center gap-2 shadow-lg"><PlusCircle size={14}/> NOVO ITEM</button>
            </div>
            {val.map((item, idx) => (
              <div key={idx} className="mb-6 p-5 bg-zinc-900/40 border border-zinc-800 rounded-3xl relative">
                 <button type="button" onClick={() => { const newVal = [...val]; newVal.splice(idx, 1); updater(newVal); }} className="absolute -top-2 -right-2 w-7 h-7 bg-zinc-800 text-zinc-500 hover:text-red-500 rounded-full flex items-center justify-center border border-zinc-700 shadow-xl"><Trash2 size={12}/></button>
                 {renderRecursive(item, `${currentPath}.${idx}`, rootType)}
              </div>
            ))}
          </div>
        );
      }

      if (typeof val === 'object' && val !== null) return <div key={key} className="pl-4 border-l border-zinc-800 mb-8 mt-2">{renderRecursive(val, currentPath, rootType)}</div>;
      
      if (isColor && typeof val === 'string' && val.startsWith('#')) {
        return (
          <div key={key} className="flex items-center justify-between mb-4 bg-zinc-900/50 p-3 rounded-2xl border border-zinc-800">
            <span className="text-[9px] text-zinc-500 font-black uppercase tracking-widest">{key}</span>
            <input type="color" value={val || "#000000"} onInput={(e) => updater((e.target as HTMLInputElement).value)} className="w-10 h-10 rounded-full cursor-pointer bg-transparent border-none p-0 overflow-hidden shadow-lg" />
          </div>
        );
      }

      const fullPath = rootType === 'sections' ? `sections.${activeSectionId}.${editMode}.${currentPath}` : `${rootType}.${currentPath}`;
      
      return (
        <div key={key} className="mb-5">
          <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest block mb-2">{key}</label>
          {isImg || isVideoField ? (
            <div className="flex gap-2">
              <div className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-[10px] text-zinc-400 truncate flex items-center overflow-hidden">
                 {typeof val === 'string' && val.length > 10 ? '✅ MÍDIA' : '❌ VAZIO'}
              </div>
              <button type="button" onClick={() => triggerUpload(fullPath)} className="bg-yellow-600 text-black p-3 rounded-xl shrink-0 transition-transform active:scale-95 shadow-lg">
                {isImg ? <ImageIcon size={18} /> : <Video size={18} />}
              </button>
            </div>
          ) : isUrlField ? (
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-600">
                <LinkIcon size={14} />
              </div>
              <input 
                type="text"
                value={val} 
                onChange={(e) => updater(e.target.value)} 
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 pl-10 text-xs text-white focus:border-yellow-500 outline-none font-medium transition-colors" 
                placeholder="Cole o link aqui..."
              />
            </div>
          ) : (
            <textarea 
              rows={typeof val === 'string' && val.length > 50 ? 4 : 1} 
              value={val} 
              onChange={(e) => updater(e.target.value)} 
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3.5 text-xs text-white focus:border-yellow-500 outline-none resize-none font-medium transition-colors" 
            />
          )}
        </div>
      );
    });
  };

  if (!isAdminOpen) return (
    <button onClick={() => setAdminOpen(true)} className="fixed bottom-8 right-8 z-[200] bg-yellow-600 text-black p-5 rounded-full shadow-2xl transition-all hover:scale-110 active:scale-90 ring-4 ring-yellow-600/20">
      <Settings size={28} />
    </button>
  );

  return (
    <>
      <div className="fixed inset-y-0 left-0 w-[320px] z-[500] bg-zinc-950 border-r border-zinc-900 flex flex-col pointer-events-auto overflow-hidden animate-fade-in-left shadow-[0_0_100px_rgba(0,0,0,1)]">
        <input type="file" ref={fileInputRef} className="hidden" accept="image/*,video/mp4,video/webm" onChange={handleFileUpload} />
        
        <div className="p-6 border-b border-zinc-900 flex justify-between items-center bg-black">
          <h1 className="text-white font-black text-[12px] uppercase italic tracking-tighter">INFLAMAX <span className="text-yellow-500">PRO</span></h1>
          <button onClick={() => setAdminOpen(false)} className="text-zinc-600 hover:text-white transition-colors"><X size={20}/></button>
        </div>

        <div className="flex border-b border-zinc-900 bg-zinc-950">
          {['structure', 'create', 'edit', 'footer'].map(tid => (
            <button key={tid} onClick={() => setActiveTab(tid as any)} className={`flex-1 py-4 text-[9px] font-black uppercase tracking-widest transition-all ${activeTab === tid ? 'text-yellow-500 border-b-2 border-yellow-500 bg-yellow-500/5' : 'text-zinc-500'}`}>
              {tid === 'structure' ? 'Blocos' : tid === 'create' ? 'Novo' : tid === 'edit' ? 'Editar' : 'Rodapé'}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto admin-scrollbar bg-zinc-950 p-6">
          {activeTab === 'structure' && (
            <div className="space-y-3">
              {data.sections.map((sec) => (
                <div key={sec.id} onClick={() => { setActiveSectionId(sec.id); setActiveTab('edit'); }} className={`p-4 rounded-2xl border cursor-pointer flex items-center justify-between transition-all group ${activeSectionId === sec.id ? 'bg-yellow-600/10 border-yellow-500' : 'bg-zinc-900 border-zinc-800'}`}>
                  <div className="flex-1 min-w-0">
                    <span className="block text-[10px] font-black text-white uppercase truncate">{sec.type}</span>
                    <span className="text-[8px] font-bold text-zinc-500 uppercase">ID: {sec.id}</span>
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button type="button" onClick={(e) => { e.stopPropagation(); moveSection(sec.id, 'up'); }} className="p-1.5 bg-zinc-800 rounded-lg"><ArrowUp size={12}/></button>
                    <button type="button" onClick={(e) => { e.stopPropagation(); moveSection(sec.id, 'down'); }} className="p-1.5 bg-zinc-800 rounded-lg"><ArrowDown size={12}/></button>
                    <button type="button" onClick={(e) => { e.stopPropagation(); removeSection(sec.id); }} className="p-1.5 bg-zinc-800 rounded-lg hover:text-red-500"><Trash2 size={12}/></button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'create' && (
            <div className="grid grid-cols-2 gap-3">
              {[
                {type: 'hero', label: 'Capa'}, {type: 'painPoints', label: 'Dores'},
                {type: 'benefits', label: 'Benefícios'}, {type: 'ingredients', label: 'Fórmula'},
                {type: 'pricing', label: 'Preços'}, {type: 'testimonials', label: 'Feedback'},
                {type: 'faq', label: 'FAQ'}, {type: 'guarantee', label: 'Garantia'},
                {type: 'video', label: 'Vídeo'}, {type: 'media', label: 'Banner'},
                {type: 'comparison', label: 'Antes/Depois'}, {type: 'trustBadges', label: 'Selos'}
              ].map(item => (
                <button key={item.type} onClick={() => addSection(item.type as SectionType)} className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl flex flex-col items-center gap-2 hover:border-yellow-600 transition-all group">
                  <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center group-hover:bg-yellow-600 group-hover:text-black transition-colors"><Plus size={20} /></div>
                  <span className="text-[8px] font-black text-zinc-500 group-hover:text-white uppercase tracking-widest text-center">{item.label}</span>
                </button>
              ))}
            </div>
          )}

          {activeTab === 'edit' && data.sections.find(s => s.id === activeSectionId) && (
            <div className="animate-fade-in-up">
              <div className="flex mb-6 bg-zinc-900 rounded-xl p-1 shadow-inner">
                <button type="button" onClick={() => setEditMode('content')} className={`flex-1 py-2.5 text-[9px] font-black uppercase rounded-lg transition-all ${editMode === 'content' ? 'bg-yellow-600 text-black shadow-lg' : 'text-zinc-500'}`}>CONTEÚDO</button>
                <button type="button" onClick={() => setEditMode('style')} className={`flex-1 py-2.5 text-[9px] font-black uppercase rounded-lg transition-all ${editMode === 'style' ? 'bg-yellow-600 text-black shadow-lg' : 'text-zinc-500'}`}>ESTILO</button>
              </div>
              {renderRecursive(data.sections.find(s => s.id === activeSectionId)?.[editMode as any], '', 'sections')}
            </div>
          )}

          {activeTab === 'footer' && (
            <div className="animate-fade-in-up">
              <div className="flex mb-6 bg-zinc-900 rounded-xl p-1">
                <button type="button" onClick={() => setEditMode('content')} className={`flex-1 py-2.5 text-[9px] font-black uppercase rounded-lg ${editMode === 'content' ? 'bg-yellow-600 text-black shadow-lg' : 'text-zinc-500'}`}>DADOS</button>
                <button type="button" onClick={() => setEditMode('style')} className={`flex-1 py-2.5 text-[9px] font-black uppercase rounded-lg ${editMode === 'style' ? 'bg-yellow-600 text-black shadow-lg' : 'text-zinc-500'}`}>ESTILO</button>
              </div>
              {editMode === 'content' ? renderRecursive(data.footer.content, 'content', 'footer') : renderRecursive(data.footer.style, 'style', 'footer')}
            </div>
          )}
        </div>

        <div className="p-6 bg-black border-t border-zinc-900">
          <button onClick={() => setAdminOpen(false)} className="w-full bg-yellow-600 hover:bg-yellow-500 text-black font-black text-[11px] uppercase py-4 rounded-2xl shadow-xl flex items-center justify-center gap-3 transition-all hover:scale-[1.02] active:scale-95">
            <Save size={18}/> PUBLICAR SITE
          </button>
        </div>
      </div>

      <div className={`fixed bottom-24 right-8 z-[600] transition-all duration-500 flex flex-col items-end ${isAiOpen ? 'w-[360px]' : 'w-16'}`}>
        <input type="file" ref={aiFileInputRef} className="hidden" multiple accept="image/*,application/pdf" onChange={(e) => {
          const files = e.target.files;
          if (!files) return;
          Array.from(files).forEach(file => {
            const reader = new FileReader();
            reader.onload = (event) => {
              const base64 = (event.target?.result as string).split(',')[1];
              setAttachments(prev => [...prev, {
                data: base64,
                mimeType: file.type,
                name: file.name,
                preview: file.type.startsWith('image/') ? (event.target?.result as string) : undefined
              }]);
            };
            reader.readAsDataURL(file);
          });
        }} />

        {isAiOpen && (
          <div className="w-full bg-zinc-950 border border-zinc-800 rounded-[2.5rem] shadow-2xl flex flex-col mb-4 overflow-hidden animate-fade-in-up">
            <div className="p-5 bg-black flex justify-between items-center border-b border-zinc-800">
              <div className="flex items-center gap-3">
                <Sparkles size={20} className="text-yellow-500 animate-pulse" />
                <span className="text-[11px] font-black uppercase tracking-widest text-white italic">IA MULTIMODAL</span>
              </div>
              <button onClick={() => setIsAiOpen(false)} className="text-zinc-400 hover:text-white"><X size={20}/></button>
            </div>

            <div className="h-[320px] overflow-y-auto p-5 flex flex-col gap-4 admin-scrollbar bg-black/40">
              {aiMessages.length === 0 && (
                <div className="bg-yellow-600/5 p-4 rounded-2xl border border-yellow-600/10 text-[11px] text-yellow-100/60 leading-relaxed">
                  👋 Olá! Sou sua IA de design. Me peça para mudar cores, textos ou anexe um print para eu ajustar o site igual!
                </div>
              )}
              {aiMessages.map((msg, i) => (
                <div key={i} className={`max-w-[85%] p-4 rounded-3xl text-[12px] font-medium leading-relaxed ${msg.role === 'user' ? 'bg-zinc-800 ml-auto text-white' : 'bg-yellow-600/10 text-yellow-100 border border-yellow-600/20'}`}>
                  {msg.text}
                </div>
              ))}
              {isAiLoading && <div className="animate-pulse text-yellow-500 text-[10px] uppercase font-black ml-auto flex items-center gap-2"><Loader2 size={12} className="animate-spin" /> IA Processando...</div>}
            </div>

            {attachments.length > 0 && (
              <div className="px-5 py-3 border-t border-zinc-900 bg-zinc-950 flex gap-2 overflow-x-auto no-scrollbar">
                {attachments.map((att, idx) => (
                  <div key={idx} className="relative group shrink-0">
                    <div className="w-12 h-12 bg-zinc-900 rounded-xl border border-zinc-800 overflow-hidden flex items-center justify-center">
                      {att.preview ? <img src={att.preview} className="w-full h-full object-cover" /> : att.mimeType.includes('audio') ? <Mic size={16} className="text-yellow-500" /> : <FileText size={16} />}
                    </div>
                    <button onClick={() => setAttachments(prev => prev.filter((_, i) => i !== idx))} className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5"><X size={8} /></button>
                  </div>
                ))}
              </div>
            )}

            <div className="p-4 border-t border-zinc-900 bg-zinc-950">
              <div className="flex flex-wrap gap-2 items-center bg-zinc-900 p-2 rounded-3xl border border-zinc-800 shadow-inner">
                <div className="flex gap-1">
                  <button type="button" onClick={() => aiFileInputRef.current?.click()} className="text-zinc-500 hover:text-yellow-500 p-2" title="Foto/PDF"><Paperclip size={20} /></button>
                  <button type="button" onClick={takeScreenshot} className="text-zinc-500 hover:text-yellow-500 p-2" title="Capturar Tela"><Camera size={20} /></button>
                  <button type="button" onMouseDown={startRecording} onMouseUp={stopRecording} onMouseLeave={stopRecording} className={`p-2 transition-all rounded-full ${isRecording ? 'bg-red-500 text-white animate-pulse' : 'text-zinc-500 hover:text-yellow-500'}`} title="Voz"><Mic size={20} /></button>
                </div>
                <input 
                  value={aiPrompt} 
                  onChange={(e) => setAiPrompt(e.target.value)} 
                  onKeyPress={(e) => e.key === 'Enter' && handleAIUpdate()} 
                  onPaste={handlePaste}
                  placeholder="Mande voz, cole print ou fale..." 
                  className="flex-1 min-w-[120px] bg-transparent text-xs text-white outline-none px-2 font-medium" 
                />
                <button type="button" onClick={() => handleAIUpdate()} className="bg-yellow-600 text-black p-2.5 rounded-full hover:scale-105 transition-all shadow-lg"><Send size={18} /></button>
              </div>
            </div>
          </div>
        )}

        <button onClick={() => setIsAiOpen(!isAiOpen)} className={`w-16 h-16 rounded-full flex items-center justify-center transition-all shadow-2xl ${isAiOpen ? 'bg-zinc-800 rotate-90 scale-90' : 'bg-yellow-600 hover:scale-110'}`}>
          {isAiOpen ? <X size={28} className="text-white" /> : <Wand2 size={30} className="text-black" />}
        </button>
      </div>
    </>
  );
};

export default AdminPanel;
