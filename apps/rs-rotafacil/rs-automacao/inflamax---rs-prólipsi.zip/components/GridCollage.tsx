
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import FormattedText from './FormattedText';

const GridCollage: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;

  if (!style.isVisible) return null;

  const images = Array.isArray(content.images) ? content.images : [];

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-24 relative group cursor-pointer border-2 transition-all ${activeSectionId === section.id ? 'border-yellow-500' : 'border-transparent'}`}
      style={{ backgroundColor: style.bgColor }}
    >
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 h-[600px]">
          {images.slice(0, 4).map((img: string, idx: number) => (
            <div key={idx} className={`relative overflow-hidden rounded-[2rem] shadow-xl ${idx === 0 || idx === 3 ? 'md:col-span-2' : ''}`}>
              <img src={img} className="w-full h-full object-cover hover:scale-110 transition-transform duration-1000" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
            </div>
          ))}
        </div>
        <div className="mt-12 text-center">
           <h3 className="text-4xl font-black uppercase" style={{ color: style.titleColor }}>
             <FormattedText text={content.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
           </h3>
        </div>
      </div>
    </section>
  );
};

export default GridCollage;
