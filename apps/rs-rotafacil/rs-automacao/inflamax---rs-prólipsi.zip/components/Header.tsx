
import React, { useState, useEffect } from 'react';
import { useSiteData } from '../context/SiteContext';
import { Phone, ShoppingCart, Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const { data, previewMode } = useSiteData();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const isMobilePreview = previewMode === 'mobile';

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    if (!targetId) return;
    if (targetId.startsWith('http') || targetId.startsWith('tel:')) return;
    
    e.preventDefault();
    setIsMobileMenuOpen(false);

    const cleanId = targetId.startsWith('#') ? targetId.substring(1) : targetId;
    const element = document.getElementById(cleanId);
    
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top + window.scrollY;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const menuItems = Array.isArray(data?.menu) ? data.menu : [];

  return (
    <header 
      className={`sticky top-0 left-0 w-full z-[300] transition-all duration-300 border-b ${
        scrolled || isMobileMenuOpen || isMobilePreview 
          ? 'bg-black border-yellow-900/30 py-2' 
          : 'bg-transparent border-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        {/* Logo / Marca */}
        <div className="flex items-center gap-1 min-w-0 flex-shrink-1">
           <a href="#" onClick={(e) => handleLinkClick(e, '#')} className="font-serif font-bold text-yellow-500 tracking-tight hover:text-yellow-400 transition-colors flex items-center min-w-0">
             <span className="gold-gradient-text mr-0.5 text-xs md:text-2xl font-bold">{data?.general?.brandNameGold || 'RS'}</span>
             <span className="text-white text-[12px] md:text-xl font-black truncate uppercase">{data?.general?.brandName || 'PRÓLIPSI'}</span>
           </a>
        </div>

        {/* Menu Desktop */}
        <nav className={`${isMobilePreview ? 'hidden' : 'hidden md:flex'} gap-6 text-[10px] font-black uppercase tracking-widest text-gray-400`}>
          {menuItems.map((item, idx) => (
            <a 
              key={idx} 
              href={item.href} 
              onClick={(e) => handleLinkClick(e, item.href)} 
              className={`transition-all cursor-pointer flex items-center gap-2 ${
                item.isButton 
                ? 'text-black bg-yellow-500 px-5 py-2 rounded-full hover:scale-105 active:scale-95 shadow-lg shadow-yellow-500/20' 
                : 'hover:text-yellow-500'
              }`}
            >
              {item.isButton && <ShoppingCart size={12} />}
              {item.label}
            </a>
          ))}
        </nav>

        {/* Botão Hambúrguer */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <a href={`https://wa.me/${data?.general?.whatsapp}`} target="_blank" className={`${isMobilePreview ? 'hidden' : 'hidden lg:flex'} items-center gap-2 text-yellow-500 hover:text-white transition-colors bg-zinc-900/50 px-4 py-2 rounded-xl border border-zinc-800`}>
            <Phone size={14} className="animate-pulse" />
            <span className="text-[10px] font-black tracking-widest">{data?.general?.whatsappDisplay || '(41) 99286-3922'}</span>
          </a>

          <button 
            className={`${isMobilePreview ? 'flex' : 'md:hidden'} text-white hover:text-yellow-500 transition-all p-2 bg-zinc-900 rounded-lg border border-zinc-800 z-[310] relative`}
            onClick={(e) => {
              e.stopPropagation();
              setIsMobileMenuOpen(!isMobileMenuOpen);
            }}
          >
            {isMobileMenuOpen ? <X size={24} className="text-yellow-500" /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Menu Mobile Overlay - Fundo Totalmente Escuro e Legível */}
      {isMobileMenuOpen && (
        <div 
          className="absolute left-0 top-full w-full bg-black backdrop-blur-3xl flex flex-col p-8 gap-6 animate-fade-in-up border-t border-zinc-900 shadow-[0_20px_100px_rgba(0,0,0,1)] z-[290] overflow-y-auto"
          style={{ 
            height: isMobilePreview ? 'calc(812px - 60px)' : 'calc(100vh - 60px)',
            opacity: 1
          }}
        >
          {menuItems.map((item, idx) => (
            <a 
              key={idx}
              href={item.href} 
              className={`text-2xl font-black uppercase tracking-tight border-b border-zinc-900/80 pb-6 flex items-center justify-between transition-colors ${item.isButton ? 'text-yellow-500' : 'text-zinc-100'}`} 
              onClick={(e) => handleLinkClick(e, item.href)}
            >
              {item.label}
              {item.isButton ? <ShoppingCart size={22} /> : <div className="w-2 h-2 rounded-full bg-yellow-500/20" />}
            </a>
          ))}
          
          <div className="mt-10 flex flex-col gap-6">
            <p className="text-[11px] font-black text-zinc-600 uppercase tracking-widest text-center italic">Atendimento Prioritário</p>
            <a href={`https://wa.me/${data?.general?.whatsapp}`} target="_blank" className="flex items-center justify-center gap-3 text-black bg-yellow-500 py-5 rounded-2xl font-black uppercase text-sm shadow-[0_10px_30px_rgba(234,179,8,0.2)] hover:scale-[1.02] active:scale-95 transition-all">
              <Phone size={20} /> CHAMAR NO WHATSAPP
            </a>
            
            <div className="flex flex-col items-center gap-4 mt-6">
                <div className="flex gap-4 opacity-40">
                  <div className="bg-zinc-900 p-3 rounded-lg border border-zinc-800"><ShoppingCart size={16} /></div>
                  <div className="bg-zinc-900 p-3 rounded-lg border border-zinc-800"><Phone size={16} /></div>
                </div>
                <p className="text-[9px] font-black text-zinc-700 uppercase tracking-widest">RS PRÓLIPSI &copy; 2025</p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
