
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { ShieldCheck, Truck, Lock, CheckCircle } from 'lucide-react';

const TrustBadges: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;

  if (!style.isVisible) return null;

  const badges = Array.isArray(content.badges) ? content.badges : [];

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-12 relative group cursor-pointer border-2 transition-all ${activeSectionId === section.id ? 'border-yellow-500' : 'border-transparent'}`}
      style={{ backgroundColor: style.bgColor }}
    >
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-center gap-8 md:gap-16">
          {badges.map((badge: any, idx: number) => (
            <div key={idx} className="flex flex-col items-center text-center max-w-[120px]">
              <div className="mb-4 p-4 rounded-full bg-zinc-900 border border-zinc-800" style={{ color: style.highlightColor }}>
                <CheckCircle size={32} />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest leading-tight" style={{ color: style.titleColor }}>{badge.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustBadges;
