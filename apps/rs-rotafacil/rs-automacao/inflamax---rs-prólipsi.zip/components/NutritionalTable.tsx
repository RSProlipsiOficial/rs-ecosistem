
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import FormattedText from './FormattedText';

const NutritionalTable: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;

  if (!style.isVisible) return null;

  const rows = Array.isArray(content.rows) ? content.rows : [];

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-20 relative group cursor-pointer border-2 transition-all ${activeSectionId === section.id ? 'border-yellow-500' : 'border-transparent'}`}
      style={{ backgroundColor: style.bgColor }}
    >
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="bg-white text-black p-8 border-4 border-black rounded-sm shadow-2xl">
          <h2 className="text-4xl font-black border-b-8 border-black pb-2 mb-4 uppercase leading-none">Tabela *Nutricional*</h2>
          <div className="border-b-4 border-black mb-4 flex justify-between font-black text-sm uppercase">
            <span>Componente</span>
            <span>Qtd por Dose</span>
          </div>
          
          <div className="space-y-2">
            {rows.map((row: any, idx: number) => (
              <div key={idx} className="flex justify-between border-b border-zinc-300 py-1 text-sm font-bold uppercase tracking-tight">
                <span>{row.label}</span>
                <span>{row.value}</span>
              </div>
            ))}
          </div>
          
          <p className="text-[10px] mt-6 leading-tight opacity-70">
            * Valores Diários com base em uma dieta de 2.000 kcal. Seus valores diários podem ser maiores ou menores dependendo de suas necessidades.
          </p>
        </div>
      </div>
    </section>
  );
};

export default NutritionalTable;
