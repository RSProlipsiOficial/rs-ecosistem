
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { Edit3 } from 'lucide-react';
import FormattedText from './FormattedText';

const Ingredients: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;

  if (!style.isVisible) return null;

  const bgStyle: any = {
    position: 'relative',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat'
  };

  if (style.bgType === 'image' && style.bgImage) {
    bgStyle.backgroundImage = `url(${style.bgImage})`;
  } else if (style.bgType === 'gradient') {
    bgStyle.background = style.bgGradient;
  } else {
    bgStyle.backgroundColor = style.bgColor || '#050505';
  }

  const items = Array.isArray(content.items) ? content.items : [];

  return (
    <section 
      id="formula" 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-20 scroll-mt-32 group relative cursor-pointer border-2 transition-all overflow-hidden ${activeSectionId === section.id ? 'border-yellow-500 ring-4 ring-yellow-500/10' : 'border-transparent'}`}
      style={bgStyle}
    >
      {style.bgType === 'video' && style.bgVideo && (
        <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover z-0 pointer-events-none">
          <source src={style.bgVideo} type="video/mp4" />
        </video>
      )}

      {(style.bgType === 'image' || style.bgType === 'video' || style.bgType === 'gradient') && (
        <div className="absolute inset-0 z-[1] pointer-events-none" style={{ backgroundColor: style.overlayColor || '#000', opacity: style.overlayOpacity ?? 0.5 }}></div>
      )}

      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center gap-12 relative z-10">
        <div className="w-full md:w-1/2">
          <h2 className="text-3xl md:text-4xl font-black mb-6 uppercase tracking-tighter leading-none" style={{ color: style.titleColor }}>
             <FormattedText text={content.sectionTitle} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
          </h2>
          <p className="mb-8 text-base font-medium leading-relaxed" style={{ color: style.textColor }}>
            <FormattedText text={content.sectionSubtitle} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
          </p>
          
          <div className="space-y-4">
            {items.map((ing: any, idx: number) => (
              <div key={idx} className="flex items-start gap-4 p-4 border-l-2 bg-zinc-900/30 rounded-r-2xl hover:bg-zinc-800/50 transition-all duration-300" style={{ borderLeftColor: style.highlightColor }}>
                <div>
                  <h4 className="font-black text-base uppercase tracking-tight" style={{ color: style.highlightColor }}>
                    <FormattedText text={ing.name} highlightColor={style.titleColor} customHighlights={content.customHighlights} />
                  </h4>
                  <p className="text-xs leading-relaxed mt-1" style={{ color: style.textColor }}>
                    {ing.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="w-full md:w-1/2 flex justify-center relative">
          <div className="relative z-10 bg-zinc-900 p-2 rounded-[2.5rem] border border-zinc-800 overflow-hidden shadow-2xl">
            <div className="absolute inset-0 z-10 pointer-events-none" style={{ backgroundColor: style.overlayColor, opacity: style.overlayOpacity || 0 }}></div>
            <img 
               src={content.image || "https://images.unsplash.com/photo-1616671276445-162152671d8a?auto=format&fit=crop&q=80&w=600"} 
               alt="Fórmula"
               className="rounded-[2.2rem] transition-all duration-1000 w-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Ingredients;
