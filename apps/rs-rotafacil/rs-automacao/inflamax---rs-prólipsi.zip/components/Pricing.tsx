
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import FormattedText from './FormattedText';

const PricingCard: React.FC<{ option: any, highlightColor: string, titleColor: string, textColor: string, customHighlights: any[] }> = ({ option, highlightColor, titleColor, textColor, customHighlights }) => {
  return (
    <div className={`relative flex flex-col rounded-[2.5rem] bg-zinc-900/50 border border-zinc-800 p-6 md:p-8 transition-all hover:scale-[1.02] w-full ${option.bestSeller ? 'ring-2 shadow-2xl shadow-yellow-500/10' : ''}`} style={{ borderColor: option.bestSeller ? highlightColor : undefined }}>
      <div className="flex justify-center mb-4 md:mb-8">
        <img src={option.image} className="h-32 md:h-48 object-contain" alt={option.title} />
      </div>
      <h3 className="text-base md:text-xl font-black text-center mb-1 uppercase leading-tight" style={{ color: titleColor }}>
        <FormattedText text={option.title} highlightColor={highlightColor} customHighlights={customHighlights} />
      </h3>
      <p className="text-[8px] md:text-[10px] text-center mb-4 md:mb-6 uppercase tracking-widest opacity-60" style={{ color: textColor }}>
        {option.subtitle}
      </p>
      
      <div className="text-center mb-5 md:mb-8">
        <p className="line-through text-[9px] md:text-xs opacity-40 mb-1" style={{ color: textColor }}>De R$ {option.originalPrice}</p>
        <p className="text-2xl md:text-4xl font-black" style={{ color: highlightColor }}>R$ {option.price}</p>
        <div className="mt-3 md:mt-4 bg-black/40 rounded-xl p-3 md:p-4 border border-zinc-800">
           <p className="text-[8px] md:text-[10px] font-bold uppercase" style={{ color: textColor }}>12x de <span className="text-white text-base md:text-lg font-black">R$ {option.installmentValue}</span></p>
        </div>
      </div>

      <a 
        href={option.checkoutUrl} 
        className="w-full py-3 md:py-5 rounded-xl text-center font-black text-[9px] md:text-xs uppercase tracking-widest text-black transition-all hover:brightness-110 active:scale-95 shadow-lg"
        style={{ backgroundColor: highlightColor }}
      >
        Comprar Agora
      </a>
    </div>
  );
};

const Pricing: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const content = section.content;
  const style = section.style;

  if (!style.isVisible) return null;

  const bgStyle: any = {
    position: 'relative',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat'
  };

  if (style.bgType === 'image' && style.bgImage) {
    bgStyle.backgroundImage = `url(${style.bgImage})`;
  } else if (style.bgType === 'gradient') {
    bgStyle.background = style.bgGradient;
  } else {
    bgStyle.backgroundColor = style.bgColor || '#050505';
  }

  const kits = content.kits ? Object.values(content.kits) : [];

  return (
    <section 
      id="ofertas" 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-12 md:py-24 relative cursor-pointer border-2 transition-all overflow-hidden ${activeSectionId === section.id ? 'border-yellow-500 bg-yellow-500/5 ring-4 ring-yellow-500/10' : 'border-transparent'}`}
      style={bgStyle}
    >
      {style.bgType === 'video' && style.bgVideo && (
        <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover z-0 pointer-events-none">
          <source src={style.bgVideo} type="video/mp4" />
        </video>
      )}

      {(style.bgType === 'image' || style.bgType === 'video' || style.bgType === 'gradient') && (
        <div className="absolute inset-0 z-[1] pointer-events-none" style={{ backgroundColor: style.overlayColor || '#000', opacity: style.overlayOpacity ?? 0.5 }}></div>
      )}

      <div className="container mx-auto px-4 relative z-10">
        <h2 className="text-2xl md:text-5xl font-black text-center mb-10 md:mb-16 uppercase tracking-tighter leading-tight" style={{ color: style.titleColor }}>
          <FormattedText text={content.sectionTitle} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-8 max-w-6xl mx-auto">
          {kits.map((kit: any) => (
            <PricingCard key={kit.id} option={kit} highlightColor={style.highlightColor} titleColor={style.titleColor} textColor={style.textColor} customHighlights={content.customHighlights || []} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;
