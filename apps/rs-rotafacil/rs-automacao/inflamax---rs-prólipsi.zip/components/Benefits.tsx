
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { CheckCircle2, Play, Image as ImageIcon } from 'lucide-react';
import FormattedText from './FormattedText';

const Benefits: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;

  if (!style.isVisible) return null;

  const bgStyle: any = {
    position: 'relative',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat'
  };

  if (style.bgType === 'image' && style.bgImage) {
    bgStyle.backgroundImage = `url(${style.bgImage})`;
  } else if (style.bgType === 'gradient') {
    bgStyle.background = style.bgGradient;
  } else {
    bgStyle.backgroundColor = style.bgColor || '#050505';
  }

  const items = Array.isArray(content.items) ? content.items : [];

  const renderMarker = (benefitColor: string) => {
    const type = style.markerType || 'dash';
    const color = style.markerColor || benefitColor;

    switch (type) {
      case 'dot':
        return <div className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0" style={{ backgroundColor: color }} />;
      case 'triangle':
        return <Play size={10} className="mt-1.5 flex-shrink-0 fill-current" style={{ color }} />;
      case 'dash':
        return <div className="w-1 h-full min-h-[20px] rounded-full flex-shrink-0" style={{ backgroundColor: color }} />;
      default:
        return null;
    }
  };

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-12 md:py-24 relative overflow-hidden group cursor-pointer border-2 transition-all ${activeSectionId === section.id ? 'border-yellow-500 ring-4 ring-yellow-500/10' : 'border-transparent'}`}
      style={bgStyle}
    >
      {/* Background de Vídeo */}
      {style.bgType === 'video' && style.bgVideo && (
        <video autoPlay muted loop playsInline className="absolute inset-0 w-full h-full object-cover z-0">
          <source src={style.bgVideo} type="video/mp4" />
        </video>
      )}

      {/* Overlay */}
      {(style.bgType === 'image' || style.bgType === 'video' || style.bgType === 'gradient') && (
        <div className="absolute inset-0 z-[1] pointer-events-none" style={{ backgroundColor: style.overlayColor || '#000', opacity: style.overlayOpacity ?? 0.5 }}></div>
      )}

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-10 md:mb-16">
          {content.sectionSubtitle && (
            <span className="font-black tracking-[0.2em] text-[8px] md:text-[10px] uppercase px-4 py-1.5 rounded-full border inline-block mb-4" style={{ color: style.highlightColor, borderColor: `${style.highlightColor}40`, backgroundColor: `${style.highlightColor}10` }}>
              {content.sectionSubtitle}
            </span>
          )}
          <h2 className="text-2xl md:text-5xl font-black mb-4 uppercase tracking-tighter" style={{ color: style.titleColor }}>
            <FormattedText text={content.sectionTitle} highlightColor={style.highlightColor} />
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-8">
          {items.map((benefit: any, index: number) => (
            <div 
              key={index}
              className="bg-zinc-900/60 backdrop-blur-md border border-zinc-800/50 transition-all shadow-xl flex flex-col overflow-hidden group/benefit"
              style={{ borderRadius: style.borderRadius ?? 32 }}
            >
              <div className="w-full overflow-hidden bg-zinc-800/20 flex items-center justify-center relative transition-colors group-hover/benefit:bg-zinc-800/40" style={{ height: style.imageHeight ? `${style.imageHeight}px` : '240px' }}>
                {benefit.image ? (
                  <img src={benefit.image} alt={benefit.title} className="w-full h-full object-cover transition-transform duration-700 group-hover/benefit:scale-105" />
                ) : (
                  <div className="flex flex-col items-center gap-3 opacity-30 group-hover/benefit:opacity-100 transition-all">
                    <div className="w-16 h-16 flex items-center justify-center bg-zinc-700 rounded-full">
                        <ImageIcon size={32} className="text-zinc-400" />
                    </div>
                    {isAdminOpen && <span className="text-[8px] font-black uppercase tracking-widest text-zinc-400">Adicionar Foto no Painel</span>}
                  </div>
                )}
              </div>
              <div className="p-6 md:p-8 flex-1 flex flex-col">
                <h3 className="text-base md:text-xl font-black mb-3 uppercase" style={{ color: style.titleColor }}>{benefit.title}</h3>
                <div className="flex gap-3">
                  {renderMarker(style.highlightColor)}
                  <p className="text-[11px] md:text-sm opacity-70 leading-relaxed" style={{ color: style.textColor }}>{benefit.text}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Benefits;
