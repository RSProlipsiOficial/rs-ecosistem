
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { Edit3 } from 'lucide-react';
import FormattedText from './FormattedText';

const SpecialBanner: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const content = section.content;
  const style = section.style;

  if (!style.isVisible) return null;

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-16 md:py-24 relative group cursor-pointer border-2 transition-all duration-300 ${activeSectionId === section.id ? 'border-yellow-500 bg-yellow-500/5' : 'border-transparent'}`}
      style={{ backgroundColor: style.bgColor }}
    >
      {isAdminOpen && (
        <div className="absolute top-4 right-4 z-50 opacity-0 group-hover:opacity-100 transition-opacity">
           <div className="bg-yellow-600 text-black px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest flex items-center gap-2">
             <Edit3 size={12}/> Bloco Especial
           </div>
        </div>
      )}

      <div className="container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto bg-white/5 border border-white/10 rounded-[2rem] p-10 md:p-16 shadow-2xl backdrop-blur-sm">
           <h2 
             className="text-4xl md:text-6xl font-black mb-10 leading-none uppercase tracking-tighter"
             style={{ color: style.titleColor }}
           >
             <FormattedText text={content.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
           </h2>
           
           <div className="flex justify-center">
              <a 
                href={content.buttonUrl || "#ofertas"} 
                className="inline-block text-black text-sm md:text-base font-black px-12 py-5 rounded-full shadow-xl transition-all hover:scale-105 active:scale-95 uppercase tracking-widest"
                style={{ backgroundColor: style.highlightColor }}
              >
                {content.buttonText}
              </a>
           </div>
        </div>
      </div>
    </section>
  );
};

export default SpecialBanner;
