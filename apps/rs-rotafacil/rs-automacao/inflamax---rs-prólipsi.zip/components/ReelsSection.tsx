
import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { Play, Edit3 } from 'lucide-react';
import FormattedText from './FormattedText';

const ReelsSection: React.FC<{ data: any }> = ({ data: section }) => {
  const { isAdminOpen, activeSectionId, setActiveSectionId } = useSiteData();
  const { content, style } = section;

  if (!style.isVisible) return null;

  return (
    <section 
      id={section.id} 
      onClick={() => isAdminOpen && setActiveSectionId(section.id)}
      className={`py-20 relative group cursor-pointer border-2 transition-all ${activeSectionId === section.id ? 'border-yellow-500' : 'border-transparent'}`}
      style={{ backgroundColor: style.bgColor }}
    >
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
           <h2 className="text-3xl md:text-4xl font-black mb-4 uppercase tracking-tighter" style={{ color: style.titleColor }}>
             <FormattedText text={content.title} highlightColor={style.highlightColor} customHighlights={content.customHighlights} />
           </h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {(content.items || []).map((item: any, idx: number) => (
            <div key={idx} className="aspect-[9/16] rounded-3xl overflow-hidden relative shadow-xl border border-white/5 group/reel">
              <img src={item.image} className="w-full h-full object-cover transition-transform duration-700 group-hover/reel:scale-110" alt={item.title} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-6">
                 <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center mb-3">
                   <Play size={16} fill="white" className="text-white ml-1" />
                 </div>
                 <span className="text-white font-black uppercase text-[10px] tracking-widest">{item.title}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ReelsSection;
