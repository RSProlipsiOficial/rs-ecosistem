
import React from 'react';
import { SiteProvider, useSiteData } from './context/SiteContext';
import Header from './components/Header';
import Hero from './components/Hero';
import PainPoints from './components/PainPoints';
import Benefits from './components/Benefits';
import Ingredients from './components/Ingredients';
import Pricing from './components/Pricing';
import Guarantee from './components/Guarantee';
import Testimonials from './components/Testimonials';
import Footer from './components/Footer';
import FloatingCTA from './components/FloatingCTA';
import AdminPanel from './components/AdminPanel';
import SpecialBanner from './components/SpecialBanner';
import MediaSection from './components/MediaSection';
import VideoSection from './components/VideoSection';
import ReelsSection from './components/ReelsSection';
import FeaturesCircle from './components/FeaturesCircle';
import GridCollage from './components/GridCollage';
import FaqSection from './components/FaqSection';
import StepProcess from './components/StepProcess';
import ComparisonSection from './components/ComparisonSection';
import TrustBadges from './components/TrustBadges';
import NutritionalTable from './components/NutritionalTable';

const SectionRenderer: React.FC<{ section: any }> = ({ section }) => {
  if (!section || !section.style?.isVisible) return null;

  switch (section.type) {
    case 'hero': return <Hero data={section} />;
    case 'painPoints': return <PainPoints data={section} />;
    case 'benefits': return <Benefits data={section} />;
    case 'ingredients': return <Ingredients data={section} />;
    case 'pricing': return <Pricing data={section} />;
    case 'guarantee': return <Guarantee data={section} />;
    case 'specialBanner': return <SpecialBanner data={section} />;
    case 'media': return <MediaSection data={section} />;
    case 'video': return <VideoSection data={section} />;
    case 'reels': return <ReelsSection data={section} />;
    case 'featuresCircle': return <FeaturesCircle data={section} />;
    case 'gridCollage': return <GridCollage data={section} />;
    case 'faq': return <FaqSection data={section} />;
    case 'stepProcess': return <StepProcess data={section} />;
    case 'comparison': return <ComparisonSection data={section} />;
    case 'trustBadges': return <TrustBadges data={section} />;
    case 'nutritionalTable': return <NutritionalTable data={section} />;
    case 'testimonials': return <Testimonials data={section} />;
    default: return null;
  }
};

const AppContent: React.FC = () => {
  const { isAdminOpen, data, previewMode } = useSiteData();
  const sections = Array.isArray(data?.sections) ? data.sections : [];

  const isMobilePreview = previewMode === 'mobile';

  return (
    <div className={`min-h-screen bg-[#050505] transition-all duration-500 ${isAdminOpen ? 'md:pl-[320px]' : ''}`}>
      <div 
        className={`transition-all duration-500 mx-auto relative ${
          isMobilePreview 
            ? 'max-w-[375px] my-10 border-[12px] border-zinc-800 rounded-[3.5rem] shadow-[0_0_100px_rgba(0,0,0,0.9)] h-[812px] overflow-y-auto overflow-x-hidden no-scrollbar bg-black' 
            : 'w-full'
        }`}
      >
        {/* Marcador de Câmera/Notch para o modo Mobile - Posicionado atrás do Header */}
        {isMobilePreview && (
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-zinc-800 rounded-b-2xl z-[300]"></div>
        )}

        <Header />
        
        <main className={`${isMobilePreview ? 'w-full' : 'w-full'}`}>
          {sections.map((section) => (
            <div key={section.id} className={isMobilePreview ? 'mobile-mode' : ''}>
               <SectionRenderer section={section} />
            </div>
          ))}
        </main>
        
        <Footer />
        <FloatingCTA />
      </div>
      <AdminPanel />
      
      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        
        /* Ajustes Mobile Globais */
        @media (max-width: 768px) {
           .grid { grid-template-columns: repeat(1, minmax(0, 1fr)) !important; }
        }

        /* Força o layout de 1 coluna quando em modo mobile preview */
        ${isMobilePreview ? `
          .grid { grid-template-columns: repeat(1, minmax(0, 1fr)) !important; }
          .container { max-width: 100% !important; padding-left: 1rem !important; padding-right: 1rem !important; }
          section { padding-top: 2rem !important; padding-bottom: 2rem !important; border-radius: 0 !important; }
          h1 { font-size: 1.75rem !important; line-height: 1.1 !important; }
          h2 { font-size: 1.5rem !important; line-height: 1.2 !important; }
          .md\\:flex-row { flex-direction: column !important; }
          .lg\\:flex-row { flex-direction: column !important; }
        ` : ''}
      `}</style>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <SiteProvider>
      <AppContent />
    </SiteProvider>
  );
};

export default App;
