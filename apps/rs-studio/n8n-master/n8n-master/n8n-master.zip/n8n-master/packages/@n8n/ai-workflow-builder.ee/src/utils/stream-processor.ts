import { AIMessage, HumanMessage, ToolMessage } from '@langchain/core/messages';
import type { ToolCall } from '@langchain/core/messages/tool';
import type { DynamicStructuredTool } from '@langchain/core/tools';

import type {
	AgentMessageChunk,
	ToolProgressChunk,
	WorkflowUpdateChunk,
	StreamOutput,
} from '../types/streaming';

export interface BuilderToolBase {
	toolName: string;
	displayTitle: string;
	getCustomDisplayTitle?: (values: Record<string, unknown>) => string;
}

export interface BuilderTool extends BuilderToolBase {
	tool: DynamicStructuredTool;
}

/**
 * Represents a text part in multi-part message content
 */
interface TextPart {
	type: string;
	text: string;
}

/**
 * Message content can be either a simple string or an array of text parts
 */
type MessageContentValue = string | TextPart[];

/**
 * Container for messages in different update types
 */
interface MessagesContainer {
	messages?: Array<{ content: MessageContentValue }>;
}

/**
 * Workflow operations data
 */
interface ProcessOperations {
	workflowJSON?: unknown;
	workflowOperations?: unknown;
}

/**
 * Agent update chunk containing different types of updates
 */
interface AgentUpdateChunk {
	agent?: MessagesContainer;
	compact_messages?: MessagesContainer;
	delete_messages?: MessagesContainer;
	process_operations?: ProcessOperations;
}

/**
 * Type guard to check if chunk is an AgentUpdateChunk
 */
function isAgentUpdateChunk(chunk: unknown): chunk is AgentUpdateChunk {
	return (
		typeof chunk === 'object' &&
		chunk !== null &&
		('agent' in chunk ||
			'compact_messages' in chunk ||
			'delete_messages' in chunk ||
			'process_operations' in chunk)
	);
}

/**
 * Type guard to check if chunk is a ToolProgressChunk
 */
function isToolProgressChunk(chunk: unknown): chunk is ToolProgressChunk {
	return typeof chunk === 'object' && chunk !== null && 'type' in chunk && chunk.type === 'tool';
}

/**
 * Tools which should trigger canvas updates
 */
export const DEFAULT_WORKFLOW_UPDATE_TOOLS = [
	'add_nodes',
	'connect_nodes',
	'update_node_parameters',
	'remove_node',
];

/**
 * Safely get the last message from an optional array
 */
function getLastMessage<T>(messages: T[] | undefined): T | null {
	if (!messages || messages.length === 0) {
		return null;
	}
	return messages[messages.length - 1];
}

/**
 * Extract text content from message content (handles both string and array formats)
 */
function extractTextFromContent(content: MessageContentValue): string {
	if (Array.isArray(content)) {
		return content
			.filter((part): part is TextPart => part.type === 'text')
			.map((part) => part.text)
			.join('\n');
	}
	return content;
}

/**
 * Create a standard agent message chunk
 */
function createMessageChunk(text: string): AgentMessageChunk {
	return {
		role: 'assistant',
		type: 'message',
		text,
	};
}

/**
 * Process delete_messages updates
 */
function processDeleteMessages(chunk: AgentUpdateChunk): StreamOutput | null {
	const messages = chunk.delete_messages?.messages;
	if (!messages || messages.length === 0) {
		return null;
	}

	return { messages: [createMessageChunk('Deleted, refresh?')] };
}

/**
 * Process compact_messages updates
 */
function processCompactMessages(chunk: AgentUpdateChunk): StreamOutput | null {
	const lastMessage = getLastMessage(chunk.compact_messages?.messages);
	if (!lastMessage) {
		return null;
	}

	const text = extractTextFromContent(lastMessage.content);
	return { messages: [createMessageChunk(text)] };
}

/**
 * Process agent messages updates
 */
function processAgentMessages(chunk: AgentUpdateChunk): StreamOutput | null {
	const lastMessage = getLastMessage(chunk.agent?.messages);
	if (!lastMessage?.content) {
		return null;
	}

	const text = extractTextFromContent(lastMessage.content);
	if (!text) {
		return null;
	}

	return { messages: [createMessageChunk(text)] };
}

/**
 * Process process_operations updates
 */
function processOperations(chunk: AgentUpdateChunk): StreamOutput | null {
	const update = chunk.process_operations;
	if (!update?.workflowJSON || update.workflowOperations === undefined) {
		return null;
	}

	const workflowUpdateChunk: WorkflowUpdateChunk = {
		role: 'assistant',
		type: 'workflow-updated',
		codeSnippet: JSON.stringify(update.workflowJSON, null, 2),
	};

	return { messages: [workflowUpdateChunk] };
}

/**
 * Process custom tool updates
 */
function processCustomToolChunk(chunk: unknown): StreamOutput | null {
	if (!isToolProgressChunk(chunk)) {
		return null;
	}

	return { messages: [chunk] };
}

/**
 * Process a single chunk from the LangGraph stream
 */
export function processStreamChunk(streamMode: string, chunk: unknown): StreamOutput | null {
	if (streamMode === 'updates') {
		if (!isAgentUpdateChunk(chunk)) {
			return null;
		}

		// Process different update types in priority order
		return (
			processDeleteMessages(chunk) ??
			processCompactMessages(chunk) ??
			processAgentMessages(chunk) ??
			processOperations(chunk)
		);
	}

	if (streamMode === 'custom') {
		return processCustomToolChunk(chunk);
	}

	return null;
}

/**
 * Create a stream processor that yields formatted chunks
 */
export async function* createStreamProcessor(
	stream: AsyncGenerator<[string, unknown], void, unknown>,
): AsyncGenerator<StreamOutput> {
	for await (const [streamMode, chunk] of stream) {
		const output = processStreamChunk(streamMode, chunk);

		if (output) {
			yield output;
		}
	}
}

/**
 * Remove context tags from message content that are used for AI context
 * but shouldn't be displayed to users
 */
export function cleanContextTags(text: string): string {
	return text.replace(/\n*<current_workflow_json>[\s\S]*?<\/current_execution_nodes_schemas>/, '');
}

/**
 * Format a HumanMessage into the expected output format
 */
function formatHumanMessage(msg: HumanMessage): Record<string, unknown> {
	// Handle array content (multi-part messages with text, images, etc.)
	if (Array.isArray(msg.content)) {
		const textParts = msg.content.filter(
			(c): c is { type: string; text: string } =>
				typeof c === 'object' && c !== null && 'type' in c && c.type === 'text' && 'text' in c,
		);
		const text = textParts.map((part) => cleanContextTags(part.text)).join('\n');
		return {
			role: 'user',
			type: 'message',
			text,
		};
	}

	// Handle simple string content
	return {
		role: 'user',
		type: 'message',
		text: cleanContextTags(msg.content),
	};
}

/**
 * Process array content from AIMessage and return formatted text messages
 */
function processArrayContent(content: unknown[]): Array<Record<string, unknown>> {
	const textMessages = content.filter(
		(c): c is { type: string; text: string } =>
			typeof c === 'object' && c !== null && 'type' in c && c.type === 'text' && 'text' in c,
	);

	return textMessages.map((textMessage) => ({
		role: 'assistant',
		type: 'message',
		text: textMessage.text,
	}));
}

/**
 * Process AIMessage content and return formatted messages
 */
function processAIMessageContent(msg: AIMessage): Array<Record<string, unknown>> {
	if (!msg.content) {
		return [];
	}

	if (Array.isArray(msg.content)) {
		return processArrayContent(msg.content);
	}

	return [
		{
			role: 'assistant',
			type: 'message',
			text: msg.content,
		},
	];
}

/**
 * Create a formatted tool call message
 */
function createToolCallMessage(
	toolCall: ToolCall,
	builderTool?: BuilderToolBase,
): Record<string, unknown> {
	return {
		id: toolCall.id,
		toolCallId: toolCall.id,
		role: 'assistant',
		type: 'tool',
		toolName: toolCall.name,
		displayTitle: builderTool?.displayTitle,
		customDisplayTitle: toolCall.args && builderTool?.getCustomDisplayTitle?.(toolCall.args),
		status: 'completed',
		updates: [
			{
				type: 'input',
				data: toolCall.args || {},
			},
		],
	};
}

/**
 * Process tool calls from AIMessage and return formatted tool messages
 */
function processToolCalls(
	toolCalls: ToolCall[],
	builderTools?: BuilderToolBase[],
): Array<Record<string, unknown>> {
	return toolCalls.map((toolCall) => {
		const builderTool = builderTools?.find((bt) => bt.toolName === toolCall.name);
		return createToolCallMessage(toolCall, builderTool);
	});
}

/**
 * Process a ToolMessage and add its output to the corresponding tool call
 */
function processToolMessage(
	msg: ToolMessage,
	formattedMessages: Array<Record<string, unknown>>,
): void {
	const toolCallId = msg.tool_call_id;

	// Find the tool message by ID (search backwards for efficiency)
	for (let i = formattedMessages.length - 1; i >= 0; i--) {
		const m = formattedMessages[i];
		if (m.type === 'tool' && m.id === toolCallId) {
			// Add output to updates array
			m.updates ??= [];
			(m.updates as Array<Record<string, unknown>>).push({
				type: 'output',
				data: typeof msg.content === 'string' ? { result: msg.content } : msg.content,
			});
			break;
		}
	}
}

export function formatMessages(
	messages: Array<AIMessage | HumanMessage | ToolMessage>,
	builderTools?: BuilderToolBase[],
): Array<Record<string, unknown>> {
	const formattedMessages: Array<Record<string, unknown>> = [];

	for (const msg of messages) {
		if (msg instanceof HumanMessage) {
			formattedMessages.push(formatHumanMessage(msg));
		} else if (msg instanceof AIMessage) {
			// Add AI message content
			formattedMessages.push(...processAIMessageContent(msg));

			// Add tool calls if present
			if (msg.tool_calls?.length) {
				formattedMessages.push(...processToolCalls(msg.tool_calls, builderTools));
			}
		} else if (msg instanceof ToolMessage) {
			processToolMessage(msg, formattedMessages);
		}
	}

	return formattedMessages;
}
