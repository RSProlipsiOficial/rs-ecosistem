export interface Message {
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  attachments?: Attachment[];
}

export interface Attachment {
  name: string;
  type: string;
  data: string; // Base64 string or raw text content
  isText: boolean;
}

export interface ChatState {
  messages: Message[];
  isLoading: boolean;
  error: string | null;
}

export enum CodeViewMode {
  PREVIEW = 'PREVIEW',
  CODE = 'CODE'
}