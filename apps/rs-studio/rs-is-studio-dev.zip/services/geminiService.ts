import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Attachment } from "../types";

const apiKey = process.env.API_KEY;

// Initialize the client
const ai = new GoogleGenAI({ apiKey: apiKey || '' });

const SYSTEM_INSTRUCTION = `
Você é o RS-IS Studio Dev, um arquiteto de IA sofisticado e de alto nível, especializado em React, TypeScript e Tailwind CSS.

Seu objetivo é fornecer assistência de "vibe coding".
1. Se o usuário pedir um componente de UI ou página, gere código HTML de alta qualidade, moderno, minimalista e pronto para produção usando Tailwind CSS.
2. SEMPRE forneça o código como um ÚNICO arquivo HTML AUTO-CONTIDO dentro de um bloco de código \`\`\`html\`\`\`.
3. Inclua <script src="https://cdn.tailwindcss.com"></script> no head do HTML gerado.
4. Garanta que o fundo da pré-visualização gerada seja distinto, mas se adeque a um tema escuro ou neutro, a menos que especificado de outra forma.
5. Seja conciso em seu texto de conversação, mantendo uma persona profissional, luxuosa e de "estúdio".
6. Ao fornecer código, certifique-se de que esteja completo e funcional.
7. Se o usuário fornecer arquivos (imagens, código, zip), analise-os cuidadosamente para entender o contexto, estilo ou requisitos.
`;

export const streamGeminiResponse = async (
  prompt: string,
  history: { role: string; parts: { text: string }[] }[],
  attachments: Attachment[] = [],
  signal?: AbortSignal
): Promise<AsyncIterable<GenerateContentResponse>> => {
  if (!apiKey) {
    throw new Error("API Key not found in environment.");
  }

  // Updated to Gemini 3.0 Pro Preview
  const model = 'gemini-3-pro-preview';

  try {
    const chat = ai.chats.create({
      model: model,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
      history: history,
    });

    // Construct the parts array for the current message
    const parts: any[] = [];
    
    // Add text prompt
    if (prompt) {
      parts.push({ text: prompt });
    }

    // Process attachments
    for (const att of attachments) {
      if (att.isText) {
        // For text files (code, txt, etc), send as text part with filename context
        parts.push({ 
          text: `\n--- START OF FILE: ${att.name} ---\n${att.data}\n--- END OF FILE ---\n` 
        });
      } else {
        // For binaries (images, pdfs), send as inlineData
        // Ensure base64 string doesn't contain the data URL prefix
        const base64Data = att.data.includes('base64,') 
          ? att.data.split('base64,')[1] 
          : att.data;

        parts.push({
          inlineData: {
            mimeType: att.type,
            data: base64Data
          }
        });
      }
    }

    // Handle AbortSignal by wrapping the promise/stream generation if supported by SDK, 
    // or simply checking signal in the loop. The SDK might not support signal directly in sendMessageStream yet,
    // so we handle interruption in the consuming loop, but for good measure we pass it if possible or check it before calling.
    
    if (signal?.aborted) {
      throw new DOMException('Aborted', 'AbortError');
    }

    // Send message with multiple parts
    const result = await chat.sendMessageStream({ 
      message: { parts }
    });
    
    return result;
  } catch (error) {
    if (signal?.aborted) {
        throw new DOMException('Aborted', 'AbortError');
    }
    console.error("Gemini API Error:", error);
    throw error;
  }
};