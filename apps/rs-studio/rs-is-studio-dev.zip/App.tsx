import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { ChatMessage } from './components/ChatMessage';
import { Preview } from './components/Preview';
import { AttachmentPreview } from './components/AttachmentPreview';
import { streamGeminiResponse } from './services/geminiService';
import { Message, Attachment } from './types';
import { ArrowUp, Paperclip, Loader2, Sparkles, Code2, MessageSquare, Plus, GripVertical, Square, Mic } from 'lucide-react';
import JSZip from 'jszip';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [generatedCode, setGeneratedCode] = useState('');
  const [mobileView, setMobileView] = useState<'chat' | 'preview'>('chat');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isListening, setIsListening] = useState(false);
  
  const abortControllerRef = useRef<AbortController | null>(null);

  // Resizable Splitter State
  const [sidebarWidth, setSidebarWidth] = useState(45); // Percentage
  const [isResizingSidebar, setIsResizingSidebar] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sidebarRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, mobileView]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  // --- RESIZE LOGIC START ---
  const startResizing = useCallback(() => {
    setIsResizingSidebar(true);
  }, []);

  const stopResizing = useCallback(() => {
    setIsResizingSidebar(false);
  }, []);

  const resize = useCallback((mouseMoveEvent: MouseEvent) => {
    if (isResizingSidebar) {
      const newWidth = (mouseMoveEvent.clientX / window.innerWidth) * 100;
      // Constrain width between 20% and 80%
      if (newWidth >= 20 && newWidth <= 80) {
        setSidebarWidth(newWidth);
      }
    }
  }, [isResizingSidebar]);

  useEffect(() => {
    window.addEventListener('mousemove', resize);
    window.addEventListener('mouseup', stopResizing);
    return () => {
      window.removeEventListener('mousemove', resize);
      window.removeEventListener('mouseup', stopResizing);
    };
  }, [resize, stopResizing]);
  // --- RESIZE LOGIC END ---

  const extractHtml = (text: string) => {
    const match = text.match(/```html\s*([\s\S]*?)(?:```|$)/);
    if (match && match[1]) {
      return match[1];
    }
    return null;
  };

  const handleReset = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setMessages([]);
    setGeneratedCode('');
    setInput('');
    setAttachments([]);
    setIsLoading(false);
  };

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      setIsLoading(false);
      setMessages(prev => [...prev, {
        role: 'model',
        content: "[Geração interrompida pelo usuário]",
        timestamp: Date.now()
      }]);
    }
  };

  // --- VOICE INPUT START ---
  const toggleVoiceInput = useCallback(() => {
    if (isListening) {
      // Logic to stop listening if managed manually, though typical webkitSpeechRecognition stops automatically on end.
      // We rely on the end event to clear state.
      setIsListening(false);
      return;
    }

    if (!('webkitSpeechRecognition' in window)) {
      alert("Seu navegador não suporta entrada de voz.");
      return;
    }

    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.lang = 'pt-BR';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput(prev => (prev ? prev + ' ' + transcript : transcript));
    };

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error", event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  }, [isListening]);
  // --- VOICE INPUT END ---

  // --- FILE HANDLING START ---
  
  const isTextFile = (name: string, type: string) => {
    const textExtensions = ['js', 'jsx', 'ts', 'tsx', 'html', 'css', 'json', 'md', 'txt', 'svg', 'xml', 'py', 'java', 'c', 'cpp', 'h', 'cs', 'go', 'rs', 'php', 'rb', 'sql', 'gitignore', 'env'];
    const ext = name.split('.').pop()?.toLowerCase();
    return type.startsWith('text/') || (ext && textExtensions.includes(ext));
  };

  const processFile = async (file: File): Promise<Attachment[]> => {
    const results: Attachment[] = [];

    if (file.name.endsWith('.zip')) {
      try {
        const zip = new JSZip();
        const zipContent = await zip.loadAsync(file);
        
        const promises: Promise<void>[] = [];
        
        zipContent.forEach((relativePath, zipEntry) => {
          if (!zipEntry.dir) {
             const promise = (async () => {
                const ext = relativePath.split('.').pop()?.toLowerCase();
                const likelyText = isTextFile(relativePath, ''); 
                if (likelyText) {
                  const content = await zipEntry.async('string');
                  results.push({
                    name: `${file.name}/${relativePath}`,
                    type: 'text/plain',
                    data: content,
                    isText: true
                  });
                }
             })();
             promises.push(promise);
          }
        });
        await Promise.all(promises);
      } catch (err) {
        console.error("Error reading zip", err);
      }
    } else {
      const isText = isTextFile(file.name, file.type);
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          resolve([{
            name: file.name,
            type: file.type || 'application/octet-stream',
            data: result, 
            isText: isText
          }]);
        };
        if (isText) {
          reader.readAsText(file);
        } else {
          reader.readAsDataURL(file);
        }
      });
    }
    return results;
  };

  const handleFiles = async (files: FileList | null) => {
    if (!files) return;
    
    setIsLoading(true); 
    const newAttachments: Attachment[] = [];

    try {
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const processed = await processFile(file);
            newAttachments.push(...processed);
        }
        setAttachments(prev => [...prev, ...newAttachments]);
    } catch (error) {
        console.error("Error processing files", error);
    } finally {
        setIsLoading(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFiles(e.target.files);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  }, []);

  const handleRemoveAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  // --- FILE HANDLING END ---

  const handleSubmit = async () => {
    if ((!input.trim() && attachments.length === 0) || isLoading) return;

    const cmd = input.trim().toLowerCase();
    if (cmd === '/clear' || cmd === '/limpar' || cmd === '/reset') {
      handleReset();
      return;
    }

    const userMessage: Message = {
      role: 'user',
      content: input.trim(),
      timestamp: Date.now(),
      attachments: [...attachments] 
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setAttachments([]); 
    setIsLoading(true);

    // Create a new AbortController for this request
    abortControllerRef.current = new AbortController();

    if (textareaRef.current) textareaRef.current.style.height = 'auto';

    try {
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.content || (m.attachments?.length ? '[Arquivo Anexado]' : '...') }] 
      }));

      const stream = await streamGeminiResponse(
        userMessage.content, 
        history, 
        userMessage.attachments,
        abortControllerRef.current.signal
      );
      
      let fullResponse = '';
      const botMessageId = Date.now() + 1;
      
      setMessages(prev => [...prev, {
        role: 'model',
        content: '',
        timestamp: botMessageId
      }]);

      for await (const chunk of stream) {
        // Check for abortion signal between chunks as fallback
        if (abortControllerRef.current?.signal.aborted) {
           break; 
        }

        const text = chunk.text || '';
        fullResponse += text;
        
        const code = extractHtml(fullResponse);
        if (code && code.length > 10) {
           setGeneratedCode(code);
        }

        setMessages(prev => prev.map(msg => 
          msg.timestamp === botMessageId 
            ? { ...msg, content: fullResponse }
            : msg
        ));
      }
    } catch (error: any) {
      if (error.name === 'AbortError' || error.message === 'Aborted') {
         console.log('Request aborted by user');
      } else {
         console.error(error);
         setMessages(prev => [...prev, {
           role: 'model',
           content: "Encontrei uma interrupção no link neural. Por favor, tente novamente.",
           timestamp: Date.now()
         }]);
      }
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div 
      className={`h-screen flex flex-col bg-onyx-950 text-zinc-100 font-sans selection:bg-gold-500/30 overflow-hidden ${isResizingSidebar ? 'cursor-col-resize select-none' : ''}`}
      onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
      onDragLeave={(e) => { e.preventDefault(); setIsDragging(false); }}
      onDrop={handleDrop}
    >
      <Header onReset={handleReset} />

      {/* Drag Overlay */}
      {isDragging && (
        <div className="absolute inset-0 z-50 bg-gold-900/20 backdrop-blur-sm border-2 border-dashed border-gold-500 flex items-center justify-center pointer-events-none">
          <div className="bg-onyx-950 p-6 rounded-xl border border-gold-500/50 flex flex-col items-center animate-bounce">
            <Plus className="w-10 h-10 text-gold-400 mb-2" />
            <span className="text-gold-100 font-serif tracking-widest">SOLTE PARA ANEXAR</span>
          </div>
        </div>
      )}

      <main className="flex-1 flex overflow-hidden relative pt-16">
        
        {/* Left Panel - Chat */}
        <div 
          ref={sidebarRef}
          className={`flex flex-col border-r border-white/5 bg-onyx-950 relative z-10 transition-transform duration-300 lg:transition-none ${
          mobileView === 'chat' ? 'translate-x-0 w-full' : '-translate-x-full absolute inset-0'
        } lg:translate-x-0 lg:relative lg:block`}
          style={{ width: mobileView === 'chat' && window.innerWidth < 1024 ? '100%' : `${sidebarWidth}%` }}
        >
          <div className="flex-1 overflow-y-auto custom-scrollbar p-4 pb-40 scroll-smooth">
            {messages.length === 0 ? (
              <HeroSection />
            ) : (
              <div className="w-full max-w-3xl mx-auto">
                {messages.map((msg, idx) => (
                  <div key={idx} className="mb-4">
                     <ChatMessage message={msg} />
                     {msg.attachments && msg.attachments.length > 0 && (
                        <div className="px-6 pb-4 flex flex-wrap gap-2">
                           {msg.attachments.map((att, attIdx) => (
                             <div key={attIdx} className="text-[10px] bg-zinc-800/50 text-zinc-500 px-2 py-1 rounded border border-white/5 flex items-center gap-1">
                               <Paperclip className="w-3 h-3" />
                               {att.name}
                             </div>
                           ))}
                        </div>
                     )}
                  </div>
                ))}
                {isLoading && (
                  <div className="flex gap-4 p-6 w-full animate-pulse">
                    <div className="w-8 h-8 rounded-full bg-zinc-900 border border-gold-900/30 flex items-center justify-center">
                        <Sparkles className="w-4 h-4 text-gold-600" />
                    </div>
                    <div className="flex items-center">
                        <span className="text-xs text-gold-600 tracking-widest uppercase">Processando Arquivos...</span>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-onyx-950 via-onyx-950/95 to-transparent pt-12 pb-6 px-4 z-20">
            <div className="max-w-3xl mx-auto relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-gold-600/20 to-zinc-600/20 rounded-2xl opacity-75 blur transition duration-500 group-hover:opacity-100"></div>
                <div className="relative bg-zinc-900/90 backdrop-blur-xl rounded-2xl border border-white/10 flex flex-col shadow-2xl overflow-hidden">
                  
                  <AttachmentPreview attachments={attachments} onRemove={handleRemoveAttachment} />

                  <textarea
                    ref={textareaRef}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Descreva sua interface ou digite /limpar..."
                    className="w-full bg-transparent text-sm text-white placeholder-zinc-500 p-3 resize-none focus:outline-none min-h-[50px] max-h-[150px]"
                    rows={1}
                  />
                  
                  <div className="flex justify-between items-center px-2 pb-2 pt-1 bg-zinc-900/50">
                    <div className="flex gap-2">
                      <input 
                        type="file" 
                        multiple 
                        ref={fileInputRef} 
                        className="hidden" 
                        onChange={handleFileSelect} 
                      />
                      <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="p-2 text-zinc-500 hover:text-white transition-colors rounded-lg hover:bg-white/5 relative group/btn" 
                        title="Anexar arquivos"
                      >
                        <Paperclip className="w-4 h-4" />
                      </button>
                      <button 
                         onClick={toggleVoiceInput}
                         className={`p-2 transition-colors rounded-lg hover:bg-white/5 ${isListening ? 'text-red-500 animate-pulse' : 'text-zinc-500 hover:text-white'}`}
                         title="Usar microfone"
                      >
                         <Mic className="w-4 h-4" />
                      </button>
                    </div>
                    
                    <button 
                      onClick={isLoading ? handleStop : handleSubmit}
                      disabled={(!input.trim() && attachments.length === 0 && !isLoading)}
                      className={`p-2 rounded-xl transition-all duration-300 ${
                        isLoading 
                          ? 'bg-red-500/20 text-red-500 hover:bg-red-500/30 border border-red-500/50'
                          : (input.trim() || attachments.length > 0)
                            ? 'bg-gold-500 text-onyx-950 hover:bg-gold-400 shadow-[0_0_15px_rgba(212,175,55,0.3)]' 
                            : 'bg-zinc-800 text-zinc-600 cursor-not-allowed'
                      }`}
                      title={isLoading ? "Parar geração" : "Enviar mensagem"}
                    >
                      {isLoading ? <Square className="w-4 h-4 fill-current" /> : <ArrowUp className="w-5 h-5" />}
                    </button>
                  </div>
                </div>
            </div>
            <div className="text-center mt-2 hidden lg:block">
               <p className="text-[10px] text-zinc-600 tracking-wider">RS-IS STUDIO DEV &bull; GEMINI 3.0 PRO</p>
            </div>
          </div>
        </div>

        {/* Resizer Handle */}
        <div 
            className="hidden lg:flex w-1 bg-zinc-900 hover:bg-gold-500/50 cursor-col-resize items-center justify-center transition-colors z-20"
            onMouseDown={startResizing}
        >
            <div className="h-8 w-1 bg-zinc-700 rounded-full"></div>
        </div>

        {/* Right Panel - Preview */}
        <div 
            className={`bg-zinc-950 absolute lg:relative inset-0 transition-transform duration-300 lg:transition-none ${
                mobileView === 'preview' ? 'translate-x-0 w-full' : 'translate-x-full lg:translate-x-0'
            } lg:block`}
            style={{ width: mobileView === 'preview' && window.innerWidth < 1024 ? '100%' : `calc(100% - ${sidebarWidth}%)` }}
        >
          <Preview code={generatedCode} isLoading={isLoading} />
        </div>
        
        {/* Mobile Toggle Controls */}
        <div className="lg:hidden fixed bottom-6 left-1/2 -translate-x-1/2 bg-zinc-900/90 backdrop-blur-md border border-white/10 rounded-full p-1 flex items-center gap-1 z-50 shadow-xl">
          <button 
            onClick={() => setMobileView('chat')}
            className={`px-4 py-2 rounded-full text-xs font-medium flex items-center gap-2 transition-all ${
              mobileView === 'chat' ? 'bg-gold-500 text-black' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <MessageSquare className="w-3 h-3" />
            Chat
          </button>
          <button 
            onClick={() => setMobileView('preview')}
            className={`px-4 py-2 rounded-full text-xs font-medium flex items-center gap-2 transition-all ${
              mobileView === 'preview' ? 'bg-gold-500 text-black' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Code2 className="w-3 h-3" />
            Visualizar
          </button>
        </div>

      </main>
    </div>
  );
};

export default App;