import React from 'react';
import { Sparkles, Terminal, Code2 } from 'lucide-react';

export const HeroSection: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4 animate-slide-up">
      <div className="mb-6 flex items-center gap-2 px-3 py-1 border border-gold-900/50 bg-gold-900/10 rounded-full">
        <span className="w-1.5 h-1.5 rounded-full bg-gold-400 animate-pulse"></span>
        <span className="text-[10px] uppercase tracking-[0.2em] text-gold-400 font-medium">Sistema Online v2.0</span>
      </div>
      
      <h1 className="font-serif text-5xl md:text-7xl text-white mb-6 leading-tight">
        Arquitete Sua <span className="text-transparent bg-clip-text bg-gradient-to-r from-gold-300 to-gold-600">Visão</span>
      </h1>
      
      <p className="text-zinc-400 max-w-2xl text-lg font-light mb-12">
        Um ambiente minimalista para vibe coding. Gere interfaces sofisticadas e lógica complexa através de linguagem natural.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl w-full">
        <div className="p-6 border border-white/5 bg-white/5 hover:border-gold-600/30 hover:bg-gold-900/5 transition-all duration-300 cursor-default group">
          <Terminal className="w-6 h-6 text-zinc-500 group-hover:text-gold-400 mb-4 transition-colors" />
          <h3 className="text-white font-medium mb-2">Sintaxe Limpa</h3>
          <p className="text-xs text-zinc-500">Código React pronto para produção gerado instantaneamente.</p>
        </div>
        <div className="p-6 border border-white/5 bg-white/5 hover:border-gold-600/30 hover:bg-gold-900/5 transition-all duration-300 cursor-default group">
          <Sparkles className="w-6 h-6 text-zinc-500 group-hover:text-gold-400 mb-4 transition-colors" />
          <h3 className="text-white font-medium mb-2">Vibe Oriented</h3>
          <p className="text-xs text-zinc-500">Descreva a sensação, nós cuidamos da engenharia.</p>
        </div>
        <div className="p-6 border border-white/5 bg-white/5 hover:border-gold-600/30 hover:bg-gold-900/5 transition-all duration-300 cursor-default group">
          <Code2 className="w-6 h-6 text-zinc-500 group-hover:text-gold-400 mb-4 transition-colors" />
          <h3 className="text-white font-medium mb-2">Stack Moderno</h3>
          <p className="text-xs text-zinc-500">Padrões Tailwind, TypeScript e React 19.</p>
        </div>
      </div>
    </div>
  );
};