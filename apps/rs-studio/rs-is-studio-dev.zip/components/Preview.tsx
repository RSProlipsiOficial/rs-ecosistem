import React, { useState } from 'react';
import { Loader2, Monitor, RefreshCw, Copy, Check, Download, Database, Code, Eye, X, Smartphone, Laptop } from 'lucide-react';

interface PreviewProps {
  code: string;
  isLoading?: boolean;
}

export const Preview: React.FC<PreviewProps> = ({ code, isLoading }) => {
  const [key, setKey] = useState(0);
  const [isCopied, setIsCopied] = useState(false);
  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');
  const [deviceMode, setDeviceMode] = useState<'desktop' | 'mobile'>('desktop');
  const [showSupabaseModal, setShowSupabaseModal] = useState(false);

  const handleRefresh = () => {
    setKey(prev => prev + 1);
  };

  const handleCopy = async () => {
    if (!code) return;
    try {
      await navigator.clipboard.writeText(code);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    } catch (err) {
      // Fallback for non-secure contexts or failures
      const textArea = document.createElement("textarea");
      textArea.value = code;
      textArea.style.position = "fixed";
      textArea.style.left = "-9999px";
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      try {
        document.execCommand('copy');
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
      } catch (e) {
        console.error('Fallback copy failed', e);
      }
      document.body.removeChild(textArea);
    }
  };

  const handleDownload = () => {
    if (!code) return;
    const blob = new Blob([code], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'project.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSupabaseClick = () => {
    setShowSupabaseModal(true);
  };

  const confirmSupabaseConnection = () => {
    window.open('https://supabase.com/dashboard', '_blank');
    setShowSupabaseModal(false);
  };

  if (!code) {
    return (
      <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-950 border-l border-white/5 text-zinc-500">
        <div className="w-16 h-16 mb-6 rounded-2xl bg-zinc-900 border border-white/5 flex items-center justify-center animate-pulse">
          <Monitor className="w-8 h-8 opacity-50" />
        </div>
        <h3 className="text-xl font-serif text-zinc-400 mb-2">Sistema Ocioso</h3>
        <p className="text-sm font-light max-w-xs text-center">
          Aguardando entrada neural para gerar pré-visualização da interface.
        </p>
      </div>
    );
  }

  return (
    <div className="w-full h-full flex flex-col bg-zinc-950 border-l border-white/5 relative">
      <div className="h-14 border-b border-white/5 flex items-center justify-between px-4 bg-zinc-900/50 backdrop-blur-sm z-20 relative">
        
        {/* View Mode Toggle */}
        <div className="flex bg-black/40 rounded-lg p-1 border border-white/5">
            <button
                onClick={() => setViewMode('preview')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-300 ${viewMode === 'preview' ? 'bg-zinc-800 text-gold-400 shadow-lg shadow-black/50 ring-1 ring-white/5' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
                <Eye className="w-3.5 h-3.5" />
                Preview
            </button>
            <button
                onClick={() => setViewMode('code')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-300 ${viewMode === 'code' ? 'bg-zinc-800 text-gold-400 shadow-lg shadow-black/50 ring-1 ring-white/5' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
                <Code className="w-3.5 h-3.5" />
                Code
            </button>
        </div>

        {/* Device Toggle (Only visible in Preview Mode) */}
        {viewMode === 'preview' && (
          <div className="flex bg-black/40 rounded-lg p-1 border border-white/5">
            <button
                onClick={() => setDeviceMode('desktop')}
                className={`p-1.5 rounded-md transition-all duration-300 ${deviceMode === 'desktop' ? 'bg-zinc-800 text-gold-400' : 'text-zinc-500 hover:text-zinc-300'}`}
                title="Desktop View"
            >
                <Laptop className="w-3.5 h-3.5" />
            </button>
            <button
                onClick={() => setDeviceMode('mobile')}
                className={`p-1.5 rounded-md transition-all duration-300 ${deviceMode === 'mobile' ? 'bg-zinc-800 text-gold-400' : 'text-zinc-500 hover:text-zinc-300'}`}
                title="Mobile View"
            >
                <Smartphone className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        <div className="flex items-center gap-2">
           {isLoading && <Loader2 className="w-3 h-3 animate-spin text-gold-500 mr-2" />}
        </div>
        
        <div className="flex items-center gap-3">
          <div className="hidden xl:flex items-center bg-white/5 rounded-lg p-0.5 border border-white/5">
            <button 
                onClick={handleSupabaseClick}
                className="flex items-center gap-2 px-3 py-1.5 hover:bg-emerald-900/20 hover:text-emerald-400 text-zinc-500 transition-all rounded-md text-[10px] font-medium tracking-wide uppercase group"
                title="Conectar Backend Supabase"
            >
                <Database className="w-3.5 h-3.5 group-hover:text-emerald-400 transition-colors" />
                <span>Supabase</span>
            </button>
          </div>

          <div className="h-6 w-px bg-white/10 mx-1"></div>

          <button 
            onClick={handleDownload} 
            className="p-2 hover:bg-white/5 rounded-lg text-zinc-500 hover:text-gold-400 transition-colors"
            title="Baixar HTML"
          >
            <Download className="w-4 h-4" />
          </button>
          <button 
            onClick={handleCopy} 
            className="p-2 hover:bg-white/5 rounded-lg text-zinc-500 hover:text-white transition-colors relative"
            title="Copiar Código"
          >
            {isCopied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
          </button>
          <button 
            onClick={handleRefresh} 
            className="p-2 hover:bg-white/5 rounded-lg text-zinc-500 hover:text-white transition-colors"
            title="Recarregar Preview"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      <div className="flex-1 relative overflow-hidden bg-[#0a0a0a] flex justify-center items-center">
        {viewMode === 'preview' ? (
             <div 
                className={`transition-all duration-300 ease-in-out bg-white shadow-2xl overflow-hidden ${
                  deviceMode === 'mobile' 
                    ? 'w-[375px] h-[667px] rounded-3xl border-[8px] border-zinc-800 shadow-[0_0_50px_rgba(0,0,0,0.5)]' 
                    : 'w-full h-full'
                }`}
             >
               <iframe
                 key={key}
                 srcDoc={code}
                 title="Preview"
                 className="w-full h-full border-0"
                 sandbox="allow-scripts"
               />
             </div>
        ) : (
            <div className="w-full h-full overflow-auto custom-scrollbar p-6 bg-onyx-950">
                <pre className="font-mono text-xs md:text-sm text-zinc-400 leading-relaxed whitespace-pre-wrap break-words break-all selection:bg-gold-500/20 selection:text-gold-200">
                    <code className="language-html">{code}</code>
                </pre>
            </div>
        )}
      </div>

      {/* Supabase Confirmation Modal */}
      {showSupabaseModal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-onyx-900 border border-white/10 rounded-xl p-6 max-w-sm w-full shadow-2xl relative overflow-hidden">
            {/* Decorative gradient */}
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-600 to-emerald-400"></div>
            
            <button 
              onClick={() => setShowSupabaseModal(false)}
              className="absolute top-4 right-4 text-zinc-500 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3 mb-4 text-emerald-400">
              <div className="p-2 bg-emerald-900/30 rounded-lg border border-emerald-500/20">
                <Database className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg text-white tracking-wide">Integração Supabase</h3>
            </div>
            
            <p className="text-zinc-400 text-sm leading-relaxed mb-8 font-light">
              Ao confirmar, você será redirecionado para o <strong>Supabase Dashboard</strong>. Lá, crie um novo projeto para hospedar o backend da sua aplicação.
            </p>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowSupabaseModal(false)}
                className="px-4 py-2 text-xs font-medium text-zinc-500 hover:text-white transition-colors uppercase tracking-wider"
              >
                Cancelar
              </button>
              <button
                onClick={confirmSupabaseConnection}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-md transition-all shadow-lg shadow-emerald-900/20 uppercase tracking-wider flex items-center gap-2"
              >
                Abrir Dashboard
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-200 animate-pulse"></div>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};