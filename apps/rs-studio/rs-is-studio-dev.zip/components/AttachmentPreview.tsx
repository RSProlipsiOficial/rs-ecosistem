import React from 'react';
import { Attachment } from '../types';
import { X, FileCode, FileImage, FileText, FileType, FileArchive } from 'lucide-react';

interface AttachmentPreviewProps {
  attachments: Attachment[];
  onRemove: (index: number) => void;
}

export const AttachmentPreview: React.FC<AttachmentPreviewProps> = ({ attachments, onRemove }) => {
  if (attachments.length === 0) return null;

  const getIcon = (type: string, name: string) => {
    if (type.startsWith('image/')) return <FileImage className="w-4 h-4 text-purple-400" />;
    if (type.includes('pdf')) return <FileText className="w-4 h-4 text-red-400" />;
    if (type.includes('zip') || name.endsWith('.zip')) return <FileArchive className="w-4 h-4 text-yellow-400" />;
    if (type.includes('javascript') || type.includes('typescript') || type.includes('html') || type.includes('css')) {
      return <FileCode className="w-4 h-4 text-blue-400" />;
    }
    return <FileType className="w-4 h-4 text-zinc-400" />;
  };

  return (
    <div className="flex flex-wrap gap-2 px-4 py-2 bg-zinc-900/50 border-t border-white/5">
      {attachments.map((file, idx) => (
        <div 
          key={idx} 
          className="group flex items-center gap-2 bg-zinc-800/80 border border-white/10 rounded-lg pl-3 pr-2 py-1.5 text-xs text-zinc-300 hover:border-gold-500/30 transition-colors animate-fade-in"
        >
          {getIcon(file.type, file.name)}
          <span className="max-w-[150px] truncate">{file.name}</span>
          <span className="text-[10px] text-zinc-600 uppercase ml-1">
            {file.isText ? 'TXT' : file.type.split('/')[1]?.toUpperCase() || 'BIN'}
          </span>
          <button 
            onClick={() => onRemove(idx)}
            className="ml-1 p-1 hover:bg-white/10 rounded-full text-zinc-500 hover:text-red-400 transition-colors"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      ))}
    </div>
  );
};