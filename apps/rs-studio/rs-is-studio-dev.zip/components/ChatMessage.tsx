import React, { useMemo } from 'react';
import { Message } from '../types';
import { Bot, User, Code2, ArrowRight } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface ChatMessageProps {
  message: Message;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isBot = message.role === 'model';

  const displayContent = useMemo(() => {
    if (!isBot) return message.content;
    
    // Regex to identify the main HTML code block
    const htmlBlockRegex = /```html[\s\S]*?```/g;
    
    // Check if the message contains the code block
    const hasCode = htmlBlockRegex.test(message.content);
    
    // Replace the code block with an empty string for the text display
    const cleanText = message.content.replace(htmlBlockRegex, '').trim();
    
    return { text: cleanText, hasCode };
  }, [message.content, message.role, isBot]);

  return (
    <div className={`flex gap-4 w-full ${isBot ? 'bg-zinc-900/30' : ''} p-6 border-b border-white/5 animate-fade-in`}>
      <div className="flex-shrink-0 mt-1">
        {isBot ? (
          <div className="w-8 h-8 flex items-center justify-center border border-gold-500/30 rounded-full">
            <Bot className="w-4 h-4 text-gold-400" />
          </div>
        ) : (
          <div className="w-8 h-8 flex items-center justify-center bg-zinc-800 rounded-full">
            <User className="w-4 h-4 text-zinc-400" />
          </div>
        )}
      </div>
      
      <div className="flex-1 min-w-0 overflow-hidden">
        <div className="flex items-center gap-2 mb-2">
          <span className={`text-xs font-bold tracking-wider uppercase ${isBot ? 'text-gold-400' : 'text-zinc-400'}`}>
            {isBot ? 'Sistema' : 'Usuário'}
          </span>
          <span className="text-[10px] text-zinc-600">
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
        
        <div className="prose prose-invert prose-p:font-light prose-headings:font-serif prose-headings:text-gold-100 prose-pre:bg-black prose-pre:border prose-pre:border-white/10 max-w-none text-zinc-300 text-sm leading-relaxed">
           <ReactMarkdown
            components={{
              pre({ node, className, children, ...props }) {
                return (
                  <pre 
                    className={`${className} whitespace-pre-wrap break-words overflow-x-hidden`} 
                    style={{ wordWrap: 'break-word', whiteSpace: 'pre-wrap' }} 
                    {...props}
                  >
                    {children}
                  </pre>
                );
              },
              code({node, className, children, ...props}) {
                const match = /language-(\w+)/.exec(className || '')
                return match ? (
                  <code className={`${className} text-gold-100 font-mono text-xs whitespace-pre-wrap break-words`} {...props}>
                    {children}
                  </code>
                ) : (
                  <code className="bg-zinc-800 px-1 py-0.5 rounded text-gold-200 font-mono text-xs break-words" {...props}>
                    {children}
                  </code>
                )
              }
            }}
           >
            {typeof displayContent === 'string' ? displayContent : displayContent.text}
           </ReactMarkdown>

           {typeof displayContent !== 'string' && displayContent.hasCode && (
             <div className="mt-4 flex items-center gap-3 p-3 bg-zinc-900/50 border border-gold-500/20 rounded-lg group hover:border-gold-500/40 transition-colors cursor-default">
               <div className="p-2 bg-gold-900/10 rounded-md">
                 <Code2 className="w-5 h-5 text-gold-500" />
               </div>
               <div className="flex-1">
                 <p className="text-xs font-medium text-gold-100 uppercase tracking-wide">Interface Gerada</p>
                 <p className="text-[10px] text-zinc-500">O código foi processado e está disponível na aba de visualização.</p>
               </div>
               <ArrowRight className="w-4 h-4 text-zinc-600 group-hover:text-gold-400 transition-colors" />
             </div>
           )}
        </div>
      </div>
    </div>
  );
};