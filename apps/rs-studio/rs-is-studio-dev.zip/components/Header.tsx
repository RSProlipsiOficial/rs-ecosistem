import React from 'react';
import { Hexagon, Menu, Trash2 } from 'lucide-react';

interface HeaderProps {
  onReset?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onReset }) => {
  return (
    <header className="fixed top-0 left-0 w-full z-50 border-b border-white/5 bg-onyx-950/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Hexagon className="w-6 h-6 text-gold-400 stroke-1" />
          <span className="font-serif text-lg tracking-wider text-white font-semibold">
            RS-IS <span className="text-gold-400">STUDIO</span> DEV
          </span>
        </div>

        <nav className="hidden md:flex items-center gap-8 text-sm font-light tracking-wide text-zinc-400">
          <a href="#" className="hover:text-gold-400 transition-colors duration-300">MANIFESTO</a>
          <a href="#" className="hover:text-gold-400 transition-colors duration-300">VITRINE</a>
          <a href="#" className="hover:text-gold-400 transition-colors duration-300">PREÇOS</a>
        </nav>

        <div className="flex items-center gap-4">
          <button className="hidden md:block text-xs font-medium tracking-widest text-zinc-500 hover:text-white transition-colors uppercase">
            Entrar
          </button>
          <button 
            onClick={onReset}
            className="group flex items-center gap-2 border border-gold-600/30 text-gold-400 hover:bg-gold-400/10 hover:border-gold-400/60 px-4 py-2 text-xs uppercase tracking-widest transition-all duration-300 rounded-sm"
            title="Limpar histórico e começar novo projeto"
          >
            <Trash2 className="w-3.5 h-3.5 opacity-70 group-hover:opacity-100" />
            <span>Nova Sessão</span>
          </button>
          <button className="md:hidden text-zinc-400">
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};