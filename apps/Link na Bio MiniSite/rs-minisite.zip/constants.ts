import { BioSite, Theme, PlanDefinition, UserProfile, UserPlan } from './types';

export const RS_THEME_DARK: Theme = {
  id: 'rs-luxury-dark',
  name: 'RS Luxury Dark',
  backgroundColor: '#0a0a0a',
  primaryColor: '#D4AF37', // Gold
  secondaryColor: '#1a1a1a',
  textColor: '#ffffff',
  fontFamily: 'Inter'
};

export const RS_THEME_LIGHT: Theme = {
  id: 'rs-luxury-light',
  name: 'RS Luxury Light',
  backgroundColor: '#f4f4f5',
  primaryColor: '#AA8C2C', // Darker Gold for contrast
  secondaryColor: '#ffffff',
  textColor: '#0a0a0a',
  fontFamily: 'Inter'
};

export const PLANS: Record<UserPlan, PlanDefinition> = {
  free: {
    id: 'free',
    name: 'RS MiniSite Start',
    maxPages: 1,
    maxClients: 0,
    price: 'Grátis',
    features: ['1 Página', 'Com marca RS MiniSite']
  },
  pro: {
    id: 'pro',
    name: 'RS MiniSite Pro',
    maxPages: 10,
    maxClients: 0,
    price: 'R$ 19,90/mês',
    features: ['Até 10 páginas', 'Sem marca d’água', 'Prioridade no suporte']
  },
  agency: {
    id: 'agency',
    name: 'RS MiniSite Agency',
    maxPages: 500, // Updated Limit
    maxClients: 100, // New Client Limit
    price: 'R$ 129,90/mês', // Updated Price
    features: ['Até 500 páginas', 'Gestão de até 100 clientes', 'Sem marca d’água', 'Revenda permitida']
  },
  admin_master: {
    id: 'admin_master',
    name: 'Admin Master',
    maxPages: Infinity,
    maxClients: Infinity,
    price: 'Acesso Global',
    features: ['Gestão de Usuários', 'Gestão de Agências', 'Controle Financeiro', 'Acesso a Todos os Sites']
  }
};

export const INITIAL_USER: UserProfile = {
  id: 'user-demo-free',
  name: 'Usuário Demo',
  email: 'demo@rsminisite.com',
  plan: 'free', 
  referralCode: 'RS-DEMO-01'
};

export const INITIAL_SITES: BioSite[] = [
  {
    id: '1',
    userId: 'user-demo-free',
    slug: 'meu-site',
    name: 'Meu MiniSite',
    isPublished: true,
    views: 42,
    theme: RS_THEME_DARK,
    plan: 'free',
    seo: {
      title: 'Meu Link na Bio',
      description: 'Saiba mais sobre meu trabalho.',
      image: 'https://picsum.photos/400/400'
    },
    sections: [
      {
        id: 'hero-1',
        type: 'hero',
        content: {
          imageSrc: 'https://picsum.photos/400/400',
          title: 'Olá, Visitante',
          subtitle: 'Bem-vindo ao meu espaço digital.'
        },
        style: { textAlign: 'center' }
      },
      {
        id: 'btn-1',
        type: 'button',
        content: {
          label: 'Fale Comigo',
          url: 'https://wa.me/',
          icon: 'message-circle'
        },
        style: {}
      }
    ]
  }
];