
import React, { useEffect, useState } from 'react';
import { Section, Theme, SocialPlatform, UserPlan, TrackingPixels, FaqItem, BentoItem, CarouselItem } from '../types';
import { 
  ExternalLink, Calendar, Instagram, Linkedin, Mail, ArrowRight,
  Facebook, Twitter, Youtube, MessageCircle, Globe, ShoppingBag, Download, MapPin, ChevronDown, Timer, Send, Link as LinkIcon
} from 'lucide-react';

interface RendererProps {
  sections: Section[];
  theme: Theme;
  isPreview?: boolean; // If true, we act as the editor preview
  onSectionClick?: (id: string) => void;
  selectedSectionId?: string | null;
  plan?: UserPlan;
  tracking?: TrackingPixels;
}

export const Renderer: React.FC<RendererProps> = ({ 
  sections, 
  theme, 
  isPreview = false,
  onSectionClick,
  selectedSectionId,
  plan = 'free',
  tracking
}) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    // Only handle PWA install logic if not in editor preview mode
    if (isPreview) return;

    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, [isPreview]);

  const handleInstallApp = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };
  
  // -- TRACKING PIXEL INJECTION --
  useEffect(() => {
    // Only inject if not in preview mode and tracking is configured
    if (isPreview || !tracking) return;

    // Helper to append script
    const injectScript = (id: string, content: string, type = 'text/javascript') => {
        if (document.getElementById(id)) return; // prevent duplicate
        const script = document.createElement('script');
        script.id = id;
        script.type = type;
        script.innerHTML = content;
        document.head.appendChild(script);
    };

    // 1. Meta Pixel (Facebook)
    if (tracking.metaPixelId) {
        injectScript('meta-pixel', `
            !function(f,b,e,v,n,t,s)
            {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '${tracking.metaPixelId}');
            fbq('track', 'PageView');
        `);
    }

    // 2. Google Analytics (GA4)
    if (tracking.googleAnalyticsId) {
        // Load the external script first
        if (!document.getElementById('ga-external')) {
            const script = document.createElement('script');
            script.id = 'ga-external';
            script.async = true;
            script.src = `https://www.googletagmanager.com/gtag/js?id=${tracking.googleAnalyticsId}`;
            document.head.appendChild(script);
        }
        
        injectScript('ga-init', `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '${tracking.googleAnalyticsId}');
        `);
    }

    // 3. Google Ads
    if (tracking.googleAdsId) {
        // Assuming global site tag is used (similar to GA4)
        injectScript('gads-init', `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '${tracking.googleAdsId}');
        `);
    }

    // 4. TikTok Pixel
    if (tracking.tiktokPixelId) {
        injectScript('tiktok-pixel', `
            !function (w, d, t) {
            w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};var o=document.createElement("script");o.type="text/javascript",o.async=!0,o.src=i+"?sdkid="+e+"&lib="+t;var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)};
            ttq.load('${tracking.tiktokPixelId}');
            ttq.page();
            }(window, document, 'ttq');
        `);
    }

    // 5. Pinterest
    if (tracking.pinterestPixelId) {
        injectScript('pinterest-pixel', `
            !function(e){if(!window.pintrk){window.pintrk = function () {
            window.pintrk.queue.push(Array.prototype.slice.call(arguments))};var
            n=window.pintrk;n.queue=[],n.version="3.0";var
            t=document.createElement("script");t.async=!0,t.src=e;var
            r=document.getElementsByTagName("script")[0];
            r.parentNode.insertBefore(t,r)}}("https://s.pinimg.com/ct/core.js");
            pintrk('load', '${tracking.pinterestPixelId}');
            pintrk('page');
        `);
    }

    // 6. Taboola
    if (tracking.taboolaPixelId) {
        injectScript('taboola-pixel', `
            window._tfa = window._tfa || [];
            window._tfa.push({notify: 'event', name: 'page_view', id: ${tracking.taboolaPixelId}});
            !function (t, f, a, x) {
                   if (!document.getElementById(x)) {
                      t.async = 1;t.src = a;t.id=x;f.parentNode.insertBefore(t, f);
                   }
            }(document.createElement('script'),
            document.getElementsByTagName('script')[0],
            '//cdn.taboola.com/libtrc/unip/${tracking.taboolaPixelId}/tfa.js',
            'tb_tfa_script');
        `);
    }

  }, [tracking, isPreview]);


  // Dynamic style injection for the specific theme wrapper
  // We use flex-col and overflow-y-auto to ensure the content scrolls within the parent container (whether phone or desktop)
  const containerStyle = {
    backgroundColor: theme.backgroundColor,
    color: theme.textColor,
    fontFamily: theme.fontFamily,
    height: '100%', 
    width: '100%',
    position: 'relative' as const, // Ensure we can position absolute children relative to this
  };

  const showBranding = plan === 'free';

  return (
    <div style={containerStyle} className="flex flex-col items-center overflow-hidden relative">
      
      {/* GLOBAL BACKGROUND MEDIA LAYER */}
      {(theme.backgroundType === 'image' || theme.backgroundType === 'video') && (
        <div className="absolute inset-0 z-0">
          {theme.backgroundType === 'image' && theme.backgroundImage && (
             <img 
               src={theme.backgroundImage} 
               alt="Global Background" 
               className="w-full h-full object-cover"
             />
          )}
          {theme.backgroundType === 'video' && theme.backgroundVideo && (
             <video 
               src={theme.backgroundVideo} 
               autoPlay 
               loop 
               muted 
               playsInline 
               className="w-full h-full object-cover"
             />
          )}
          {/* Global Overlay */}
          <div 
             className="absolute inset-0 bg-black transition-opacity duration-300 pointer-events-none" 
             style={{ opacity: theme.backgroundOverlayOpacity ?? 0 }} 
          />
        </div>
      )}

      {/* SCROLLABLE CONTENT AREA */}
      {/* z-10 ensures content sits on top of the global background */}
      <div className="w-full h-full overflow-y-auto scrollbar-hide relative z-10 flex flex-col items-center py-12 px-6">
        <div className="w-full max-w-md space-y-6">
            {sections.map((section) => (
            <div 
                key={section.id} 
                className="relative group/block rounded-xl transition-all duration-300"
            >
                {/* 
                    BLOCK BACKGROUND MEDIA LAYER
                    Renders behind the block content.
                */}
                {(section.style.backgroundType === 'image' || section.style.backgroundType === 'video') && (
                <div className="absolute inset-0 rounded-xl overflow-hidden z-0">
                    {section.style.backgroundType === 'image' && section.style.backgroundImage && (
                        <img 
                        src={section.style.backgroundImage} 
                        alt="Background" 
                        className="w-full h-full object-cover"
                        />
                    )}
                    {section.style.backgroundType === 'video' && section.style.backgroundVideo && (
                        <video 
                        src={section.style.backgroundVideo} 
                        autoPlay 
                        loop 
                        muted 
                        playsInline 
                        className="w-full h-full object-cover"
                        />
                    )}
                    {/* Overlay for text readability */}
                    <div 
                        className="absolute inset-0 bg-black transition-opacity duration-300" 
                        style={{ opacity: section.style.overlayOpacity ?? 0.4 }} 
                    />
                </div>
                )}

                {/* 
                    Editor Selection Wrapper:
                    If we are in editor mode (onSectionClick exists), we wrap the block 
                    to handle selection and visualize the active state.
                */}
                {onSectionClick && (
                    <div 
                        onClick={(e) => {
                            e.stopPropagation();
                            onSectionClick(section.id);
                        }}
                        className={`
                            absolute -inset-2 rounded-xl transition-all duration-200 z-20 cursor-pointer
                            ${selectedSectionId === section.id 
                                ? 'ring-2 ring-rs-gold bg-rs-gold/5' 
                                : 'hover:bg-rs-gold/5 hover:ring-1 hover:ring-rs-gold/30'}
                        `}
                    />
                )}
                
                {/* Render the actual block - relative + z-10 ensures it sits on top of bg */}
                <div className="relative z-10">
                    <BlockRenderer section={section} theme={theme} />
                </div>
            </div>
            ))}
            
            {/* Footer Branding - Only for Free Plan */}
            {showBranding && (
              <div className="mt-16 pt-0 w-full flex flex-col gap-3">
                {/* Editable Client Name/Mindset Area */}
                <div className="text-center font-bold text-xs tracking-wider" style={{ color: theme.primaryColor }}>
                    {theme.customFooterText || "MINDSET"}
                </div>

                {/* Bottom Row: Rights & Privative */}
                <div className="flex justify-between items-center text-[9px] uppercase tracking-widest opacity-50 w-full border-t pt-3" style={{ borderColor: `${theme.textColor}20` }}>
                    <span>All rights reserved</span>
                    <span>RS Privative</span>
                </div>
              </div>
            )}
        </div>
      </div>

      {/* SAVE TO PHONE BUTTON (PWA INSTALL) - Only in public view */}
      {deferredPrompt && !isPreview && (
        <button
          onClick={handleInstallApp}
          className="fixed bottom-6 right-6 z-50 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 text-white rounded-full p-3 shadow-2xl animate-bounce"
          title="Salvar no Celular (Instalar App)"
          style={{ color: theme.textColor, borderColor: theme.primaryColor }}
        >
          <Download size={24} />
        </button>
      )}
    </div>
  );
};

const SocialIcon = ({ platform, size = 20 }: { platform: SocialPlatform, size?: number }) => {
  switch (platform) {
    case 'instagram': return <Instagram size={size} />;
    case 'facebook': return <Facebook size={size} />;
    case 'linkedin': return <Linkedin size={size} />;
    case 'twitter': return <Twitter size={size} />;
    case 'youtube': return <Youtube size={size} />;
    case 'whatsapp': return <MessageCircle size={size} />;
    case 'website': return <Globe size={size} />;
    default: return <ExternalLink size={size} />;
  }
};

const getEmbedUrl = (url: string) => {
  if (!url) return '';
  // Enhanced Regex to capture IDs from standard, short, and shorts URLs
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=|shorts\/)([^#&?]*).*/;
  const match = url.match(regExp);
  
  if (match && match[2].length === 11) {
    return `https://www.youtube.com/embed/${match[2]}`;
  }
  return url; 
};

// --- SUB-COMPONENTS FOR NEW BLOCKS ---

const BentoBlock: React.FC<{ items: BentoItem[], theme: Theme }> = ({ items, theme }) => {
    return (
        <div className="grid grid-cols-2 gap-3 w-full">
            {items.map((item, idx) => (
                <a
                    key={idx}
                    href={item.url || '#'}
                    target={item.url ? "_blank" : undefined}
                    className="relative group overflow-hidden rounded-2xl aspect-[4/3] p-4 flex flex-col justify-between transition-all hover:scale-[1.02] active:scale-95"
                    style={{
                        backgroundColor: item.backgroundColor || 'rgba(255,255,255,0.05)',
                        color: item.textColor || theme.textColor,
                        border: `1px solid ${theme.textColor}10`
                    }}
                >
                    {/* Background Image if exists */}
                    {item.type === 'image' && item.imageSrc && (
                        <>
                            <img src={item.imageSrc} alt="" className="absolute inset-0 w-full h-full object-cover transition-transform group-hover:scale-110" />
                            <div className="absolute inset-0 bg-black/40"></div>
                        </>
                    )}
                    
                    {/* Content */}
                    <div className="relative z-10 h-full flex flex-col justify-between">
                         <div className="flex justify-between items-start">
                             <div className={`p-1.5 rounded-full backdrop-blur-md ${item.type === 'image' ? 'bg-white/20' : 'bg-rs-gold/10 text-rs-gold'}`}>
                                 {item.type === 'link' ? <LinkIcon size={14} /> : item.type === 'image' ? <ExternalLink size={14} /> : <ArrowRight size={14} />}
                             </div>
                         </div>
                         <div>
                             <h4 className="font-bold text-sm leading-tight">{item.title || 'Título'}</h4>
                             <p className="text-[10px] opacity-70 mt-1 truncate">{item.subtitle || 'Subtítulo'}</p>
                         </div>
                    </div>
                </a>
            ))}
        </div>
    );
};

const CarouselBlock: React.FC<{ items: CarouselItem[], theme: Theme }> = ({ items, theme }) => {
    return (
        <div className="w-full overflow-x-auto pb-4 pt-1 snap-x snap-mandatory flex gap-4 scrollbar-hide -mx-2 px-2">
            {items.map((item, idx) => (
                <a
                    key={idx}
                    href={item.url || '#'}
                    target={item.url ? "_blank" : undefined}
                    className="snap-center shrink-0 w-40 aspect-[3/4] rounded-2xl overflow-hidden relative group shadow-lg border border-white/5"
                >
                    <img 
                        src={item.imageSrc} 
                        alt={item.title} 
                        className="absolute inset-0 w-full h-full object-cover transition-transform group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                    <div className="absolute bottom-0 left-0 right-0 p-3">
                        <h4 className="text-white font-bold text-sm leading-tight">{item.title}</h4>
                        {item.url && <div className="mt-1 text-[10px] text-rs-gold flex items-center gap-1">Ver mais <ArrowRight size={10}/></div>}
                    </div>
                </a>
            ))}
        </div>
    );
};

const CountdownBlock: React.FC<{ targetDate: string, theme: Theme }> = ({ targetDate, theme }) => {
    const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

    useEffect(() => {
        const calculateTimeLeft = () => {
            const difference = +new Date(targetDate) - +new Date();
            if (difference > 0) {
                setTimeLeft({
                    days: Math.floor(difference / (1000 * 60 * 60 * 24)),
                    hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                    minutes: Math.floor((difference / 1000 / 60) % 60),
                    seconds: Math.floor((difference / 1000) % 60),
                });
            } else {
                setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
            }
        };

        const timer = setInterval(calculateTimeLeft, 1000);
        calculateTimeLeft();
        return () => clearInterval(timer);
    }, [targetDate]);

    const TimeBox = ({ value, label }: { value: number, label: string }) => (
        <div className="flex flex-col items-center">
            <div className="w-12 h-12 flex items-center justify-center bg-white/10 backdrop-blur-md rounded-lg border border-white/10 shadow-lg text-xl font-bold font-mono">
                {String(value).padStart(2, '0')}
            </div>
            <span className="text-[10px] uppercase tracking-wider mt-1 opacity-70">{label}</span>
        </div>
    );

    return (
        <div className="flex gap-3 justify-center">
            <TimeBox value={timeLeft.days} label="Dias" />
            <TimeBox value={timeLeft.hours} label="Hrs" />
            <TimeBox value={timeLeft.minutes} label="Min" />
            <TimeBox value={timeLeft.seconds} label="Seg" />
        </div>
    );
};

const FaqBlock: React.FC<{ items: FaqItem[], theme: Theme }> = ({ items, theme }) => {
    const [openIndex, setOpenIndex] = useState<number | null>(null);

    return (
        <div className="space-y-2 w-full">
            {items.map((item, idx) => (
                <div 
                    key={idx} 
                    className="rounded-lg overflow-hidden border border-white/5 bg-white/5 backdrop-blur-sm transition-colors hover:bg-white/10"
                >
                    <button 
                        onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                        className="w-full flex items-center justify-between p-4 text-left text-sm font-semibold"
                        style={{ color: theme.textColor }}
                    >
                        <span>{item.question}</span>
                        <ChevronDown 
                            size={16} 
                            className={`transition-transform duration-300 ${openIndex === idx ? 'rotate-180' : ''}`}
                            style={{ color: theme.primaryColor }}
                        />
                    </button>
                    <div 
                        className={`overflow-hidden transition-all duration-300 ease-in-out ${openIndex === idx ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'}`}
                    >
                        <div className="p-4 pt-0 text-xs opacity-80 leading-relaxed border-t border-white/5 mt-2">
                            {item.answer}
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
};

const NewsletterBlock: React.FC<{ content: any, theme: Theme }> = ({ content, theme }) => {
    const [email, setEmail] = useState('');
    const [submitted, setSubmitted] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // In a real app, this would submit to an API endpoint
        setSubmitted(true);
        setTimeout(() => {
            setEmail('');
            setSubmitted(false);
        }, 3000);
    };

    return (
        <form onSubmit={handleSubmit} className="w-full flex flex-col gap-3">
             <div className="relative">
                <input 
                    type="email" 
                    required
                    placeholder={content.placeholderText || 'Seu melhor e-mail'}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full p-4 rounded-xl bg-white/10 backdrop-blur-md border border-white/10 text-sm outline-none focus:border-opacity-50 transition-colors placeholder:text-gray-400"
                    style={{ borderColor: theme.primaryColor, color: theme.textColor }}
                />
                <Mail size={18} className="absolute right-4 top-1/2 -translate-y-1/2 opacity-50" />
             </div>
             <button 
                type="submit"
                disabled={submitted}
                className="w-full py-3.5 rounded-xl font-bold text-sm shadow-lg flex items-center justify-center gap-2 transition-transform active:scale-95"
                style={{ backgroundColor: theme.primaryColor, color: theme.backgroundColor === '#0a0a0a' ? '#000' : '#fff' }}
             >
                 {submitted ? 'Inscrito com sucesso!' : (
                    <>
                        {content.buttonText || 'Inscrever-se'} 
                        <Send size={16} />
                    </>
                 )}
             </button>
        </form>
    );
};

const BlockRenderer: React.FC<{ section: Section; theme: Theme }> = ({ section, theme }) => {
  // Helper: If custom background is set, transparentize default backgrounds to let image show through
  const hasCustomBg = section.style.backgroundType === 'image' || section.style.backgroundType === 'video';

  switch (section.type) {
    case 'hero':
      return (
        <div className={`flex flex-col items-center ${section.style.textAlign === 'left' ? 'items-start' : section.style.textAlign === 'right' ? 'items-end' : ''} space-y-4 animate-fade-in p-4`}>
          <div className="relative p-1 rounded-full bg-gradient-to-tr from-transparent via-transparent to-transparent" style={{ borderColor: theme.primaryColor }}>
             {/* Gold ring effect */}
            <div className="absolute inset-0 rounded-full border-2 border-opacity-50" style={{ borderColor: theme.primaryColor }}></div>
            <img 
              src={section.content.imageSrc || 'https://picsum.photos/200'} 
              alt={section.content.title}
              className="w-28 h-28 md:w-32 md:h-32 rounded-full object-cover border-4 border-transparent"
            />
          </div>
          <h1 className="text-2xl font-bold tracking-tight font-serif text-shadow-sm">{section.content.title}</h1>
          {section.content.subtitle && (
            <p className="text-sm opacity-90 max-w-xs leading-relaxed text-shadow-sm font-medium">{section.content.subtitle}</p>
          )}
        </div>
      );

    case 'button':
      return (
        <a 
          href={section.content.url || '#'}
          target="_blank"
          rel="noopener noreferrer"
          className="group w-full block transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg active:scale-95"
          onClick={(e) => {}}
        >
          <div 
            className="w-full py-4 px-6 rounded-xl flex items-center justify-between font-semibold shadow-md backdrop-blur-sm border border-opacity-10"
            style={{ 
              backgroundColor: hasCustomBg ? 'rgba(0,0,0,0.2)' : theme.secondaryColor, 
              borderColor: theme.primaryColor,
              color: theme.textColor,
              borderWidth: hasCustomBg ? '1px' : '0px'
            }}
          >
            <span className="flex items-center gap-3">
              {section.content.icon === 'calendar' && <Calendar size={18} style={{ color: theme.primaryColor }} />}
              {section.content.icon === 'instagram' && <Instagram size={18} style={{ color: theme.primaryColor }} />}
              {section.content.icon === 'linkedin' && <Linkedin size={18} style={{ color: theme.primaryColor }} />}
              {!section.content.icon && <ExternalLink size={18} style={{ color: theme.primaryColor }} />}
              {section.content.label}
            </span>
            <ArrowRight size={16} className="opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: theme.primaryColor }} />
          </div>
        </a>
      );

    case 'text':
      return (
        <div 
          className="w-full p-6 rounded-xl border border-opacity-5 backdrop-blur-sm"
          style={{ 
            backgroundColor: hasCustomBg ? 'rgba(0,0,0,0.3)' : 'rgba(255,255,255,0.03)',
            textAlign: section.style.textAlign || 'left',
            borderColor: theme.primaryColor
          }}
        >
          {section.content.title && <h3 className="text-lg font-semibold mb-2" style={{ color: theme.primaryColor }}>{section.content.title}</h3>}
          <p className="text-sm opacity-90 leading-relaxed font-medium">{section.content.subtitle}</p>
        </div>
      );
    
    case 'product':
        return (
            <div 
                className="w-full rounded-2xl overflow-hidden shadow-lg border border-opacity-10 group"
                style={{ 
                    backgroundColor: hasCustomBg ? 'rgba(0,0,0,0.4)' : theme.secondaryColor,
                    borderColor: theme.primaryColor,
                    backdropFilter: hasCustomBg ? 'blur(10px)' : 'none'
                }}
            >
                {/* Product Image */}
                <div className="w-full h-48 bg-black/20 overflow-hidden relative">
                    <img 
                        src={section.content.imageSrc || 'https://via.placeholder.com/400x300'} 
                        alt={section.content.title} 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                </div>
                
                {/* Content */}
                <div className="p-5">
                    <h3 className="font-bold text-lg mb-1 leading-tight">{section.content.title}</h3>
                    <p className="text-sm opacity-70 mb-4 line-clamp-2">{section.content.subtitle}</p>
                    
                    <div className="flex items-end gap-2 mb-4">
                        <span className="text-xl font-bold" style={{ color: theme.primaryColor }}>
                            {section.content.price}
                        </span>
                        {section.content.oldPrice && (
                            <span className="text-sm line-through opacity-50 mb-1">
                                {section.content.oldPrice}
                            </span>
                        )}
                    </div>

                    <a 
                        href={section.content.url || '#'}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full py-3 rounded-lg flex items-center justify-center gap-2 font-bold text-sm uppercase tracking-wide transition-all active:scale-95"
                        style={{
                            backgroundColor: theme.primaryColor,
                            color: theme.backgroundColor === '#0a0a0a' ? '#000' : '#fff'
                        }}
                    >
                        <ShoppingBag size={16} />
                        {section.content.label || 'Comprar Agora'}
                    </a>
                </div>
            </div>
        );

    case 'gallery':
        return (
            <div className="grid grid-cols-2 gap-2 w-full p-2">
                {section.content.items?.map((img, idx) => (
                    <img key={idx} src={img} alt="Gallery" className="w-full h-32 object-cover rounded-lg hover:opacity-90 transition-opacity cursor-pointer" />
                )) || <div className="p-4 text-center text-xs opacity-50 border border-dashed rounded w-full col-span-2">Galeria Vazia</div>}
            </div>
        );

    case 'social':
      return (
        <div className={`flex flex-wrap gap-4 w-full p-2 ${section.style.textAlign === 'left' ? 'justify-start' : section.style.textAlign === 'right' ? 'justify-end' : 'justify-center'}`}>
           {section.content.socialLinks?.map((link, idx) => (
              <a 
                key={idx}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-full transition-all duration-300 hover:scale-110 shadow-lg backdrop-blur-md"
                style={{
                   backgroundColor: hasCustomBg ? 'rgba(255,255,255,0.1)' : theme.secondaryColor,
                   color: theme.primaryColor,
                   border: `1px solid ${theme.primaryColor}40`
                }}
              >
                  <SocialIcon platform={link.platform} size={22} />
              </a>
           ))}
        </div>
      );

    case 'video':
      const embedUrl = getEmbedUrl(section.content.url || '');
      return (
        <div className={`w-full flex flex-col p-4 ${section.style.textAlign === 'left' ? 'items-start text-left' : section.style.textAlign === 'right' ? 'items-end text-right' : 'items-center text-center'} space-y-4`}>
            {/* Title Above */}
            {section.content.title && (
                 <h3 className="text-lg font-bold leading-tight text-shadow-sm" style={{ color: theme.primaryColor }}>
                    {section.content.title}
                 </h3>
            )}
            
            <div className="w-full aspect-video rounded-xl overflow-hidden shadow-lg border border-opacity-10 relative" style={{ borderColor: theme.textColor }}>
                {embedUrl ? (
                     <iframe 
                     src={embedUrl} 
                     className="w-full h-full" 
                     frameBorder="0" 
                     allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                     allowFullScreen
                   ></iframe>
                ) : (
                    <div className="w-full h-full flex items-center justify-center bg-white/5 text-xs opacity-50">
                        Vídeo (URL inválida ou vazia)
                    </div>
                )}
            </div>

            {/* Description Below */}
            {section.content.subtitle && (
                <p className="text-sm opacity-90 leading-relaxed max-w-full break-words text-shadow-sm font-medium">
                    {section.content.subtitle}
                </p>
            )}
        </div>
      );

    case 'image-text':
        return (
            <div 
                className="w-full p-4 rounded-xl flex gap-4 items-center border border-opacity-10 shadow-sm backdrop-blur-sm"
                style={{ 
                    backgroundColor: hasCustomBg ? 'rgba(0,0,0,0.4)' : theme.secondaryColor,
                    borderColor: theme.primaryColor,
                    flexDirection: section.style.textAlign === 'right' ? 'row-reverse' : 'row'
                }}
            >
                <img 
                    src={section.content.imageSrc || 'https://via.placeholder.com/150'} 
                    alt={section.content.title}
                    className="w-20 h-20 rounded-lg object-cover flex-shrink-0"
                />
                <div className={`flex-1 ${section.style.textAlign === 'right' ? 'text-right' : 'text-left'}`}>
                     <h3 className="font-bold text-base leading-tight mb-1" style={{ color: theme.primaryColor }}>
                        {section.content.title}
                     </h3>
                     <p className="text-xs opacity-80 leading-relaxed">
                        {section.content.subtitle}
                     </p>
                </div>
            </div>
        );

    case 'whatsapp':
        // WhatsApp Block Rendering
        const waNumber = section.content.whatsappNumber?.replace(/\D/g, '') || '';
        const waMessage = encodeURIComponent(section.content.whatsappMessage || '');
        const waUrl = waNumber ? `https://wa.me/${waNumber}?text=${waMessage}` : '#';

        return (
            <a 
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group w-full block transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg active:scale-95"
            >
                <div 
                    className="w-full py-4 px-6 rounded-xl flex items-center justify-between font-semibold shadow-md backdrop-blur-sm"
                    style={{ 
                        backgroundColor: hasCustomBg ? 'rgba(37, 211, 102, 0.9)' : section.style.backgroundColor || '#25D366', 
                        color: section.style.textColor || '#FFFFFF',
                    }}
                >
                    <span className="flex items-center gap-3">
                        <MessageCircle size={22} className="fill-current" />
                        <span className="text-lg">{section.content.label || 'WhatsApp'}</span>
                    </span>
                    <ArrowRight size={20} className="opacity-70 group-hover:opacity-100 transition-opacity" />
                </div>
            </a>
        );

    // --- NEW BLOCKS ---
    case 'bento':
        return <BentoBlock items={section.content.bentoItems || []} theme={theme} />;

    case 'carousel':
        return <CarouselBlock items={section.content.carouselItems || []} theme={theme} />;

    case 'countdown':
        return (
            <div className="w-full p-6 rounded-xl border border-white/10 bg-black/20 backdrop-blur-sm flex flex-col items-center">
                 {section.content.title && (
                    <h3 className="text-lg font-bold mb-4" style={{ color: theme.primaryColor }}>{section.content.title}</h3>
                 )}
                 <CountdownBlock targetDate={section.content.targetDate || new Date().toISOString()} theme={theme} />
                 {section.content.subtitle && (
                     <p className="text-xs opacity-70 mt-4 text-center">{section.content.subtitle}</p>
                 )}
            </div>
        );

    case 'faq':
        return (
            <div className="w-full">
                {section.content.title && (
                     <h3 className="text-lg font-bold mb-4 text-center" style={{ color: theme.primaryColor }}>{section.content.title}</h3>
                )}
                <FaqBlock items={section.content.faqItems || []} theme={theme} />
            </div>
        );

    case 'newsletter':
        return (
             <div className="w-full p-6 rounded-xl border border-white/10 bg-black/20 backdrop-blur-sm flex flex-col items-center">
                {section.content.title && (
                    <h3 className="text-lg font-bold mb-2" style={{ color: theme.primaryColor }}>{section.content.title}</h3>
                )}
                {section.content.subtitle && (
                    <p className="text-xs opacity-80 mb-6 text-center">{section.content.subtitle}</p>
                )}
                <NewsletterBlock content={section.content} theme={theme} />
             </div>
        );

    case 'map':
        const mapUrl = section.content.mapAddress 
            ? `https://www.google.com/maps/embed/v1/place?key=YOUR_API_KEY&q=${encodeURIComponent(section.content.mapAddress)}`
            : '';
        // Note: In production, user needs a Google Maps API Key or use a static map generator. 
        // For this demo, we use an iframe placeholder logic that works with standard embed links if user provides them,
        // or a visual placeholder.
        
        return (
            <div className="w-full rounded-xl overflow-hidden border border-white/10 bg-gray-800 relative aspect-video flex items-center justify-center">
                {section.content.mapAddress ? (
                   <iframe 
                      width="100%" 
                      height="100%" 
                      style={{border:0}} 
                      loading="lazy" 
                      allowFullScreen 
                      src={`https://maps.google.com/maps?q=${encodeURIComponent(section.content.mapAddress)}&t=&z=13&ie=UTF8&iwloc=&output=embed`}
                   ></iframe>
                ) : (
                    <div className="text-center p-4 opacity-50 flex flex-col items-center">
                        <MapPin size={32} className="mb-2" />
                        <span className="text-xs">Endereço não configurado</span>
                    </div>
                )}
                 {/* Overlay Gradient for integration */}
                 <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_20px_rgba(0,0,0,0.5)]"></div>
            </div>
        );

    case 'divider':
        return (
            <div className="w-full flex justify-center py-2" style={{ paddingLeft: '10%', paddingRight: '10%' }}>
                <div 
                    style={{ 
                        width: section.style.dividerWidth || '100%',
                        height: section.style.dividerThickness || '1px',
                        backgroundColor: section.style.backgroundColor || theme.primaryColor, // Repurpose backgroundColor for the line itself
                        opacity: section.style.overlayOpacity ?? 1,
                        borderRadius: '999px'
                    }} 
                />
            </div>
        );

    case 'spacer':
        return (
            <div 
                style={{ height: section.style.height || '32px' }} 
                className="w-full transition-all duration-300"
            />
        );

    default:
      return null;
  }
};