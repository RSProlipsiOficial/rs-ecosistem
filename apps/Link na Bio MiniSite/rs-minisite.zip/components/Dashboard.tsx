import React, { useState, useMemo, useEffect } from 'react';
import { BioSite, UserProfile, UserPlan, PlanDefinition, AgencyClient, ClientPayment, PaymentStatus, PaymentMethod } from '../types';
import { Plus, Edit3, ExternalLink, BarChart3, MoreVertical, Moon, Sun, Crown, CheckCircle2, CreditCard, Lock, X, Loader2, ShieldCheck, QrCode, Copy, Smartphone, Users, Briefcase, UserPlus, ArrowLeft, Filter, MousePointer2, TrendingUp, LayoutDashboard, MapPin, Mail, Phone, Calendar, FileText, ChevronRight, Search, ArrowUpDown, Share2, Ticket, DollarSign, Wallet, TrendingDown, ArrowUpRight, Target, ArrowRight, Shield, Percent, Save, MessageCircle, Download } from 'lucide-react';
import { PLANS } from '../constants';

interface DashboardProps {
  user: UserProfile;
  sites: BioSite[];
  clients?: AgencyClient[]; // New prop for agency clients
  payments?: ClientPayment[]; // New prop for financial data
  onCreateNew: (clientId?: string) => void;
  onAddClient?: (clientData: Omit<AgencyClient, 'id' | 'agencyId' | 'createdAt' | 'updatedAt'>) => void;
  onUpdateClient?: (client: AgencyClient) => void;
  onAddPayment?: (payment: Omit<ClientPayment, 'id'>) => void;
  onEdit: (site: BioSite) => void;
  onView: (slug: string) => void;
  onUpdatePlan: (plan: UserPlan) => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
  onNavigateToAdmin?: () => void; // New prop for admin navigation
  onLog?: (action: string, target: string) => void; // New log prop
}

export const Dashboard: React.FC<DashboardProps> = ({ user, sites, clients = [], payments = [], onCreateNew, onAddClient, onUpdateClient, onAddPayment, onEdit, onView, onUpdatePlan, isDarkMode, toggleTheme, onNavigateToAdmin, onLog }) => {
  const currentPlan = PLANS[user.plan];
  
  // ROLE CHECKS
  const isAdmin = user.plan === 'admin_master';
  const isAgency = user.plan === 'agency' || isAdmin;

  // FIXED: Only count sites that belong to the current user for usage limits (Admin has Infinity)
  const userSites = useMemo(() => sites.filter(s => s.userId === user.id), [sites, user.id]);
  const usageCount = userSites.length;
  
  const isLimitReached = usageCount >= currentPlan.maxPages;
  const usagePercentage = Math.min((usageCount / (currentPlan.maxPages === Infinity ? 100 : currentPlan.maxPages)) * 100, 100);

  // Client Limits
  const clientUsageCount = clients.length;
  const isClientLimitReached = clientUsageCount >= currentPlan.maxClients;

  // Upgrade Modal State
  const [showPlansModal, setShowPlansModal] = useState(false);
  const [upgradeTarget, setUpgradeTarget] = useState<UserPlan | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Agency Mode State
  // Default to 'dashboard' if Agency/Admin so they see stats immediately. 'sites' for users.
  const [dashboardTab, setDashboardTab] = useState<'dashboard' | 'sites' | 'clients' | 'invites' | 'finance'>(isAgency ? 'dashboard' : 'sites'); 
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);
  const [isClientModalOpen, setIsClientModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  
  // Analytics State
  const [analyticsPeriod, setAnalyticsPeriod] = useState<'7d' | '30d' | '90d'>('30d');

  // Client List Filtering & Sorting State
  const [clientSearch, setClientSearch] = useState('');
  const [clientFilterStatus, setClientFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [clientSort, setClientSort] = useState<'recent' | 'name'>('recent');

  // Invitation / Referral State
  const [linkCopied, setLinkCopied] = useState(false);

  // PWA Install State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallApp = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  // CRM Form State
  const initialClientState = {
      name: '',
      email: '',
      cpf: '',
      phone: '',
      birthDate: '',
      address: {
          line: '',
          number: '',
          city: '',
          state: '',
          zip: ''
      },
      notes: '',
      status: 'active' as 'active' | 'inactive',
      monthlyFee: 0 // New field
  };
  const [clientForm, setClientForm] = useState(initialClientState);
  const [editingClientId, setEditingClientId] = useState<string | null>(null);

  // Payment Form State
  const initialPaymentState = {
      clientId: '',
      amount: '',
      date: new Date().toISOString().split('T')[0],
      dueDate: new Date().toISOString().split('T')[0],
      status: 'paid' as PaymentStatus,
      method: 'pix' as PaymentMethod,
      notes: ''
  };
  const [paymentForm, setPaymentForm] = useState(initialPaymentState);

  const handlePlanSelect = (targetPlan: UserPlan) => {
    // If selecting current plan, do nothing
    if (targetPlan === user.plan) return;

    // If downgrading to free, just confirm
    if (targetPlan === 'free') {
        if (window.confirm('Tem certeza que deseja voltar para o plano Grátis? Seus sites extras podem ficar indisponíveis.')) {
            onUpdatePlan('free');
            if (onLog) onLog('change_plan', 'Downgrade para Free');
            setShowPlansModal(false);
        }
        return;
    }

    // If upgrading (Pro or Agency), open Payment Confirmation
    setUpgradeTarget(targetPlan);
    setShowPlansModal(false); // Close plans modal if open, switch to payment view (simulated via upgradeTarget state)
  };

  const handleConfirmPayment = () => {
    if (!upgradeTarget) return;
    
    setIsProcessing(true);
    
    // Simulate API Call / Gateway processing
    setTimeout(() => {
        // 1. CRITICAL: Update the global state immediately via parent callback
        // This triggers a re-render of Dashboard with the new plan limits
        onUpdatePlan(upgradeTarget);

        if (onLog) onLog('change_plan', `Upgrade para ${PLANS[upgradeTarget].name}`);
        
        // 2. Stop processing & Close modal
        setIsProcessing(false);
        setUpgradeTarget(null);
        setShowPlansModal(false);
        
        // 3. User feedback (UI is already unlocked in background)
        alert(`Pagamento confirmado! Bem-vindo ao plano ${PLANS[upgradeTarget].name}. Seus limites foram liberados.`);
    }, 2000);
  };

  const handleCreateClick = () => {
      if (isLimitReached) {
          // If limit reached, force open the Plans Modal
          setShowPlansModal(true);
      } else {
          // If in agency mode and inside a client view, create for that client
          if (selectedClientId) {
              onCreateNew(selectedClientId);
          } else {
              // Default creates for the agency owner
              onCreateNew();
          }
      }
  };

  const handleAddClientClick = () => {
      if (isClientLimitReached) {
          alert(`Limite de clientes atingido (${currentPlan.maxClients}). Por favor, entre em contato com o suporte para aumentar seu limite.`);
          return;
      }
      setEditingClientId(null);
      setClientForm(initialClientState);
      setIsClientModalOpen(true);
  };

  const handleAddPaymentClick = () => {
      setPaymentForm(initialPaymentState);
      setIsPaymentModalOpen(true);
  };

  const handleEditClientClick = (client: AgencyClient) => {
      setEditingClientId(client.id);
      setClientForm({
          name: client.name,
          email: client.email,
          cpf: client.cpf || '',
          phone: client.phone || '',
          birthDate: client.birthDate || '',
          address: {
              line: client.address?.line || '',
              number: client.address?.number || '',
              city: client.address?.city || '',
              state: client.address?.state || '',
              zip: client.address?.zip || ''
          },
          notes: client.notes || '',
          status: client.status,
          monthlyFee: client.monthlyFee || 0
      });
      setIsClientModalOpen(true);
  };

  const handleSaveClient = (e: React.FormEvent) => {
      e.preventDefault();
      
      // Validação do valor mínimo
      if (clientForm.monthlyFee < 5) {
          alert("O valor mínimo da mensalidade deve ser R$ 5,00.");
          return;
      }

      if (editingClientId && onUpdateClient) {
          // Update Mode
          const existingClient = clients.find(c => c.id === editingClientId);
          if (existingClient) {
              onUpdateClient({
                  ...existingClient,
                  ...clientForm
              });
          }
      } else if (onAddClient) {
          // Create Mode
          onAddClient(clientForm);
      }
      
      setIsClientModalOpen(false);
      setClientForm(initialClientState);
      setEditingClientId(null);
  };

  const handleSavePayment = (e: React.FormEvent) => {
      e.preventDefault();
      if (!paymentForm.clientId) {
          alert("Selecione um cliente.");
          return;
      }
      if (onAddPayment) {
          onAddPayment({
              clientId: paymentForm.clientId,
              amount: parseFloat(paymentForm.amount),
              date: new Date(paymentForm.date),
              dueDate: new Date(paymentForm.dueDate),
              status: paymentForm.status,
              method: paymentForm.method,
              notes: paymentForm.notes
          });
      }
      setIsPaymentModalOpen(false);
      setPaymentForm(initialPaymentState);
  };

  const handleCopyInviteLink = () => {
      const link = `${window.location.origin}/signup?ref=${user.referralCode || 'RS-AGENCY'}`;
      navigator.clipboard.writeText(link);
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
  };

  // Filter sites based on view (My Sites vs Client Sites vs All)
  const displayedSites = useMemo(() => {
      // 1. Specific Client Selected (Drill Down)
      // Show only sites linked to this client
      if (selectedClientId) {
          return sites.filter(s => s.clientId === selectedClientId);
      }
      
      // 2. Admin View Logic (Global)
      if (isAdmin) {
          // Dashboard Tab: Return ALL sites in the system for overview
          if (dashboardTab === 'dashboard' || dashboardTab === 'sites') {
              return sites;
          }
           // Other tabs logic handled elsewhere or returns filtered view
          return [];
      }

      // 3. Agency View Logic
      if (user.plan === 'agency') {
           // Dashboard Tab: Return ALL sites owned by Agency User (Global Stats for Agency)
           if (dashboardTab === 'dashboard') {
               return sites.filter(s => s.userId === user.id);
           }

           // My Sites Tab: Return ONLY Owner sites that are NOT linked to a client
           if (dashboardTab === 'sites') {
               return sites.filter(s => s.userId === user.id && !s.clientId);
           }
           
           // Clients, Invites, Finance Tabs: List handled separately
           return [];
      }

      // 4. Default (Free/Pro): Only user's own sites
      return sites.filter(s => s.userId === user.id);
  }, [sites, selectedClientId, user.id, user.plan, dashboardTab, clients, isAdmin]);

  // Filtered Clients Logic
  const filteredClients = useMemo(() => {
      let result = [...clients]; // Admin sees all clients passed in props (which ideally contains all system clients in this architecture)

      // 1. Search (Name, Email, Phone, CPF)
      if (clientSearch.trim()) {
          const lowerTerm = clientSearch.toLowerCase();
          result = result.filter(c => 
              c.name.toLowerCase().includes(lowerTerm) ||
              c.email.toLowerCase().includes(lowerTerm) ||
              (c.phone && c.phone.includes(lowerTerm)) ||
              (c.cpf && c.cpf.includes(lowerTerm))
          );
      }

      // 2. Filter by Status
      if (clientFilterStatus !== 'all') {
          result = result.filter(c => c.status === clientFilterStatus);
      }

      // 3. Sort
      result.sort((a, b) => {
          if (clientSort === 'name') {
              return a.name.localeCompare(b.name);
          }
          // Default: Recent (createdAt desc)
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });

      return result;
  }, [clients, clientSearch, clientFilterStatus, clientSort]);


  // ADVANCED ANALYTICS DATA PREPARATION
  const analyticsData = useMemo(() => {
    // If no sites to display, return empty
    if (displayedSites.length === 0) return { 
        sortedSites: [], 
        topClients: [],
        totalViews: 0, 
        totalClicks: 0, 
        totalLeads: 0, 
        chartData: [] 
    };

    // 1. Aggregates
    let totalViews = 0;
    let totalClicks = 0;
    let totalLeads = 0; // Simulated: Clicks on 'whatsapp' or 'button' type blocks often indicate leads

    const sitesWithStats = displayedSites.map(site => {
      const siteClicks = site.sections.reduce((acc, sec) => acc + (sec.clicks || 0), 0);
      const siteLeads = site.sections.reduce((acc, sec) => {
          if (sec.type === 'whatsapp' || (sec.type === 'button' && (sec.content.label?.toLowerCase().includes('contato') || sec.content.label?.toLowerCase().includes('agendar')))) {
              return acc + (sec.clicks || 0);
          }
          return acc;
      }, 0);

      totalViews += site.views;
      totalClicks += siteClicks;
      totalLeads += siteLeads;

      return { ...site, totalClicks, totalLeads };
    });
    
    // 2. Rankings
    const sortedSites = [...sitesWithStats].sort((a, b) => b.views - a.views).slice(0, 5);

    // Group by Client (for Agency/Admin view)
    const clientStatsMap = new Map<string, { name: string, views: number, clicks: number }>();
    sitesWithStats.forEach(site => {
        if (site.clientId) {
            const client = clients.find(c => c.id === site.clientId);
            if (client) {
                const current = clientStatsMap.get(client.id) || { name: client.name, views: 0, clicks: 0 };
                clientStatsMap.set(client.id, {
                    name: client.name,
                    views: current.views + site.views,
                    clicks: current.clicks + site.totalClicks
                });
            }
        }
    });
    const topClients = Array.from(clientStatsMap.values()).sort((a, b) => b.views - a.views).slice(0, 5);

    // 3. Mock Chart Data (Daily breakdown based on Period)
    const days = analyticsPeriod === '7d' ? 7 : analyticsPeriod === '30d' ? 30 : 90;
    const chartData = [];
    
    for (let i = 0; i < days; i++) {
        const date = new Date();
        date.setDate(date.getDate() - (days - 1 - i));
        
        const base = Math.max(5, Math.floor(totalViews / days));
        const variance = Math.floor(Math.random() * base * 0.5) * (Math.random() > 0.5 ? 1 : -1);
        const value = Math.max(0, base + variance);
        
        chartData.push({
            date: date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
            value: value
        });
    }

    return { sortedSites, topClients, totalViews, totalClicks, totalLeads, chartData };
  }, [displayedSites, clients, analyticsPeriod]);

  // FINANCE DATA PREPARATION (MVP)
  const financeData = useMemo(() => {
      const now = new Date();
      const currentMonth = now.getMonth();
      const currentYear = now.getFullYear();

      const activeClients = clients.filter(c => c.status === 'active').length;
      
      const newClientsMonth = clients.filter(c => {
          const d = new Date(c.createdAt);
          return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
      }).length;

      // Project Monthly Revenue based on client fees
      const projectedRevenue = clients
        .filter(c => c.status === 'active')
        .reduce((acc, curr) => acc + (curr.monthlyFee || 0), 0);

      // MRR Calculation based on actual payments
      const mrr = payments
          .filter(p => {
              const d = new Date(p.date);
              return d.getMonth() === currentMonth && d.getFullYear() === currentYear && p.status === 'paid';
          })
          .reduce((acc, curr) => acc + curr.amount, 0);

      const churnMonth = clients.filter(c => {
           const d = new Date(c.updatedAt || c.createdAt);
           return c.status === 'inactive' && d.getMonth() === currentMonth && d.getFullYear() === currentYear;
      }).length;

      return {
          activeClients,
          newClientsMonth,
          mrr,
          projectedRevenue,
          churnMonth
      };
  }, [clients, payments]);


  const selectedClient = clients.find(c => c.id === selectedClientId);

  // Helper booleans to control rendering based on Plan + Tab
  const showBanner = !isAgency || (isAgency && dashboardTab === 'dashboard');
  const showAnalytics = (!isAgency && displayedSites.length > 0) || (isAgency && dashboardTab === 'dashboard');
  const showSiteGrid = (!isAgency) || (isAgency && (dashboardTab === 'sites' || dashboardTab === 'dashboard')) || selectedClientId;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-rs-black text-gray-900 dark:text-white p-6 md:p-12 transition-colors duration-300 flex flex-col relative">
      <div className="max-w-6xl mx-auto w-full flex-1">
        
        {/* Header Section */}
        <header className="flex flex-col md:flex-row justify-between items-start md:items-end mb-8 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
                <h1 className="text-4xl font-serif font-bold text-rs-goldDark dark:text-rs-gold">RS MiniSite</h1>
                {isAgency && !isAdmin && (
                    <span className="bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300 px-2 py-0.5 rounded text-[10px] font-bold uppercase border border-purple-200 dark:border-purple-800">Agency Console</span>
                )}
                {isAdmin && (
                    <span className="bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300 px-2 py-0.5 rounded text-[10px] font-bold uppercase border border-red-200 dark:border-red-800">Admin Master</span>
                )}
            </div>
            <p className="text-gray-500 dark:text-gray-400 text-lg">Seu site profissional para bio em minutos.</p>
          </div>
          
          <div className="flex items-center gap-4">
            
            {/* Install App Button */}
            {deferredPrompt && (
              <button 
                onClick={handleInstallApp}
                className="p-3 rounded-full bg-rs-goldDark dark:bg-rs-gold text-white dark:text-black hover:opacity-90 transition-colors shadow-lg animate-pulse"
                title="Instalar App no Computador/Celular"
              >
                <Download size={20} />
              </button>
            )}

            <button 
                onClick={toggleTheme} 
                className="p-3 rounded-full bg-white dark:bg-rs-dark border border-gray-200 dark:border-rs-gray text-gray-600 dark:text-gray-300 hover:text-rs-goldDark dark:hover:text-rs-gold transition-colors shadow-sm"
                title="Alternar Tema"
            >
                {isDarkMode ? <Moon size={20} /> : <Sun size={20} />}
            </button>

            {/* ADMIN BUTTON */}
            {isAdmin && onNavigateToAdmin && (
              <button 
                onClick={onNavigateToAdmin}
                className="flex items-center gap-2 px-6 py-3 rounded-lg font-bold transition-all shadow-lg bg-red-600 hover:bg-red-700 text-white hover:shadow-red-500/20 border-2 border-red-500/50"
              >
                <Shield size={20} />
                Painel Master
              </button>
            )}
            
            {/* Create Button: Show on Non-Agency OR Agency (Dashboard/Sites tabs only) */}
            {(!isAgency || (isAgency && dashboardTab !== 'clients' && dashboardTab !== 'invites' && dashboardTab !== 'finance')) && (
                <button 
                    onClick={handleCreateClick}
                    className={`flex items-center gap-2 px-6 py-3 rounded-lg font-bold transition-all shadow-lg ${
                        isLimitReached 
                        ? 'bg-gray-800 text-white border border-rs-gold hover:bg-black hover:shadow-rs-gold/40 animate-pulse' 
                        : 'bg-rs-goldDark dark:bg-rs-gold hover:bg-yellow-600 dark:hover:bg-yellow-500 text-white dark:text-black hover:shadow-rs-gold/20'
                    }`}
                >
                    {isLimitReached ? <Crown size={20} className="text-rs-gold" /> : <Plus size={20} />}
                    {isLimitReached ? 'Upgrade para Criar' : 'Criar Novo MiniSite'}
                </button>
            )}

            {/* Show "Add Client" button if in Client tab or Client List View */}
            {isAgency && dashboardTab === 'clients' && !selectedClientId && (
                <button 
                    onClick={handleAddClientClick}
                    className={`flex items-center gap-2 px-6 py-3 rounded-lg font-bold transition-all shadow-lg ${
                        isClientLimitReached
                        ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                        : 'bg-rs-goldDark dark:bg-rs-gold hover:bg-yellow-600 dark:hover:bg-yellow-500 text-white dark:text-black hover:shadow-rs-gold/20'
                    }`}
                >
                    <UserPlus size={20} />
                    Novo Cliente
                </button>
            )}

             {/* Show "New Payment" button if in Finance tab */}
             {isAgency && dashboardTab === 'finance' && (
                <button 
                    onClick={handleAddPaymentClick}
                    className="flex items-center gap-2 px-6 py-3 rounded-lg font-bold transition-all shadow-lg bg-green-600 hover:bg-green-700 text-white hover:shadow-green-500/20"
                >
                    <Plus size={20} />
                    Novo Pagamento
                </button>
            )}
          </div>
        </header>

        {/* Agency Navigation Tabs - REORGANIZED */}
        {isAgency && (
            <div className="flex gap-4 mb-8 border-b border-gray-200 dark:border-rs-gray justify-start items-center overflow-x-auto">
                <button 
                    onClick={() => { setDashboardTab('dashboard'); setSelectedClientId(null); }}
                    className={`pb-4 px-4 font-bold text-sm transition-all flex items-center gap-2 border-b-2 whitespace-nowrap ${
                        dashboardTab === 'dashboard'
                        ? 'text-rs-goldDark dark:text-rs-gold border-rs-goldDark dark:border-rs-gold'
                        : 'text-gray-500 border-transparent hover:text-gray-900 dark:hover:text-white'
                    }`}
                >
                    <LayoutDashboard size={18} />
                    Dashboard
                </button>
                <button 
                    onClick={() => { setDashboardTab('sites'); setSelectedClientId(null); }}
                    className={`pb-4 px-4 font-bold text-sm transition-all flex items-center gap-2 border-b-2 whitespace-nowrap ${
                        dashboardTab === 'sites' && !selectedClientId
                        ? 'text-rs-goldDark dark:text-rs-gold border-rs-goldDark dark:border-rs-gold'
                        : 'text-gray-500 border-transparent hover:text-gray-900 dark:hover:text-white'
                    }`}
                >
                    <Briefcase size={18} />
                    {isAdmin ? 'Todos os Sites' : 'Meus Sites'}
                </button>
                <button 
                    onClick={() => { setDashboardTab('clients'); setSelectedClientId(null); }}
                    className={`pb-4 px-4 font-bold text-sm transition-all flex items-center gap-2 border-b-2 whitespace-nowrap ${
                        dashboardTab === 'clients' || selectedClientId
                        ? 'text-rs-goldDark dark:text-rs-gold border-rs-goldDark dark:border-rs-gold'
                        : 'text-gray-500 border-transparent hover:text-gray-900 dark:hover:text-white'
                    }`}
                >
                    <Users size={18} />
                    {isAdmin ? 'Agências e Clientes' : 'Clientes'}
                </button>
                <button 
                    onClick={() => { setDashboardTab('invites'); setSelectedClientId(null); }}
                    className={`pb-4 px-4 font-bold text-sm transition-all flex items-center gap-2 border-b-2 whitespace-nowrap ${
                        dashboardTab === 'invites'
                        ? 'text-rs-goldDark dark:text-rs-gold border-rs-goldDark dark:border-rs-gold'
                        : 'text-gray-500 border-transparent hover:text-gray-900 dark:hover:text-white'
                    }`}
                >
                    <Ticket size={18} />
                    Convites
                </button>
                 <button 
                    onClick={() => { setDashboardTab('finance'); setSelectedClientId(null); }}
                    className={`pb-4 px-4 font-bold text-sm transition-all flex items-center gap-2 border-b-2 whitespace-nowrap ${
                        dashboardTab === 'finance'
                        ? 'text-rs-goldDark dark:text-rs-gold border-rs-goldDark dark:border-rs-gold'
                        : 'text-gray-500 border-transparent hover:text-gray-900 dark:hover:text-white'
                    }`}
                >
                    <DollarSign size={18} />
                    Financeiro
                </button>
            </div>
        )}

        {/* PLAN SELECTION / BANNER SECTION */}
        {!isAdmin && !isAgency && (
            <div className="mb-8 p-6 bg-gradient-to-r from-gray-900 to-black rounded-2xl text-white relative overflow-hidden border border-rs-gold/30 shadow-2xl animate-fade-in">
                {/* Background Crown Icon */}
                <div className="absolute -top-6 -right-6 p-8 opacity-10 pointer-events-none transform rotate-12">
                    <Crown size={180} />
                </div>
                
                <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                    <div>
                        <div className="flex items-center gap-3 mb-2">
                            <span className="bg-rs-gold text-black text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1">
                                <CheckCircle2 size={12} />
                                Plano Atual: {currentPlan.name}
                            </span>
                            {user.plan === 'free' && (
                                <span className="text-xs text-gray-400 border border-gray-700 px-2 py-1 rounded-full">
                                    Limites: {usageCount}/{currentPlan.maxPages} Sites
                                </span>
                            )}
                        </div>
                        
                        <h2 className="text-3xl font-serif font-bold text-white mb-2">
                            {user.plan === 'free' ? 'Desbloqueie o Poder Total' : 'Gerenciar Assinatura'}
                        </h2>
                        <p className="text-gray-400 text-sm max-w-xl">
                            {user.plan === 'free' 
                                ? 'Você está no plano gratuito. Faça upgrade para remover a marca d\'água, criar sites ilimitados e acessar o painel de agência.' 
                                : 'Aproveite todos os recursos exclusivos do seu plano atual ou mude de nível.'}
                        </p>
                    </div>

                    <button 
                        onClick={() => setShowPlansModal(true)}
                        className="whitespace-nowrap bg-rs-gold hover:bg-white text-black font-bold py-3 px-8 rounded-lg transition-all transform hover:scale-105 shadow-[0_0_20px_rgba(212,175,55,0.3)] flex items-center gap-2"
                    >
                        <Crown size={20} />
                        {user.plan === 'free' ? 'Fazer Upgrade' : 'Ver Planos'}
                    </button>
                </div>
            </div>
        )}

        {/* Analytics Section (If user has sites) */}
        {displayedSites.length > 0 && showAnalytics && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8 animate-fade-in">
                <div className="bg-white dark:bg-rs-dark p-6 rounded-xl border border-gray-200 dark:border-rs-gray shadow-sm">
                    <div className="flex justify-between items-start mb-2">
                        <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Visualizações</p>
                        <BarChart3 size={18} className="text-rs-gold" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{analyticsData.totalViews.toLocaleString()}</h3>
                    <p className="text-[10px] text-green-500 mt-1 flex items-center gap-1"><TrendingUp size={10} /> +12% vs mês anterior</p>
                </div>
                <div className="bg-white dark:bg-rs-dark p-6 rounded-xl border border-gray-200 dark:border-rs-gray shadow-sm">
                    <div className="flex justify-between items-start mb-2">
                        <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Cliques Totais</p>
                        <MousePointer2 size={18} className="text-blue-500" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{analyticsData.totalClicks.toLocaleString()}</h3>
                    <p className="text-[10px] text-gray-400 mt-1">Interações nos botões</p>
                </div>
                <div className="bg-white dark:bg-rs-dark p-6 rounded-xl border border-gray-200 dark:border-rs-gray shadow-sm">
                    <div className="flex justify-between items-start mb-2">
                        <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Leads (WhatsApp)</p>
                        <MessageCircle size={18} className="text-green-500" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{analyticsData.totalLeads.toLocaleString()}</h3>
                    <p className="text-[10px] text-gray-400 mt-1">Cliques em contato</p>
                </div>
                <div className="bg-white dark:bg-rs-dark p-6 rounded-xl border border-gray-200 dark:border-rs-gray shadow-sm flex flex-col justify-center items-center text-center">
                    <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Seu Plano</p>
                    <span className="text-lg font-bold text-rs-goldDark dark:text-rs-gold">{currentPlan.name}</span>
                    <button onClick={() => setShowPlansModal(true)} className="text-[10px] text-gray-400 hover:text-white underline mt-1">Gerenciar Assinatura</button>
                </div>
            </div>
        )}

        {/* Sites Grid (Visible for standard users OR if Agency is on 'sites' tab) */}
        {showSiteGrid && (
            <div className="animate-fade-in">
                <div className="flex justify-between items-end mb-6">
                    <div>
                        <h2 className="text-2xl font-serif font-bold text-gray-900 dark:text-white">
                            {selectedClientId ? `Sites de ${selectedClient?.name}` : 'Meus MiniSites'}
                        </h2>
                        <p className="text-sm text-gray-500">Gerencie suas páginas e acompanhe resultados.</p>
                    </div>
                    {!isAgency && (
                        <div className="text-right">
                            <span className="text-xs font-bold text-gray-500 uppercase">Uso do Plano</span>
                            <div className="w-32 h-2 bg-gray-200 dark:bg-rs-gray rounded-full mt-1 overflow-hidden">
                                <div className="h-full bg-rs-gold" style={{ width: `${usagePercentage}%` }}></div>
                            </div>
                            <span className="text-[10px] text-gray-400">{usageCount} de {currentPlan.maxPages === Infinity ? 'Ilimitado' : currentPlan.maxPages} sites</span>
                        </div>
                    )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {/* Create New Card */}
                    <button 
                        onClick={handleCreateClick}
                        className="group relative h-64 rounded-2xl border-2 border-dashed border-gray-300 dark:border-rs-gray hover:border-rs-goldDark dark:hover:border-rs-gold bg-gray-50 dark:bg-transparent flex flex-col items-center justify-center gap-4 transition-all hover:bg-rs-gold/5"
                    >
                        <div className="w-16 h-16 rounded-full bg-gray-200 dark:bg-rs-gray flex items-center justify-center group-hover:scale-110 transition-transform group-hover:bg-rs-gold group-hover:text-black text-gray-400">
                            {isLimitReached ? <Crown size={32} /> : <Plus size={32} />}
                        </div>
                        <div className="text-center">
                            <h3 className="font-bold text-gray-900 dark:text-white group-hover:text-rs-goldDark dark:group-hover:text-rs-gold transition-colors">Criar Novo MiniSite</h3>
                            <p className="text-xs text-gray-500 px-8 mt-1">
                                {isLimitReached ? 'Limite atingido. Faça upgrade.' : 'Comece do zero ou use um template.'}
                            </p>
                        </div>
                    </button>

                    {/* Existing Sites */}
                    {displayedSites.map((site) => (
                        <div key={site.id} className="group bg-white dark:bg-rs-dark rounded-2xl border border-gray-200 dark:border-rs-gray overflow-hidden hover:shadow-xl hover:border-rs-gold/50 transition-all duration-300 relative">
                            {/* Card Header/Preview */}
                            <div className="h-32 bg-gray-100 dark:bg-black/50 relative overflow-hidden group-hover:h-36 transition-all duration-300">
                                {/* Mockup Preview Background */}
                                <div className="absolute inset-0 flex items-center justify-center opacity-50 blur-sm scale-110">
                                    <div className="w-full h-full bg-gradient-to-tr from-gray-200 via-gray-300 to-gray-200 dark:from-rs-gray dark:via-black dark:to-rs-gray"></div>
                                </div>
                                
                                <div className="absolute top-4 right-4 flex gap-2">
                                    <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase backdrop-blur-md ${site.isPublished ? 'bg-green-500/20 text-green-500 border border-green-500/30' : 'bg-gray-500/20 text-gray-400 border border-gray-500/30'}`}>
                                        {site.isPublished ? 'Online' : 'Rascunho'}
                                    </span>
                                </div>
                            </div>

                            {/* Content */}
                            <div className="p-6 relative">
                                {/* Overlapping Avatar */}
                                <div className="absolute -top-8 left-6 w-16 h-16 rounded-full border-4 border-white dark:border-rs-dark bg-black flex items-center justify-center text-rs-gold font-serif font-bold text-xl shadow-lg">
                                    {site.name.charAt(0)}
                                </div>

                                <div className="mt-8">
                                    <h3 className="font-bold text-lg text-gray-900 dark:text-white truncate">{site.name}</h3>
                                    <a href={`/${site.slug}`} target="_blank" rel="noreferrer" className="text-xs text-gray-500 hover:text-rs-goldDark dark:hover:text-rs-gold transition-colors flex items-center gap-1 mb-4">
                                        bio.rs/{site.slug} <ExternalLink size={10} />
                                    </a>

                                    <div className="grid grid-cols-2 gap-4 py-4 border-t border-gray-100 dark:border-rs-gray">
                                        <div>
                                            <p className="text-[10px] text-gray-400 uppercase font-bold">Visualizações</p>
                                            <p className="font-mono font-bold text-gray-800 dark:text-gray-200">{site.views}</p>
                                        </div>
                                        <div>
                                            <p className="text-[10px] text-gray-400 uppercase font-bold">Cliques</p>
                                            <p className="font-mono font-bold text-gray-800 dark:text-gray-200">
                                                {site.sections.reduce((acc, sec) => acc + (sec.clicks || 0), 0)}
                                            </p>
                                        </div>
                                    </div>

                                    <div className="flex gap-2 mt-2">
                                        <button 
                                            onClick={() => onEdit(site)}
                                            className="flex-1 bg-rs-goldDark dark:bg-rs-gold hover:bg-yellow-600 dark:hover:bg-yellow-500 text-white dark:text-black py-2 rounded-lg font-bold text-sm transition-colors flex items-center justify-center gap-2"
                                        >
                                            <Edit3 size={16} /> Editar
                                        </button>
                                        <button 
                                            onClick={() => onView(site.slug)}
                                            className="px-3 border border-gray-300 dark:border-rs-gray hover:border-rs-goldDark dark:hover:border-rs-gold rounded-lg text-gray-500 hover:text-rs-goldDark dark:hover:text-rs-gold transition-colors"
                                            title="Visualizar"
                                        >
                                            <Smartphone size={18} />
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        )}
        
        {/* FINANCE TAB CONTENT - AGENCY (Preserved from previous step) */}
        {isAgency && dashboardTab === 'finance' && !selectedClientId && (
            <div className="space-y-6 animate-fade-in">
                {/* Financial KPIs */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-white dark:bg-rs-dark p-6 rounded-xl border border-gray-200 dark:border-rs-gray shadow-sm">
                        <div className="flex justify-between items-start mb-2">
                            <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Receita Bruta (Projetada)</p>
                            <DollarSign size={18} className="text-green-500" />
                        </div>
                        <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                            R$ {financeData.projectedRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </h3>
                        <p className="text-[10px] text-gray-400 mt-1">Soma das mensalidades cadastradas.</p>
                    </div>
                    <div className="bg-white dark:bg-rs-dark p-6 rounded-xl border border-gray-200 dark:border-rs-gray shadow-sm border-l-4 border-l-red-500">
                        <div className="flex justify-between items-start mb-2">
                            <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Taxa da Plataforma (10%)</p>
                            <Percent size={18} className="text-red-500" />
                        </div>
                        <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                            R$ {(financeData.projectedRevenue * 0.10).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </h3>
                        <p className="text-[10px] text-gray-400 mt-1">Custo operacional.</p>
                    </div>
                    <div className="bg-white dark:bg-rs-dark p-6 rounded-xl border border-gray-200 dark:border-rs-gray shadow-sm border-l-4 border-l-green-500">
                        <div className="flex justify-between items-start mb-2">
                            <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Lucro Líquido Estimado</p>
                            <TrendingUp size={18} className="text-green-500" />
                        </div>
                        <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                            R$ {(financeData.projectedRevenue * 0.90).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </h3>
                        <p className="text-[10px] text-gray-400 mt-1">Seu lucro após taxas.</p>
                    </div>
                    <div className="bg-white dark:bg-rs-dark p-6 rounded-xl border border-gray-200 dark:border-rs-gray shadow-sm">
                        <div className="flex justify-between items-start mb-2">
                            <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Pagamentos Reais (Mês)</p>
                            <Wallet size={18} className="text-blue-500" />
                        </div>
                        <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                            R$ {financeData.mrr.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </h3>
                        <p className="text-[10px] text-gray-400 mt-1">Confirmados via transações.</p>
                    </div>
                </div>

                {/* Transactions List */}
                <div className="bg-white dark:bg-rs-dark rounded-xl border border-gray-200 dark:border-rs-gray overflow-hidden">
                    <div className="p-4 border-b border-gray-200 dark:border-rs-gray">
                        <h3 className="font-bold text-lg text-gray-900 dark:text-white">Histórico de Transações</h3>
                    </div>
                    <table className="w-full text-sm text-left">
                        <thead className="bg-gray-50 dark:bg-black/20 text-gray-500 font-bold uppercase text-xs">
                            <tr>
                                <th className="p-4">Data</th>
                                <th className="p-4">Cliente</th>
                                <th className="p-4">Descrição</th>
                                <th className="p-4 text-right">Valor</th>
                                <th className="p-4 text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-white/5">
                            {payments.map(p => (
                                <tr key={p.id} className="hover:bg-gray-50 dark:hover:bg-white/5">
                                    <td className="p-4">{new Date(p.date).toLocaleDateString()}</td>
                                    <td className="p-4 font-bold">{clients.find(c => c.id === p.clientId)?.name || 'Cliente Removido'}</td>
                                    <td className="p-4 text-xs text-gray-500">{p.notes}</td>
                                    <td className="p-4 text-right">R$ {p.amount.toFixed(2)}</td>
                                    <td className="p-4 text-center">
                                        <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${p.status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                            {p.status}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                            {payments.length === 0 && <tr><td colSpan={5} className="p-8 text-center text-gray-500">Nenhuma transação registrada.</td></tr>}
                        </tbody>
                    </table>
                </div>
            </div>
        )}

        {/* --- MODALS --- */}

        {/* 1. PLANS SELECTION MODAL (NEW) */}
        {showPlansModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
                <div className="w-full max-w-4xl bg-white dark:bg-rs-dark border border-gray-200 dark:border-rs-gold/30 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
                    <div className="p-6 border-b border-gray-200 dark:border-gray-800 flex justify-between items-center bg-gray-50 dark:bg-black/20 shrink-0">
                        <div>
                            <h3 className="font-serif font-bold text-xl text-gray-900 dark:text-white">Gerenciar Assinatura</h3>
                            <p className="text-sm text-gray-500">Escolha o plano ideal para suas necessidades.</p>
                        </div>
                        <button onClick={() => setShowPlansModal(false)} className="text-gray-400 hover:text-red-500 transition-colors">
                            <X size={20} />
                        </button>
                    </div>
                    
                    <div className="overflow-y-auto p-6 custom-scrollbar">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            {Object.entries(PLANS).filter(([key]) => key !== 'admin_master').map(([key, plan]) => {
                                const isCurrent = user.plan === key;
                                const isHighlighted = key === 'pro';
                                return (
                                    <div 
                                        key={key} 
                                        className={`p-6 rounded-xl border flex flex-col relative transition-all ${
                                            isHighlighted ? 'border-rs-gold bg-black/5 dark:bg-black/20 scale-105 shadow-xl z-10' : 'border-gray-200 dark:border-rs-gray bg-white dark:bg-rs-black'
                                        } ${isCurrent ? 'ring-2 ring-green-500 border-transparent' : ''}`}
                                    >
                                        {isHighlighted && (
                                            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-rs-gold text-black text-[10px] font-bold uppercase px-3 py-1 rounded-full shadow-md">
                                                Recomendado
                                            </div>
                                        )}
                                        
                                        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{plan.name}</h3>
                                        <p className="text-3xl font-bold text-rs-goldDark dark:text-rs-gold mb-6">{plan.price}</p>
                                        
                                        <ul className="space-y-3 mb-8 flex-1">
                                            {plan.features.map((feat, i) => (
                                                <li key={i} className="flex items-start gap-2 text-sm text-gray-600 dark:text-gray-400">
                                                    <CheckCircle2 size={16} className="text-green-500 shrink-0 mt-0.5" />
                                                    {feat}
                                                </li>
                                            ))}
                                        </ul>

                                        <button 
                                            onClick={() => handlePlanSelect(key as UserPlan)}
                                            disabled={isCurrent}
                                            className={`w-full py-3 rounded-lg font-bold uppercase tracking-wider text-xs transition-all ${
                                                isCurrent 
                                                ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 border border-green-200 dark:border-green-800 cursor-default'
                                                : isHighlighted 
                                                    ? 'bg-rs-gold hover:bg-rs-goldDark text-black shadow-lg hover:shadow-rs-gold/30'
                                                    : 'bg-gray-100 dark:bg-white/10 hover:bg-gray-200 dark:hover:bg-white/20 text-gray-900 dark:text-white'
                                            }`}
                                        >
                                            {isCurrent ? 'Plano Atual' : key === 'free' ? 'Selecionar' : 'Fazer Upgrade'}
                                        </button>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* 2. PAYMENT CONFIRMATION MODAL (NEW) */}
        {upgradeTarget && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-fade-in">
                <div className="w-full max-w-md bg-white dark:bg-rs-dark border border-rs-gold rounded-xl shadow-2xl overflow-hidden relative">
                    <button onClick={() => setUpgradeTarget(null)} className="absolute top-4 right-4 text-gray-400 hover:text-white"><X size={20} /></button>
                    
                    <div className="p-8 text-center">
                        <div className="w-16 h-16 bg-rs-gold/20 rounded-full flex items-center justify-center mx-auto mb-4 text-rs-gold">
                            <CreditCard size={32} />
                        </div>
                        <h3 className="text-2xl font-serif font-bold text-gray-900 dark:text-white mb-2">Confirmar Upgrade</h3>
                        <p className="text-gray-500 mb-6">Você está assinando o plano <span className="font-bold text-white">{PLANS[upgradeTarget].name}</span>.</p>
                        
                        <div className="bg-gray-50 dark:bg-black/30 rounded-lg p-4 mb-6 border border-gray-200 dark:border-rs-gray">
                            <div className="flex justify-between items-center mb-2">
                                <span className="text-sm text-gray-500">Valor Mensal</span>
                                <span className="font-bold text-lg text-white">{PLANS[upgradeTarget].price}</span>
                            </div>
                            <div className="w-full h-px bg-gray-200 dark:bg-gray-700 my-2" />
                            <div className="flex items-center gap-2 text-xs text-green-500 justify-center">
                                <Shield size={12} /> Pagamento 100% Seguro
                            </div>
                        </div>

                        <button 
                            onClick={handleConfirmPayment}
                            disabled={isProcessing}
                            className="w-full py-3 bg-rs-gold hover:bg-rs-goldDark text-black font-bold rounded-lg shadow-lg flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {isProcessing ? <Loader2 size={18} className="animate-spin" /> : <CheckCircle2 size={18} />}
                            {isProcessing ? 'Processando...' : 'Confirmar e Assinar'}
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* 3. CLIENT MODAL (Existing) */}
        {isClientModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
                <div className="w-full max-w-2xl bg-white dark:bg-rs-dark border border-gray-200 dark:border-rs-gold/30 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
                    <div className="p-6 border-b border-gray-200 dark:border-gray-800 flex justify-between items-center bg-gray-50 dark:bg-black/20 shrink-0">
                        <h3 className="font-serif font-bold text-xl text-gray-900 dark:text-white">
                            {editingClientId ? 'Editar Cliente' : 'Novo Cliente'}
                        </h3>
                        <button onClick={() => setIsClientModalOpen(false)} className="text-gray-400 hover:text-red-500 transition-colors">
                            <X size={20} />
                        </button>
                    </div>
                    
                    <div className="overflow-y-auto p-6 custom-scrollbar">
                        <form onSubmit={handleSaveClient} className="space-y-6">
                            
                            {/* NEW FINANCIAL SECTION IN MODAL */}
                            <div className="bg-rs-gold/10 border border-rs-gold/30 rounded-lg p-4 mb-4">
                                <h4 className="text-xs font-bold text-rs-goldDark dark:text-rs-gold uppercase tracking-widest mb-3 flex items-center gap-2">
                                    <DollarSign size={14} /> Configuração Financeira
                                </h4>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="col-span-2 md:col-span-1">
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Valor da Mensalidade (R$)</label>
                                        <input 
                                            type="number" 
                                            required
                                            min="5" 
                                            step="0.01"
                                            className="w-full bg-white dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold text-lg font-bold"
                                            value={clientForm.monthlyFee}
                                            onChange={e => setClientForm({...clientForm, monthlyFee: parseFloat(e.target.value) || 0})}
                                            placeholder="0.00"
                                        />
                                        <p className="text-[10px] text-gray-400 mt-1">Mínimo R$ 5,00 por cliente.</p>
                                    </div>
                                    <div className="col-span-2 md:col-span-1 flex flex-col justify-center gap-1 text-xs border-l border-gray-300 dark:border-gray-700 pl-4">
                                        <div className="flex justify-between">
                                            <span className="text-gray-500">Sua Receita (90%):</span>
                                            <span className="font-bold text-green-500">R$ {(clientForm.monthlyFee * 0.90).toFixed(2)}</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-gray-500">Taxa Plataforma (10%):</span>
                                            <span className="font-bold text-red-400">R$ {(clientForm.monthlyFee * 0.10).toFixed(2)}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Section 1: Basic Info */}
                            <div className="space-y-4">
                                <h4 className="text-xs font-bold text-rs-goldDark dark:text-rs-gold uppercase tracking-widest border-b border-gray-200 dark:border-rs-gray pb-2">Dados Pessoais</h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="col-span-2">
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Nome Completo</label>
                                        <input 
                                            type="text" 
                                            required
                                            className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                            value={clientForm.name}
                                            onChange={e => setClientForm({...clientForm, name: e.target.value})}
                                        />
                                    </div>
                                    <div className="col-span-2 md:col-span-1">
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">E-mail</label>
                                        <input 
                                            type="email" 
                                            required
                                            className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                            value={clientForm.email}
                                            onChange={e => setClientForm({...clientForm, email: e.target.value})}
                                        />
                                    </div>
                                    <div className="col-span-2 md:col-span-1">
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Telefone / WhatsApp</label>
                                        <input 
                                            type="text" 
                                            className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                            value={clientForm.phone}
                                            onChange={e => setClientForm({...clientForm, phone: e.target.value})}
                                            placeholder="(00) 00000-0000"
                                        />
                                    </div>
                                    <div className="col-span-2 md:col-span-1">
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">CPF</label>
                                        <input 
                                            type="text" 
                                            className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                            value={clientForm.cpf}
                                            onChange={e => setClientForm({...clientForm, cpf: e.target.value})}
                                            placeholder="000.000.000-00"
                                        />
                                    </div>
                                    <div className="col-span-2 md:col-span-1">
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Data de Nascimento</label>
                                        <input 
                                            type="date" 
                                            className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                            value={clientForm.birthDate}
                                            onChange={e => setClientForm({...clientForm, birthDate: e.target.value})}
                                        />
                                    </div>
                                </div>
                            </div>

                            {/* Section 2: Address */}
                            <div className="space-y-4">
                                <h4 className="text-xs font-bold text-rs-goldDark dark:text-rs-gold uppercase tracking-widest border-b border-gray-200 dark:border-rs-gray pb-2">Endereço</h4>
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <div className="col-span-1">
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">CEP</label>
                                        <input 
                                            type="text" 
                                            className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                            value={clientForm.address.zip}
                                            onChange={e => setClientForm({...clientForm, address: {...clientForm.address, zip: e.target.value}})}
                                        />
                                    </div>
                                    <div className="col-span-3">
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Logradouro</label>
                                        <input 
                                            type="text" 
                                            className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                            value={clientForm.address.line}
                                            onChange={e => setClientForm({...clientForm, address: {...clientForm.address, line: e.target.value}})}
                                        />
                                    </div>
                                    <div className="col-span-1">
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Número</label>
                                        <input 
                                            type="text" 
                                            className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                            value={clientForm.address.number}
                                            onChange={e => setClientForm({...clientForm, address: {...clientForm.address, number: e.target.value}})}
                                        />
                                    </div>
                                    <div className="col-span-2">
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Cidade</label>
                                        <input 
                                            type="text" 
                                            className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                            value={clientForm.address.city}
                                            onChange={e => setClientForm({...clientForm, address: {...clientForm.address, city: e.target.value}})}
                                        />
                                    </div>
                                    <div className="col-span-1">
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Estado</label>
                                        <input 
                                            type="text" 
                                            className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                            value={clientForm.address.state}
                                            onChange={e => setClientForm({...clientForm, address: {...clientForm.address, state: e.target.value}})}
                                            placeholder="UF"
                                            maxLength={2}
                                        />
                                    </div>
                                </div>
                            </div>

                            {/* Section 3: Management */}
                            <div className="space-y-4">
                                <h4 className="text-xs font-bold text-rs-goldDark dark:text-rs-gold uppercase tracking-widest border-b border-gray-200 dark:border-rs-gray pb-2">Gestão</h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Status</label>
                                        <select
                                            className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                            value={clientForm.status}
                                            onChange={e => setClientForm({...clientForm, status: e.target.value as 'active' | 'inactive'})}
                                        >
                                            <option value="active">Ativo</option>
                                            <option value="inactive">Inativo</option>
                                        </select>
                                    </div>
                                    <div className="col-span-2">
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Notas Internas</label>
                                        <textarea 
                                            className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                            rows={3}
                                            value={clientForm.notes}
                                            onChange={e => setClientForm({...clientForm, notes: e.target.value})}
                                            placeholder="Informações adicionais sobre este cliente..."
                                        />
                                    </div>
                                </div>
                            </div>

                            <div className="pt-4 flex gap-3 justify-end">
                                <button 
                                    type="button" 
                                    onClick={() => setIsClientModalOpen(false)}
                                    className="px-4 py-2 rounded-lg text-gray-500 hover:text-gray-900 dark:hover:text-white font-bold text-sm"
                                >
                                    Cancelar
                                </button>
                                <button 
                                    type="submit"
                                    className="px-6 py-2 bg-rs-goldDark dark:bg-rs-gold text-black rounded-lg font-bold text-sm hover:opacity-90 flex items-center gap-2"
                                >
                                    <Save size={16} />
                                    Salvar Cliente
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        )}

        {/* ... (Existing Payment Modal) ... */}
        {isPaymentModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
                <div className="w-full max-w-lg bg-white dark:bg-rs-dark border border-gray-200 dark:border-rs-gold/30 rounded-xl shadow-2xl overflow-hidden">
                    <div className="p-6 border-b border-gray-200 dark:border-gray-800 flex justify-between items-center bg-gray-50 dark:bg-black/20">
                        <h3 className="font-serif font-bold text-xl text-gray-900 dark:text-white">
                            Nova Transação
                        </h3>
                        <button onClick={() => setIsPaymentModalOpen(false)} className="text-gray-400 hover:text-red-500 transition-colors">
                            <X size={20} />
                        </button>
                    </div>
                    <form onSubmit={handleSavePayment} className="p-6 space-y-4">
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Cliente</label>
                            <select
                                required
                                className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                value={paymentForm.clientId}
                                onChange={e => setPaymentForm({...paymentForm, clientId: e.target.value})}
                            >
                                <option value="">Selecione um cliente...</option>
                                {clients.map(c => (
                                    <option key={c.id} value={c.id}>{c.name} - {c.email}</option>
                                ))}
                            </select>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Valor (R$)</label>
                                <input 
                                    type="number" 
                                    required
                                    step="0.01"
                                    className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                    value={paymentForm.amount}
                                    onChange={e => setPaymentForm({...paymentForm, amount: e.target.value})}
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Data</label>
                                <input 
                                    type="date" 
                                    required
                                    className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                    value={paymentForm.date}
                                    onChange={e => setPaymentForm({...paymentForm, date: e.target.value})}
                                />
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Método</label>
                                <select
                                    className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                    value={paymentForm.method}
                                    onChange={e => setPaymentForm({...paymentForm, method: e.target.value as any})}
                                >
                                    <option value="pix">Pix</option>
                                    <option value="card">Cartão de Crédito</option>
                                    <option value="boleto">Boleto</option>
                                    <option value="cash">Dinheiro</option>
                                    <option value="transfer">Transferência</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Status</label>
                                <select
                                    className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                    value={paymentForm.status}
                                    onChange={e => setPaymentForm({...paymentForm, status: e.target.value as any})}
                                >
                                    <option value="paid">Pago</option>
                                    <option value="pending">Pendente</option>
                                    <option value="overdue">Atrasado</option>
                                    <option value="cancelled">Cancelado</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Observações</label>
                            <textarea 
                                rows={2}
                                className="w-full bg-gray-50 dark:bg-black/50 border border-gray-300 dark:border-gray-700 rounded-lg p-3 text-gray-900 dark:text-white outline-none focus:border-rs-gold"
                                value={paymentForm.notes}
                                onChange={e => setPaymentForm({...paymentForm, notes: e.target.value})}
                                placeholder="Detalhes da transação..."
                            />
                        </div>
                        
                        <div className="pt-4 flex gap-3 justify-end">
                            <button 
                                type="button" 
                                onClick={() => setIsPaymentModalOpen(false)}
                                className="px-4 py-2 rounded-lg text-gray-500 hover:text-gray-900 dark:hover:text-white font-bold text-sm"
                            >
                                Cancelar
                            </button>
                            <button 
                                type="submit"
                                className="px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-bold text-sm flex items-center gap-2 shadow-lg"
                            >
                                <Save size={16} />
                                Registrar Transação
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};