import React, { useState, useEffect } from 'react';
import { Dashboard } from './components/Dashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { Editor } from './components/Editor';
import { Renderer } from './components/Renderer';
import { LandingPage } from './components/LandingPage';
import { Signup } from './components/Signup';
import { Login } from './components/Login';
import { INITIAL_SITES, INITIAL_USER, PLANS, RS_THEME_DARK, RS_THEME_LIGHT } from './constants';
import { BioSite, ViewMode, UserProfile, UserPlan, AgencyClient, ClientPayment, SystemLog, Agency } from './types';
import { supabase } from './supabaseClient';

export default function App() {
  const [user, setUser] = useState<UserProfile>(INITIAL_USER);
  const [sites, setSites] = useState<BioSite[]>(INITIAL_SITES);
  const [clients, setClients] = useState<AgencyClient[]>([]); // State for Agency Clients
  const [payments, setPayments] = useState<ClientPayment[]>([]); // State for Payments
  const [logs, setLogs] = useState<SystemLog[]>([]); // State for System Logs
  
  // -- NEW: Agencies State --
  const [agencies, setAgencies] = useState<Agency[]>([
    { id: '1', name: 'Agência Digital One', email: 'contato@digitalone.com', clientsCount: 12, revenue: 1500, status: 'active', createdAt: new Date() },
    { id: '2', name: 'Marketing Pro', email: 'suporte@mktpro.com.br', clientsCount: 5, revenue: 650, status: 'active', createdAt: new Date() },
    { id: '3', name: 'RS Franquia SP', email: 'sp@rsfranchise.com', clientsCount: 45, revenue: 5800, status: 'inactive', createdAt: new Date() },
  ]);

  const [currentView, setCurrentView] = useState<ViewMode>('landing');
  const [activeSiteId, setActiveSiteId] = useState<string | null>(null);
  
  // Initialize state from localStorage or default to true (Dark Mode)
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('rs-theme-preference');
    return saved !== null ? JSON.parse(saved) : true;
  });

  // Helper for Logging
  const handleAddLog = (action: string, target: string) => {
     const newLog: SystemLog = {
         id: Math.random().toString(36).substr(2, 9),
         actorName: user.name,
         actorEmail: user.email,
         action: action,
         target: target,
         timestamp: new Date()
     };
     setLogs(prev => [newLog, ...prev]);
  };

  // -- Agency Management Handlers --
  const handleAddAgency = (agencyData: Omit<Agency, 'id' | 'createdAt'>) => {
      const newAgency: Agency = {
          ...agencyData,
          id: Math.random().toString(36).substr(2, 9),
          createdAt: new Date()
      };
      setAgencies(prev => [...prev, newAgency]);
      handleAddLog('create_agency', `Criou agência: ${newAgency.name}`);
  };

  const handleUpdateAgency = (updatedAgency: Agency) => {
      setAgencies(prev => prev.map(a => a.id === updatedAgency.id ? updatedAgency : a));
      handleAddLog('update_agency', `Atualizou agência: ${updatedAgency.name}`);
  };

  const handleDeleteAgency = (id: string) => {
      const agency = agencies.find(a => a.id === id);
      if (agency) {
          setAgencies(prev => prev.filter(a => a.id !== id));
          handleAddLog('delete_item', `Removeu agência: ${agency.name}`);
      }
  };


  // Supabase Auth Integration
  useEffect(() => {
    // Check active session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session && session.user) {
        // Map Supabase user to UserProfile
        const mappedUser: UserProfile = {
            id: session.user.id,
            name: session.user.user_metadata.full_name || 'Usuário',
            email: session.user.email || '',
            plan: 'free', // Default, should ideally fetch from DB
            referralCode: `RS-${session.user.id.substr(0,4).toUpperCase()}`
        };
        setUser(mappedUser);
        
        // DEMO FIX: Ensure user sees demo sites if they were initial demo user
        setSites(prev => prev.map(s => {
             // If site belonged to initial user or has no owner, assign to logged in user
             if (s.userId === INITIAL_USER.id) {
                 return { ...s, userId: mappedUser.id };
             }
             return s;
        }));

        if (currentView === 'landing' || currentView === 'login' || currentView === 'signup') {
            setCurrentView('dashboard');
        }
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session && session.user) {
        const mappedUser: UserProfile = {
            id: session.user.id,
            name: session.user.user_metadata.full_name || 'Usuário',
            email: session.user.email || '',
            plan: 'free',
            referralCode: `RS-${session.user.id.substr(0,4).toUpperCase()}`
        };
        setUser(mappedUser);

        // DEMO FIX: Ensure user sees demo sites if they were initial demo user
        setSites(prev => prev.map(s => {
             if (s.userId === INITIAL_USER.id) {
                 return { ...s, userId: mappedUser.id };
             }
             return s;
        }));

        // Only redirect if we are in auth screens
        if (currentView === 'landing' || currentView === 'login' || currentView === 'signup') {
            setCurrentView('dashboard');
        }
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  // Effect to apply the 'dark' class to the html/body and save preference
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('rs-theme-preference', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('rs-theme-preference', 'false');
    }
  }, [isDarkMode]);

  // -- Plan Management --

  const handleUpdatePlan = (newPlan: UserPlan) => {
    setUser(prev => ({ ...prev, plan: newPlan }));
    // Update all existing sites to reflect the new plan (removes/adds watermark immediately)
    setSites(prev => prev.map(site => ({ ...site, plan: newPlan })));
  };

  // -- Navigation Handlers --

  const toggleTheme = () => {
    setIsDarkMode((prev: boolean) => !prev);
    
    // If we are editing a site, we also want to toggle the site's theme 
    // to match the user's preference immediately for a better UX.
    if (activeSiteId) {
       const site = sites.find(s => s.id === activeSiteId);
       if (site) {
           const newTheme = !isDarkMode ? RS_THEME_DARK : RS_THEME_LIGHT; // Logic inverted because state hasn't updated yet in closure
           handleSaveSite({ ...site, theme: newTheme });
       }
    }
  };

  const handleAddClient = (clientData: Omit<AgencyClient, 'id' | 'agencyId' | 'createdAt' | 'updatedAt'> & { agencyId?: string }) => {
      // Check Client Limits if not Admin
      if (user.plan !== 'admin_master') {
          const currentPlanDef = PLANS[user.plan];
          if (clients.length >= currentPlanDef.maxClients) {
              alert(`Limite de clientes do plano ${currentPlanDef.name} atingido (${currentPlanDef.maxClients}).`);
              return;
          }
      }

      const newClient: AgencyClient = {
          ...clientData,
          id: Math.random().toString(36).substr(2, 9),
          agencyId: clientData.agencyId || user.id, // Use passed agencyId (for Admin) or logged user
          createdAt: new Date(),
          updatedAt: new Date(),
          status: clientData.status || 'active'
      };
      setClients([...clients, newClient]);
      
      if (user.plan === 'admin_master') {
          handleAddLog('create_client', `Criou cliente: ${newClient.name}`);
      }
  };

  const handleUpdateClient = (client: AgencyClient) => {
      setClients(prev => prev.map(c => c.id === client.id ? { ...client, updatedAt: new Date() } : c));
      if (user.plan === 'admin_master') {
        handleAddLog('update_client', `Atualizou cliente: ${client.name}`);
      }
  };

  const handleDeleteClient = (id: string) => {
      const client = clients.find(c => c.id === id);
      if (client) {
          setClients(prev => prev.filter(c => c.id !== id));
          handleAddLog('delete_item', `Removeu cliente: ${client.name}`);
      }
  };

  const handleAddPayment = (paymentData: Omit<ClientPayment, 'id'>) => {
      const newPayment: ClientPayment = {
          ...paymentData,
          id: Math.random().toString(36).substr(2, 9)
      };
      setPayments(prev => [newPayment, ...prev]);
      if (user.plan === 'admin_master') {
          handleAddLog('add_payment', `Novo pagamento: R$ ${paymentData.amount}`);
      }
  };

  const handleCreateNew = (clientId?: string) => {
    // Check Creation Limits (Total Sites >= Plan Limit)
    const currentPlanDef = PLANS[user.plan];
    if (sites.length >= currentPlanDef.maxPages) {
        alert(`Limite do plano ${currentPlanDef.name} atingido (${currentPlanDef.maxPages} sites). Por favor, faça upgrade.`);
        return;
    }

    const newSite: BioSite = {
      id: Math.random().toString(36).substr(2, 9),
      userId: user.id, // Always belongs to the logged in user (Agency Owner)
      clientId: clientId, // Linked to a client if provided
      slug: `site-${Math.random().toString(36).substr(2, 5)}`,
      name: 'Novo MiniSite',
      isPublished: false,
      plan: user.plan,
      views: 0,
      theme: isDarkMode ? RS_THEME_DARK : RS_THEME_LIGHT,
      seo: {
        title: 'Meu Novo Site',
        description: '',
        image: ''
      },
      sections: [
        {
          id: 'hero-1',
          type: 'hero',
          content: {
            title: 'Olá, Mundo!',
            subtitle: 'Bem-vindo ao meu novo MiniSite RS.'
          },
          style: { textAlign: 'center' }
        }
      ]
    };

    setSites([...sites, newSite]);
    setActiveSiteId(newSite.id);
    setCurrentView('editor');
  };

  const handleEditSite = (site: BioSite) => {
    setActiveSiteId(site.id);
    setCurrentView('editor');
  };

  const handleSaveSite = (updatedSite: BioSite) => {
    // Logic to detect if site was just published
    const oldSite = sites.find(s => s.id === updatedSite.id);
    if (oldSite && !oldSite.isPublished && updatedSite.isPublished) {
        handleAddLog('publish_site', updatedSite.name);
    }

    setSites(prev => prev.map(s => s.id === updatedSite.id ? updatedSite : s));
  };

  const handleTrackClick = (sectionId: string) => {
      setSites(prev => prev.map(s => {
          if (s.id !== activeSiteId) return s;
          return {
              ...s,
              sections: s.sections.map(sec => 
                  sec.id === sectionId 
                  ? { ...sec, clicks: (sec.clicks || 0) + 1 } 
                  : sec
              )
          };
      }));
  };

  const handleViewSite = (slug: string) => {
    // In a real app this would go to a route. 
    // Here we simulate the public view by changing state and finding the site.
    const site = sites.find(s => s.slug === slug);
    if (site) {
        // Increment views
        setSites(prev => prev.map(s => 
          s.id === site.id ? { ...s, views: s.views + 1 } : s
        ));

        setActiveSiteId(site.id);
        setCurrentView('preview');
    }
  };

  const handleBackToDashboard = () => {
    setActiveSiteId(null);
    setCurrentView('dashboard');
  };

  const handleBackToEditor = () => {
    setCurrentView('editor');
  };

  // -- Render Logic --

  // 1. Landing Page
  if (currentView === 'landing') {
    return (
        <LandingPage 
            onLogin={() => setCurrentView('login')}
            onGetStarted={() => setCurrentView('signup')}
        />
    );
  }

  // 2. Auth Pages
  if (currentView === 'login') {
      return (
          <Login 
            onBack={() => setCurrentView('landing')}
            onSuccess={(loggedUser) => {
                setUser(loggedUser);
                setSites(prev => prev.map(s => s.userId === INITIAL_USER.id ? { ...s, userId: loggedUser.id } : s));
                
                if (loggedUser.plan === 'admin_master') {
                    setCurrentView('dashboard'); 
                } else {
                    setCurrentView('dashboard');
                }
            }}
            onNavigateToSignup={() => setCurrentView('signup')}
          />
      );
  }

  if (currentView === 'signup') {
      return (
          <Signup 
            onBack={() => setCurrentView('landing')}
            onSuccess={(newUser) => {
                setUser(newUser);
                setSites(prev => prev.map(s => s.userId === INITIAL_USER.id ? { ...s, userId: newUser.id } : s));
                setCurrentView('dashboard');
            }}
            onNavigateToLogin={() => setCurrentView('login')}
          />
      );
  }

  // 3. Editor Mode
  if (currentView === 'editor' && activeSiteId) {
    const activeSite = sites.find(s => s.id === activeSiteId);
    if (activeSite) {
      return (
        <Editor 
          site={activeSite} 
          onSave={handleSaveSite} 
          onBack={handleBackToDashboard}
          toggleTheme={toggleTheme}
          isDarkMode={isDarkMode}
        />
      );
    }
  }

  // 4. Public Preview Mode (The "Live" Site)
  if (currentView === 'preview' && activeSiteId) {
     const activeSite = sites.find(s => s.id === activeSiteId);
     if (activeSite) {
         return (
             <div className="w-full h-screen relative">
                 <Renderer 
                    sections={activeSite.sections} 
                    theme={activeSite.theme} 
                    plan={activeSite.plan} 
                    tracking={activeSite.tracking} 
                 />
                 <button 
                    onClick={handleBackToDashboard}
                    className="fixed bottom-4 right-4 bg-black text-white px-4 py-2 rounded-full shadow-lg text-xs font-bold z-50 opacity-50 hover:opacity-100"
                 >
                     Voltar ao App
                 </button>
             </div>
         );
     }
  }

  // 5. Admin Dashboard (Exclusive)
  if (currentView === 'admin' && user.plan === 'admin_master') {
    return (
      <AdminDashboard 
        user={user}
        sites={sites}
        clients={clients}
        payments={payments}
        logs={logs}
        agencies={agencies}
        onAddAgency={handleAddAgency}
        onUpdateAgency={handleUpdateAgency}
        onDeleteAgency={handleDeleteAgency}
        onAddClient={handleAddClient} // Pass Client Handlers
        onUpdateClient={handleUpdateClient} // Pass Client Handlers
        onDeleteClient={handleDeleteClient} // Pass Client Handlers
        onAddPayment={handleAddPayment} // Pass Payment Handler
        onLogout={() => {
          supabase.auth.signOut();
          setCurrentView('landing');
        }}
        onBackToApp={() => setCurrentView('dashboard')}
      />
    );
  }

  // 6. Dashboard (Default authenticated view)
  return (
    <Dashboard 
      user={user} 
      sites={sites} 
      clients={clients}
      payments={payments}
      onCreateNew={handleCreateNew} 
      onAddClient={handleAddClient}
      onUpdateClient={handleUpdateClient}
      onAddPayment={handleAddPayment}
      onEdit={handleEditSite}
      onView={handleViewSite}
      onUpdatePlan={handleUpdatePlan}
      isDarkMode={isDarkMode}
      toggleTheme={toggleTheme}
      onNavigateToAdmin={() => setCurrentView('admin')}
      onLog={handleAddLog}
    />
  );
}