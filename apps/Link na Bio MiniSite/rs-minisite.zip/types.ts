
// The core architecture: We save JSON, not HTML.

export type BlockType = 'hero' | 'text' | 'button' | 'gallery' | 'video' | 'social' | 'product' | 'image-text' | 'whatsapp' | 'divider' | 'spacer' | 'map' | 'countdown' | 'faq' | 'newsletter' | 'bento' | 'carousel';

export type SocialPlatform = 'instagram' | 'facebook' | 'linkedin' | 'twitter' | 'youtube' | 'whatsapp' | 'website';

export type UserPlan = 'free' | 'pro' | 'agency' | 'admin_master';

export interface PlanDefinition {
  id: UserPlan;
  name: string;
  maxPages: number;
  maxClients: number; // New field for Agency limits
  price: string;
  features: string[];
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  plan: UserPlan;
  referralCode?: string; // Unique code for referrals
  referredBy?: string;   // Code of the agency who referred this user
}

export interface Agency {
  id: string;
  name: string;
  email: string;
  clientsCount: number;
  revenue: number;
  status: 'active' | 'inactive';
  createdAt: Date;
}

export interface AgencyClientAddress {
  line: string;
  number: string;
  city: string;
  state: string;
  zip: string;
}

export interface AgencyClient {
  id: string;
  agencyId: string; // Foreign Key equivalent
  name: string; // full_name
  email: string;
  createdAt: Date;
  updatedAt?: Date;
  
  // CRM Fields
  cpf?: string;
  phone?: string;
  birthDate?: string;
  address?: AgencyClientAddress;
  notes?: string;
  status: 'active' | 'inactive';
  
  // Financial
  monthlyFee?: number; // Valor cobrado do cliente final
}

export type PaymentStatus = 'paid' | 'pending' | 'overdue' | 'cancelled';
export type PaymentMethod = 'pix' | 'card' | 'boleto' | 'cash' | 'transfer';

export interface ClientPayment {
  id: string;
  clientId: string;
  amount: number;
  date: Date;
  dueDate: Date;
  status: PaymentStatus;
  method: PaymentMethod;
  notes?: string;
}

export interface SystemLog {
  id: string;
  actorName: string;
  actorEmail: string;
  action: string; // 'create_agency' | 'change_plan' | 'publish_site' | 'delete_item'
  target: string; // Description of what was affected
  timestamp: Date;
}

export interface SocialLink {
  platform: SocialPlatform;
  url: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

// New Interface for Bento Grid Items
export interface BentoItem {
    type: 'image' | 'text' | 'link';
    title?: string;
    subtitle?: string;
    imageSrc?: string;
    url?: string;
    backgroundColor?: string;
    textColor?: string;
}

// New Interface for Carousel Items
export interface CarouselItem {
    imageSrc: string;
    title?: string;
    url?: string;
}

export interface BlockStyle {
  backgroundColor?: string;
  textColor?: string;
  padding?: string;
  borderRadius?: string;
  textAlign?: 'left' | 'center' | 'right';
  // New Background Fields
  backgroundType?: 'color' | 'image' | 'video'; // defaults to 'color' (or none)
  backgroundImage?: string;
  backgroundVideo?: string;
  overlayOpacity?: number; // 0.0 to 1.0 (0% to 100%)
  
  // Spacer & Divider specific
  height?: string; // For spacer (e.g., '50px')
  dividerWidth?: string; // For divider (e.g., '80%')
  dividerThickness?: string; // For divider (e.g., '2px')
}

export interface BlockContent {
  title?: string;
  subtitle?: string;
  imageSrc?: string;
  url?: string;
  label?: string;
  items?: string[]; // For gallery images
  icon?: string;
  socialLinks?: SocialLink[];
  price?: string;    // New field for product
  oldPrice?: string; // New field for product
  whatsappNumber?: string; // For WhatsApp Block
  whatsappMessage?: string; // For WhatsApp Block
  
  // New Fields for Advanced Blocks
  faqItems?: FaqItem[];
  mapAddress?: string; // For Google Maps Embed
  targetDate?: string; // For Countdown ISO String
  placeholderText?: string; // For Newsletter Input
  buttonText?: string; // For Newsletter Button
  
  // Visual Variety
  bentoItems?: BentoItem[]; // Array of 2 items
  carouselItems?: CarouselItem[];
}

export interface Section {
  id: string;
  type: BlockType;
  content: BlockContent;
  style: BlockStyle;
  clicks?: number; // Track clicks per section
}

export interface Theme {
  id: string;
  name: string;
  backgroundColor: string;
  primaryColor: string; // The Gold
  secondaryColor: string;
  textColor: string;
  fontFamily: string;
  
  // Global Background Fields
  backgroundType?: 'color' | 'image' | 'video';
  backgroundImage?: string;
  backgroundVideo?: string;
  backgroundOverlayOpacity?: number;
  
  // Footer Customization
  customFooterText?: string;
}

export interface SeoConfig {
  title: string;
  description: string;
  image: string;
}

export interface TrackingPixels {
  metaPixelId?: string;
  googleAnalyticsId?: string; // G-XXXXXXXXXX
  googleAdsId?: string;       // AW-XXXXXXXXX
  tiktokPixelId?: string;
  pinterestPixelId?: string;
  taboolaPixelId?: string;
}

export interface BioSite {
  id: string;
  userId: string;
  clientId?: string; // Relationship: Optional Foreign Key to AgencyClient
  slug: string;
  name: string;
  plan?: UserPlan;
  sections: Section[];
  theme: Theme;
  isPublished: boolean;
  views: number;
  seo: SeoConfig;
  tracking?: TrackingPixels;
}

export type ViewMode = 'dashboard' | 'editor' | 'preview' | 'landing' | 'login' | 'signup' | 'admin';
