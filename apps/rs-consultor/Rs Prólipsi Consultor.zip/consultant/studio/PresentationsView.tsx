import React from 'react';

const PresentationsView: React.FC = () => {
  return null;
};

export default PresentationsView;