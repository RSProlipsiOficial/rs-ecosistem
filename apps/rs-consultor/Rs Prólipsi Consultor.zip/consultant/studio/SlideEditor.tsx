import React from 'react';

const SlideEditor: React.FC = () => {
  return null;
};

export default SlideEditor;