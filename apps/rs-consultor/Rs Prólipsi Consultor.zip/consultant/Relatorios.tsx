
import React, { useMemo, useState } from 'react';
import { useNavigate, NavLink } from 'react-router-dom';
import Card from '../components/Card';
import { mockUser, mockNetworkReport, mockFullNetwork, countNetworkNodes, mockBonusDepthData, mockBonusFidelityData, mockCycleSummary, mockWalletTransactions } from './data';
import { IconUsers, IconTrendingUp, IconActive, IconInactive, IconHandCoins, IconGitFork, IconAward, IconRepeat, IconStar, IconSearch, IconWhatsapp, IconEye, IconFilter } from '../components/icons';
import Modal from '../components/Modal';
import { ReportModal } from './wallet/SaldoExtrato'; // Reusing ReportModal from SaldoExtrato
import type { WalletTransaction } from '../types';

const formatCurrency = (value: number | string) => {
    const num = typeof value === 'string' ? parseFloat(value) : value;
    return `R$ ${num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

const StatCard: React.FC<{ icon: React.ElementType, title: string, value: string | number, subValue?: string }> = ({ icon: Icon, title, value, subValue }) => (
    <Card className="flex items-center space-x-4">
        <div className="p-3 bg-brand-gray-light rounded-full">
            <Icon size={24} className="text-brand-gold" />
        </div>
        <div>
            <h4 className="text-sm text-brand-text-dim">{title}</h4>
            <p className="text-2xl font-bold text-white">{value}</p>
            {subValue && <p className="text-xs text-brand-text-dim">{subValue}</p>}
        </div>
    </Card>
);

interface BonusSummaryItemProps {
    title: string;
    value: number;
    icon: React.ElementType;
    onClick: () => void;
}

const BonusSummaryItem: React.FC<BonusSummaryItemProps> = ({ title, value, icon: Icon, onClick }) => (
    <button onClick={onClick} className="flex flex-col items-center text-center p-3 bg-brand-gray-light rounded-lg hover:bg-brand-gray transition-colors duration-200 cursor-pointer h-full"> {/* Added h-full for consistent height */}
        <Icon size={28} className="text-brand-gold mb-2 flex-shrink-0" />
        <h4 className="text-sm font-bold text-white mb-1 min-h-12 flex items-center justify-center text-center leading-tight line-clamp-2">{title}</h4> {/* h-12 and flex for vertical centering */}
        <p className="text-lg font-extrabold text-brand-gold">{formatCurrency(value)}</p>
    </button>
);


interface BonusDataMapping {
    title: string;
    icon: React.ElementType;
    transactionType: WalletTransaction['type'] | WalletTransaction['type'][];
    value: number;
}


const UserReportRow = React.memo(({ user }: { user: typeof mockNetworkReport[0] }) => {
    const handleSendWhatsApp = (whatsapp: string) => {
        if (!whatsapp) return;
        const message = `Olá, ${user.name}! Vi seu contato no painel da RS Prólipsi e gostaria de conversar.`;
        const phoneNumber = whatsapp.replace(/\D/g, ''); // Remove non-numeric chars
        const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
        window.open(url, '_blank', 'noopener,noreferrer');
    };

    return (
        <tr className="border-b border-brand-gray-light last:border-b-0 hover:bg-brand-gray-light/50">
            <td className="p-3">
                <div className="flex items-center space-x-3">
                    <img src={user.avatarUrl} alt={user.name} className="h-10 w-10 rounded-full" />
                    <div>
                        <p className="font-semibold text-white text-sm">{user.name}</p>
                        <p className="text-xs text-gray-400">Desde: {new Date(user.joinDate).toLocaleDateString('pt-BR')}</p>
                    </div>
                </div>
            </td>
            <td className="p-3 text-sm font-semibold">{user.pin}</td>
            <td className="p-3 text-sm">
                <span className={`flex items-center gap-2 font-semibold ${user.status === 'active' ? 'text-green-400' : 'text-red-400'}`}>
                    {user.status === 'active' ? <IconActive size={16}/> : <IconInactive size={16}/>}
                    <span className="capitalize">{user.status === 'active' ? 'Ativo' : 'Inativo'}</span>
                </span>
            </td>
            <td className="p-3 text-right font-mono">{user.totalCycles}</td> {/* New column */}
            <td className="p-3 text-right font-mono">{formatCurrency(user.personalVolume)}</td>
            <td className="p-3 text-right font-mono">{formatCurrency(user.groupVolume)}</td>
            <td className="p-3 text-sm flex justify-between items-center">
                {new Date(user.lastActivity).toLocaleDateString('pt-BR')}
                <button 
                    onClick={() => handleSendWhatsApp(user.whatsapp)}
                    className="p-1.5 bg-green-500/10 rounded-full hover:bg-green-500/30 text-green-400 ml-2"
                    title={`Enviar WhatsApp para ${user.name}`}
                >
                    <IconWhatsapp size={16} />
                </button>
            </td>
        </tr>
    );
});

const RelatoriosRede: React.FC = () => {
    const navigate = useNavigate();

    const [searchTerm, setSearchTerm] = useState('');
    const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');

    // Report modal state from SaldoExtrato for reuse
    const [reportModalData, setReportModalData] = useState<{
        isOpen: boolean;
        title: string;
        transactions: WalletTransaction[];
    }>({ isOpen: false, title: '', transactions: [] });

    // --- Bonus Calculations ---
    // DO NOT MODIFY: Fix for "Operator '+' cannot be applied to types 'number[]' and 'number'."
    const totalBonusProfundidade = useMemo(() => {
        return mockBonusDepthData.reduce<number>((levelAcc, level) => {
            return levelAcc + level.cycles.reduce<number>((cycleAcc, cycle) => {
                return cycleAcc + (cycle.peopleCompleted * level.bonusPerPerson);
            }, 0);
        }, 0);
    }, []);

    const userMaxCompletedCycle = Math.max(0, ...mockCycleSummary.filter(c => c.completed > 0).map(c => Number(c.level)));
    // DO NOT MODIFY: Fix for "Operator '+' cannot be applied to types 'number[]' and 'number'."
    const totalBonusFidelidade = useMemo(() => {
        return mockBonusFidelityData.reduce<number>((levelAcc, levelData) => {
            const isEligible = levelData.level <= 5 ? userMaxCompletedCycle >= levelData.level : userMaxCompletedCycle >= 5;
            if (!isEligible) return levelAcc;

            return levelAcc + levelData.cycles.reduce<number>((cycleAcc, cycle) => {
                return cycleAcc + (cycle.peopleCompleted * levelData.bonusPerPerson);
            }, 0);
        }, 0);
    }, [userMaxCompletedCycle]);

    const totalAllBonuses = mockUser.bonusCicloGlobal + mockUser.bonusTopSigme + mockUser.bonusPlanoCarreira + totalBonusProfundidade + totalBonusFidelidade;
    
    const bonusDataMapping: BonusDataMapping[] = useMemo(() => [
        { title: "Bônus Matriz SIGME", value: mockUser.bonusCicloGlobal || 0, icon: IconGitFork, transactionType: 'commission_cycle' },
        { title: "Bônus de Profundidade", value: totalBonusProfundidade, icon: IconUsers, transactionType: 'bonus_compensation' }, // Assuming depth bonus is tracked as compensation for simplicity
        { title: "Bônus de Fidelidade", value: totalBonusFidelidade, icon: IconRepeat, transactionType: 'bonus_fidelity' },
        { title: "Bônus Plano de Carreira", value: mockUser.bonusPlanoCarreira || 0, icon: IconAward, transactionType: 'bonus_career' },
        { title: "Bônus Top SIGME", value: mockUser.bonusTopSigme || 0, icon: IconStar, transactionType: 'bonus_sigme' },
    ], [mockUser, totalBonusProfundidade, totalBonusFidelidade]);

    const showDetailedBonusReport = (title: string, transactionType: WalletTransaction['type'] | WalletTransaction['type'][]) => {
        const typesArray = Array.isArray(transactionType) ? transactionType : [transactionType];
        const relevantTransactions = mockWalletTransactions.filter(t => typesArray.includes(t.type));
        setReportModalData({
            isOpen: true,
            title: `Extrato Detalhado - ${title}`,
            transactions: relevantTransactions,
        });
    };

    // --- Filtered Direct Reports ---
    const filteredDirectReports = useMemo(() => {
        let filtered = mockNetworkReport;

        if (searchTerm.trim()) {
            const lowerCaseSearchTerm = searchTerm.toLowerCase();
            filtered = filtered.filter(user =>
                user.name.toLowerCase().includes(lowerCaseSearchTerm) ||
                user.pin.toLowerCase().includes(lowerCaseSearchTerm) ||
                user.id.toLowerCase().includes(lowerCaseSearchTerm) // Assuming user.id can be consultant ID
            );
        }

        if (filterStatus !== 'all') {
            filtered = filtered.filter(user => user.status === filterStatus);
        }
        return filtered;
    }, [searchTerm, filterStatus]);


    // --- Network Report Stats ---
    const totalDirects = mockNetworkReport.length;
    const activeDirects = mockNetworkReport.filter(d => d.status === 'active').length;
    const totalGroupVolume = mockNetworkReport.reduce((acc, d) => acc + parseFloat(d.groupVolume), 0);
    const totalPeopleInFullNetwork = countNetworkNodes(mockFullNetwork) - 1; // Exclude the root user


    return (
        <div className="space-y-8">
            <div>
                <h1 className="text-3xl font-bold text-brand-gold">Relatórios de Rede</h1>
                <p className="text-gray-400 mt-1">Acompanhe a saúde e o desempenho da sua equipe e seus bônus.</p>
            </div>

            {/* Total Geral de Bônus Acumulados */}
            <Card className="flex flex-col justify-center items-center text-center bg-gradient-to-br from-brand-gray to-brand-gray-dark border-2 border-brand-gold shadow-gold-glow p-6">
                <IconHandCoins size={48} className="text-brand-gold mb-3" />
                <p className="text-gray-400 text-lg">Total Geral de Bônus Acumulados</p>
                <p className="text-5xl font-extrabold text-brand-gold my-2">{formatCurrency(totalAllBonuses)}</p>
            </Card>

            {/* Network Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard icon={IconUsers} title="Total de Pessoas na Rede" value={totalPeopleInFullNetwork.toLocaleString('pt-BR')} subValue="Sua rede completa" />
                <StatCard icon={IconActive} title="Indicados Diretos" value={totalDirects} subValue={`${totalDirects > 0 ? ((activeDirects/totalDirects)*100).toFixed(0) : 0}% ativos`} />
                <StatCard icon={IconTrendingUp} title="Volume Financeiro Gerado" value={formatCurrency(totalGroupVolume)} subValue="Este mês" />
            </div>

            {/* Individual Bonus Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
                {bonusDataMapping.map(bonus => (
                    <BonusSummaryItem
                        key={bonus.title}
                        title={bonus.title}
                        value={bonus.value}
                        icon={bonus.icon}
                        onClick={() => showDetailedBonusReport(bonus.title, bonus.transactionType)}
                    />
                ))}
            </div>
            
            {/* Direct Reports Table */}
            <Card>
                <h2 className="text-xl font-bold text-white mb-4">Desempenho dos Indicados Diretos</h2>
                <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-3 mb-4">
                    <div className="relative flex-grow">
                        <IconSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                        <input 
                            type="text"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            placeholder="Buscar consultor por nome, PIN ou ID..."
                            className="w-full bg-brand-gray border border-brand-gray-light rounded-lg py-3 pl-12 pr-4 focus:ring-2 focus:ring-brand-gold focus:outline-none"
                        />
                    </div>
                    <select
                        aria-label="Filtrar por status"
                        value={filterStatus}
                        onChange={(e) => setFilterStatus(e.target.value as 'all' | 'active' | 'inactive')}
                        className="w-full sm:w-auto bg-brand-gray border border-brand-gray-light rounded-lg py-3 px-4 focus:ring-2 focus:ring-brand-gold focus:outline-none text-sm appearance-none cursor-pointer"
                        style={{backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke-width='2' stroke='%239CA3AF' class='w-4 h-4'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='m19.5 8.25-7.5 7.5-7.5-7.5'/%3E%3C/svg%3E")`, backgroundRepeat: 'no-repeat', backgroundPosition: 'right 0.75rem center'}}
                    >
                        <option value="all">Todos os Status</option>
                        <option value="active">Ativo</option>
                        <option value="inactive">Inativo</option>
                    </select>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="border-b border-brand-gray text-sm text-gray-400">
                            <tr>
                                <th className="p-3">Consultor</th>
                                <th className="p-3">PIN</th>
                                <th className="p-3">Status</th>
                                <th className="p-3 text-right">Ciclos Atuais</th>
                                <th className="p-3 text-right">Volume Pessoal</th>
                                <th className="p-3 text-right">Volume de Grupo</th>
                                <th className="p-3">Última Atividade</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredDirectReports.length > 0 ? (
                                filteredDirectReports.map(user => (
                                    <UserReportRow key={user.id} user={user} />
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={7} className="text-center py-8 text-gray-500">Nenhum indicado direto encontrado com os filtros aplicados.</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </Card>

            {/* Reusing ReportModal from SaldoExtrato for detailed bonus reports */}
            <ReportModal
                isOpen={reportModalData.isOpen}
                onClose={() => setReportModalData({ ...reportModalData, isOpen: false })}
                title={reportModalData.title}
                transactions={reportModalData.transactions}
            />
        </div>
    );
};

export default RelatoriosRede;