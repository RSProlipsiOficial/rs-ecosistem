import React from 'react';
import Card from '../../components/Card';
import { IconDownload, IconImage, IconFileText } from '../../components/icons';
import { mockPromoBanners } from '../data';

const downloadAssets = [
  { id: 'asset-1', title: 'Banner Pack Inicial', type: 'image', url: mockPromoBanners[0].imageUrl, format: 'PNG' },
  { id: 'asset-2', title: 'Banner Cuidados Essenciais', type: 'image', url: mockPromoBanners[1].imageUrl, format: 'PNG' },
  { id: 'asset-3', title: 'Banner Kit Verão', type: 'image', url: mockPromoBanners[2].imageUrl, format: 'PNG' },
  { id: 'asset-4', title: 'Manual do Consultor', type: 'document', url: '#', format: 'PDF' },
  { id: 'asset-5', title: 'Tabela de Preços', type: 'document', url: '#', format: 'PDF' },
  { id: 'asset-6', title: 'Apresentação de Negócios', type: 'document', url: '#', format: 'PDF' },
];

const DownloadCard: React.FC<{ asset: typeof downloadAssets[0] }> = ({ asset }) => {
  const Icon = asset.type === 'image' ? IconImage : IconFileText;
  return (
    <Card className="flex flex-col">
      <div className="relative aspect-video bg-brand-gray-dark rounded-md flex items-center justify-center">
        {asset.type === 'image' ? (
          <img src={asset.url} alt={asset.title} className="max-h-full max-w-full object-contain" />
        ) : (
          <Icon size={48} className="text-brand-text-dim" />
        )}
      </div>
      <div className="mt-4 flex-grow">
        <h3 className="font-semibold text-white">{asset.title}</h3>
        <p className="text-sm text-brand-text-dim">{asset.format}</p>
      </div>
      <a
        href={asset.url}
        download
        className="mt-4 w-full flex items-center justify-center gap-2 bg-brand-gold text-brand-dark font-bold py-2 px-4 rounded-lg hover:bg-yellow-400 transition-colors"
      >
        <IconDownload size={18} />
        <span>Baixar</span>
      </a>
    </Card>
  );
};

const Downloads: React.FC = () => {
  return (
    <div className="animate-fade-in">
      <h2 className="text-2xl font-bold text-white mb-6">Materiais para Download</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {downloadAssets.map(asset => (
          <DownloadCard key={asset.id} asset={asset} />
        ))}
      </div>
    </div>
  );
};

export default Downloads;