import type { User, WalletTransaction, ShopOrder, SystemMessage, CycleInfo, NetworkNode, Invoice, Subscription, AnticipationRequest, Course, CDInfo, CDProduct, CDConsultantOrder, CDInventoryItem, Incentive } from '../types';

export const mockUser: User & { [key: string]: any } = {
  id: 'user-01',
  name: 'Ana Carolina',
  email: 'ana.carolina@example.com',
  avatarUrl: 'https://i.pravatar.cc/150?u=user-01',
  whatsapp: '5511987654321',
  status: 'active',
  pin: 'Ouro',
  cpfCnpj: '123.456.789-00',
  birthDate: '1990-05-15',
  registrationDate: '2024-01-10', // Data de cadastro adicionada
  hasPurchased: true,
  address: {
    zipCode: '01001-000',
    street: 'Praça da Sé',
    number: '1',
    neighborhood: 'Sé',
    city: 'São Paulo',
    state: 'SP',
  },
  bankAccount: {
    bank: 'Banco Digital S.A.',
    agency: '0001',
    accountNumber: '123456-7',
    accountType: 'checking',
    pixKey: 'ana.carolina@example.com',
  },
  // New data for dashboard
  idConsultor: 'C0000111000000',
  graduacao: 'DIAMANTE PRESIDENCIAL',
  categoria: 'DIAMANTE',
  linkIndicacao: 'https://rsprolipsi.com/register/anacarolina',
  linkAfiliado: 'https://rsprolipsi.com/loja/anacarolina',
  personalVolume: 1500,
  groupVolume: 25000,
  totalVolume: 26500,
  bonusCicloGlobal: 216.00,
  bonusTopSigme: 550.00,
  bonusPlanoCarreira: 50.00,
  upline: {
    name: 'Maria Santos',
    avatarUrl: 'https://i.pravatar.cc/150?u=upline-01',
    idConsultor: 'C00001110000002',
    whatsapp: '5511912345678',
  },
};

export const mockPromoBanners = [
  {
    id: 'promo-1',
    preTitle: 'SAIA NA FRENTE COM O',
    title: 'Pack Inicial Full',
    price: 99.90,
    imageUrl: 'https://i.imgur.com/uF4NojZ.png',
    ctaText: 'Adquirir agora',
  },
  {
    id: 'promo-2',
    preTitle: 'NOVA LINHA DE PRODUTOS',
    title: 'Cuidados Essenciais',
    price: 149.90,
    imageUrl: 'https://i.imgur.com/gC27R4s.png',
    ctaText: 'Conheça a linha',
  },
  {
    id: 'promo-3',
    preTitle: 'OFERTA POR TEMPO LIMITADO',
    title: 'Kit Verão Completo',
    price: 129.90,
    imageUrl: 'https://i.imgur.com/3Tf0Q1U.png',
    ctaText: 'Aproveitar',
  },
  {
    id: 'promo-4',
    preTitle: 'VENDA SEM ESTOQUE',
    title: 'Dropshipping',
    price: 0,
    imageUrl: 'https://i.imgur.com/uF4NojZ.png',
    ctaText: 'Saiba Mais',
  },
  {
    id: 'promo-5',
    preTitle: 'SUA LOJA, SEU LUCRO',
    title: 'Venda Direta',
    price: 0,
    imageUrl: 'https://i.imgur.com/gC27R4s.png',
    ctaText: 'Ver Produtos',
  },
  {
    id: 'promo-6',
    preTitle: 'OPORTUNIDADES',
    title: 'Outros',
    price: 0,
    imageUrl: 'https://i.imgur.com/3Tf0Q1U.png',
    ctaText: 'Explorar',
  }
];

export const mockWalletTransactions: WalletTransaction[] = [
  { id: 'tx-01', date: '2024-07-22', description: 'Bônus de conclusão de ciclo', amount: 216, type: 'commission_cycle', status: 'completed', details: { bonusType: 'Ciclo Universal L1', sourceUser: { id: 'network-l1', name: 'Rede L1', avatarUrl: 'https://i.pravatar.cc/150?u=net1' }, networkLevel: 1, dynamicCompressionLevel: 1 } },
  { id: 'tx-02', date: '2024-07-21', description: 'Comissão - Venda RS Shop #5432', amount: 25.50, type: 'commission_shop', status: 'completed', details: { bonusType: 'Comissão Venda Direta', sourceUser: { id: 'client-xyz', name: 'Cliente Final' }, networkLevel: 0 } },
  { id: 'tx-03', date: '2024-07-20', description: 'Saque para conta bancária', amount: -150, type: 'withdrawal', status: 'completed' },
  { id: 'tx-04', date: '2024-07-18', description: 'Bônus de Plano de Carreira', amount: 50, type: 'bonus_career', status: 'completed', details: { bonusType: 'Avanço para PIN Prata', sourceUser: { id: 'system', name: 'RS Prólipsi' }, networkLevel: 0 } },
  { id: 'tx-05', date: '2024-07-15', description: 'Transferência enviada para user-05', amount: -30, type: 'transfer_out', status: 'completed' },
  { id: 'tx-06', date: '2024-07-12', description: 'Bônus de compensação', amount: 12.75, type: 'bonus_compensation', status: 'completed', details: { bonusType: 'Indicação Direta', sourceUser: { id: 'user-14', name: 'Carlos Souza', avatarUrl: 'https://i.pravatar.cc/150?u=user-14' }, networkLevel: 2, dynamicCompressionLevel: 3 } },
  { id: 'tx-07', date: '2024-07-10', description: 'Transferência recebida de user-02', amount: 45, type: 'transfer_in', status: 'pending' },
  { id: 'tx-08', date: '2024-07-25', description: 'Bônus SIGME Mensal', amount: 450.00, type: 'bonus_sigme', status: 'completed', details: { bonusType: 'Matriz 5x5', sourceUser: { id: 'user-22', name: 'Juliana Almeida', avatarUrl: 'https://i.pravatar.cc/150?u=user-22' }, networkLevel: 4 } },
  { id: 'tx-09', date: '2024-07-28', description: 'Bônus Fidelidade Trimestral', amount: 125.50, type: 'bonus_fidelity', status: 'completed', details: { bonusType: 'Participação de Lucros', sourceUser: { id: 'system', name: 'RS Prólipsi' }, networkLevel: 0 } },
];

export const mockShopOrders: ShopOrder[] = [
    { id: 'order-01', date: '2024-07-21', product: 'Kit Essencial Prólipsi', status: 'shipped', commission: 25.50 },
    { id: 'order-02', date: '2024-07-15', product: 'Sérum Rejuvenescedor', status: 'completed', commission: 15.75 },
    { id: 'order-03', date: '2024-07-05', product: 'Creme Hidratante Noturno', status: 'completed', commission: 12.30 },
];

export const mockMessages: SystemMessage[] = [
  { id: 'msg-04', title: '💡 Oportunidade na sua Rede!', content: 'Seu indicado direto, Carlos Souza, precisa de apenas R$ 50,00 em volume para atingir o próximo PIN! Envie uma mensagem de incentivo para ajudá-lo a fechar o mês com chave de ouro.', date: '2024-07-28', read: false, type: 'alert' },
  { id: 'msg-01', title: 'Alerta de Manutenção Programada', content: 'Nossa plataforma passará por uma manutenção programada na próxima madrugada. A previsão é que os serviços fiquem indisponíveis por aproximadamente 2 horas, entre 3h e 5h da manhã.', date: '2024-07-27', read: false, type: 'alert' },
  { id: 'msg-02', title: 'Novos Produtos na RS Shop!', content: 'Confira os lançamentos incríveis que acabaram de chegar na RS Shop. Acesse a seção de Marketplace para ver a nova linha de cuidados faciais e as ferramentas de marketing atualizadas.', date: '2024-07-20', read: false, type: 'announcement' },
  { id: 'msg-05', title: '📈 Análise Preditiva RSIA', content: 'Identificamos 3 consultores na sua rede (até o 3º nível) com alto potencial de crescimento este mês. Clique aqui para ver um relatório detalhado e sugestões de ação.', date: '2024-07-25', read: true, type: 'announcement' },
  { id: 'msg-03', title: 'Promoção de Aniversário', content: 'Aproveite 20% de desconto em toda a linha facial esta semana para comemorar nosso aniversário. Use o cupom ANIVERRS no checkout!', date: '2024-07-18', read: true, type: 'promotion' },
];

const generateParticipants = (count: number, startIndex: number): User[] => {
    const pins = ['Bronze', 'Iniciante', 'Bronze', 'Prata', 'Iniciante', 'Bronze', 'Bronze', 'Prata', 'Iniciante', 'Bronze'];
    return Array.from({ length: count }, (_, i) => {
        const userIndex = startIndex + i;
        const birthYear = 1975 + (userIndex % 25); // Years from 1975 to 1999
        const birthMonth = (userIndex % 12) + 1; // Months from 1 to 12
        const birthDay = (userIndex % 28) + 1; // Days from 1 to 28
        return {
            id: `user-${userIndex.toString().padStart(2, '0')}`,
            name: `Consultor ${String.fromCharCode(65 + userIndex - 2)}`,
            email: `consultor${userIndex}@example.com`,
            avatarUrl: `https://i.pravatar.cc/150?u=user-${userIndex.toString().padStart(2, '0')}`,
            whatsapp: `55119999999${userIndex.toString().padStart(2, '0')}`,
            status: Math.random() > 0.2 ? 'active' : 'inactive' as 'active' | 'inactive' | 'pending',
            pin: pins[i % pins.length],
            cpfCnpj: '000.000.000-00',
            birthDate: `${birthYear}-${String(birthMonth).padStart(2, '0')}-${String(birthDay).padStart(2, '0')}`,
            registrationDate: '2024-01-10',
            hasPurchased: Math.random() > 0.4, // 60% chance of having made a purchase
            address: { zipCode: '', street: '', number: '', neighborhood: '', city: '', state: '' },
            bankAccount: { bank: '', agency: '', accountNumber: '', accountType: 'checking', pixKey: '' }
        };
    });
};

export const mockNetworkMembers: User[] = generateParticipants(50, 2);


// FIX: Exported createEmptyNode to make it available for import in other modules.
export const createEmptyNode = (id: string, level: number): NetworkNode => ({
    id,
    name: 'Vago',
    email: '',
    avatarUrl: 'https://via.placeholder.com/150/222222/888888?text=+',
    whatsapp: '',
    status: 'inactive',
    pin: 'Vago',
    cpfCnpj: '',
    birthDate: '',
    registrationDate: '',
    hasPurchased: false,
    level,
    children: [],
    isEmpty: true,
    address: { zipCode: '', street: '', number: '', neighborhood: '', city: '', state: '' },
    bankAccount: { bank: '', agency: '', accountNumber: '', accountType: 'checking', pixKey: '' }
});


export const mockCycleInfo: CycleInfo[] = [
    { level: 1, completed: true, participants: generateParticipants(6, 2), personalConsumption: 100, cycleTotal: 700, divisionBase: 600, amountReceived: 216 },
    { level: 2, completed: true, participants: generateParticipants(6, 8), personalConsumption: 100, cycleTotal: 700, divisionBase: 600, amountReceived: 216 },
    { level: 3, completed: false, participants: generateParticipants(4, 14), personalConsumption: 100, cycleTotal: 500, divisionBase: 600, amountReceived: 0 },
    { level: 4, completed: false, participants: [], personalConsumption: 0, cycleTotal: 0, divisionBase: 600, amountReceived: 0 },
];

export const mockCycleProgress = {
    l1: { current: 6, total: 6 },
    l2: { current: 30, total: 36 },
    l3: { current: 88, total: 216 },
};

export const mockCycleSummary = [
    { level: '1', completed: 1, bonus: 108.00, lastClosed: '2024-07-22' },
    { level: '2', completed: 1, bonus: 108.00, lastClosed: '2024-07-15' },
    { level: '3', completed: 1, bonus: 108.00, lastClosed: '2024-07-08' },
    { level: '4', completed: 0, bonus: 0.00, lastClosed: '-' },
    { level: '5', completed: 0, bonus: 0.00, lastClosed: '-' },
    { level: '6', completed: 0, bonus: 0.00, lastClosed: '-' },
    { level: '7', completed: 0, bonus: 0.00, lastClosed: '-' },
    { level: '8', completed: 0, bonus: 0.00, lastClosed: '-' },
    { level: '9', completed: 0, bonus: 0.00, lastClosed: '-' },
    { level: '10', completed: 0, bonus: 0.00, lastClosed: '-' },
];


export const mockNetwork: NetworkNode = {
  ...mockUser, // Ana Carolina
  level: 0,
  children: [
    { // Consultor A
        ...generateParticipants(1, 2)[0], 
        level: 1, 
        children: [ // This node will have 2 children, showing nesting still works
            { ...generateParticipants(1, 8)[0], level: 2, children: [] }, // Consultor G
            { ...generateParticipants(1, 9)[0], level: 2, children: [] }, // Consultor H
        ] 
    },
    { // Consultor B
        ...generateParticipants(1, 3)[0], 
        level: 1, 
        children: [] 
    },
    { // Consultor C
        ...generateParticipants(1, 4)[0], 
        level: 1,
        children: []
    },
    { // Consultor D
        ...generateParticipants(1, 5)[0],
        status: 'inactive', 
        level: 1, 
        children: [] 
    },
    createEmptyNode('empty-L1-1', 1),
    createEmptyNode('empty-L1-2', 1),
  ]
};

export const mockDeepNetwork: NetworkNode = {
  ...mockUser, // Ana Carolina - L0
  level: 0,
  children: [
    { // Consultor M (from another batch) - L1
        ...generateParticipants(1, 14)[0], 
        name: 'Consultor M',
        pin: 'Bronze',
        level: 1, 
        children: [ // L2
            { 
                ...generateParticipants(1, 20)[0], 
                name: 'Consultor S',
                pin: 'Iniciante',
                level: 2, 
                children: [ // L3
                    { ...generateParticipants(1, 21)[0], name: 'Consultor T', pin: 'Iniciante', level: 3, children: [] },
                    createEmptyNode('empty-l3-1', 3)
                ] 
            },
            { ...generateParticipants(1, 22)[0], name: 'Consultor U', pin: 'Bronze', level: 2, children: [] },
        ] 
    },
    { // Consultor N - L1
        ...generateParticipants(1, 15)[0], 
        name: 'Consultor N',
        pin: 'Iniciante',
        level: 1, 
        children: [ // L2
             { ...generateParticipants(1, 23)[0], name: 'Consultor V', pin: 'Bronze', level: 2, children: [] },
             createEmptyNode('empty-l2-1', 2)
        ] 
    },
    { // Consultor O - L1
        ...generateParticipants(1, 16)[0], 
        name: 'Consultor O',
        pin: 'Bronze',
        level: 1,
        children: []
    },
    { // Consultor P - L1
        ...generateParticipants(1, 17)[0],
        name: 'Consultor P',
        pin: 'Prata',
        status: 'active', 
        level: 1, 
        children: [] 
    },
    createEmptyNode('empty-L1-1', 1),
    createEmptyNode('empty-L1-2', 1),
  ]
};

export const mockBonuses = [
    { id: 'bonus-01', date: '2024-07-22', type: 'Direto', source: 'user-02', status: 'pago', amount: 12.75 },
    { id: 'bonus-02', date: '2024-07-20', type: 'Derramamento', source: 'user-08', status: 'pago', amount: 5.50 },
    { id: 'bonus-03', date: '2024-07-18', type: 'Indireto', source: 'user-04', status: 'pago', amount: 8.00 },
    { id: 'bonus-04', date: '2024-07-15', type: 'Direto', source: 'user-03', status: 'pago', amount: 12.75 },
    { id: 'bonus-05', date: '2024-07-10', type: 'Derramamento', source: 'user-10', status: 'pendente', amount: 5.50 },
];


export const mockCareerPlan = {
    currentCycles: 100, // Updated for better VMEc demo
    quarterlyEarnings: 1250.75,
    monthlyGrowth: [
        { month: 'Maio', L1: 4, L2: 2, L3: 1 },
        { month: 'Junho', L1: 6, L2: 3, L3: 1 },
        { month: 'Julho', L1: 5, L2: 2, L3: 0 },
    ],
    pinTable: [
        { pin: 'Bronze', cycles: 5, minLines: 0, vmec: '—', bonus: 13.50, iconColor: '#cd7f32' }, // Bronze color
        { pin: 'Prata', cycles: 15, minLines: 1, vmec: '100%', bonus: 40.50, iconColor: '#c0c0c0' },
        { pin: 'Ouro', cycles: 70, minLines: 1, vmec: '100%', bonus: 189.00, iconColor: '#ffd700' },
        { pin: 'Safira', cycles: 150, minLines: 2, vmec: '60/40', bonus: 405.00, iconColor: '#0f52ba' },
        { pin: 'Esmeralda', cycles: 300, minLines: 2, vmec: '60/40', bonus: 810.00, iconColor: '#50c878' },
        { pin: 'Topázio', cycles: 500, minLines: 2, vmec: '60/40', bonus: 1350.00, iconColor: '#ffc87c' },
        { pin: 'Rubi', cycles: 750, minLines: 3, vmec: '50/30/20', bonus: 2025.00, iconColor: '#e0115f' },
        { pin: 'Diamante', cycles: 1500, minLines: 3, vmec: '50/30/20', bonus: 4050.00, iconColor: '#b9f2ff' },
        { pin: 'Duplo Diamante', cycles: 3000, minLines: 4, vmec: '40/30/20/10', bonus: 18450.00, iconColor: '#82EEFF' },
        { pin: 'Triplo Diamante', cycles: 5000, minLines: 5, vmec: '35/25/20/10/10', bonus: 36450.00, iconColor: '#00BFFF' },
        { pin: 'Diamante Red', cycles: 15000, minLines: 6, vmec: '30/20/18/12/10/10', bonus: 67500.00, iconColor: '#ff4500' },
        { pin: 'Diamante Blue', cycles: 25000, minLines: 6, vmec: '30/20/18/12/10/10', bonus: 105300.00, iconColor: '#4169e1' },
        { pin: 'Diamante Black', cycles: 50000, minLines: 6, vmec: '30/20/18/12/10/10', bonus: 135000.00, iconColor: '#e5e7eb' },
    ]
};

export const mockShopCareerPlan = {
    currentRevenue: 18500.75,
    quarterlyRevenue: 52300.50,
    monthlyGrowth: [
        { month: 'Maio', revenue: 15000 },
        { month: 'Junho', revenue: 18500 },
        { month: 'Julho', revenue: 19800 },
    ],
    pinTable: [
        { pin: 'Vendedor Bronze', revenue: 5000, bonus: 100, iconColor: 'text-amber-600' },
        { pin: 'Vendedor Prata', revenue: 10000, bonus: 250, iconColor: 'text-gray-400' },
        { pin: 'Vendedor Ouro', revenue: 20000, bonus: 500, iconColor: 'text-yellow-400' },
        { pin: 'Líder de Vendas', revenue: 40000, bonus: 1000, iconColor: 'text-emerald-400' },
        { pin: 'Executivo de Vendas', revenue: 80000, bonus: 2500, iconColor: 'text-blue-400' },
        { pin: 'Diretor de Vendas', revenue: 150000, bonus: 5000, iconColor: 'text-indigo-400' },
        { pin: 'Embaixador Bronze', revenue: 300000, bonus: 10000, iconColor: 'text-rose-400' },
        { pin: 'Embaixador Prata', revenue: 600000, bonus: 20000, iconColor: 'text-fuchsia-400' },
        { pin: 'Embaixador Ouro', revenue: 1000000, bonus: 50000, iconColor: 'text-violet-400' },
    ]
};


export const mockTopSigmeRanking = [
    { position: 1, name: 'João Silva', avatarUrl: 'https://i.pravatar.cc/150?u=user-11', cycles: 15, earnings: 1250.50 },
    { position: 2, name: 'Maria Oliveira', avatarUrl: 'https://i.pravatar.cc/150?u=user-12', cycles: 12, earnings: 980.00 },
    { position: 3, name: 'Pedro Santos', avatarUrl: 'https://i.pravatar.cc/150?u=user-13', cycles: 10, earnings: 750.25 },
    { position: 4, name: 'Ana Carolina', avatarUrl: mockUser.avatarUrl, cycles: 8, earnings: 550.00 },
    { position: 5, name: 'Carlos Souza', avatarUrl: 'https://i.pravatar.cc/150?u=user-14', cycles: 7, earnings: 480.75 },
    { position: 6, name: 'Mariana Costa', avatarUrl: 'https://i.pravatar.cc/150?u=user-15', cycles: 6, earnings: 420.00 },
    { position: 7, name: 'Lucas Pereira', avatarUrl: 'https://i.pravatar.cc/150?u=user-16', cycles: 5, earnings: 380.50 },
    { position: 8, name: 'Juliana Almeida', avatarUrl: 'https://i.pravatar.cc/150?u=user-17', cycles: 5, earnings: 350.00 },
    { position: 9, name: 'Rafael Ferreira', avatarUrl: 'https://i.pravatar.cc/150?u=user-18', cycles: 4, earnings: 310.20 },
    { position: 10, name: 'Fernanda Lima', avatarUrl: 'https://i.pravatar.cc/150?u=user-19', cycles: 4, earnings: 290.00 },
];

// New mock data for Top Sigme Members to be displayed on Dashboard
export const mockTopSigmeDashboardMembers = [
  { position: 1, name: 'João Silva', avatarUrl: 'https://i.pravatar.cc/150?u=user-11', pin: 'Diamante Red' },
  { position: 2, name: 'Maria Oliveira', avatarUrl: 'https://i.pravatar.cc/150?u=user-12', pin: 'Duplo Diamante' },
  { position: 3, name: 'Pedro Santos', avatarUrl: 'https://i.pravatar.cc/150?u=user-13', pin: 'Diamante' },
];


export const mockTopSigmePersonalStats = {
    totalEarnings: 550.00,
};

export const mockTopSigmeMonthlySummary = {
    totalGlobalCycles: 250,
    totalDistributed: 15000.00,
    closingDate: '31/07/2024',
};

export const mockInvoices: Invoice[] = [
    { id: 'inv-01', customerName: 'Cliente A', dueDate: '2024-07-25', amount: 150.00, status: 'pending' },
    { id: 'inv-02', customerName: 'Cliente B', dueDate: '2024-07-20', amount: 89.90, status: 'paid' },
    { id: 'inv-03', customerName: 'Cliente C', dueDate: '2024-07-15', amount: 250.00, status: 'overdue' },
];

export const mockSubscriptions: Subscription[] = [
    { id: 'sub-01', planName: 'Plano Mensal Essencial', customerName: 'Cliente D', nextBillingDate: '2024-08-01', amount: 99.90, status: 'active' },
    { id: 'sub-02', planName: 'Plano Trimestral Premium', customerName: 'Cliente E', nextBillingDate: '2024-09-15', amount: 279.90, status: 'active' },
    { id: 'sub-03', planName: 'Plano Mensal Básico', customerName: 'Cliente F', nextBillingDate: '2024-07-10', amount: 49.90, status: 'cancelled' },
];

export const mockShopProducts = [
    { id: 'prod-01', name: 'Kit Essencial Prólipsi', imageUrl: 'https://via.placeholder.com/300x300.png/1a1a1a/FFD700?text=Pr%C3%B3lipsi', category: 'RS Dropshipping', price: 199.90, commission: 0 },
    { id: 'prod-02', name: 'Smartwatch Fitness X', imageUrl: 'https://via.placeholder.com/300x300.png/1a1a1a/FFFFFF?text=Smartwatch', category: 'Afiliado - Eletrônicos', price: 350.00, commission: 15 },
    { id: 'prod-03', name: 'Cápsulas de Colágeno', imageUrl: 'https://via.placeholder.com/300x300.png/1a1a1a/FFD700?text=Col%C3%A1geno', category: 'RS Dropshipping', price: 89.90, commission: 0 },
    { 
      id: 'prod-04', 
      name: 'Curso de Marketing Digital', 
      imageUrl: 'https://via.placeholder.com/300x300.png/1a1a1a/FFFFFF?text=Curso', 
      category: 'Afiliado - Cursos', 
      price: 497.00, 
      commission: 30,
      details: {
        mainVideoId: 'ZygeL4a2mGg', // Placeholder video from "Mestres do Tráfego Pago"
        description: 'Um curso completo para você dominar as principais ferramentas de marketing digital, desde o tráfego pago até estratégias de conteúdo orgânico. Aprenda com os melhores do mercado e transforme seus resultados.',
        keyMetrics: [
          { value: '+50 horas', label: 'de conteúdo', icon: 'IconFileClock' },
          { value: '+1.200', label: 'Alunos Satisfeitos', icon: 'IconUsers' },
          { value: 'Certificado', label: 'de Conclusão', icon: 'IconAward' },
          { value: 'Acesso', label: 'Vitalício', icon: 'IconRepeat' }
        ],
        videoGallery: [
          { id: 'v1', title: 'Módulo 1: Introdução', thumbnailUrl: 'https://i.ytimg.com/vi/ZygeL4a2mGg/hqdefault.jpg' },
          { id: 'v2', title: 'Módulo 2: Google Ads', thumbnailUrl: 'https://i.ytimg.com/vi/d5pAhc2ClYk/hqdefault.jpg' },
          { id: 'v3', title: 'Módulo 3: SEO', thumbnailUrl: 'https://i.ytimg.com/vi/Uh9643c2voY/hqdefault.jpg' }
        ]
      }
    },
];

export const mockAffiliateSellers = [
    { id: 'seller-01', name: 'Tech Store Brasil', logoUrl: 'https://via.placeholder.com/100', category: 'Eletrônicos', commissionRate: 15 },
    { id: 'seller-02', name: 'Beleza Natural Cosméticos', logoUrl: 'https://via.placeholder.com/100', category: 'Cosméticos', commissionRate: 20 },
    { id: 'seller-03', name: 'Academia do Saber', logoUrl: 'https://via.placeholder.com/100', category: 'Cursos Online', commissionRate: 30 },
];

export const mockShortenedLinks = [
    { id: 'link-01', original: 'https://rs-shop.com.br/loja/seller-01?ref=user-01', short: 'https://rs.shp/aB3xZ', clicks: 152 },
    { id: 'link-02', original: 'https://rs-shop.com.br/loja/seller-03/curso-mkt?ref=user-01', short: 'https://rs.shp/cY7uP', clicks: 89 },
];

export const mockShopSettings = {
    storeSlug: 'ana-carolina',
    payoutMethod: 'pix',
};

export const mockPixels = [
    { id: 'px-fb-01', name: 'Campanha de Verão', platform: 'facebook' as const, status: 'active' as const, pixelId: '123456789012345', accessToken: 'EAA...dZ' },
    { id: 'px-gg-01', name: 'Rede de Pesquisa', platform: 'google' as const, status: 'active' as const, pixelId: 'AW-987654321', conversionLabel: 'xyz-ABC123' },
    { id: 'px-tk-01', name: 'Campanha de Influencers', platform: 'tiktok' as const, status: 'active' as const, pixelId: 'C1A2B3D4E5F6G7H8' },
    { id: 'px-tb-01', name: 'Conteúdo Patrocinado', platform: 'taboola' as const, status: 'inactive' as const, pixelId: '9876543' },
    { id: 'px-pt-01', name: 'Campanha de Jóias', platform: 'pinterest' as const, status: 'active' as const, pixelId: '9876543210987' },
];

export const mockIncentives: Incentive[] = [
    { id: 'inc-1', name: 'Viagem Nacional', progress: 75, target: 100 },
    { id: 'inc-2', name: 'Viagem Internacional', progress: 30, target: 100 },
];

// Generate a larger pool of users for matrix simulation
export const mockMatrixMembers: User[] = generateParticipants(1000, 51); // Start from index 51 to avoid conflicts

// Define the user's direct referrals
export const mockDirects: User[] = generateParticipants(6, 2).map((user, i) => ({
    ...user,
    name: `Direto ${String.fromCharCode(65 + i)}`,
    avatarUrl: `https://i.pravatar.cc/150?u=direct-${String.fromCharCode(65 + i)}`,
    pin: ['Iniciante', 'Bronze', 'Prata', 'Ouro'][i % 4] // Assign some diverse pins
}));


const pinLevels = ['Iniciante', ...mockCareerPlan.pinTable.map(p => p.pin)];

/**
 * Recursively assigns pins to nodes in the network based on their downline.
 * This function uses a post-order traversal: it processes children before the parent.
 */
const assignPins = (node: NetworkNode): void => {
    if (!node || node.isEmpty) {
        return; // Empty nodes don't get a pin
    }

    // Recursively assign pins to all children first.
    if (node.children && node.children.length > 0) {
        node.children.forEach(assignPins);
    }
    
    // Now, determine the current node's pin based on its direct children's pins.
    // A direct is considered "graduated" if their pin is not 'Iniciante' or 'Vago'.
    const graduatedDirects = node.children
        .filter(child => !child.isEmpty && child.pin && child.pin !== 'Iniciante' && child.pin !== 'Vago')
        .length;
    
    // The number of graduated directs maps to an index in the pinLevels array.
    // 0 graduated => 'Iniciante' (index 0)
    // 1 graduated => 'Bronze' (index 1)
    // 2 graduated => 'Prata' (index 2), and so on.
    const pinIndex = Math.min(graduatedDirects, pinLevels.length - 1);
    node.pin = pinLevels[pinIndex];
};


export const generateMatrixNetwork = (
    width: number,
    depth: number,
    rootUser: User,
    directs: User[],
    pool: User[]
): NetworkNode => {
    const root: NetworkNode = {
        ...rootUser,
        level: 0,
        children: [],
    };

    const memberPool = [...pool]; // Create a mutable copy
    const usedIds = new Set<string>([rootUser.id, ...directs.map(d => d.id)]);

    const queue: NetworkNode[] = [root];
    let head = 0;
    let directsPlaced = 0;

    while (head < queue.length) {
        const currentNode = queue[head++];
        
        if (currentNode.level >= depth) {
            continue;
        }

        const childrenCount = width;
        
        for (let i = 0; i < childrenCount; i++) {
            let nextMember: User | null = null;
            
            // Prioritize placing directs on the first level
            if (currentNode.level === 0 && directsPlaced < directs.length && i < width) {
                nextMember = directs[directsPlaced++];
            } else {
                // Find next available member from the pool
                let poolIndex = 0;
                while(poolIndex < memberPool.length) {
                    if (!usedIds.has(memberPool[poolIndex].id)) {
                        nextMember = memberPool.splice(poolIndex, 1)[0];
                        usedIds.add(nextMember.id);
                        break;
                    }
                    poolIndex++;
                }
            }

            if (nextMember) {
                const childNode: NetworkNode = {
                    ...(nextMember as User),
                    level: currentNode.level + 1,
                    children: [],
                };
                currentNode.children.push(childNode);
                queue.push(childNode);
            } else {
                // If pool runs out, fill with empty nodes
                currentNode.children.push(createEmptyNode(`empty-${currentNode.id}-${i}`, currentNode.level + 1));
            }
        }
    }

    // Assign pins dynamically based on the final network structure.
    assignPins(root);

    // The root user's pin is determined by their overall career, not just this matrix view.
    // So, we restore their original pin after the downline has been calculated.
    root.pin = rootUser.pin;


    return root;
};

// --- NEW DEEP MOCK NETWORK FOR REPORTS ---
const names = ["Silva", "Santos", "Oliveira", "Souza", "Rodrigues", "Ferreira", "Alves", "Pereira", "Lima", "Gomes", "Costa", "Ribeiro", "Martins", "Carvalho", "Almeida", "Lopes", "Dias", "Vieira", "Barbosa", "Mendes"];
const firstNames = ["Miguel", "Arthur", "Gael", "Heitor", "Theo", "Davi", "Gabriel", "Bernardo", "Samuel", "João", "Helena", "Alice", "Laura", "Manuela", "Valentina", "Sophia", "Isabella", "Heloísa", "Luísa", "Maitê"];

let userCounter = 500;
const generateDeepMockNetwork = (depth: number, maxDepth: number, childrenPerNode: number): NetworkNode[] => {
    if (depth > maxDepth) return [];
    
    const children: NetworkNode[] = [];
    const numChildren = Math.floor(Math.random() * (childrenPerNode + 1));

    for(let i = 0; i < numChildren; i++) {
        const id = `deep-user-${userCounter++}`;
        const pinProb = Math.random();
        let pin = 'Iniciante';
        if (pinProb > 0.7) pin = 'Bronze';
        if (pinProb > 0.9) pin = 'Prata';
        if (pinProb > 0.97) pin = 'Ouro';
        if (pinProb > 0.99) pin = 'Safira';

        children.push({
            id: id,
            name: `${firstNames[userCounter % firstNames.length]} ${names[userCounter % names.length]}`,
            email: `consultor${userCounter}@example.com`,
            avatarUrl: `https://i.pravatar.cc/150?u=${id}`,
            level: depth,
            pin: pin,
            status: Math.random() > 0.3 ? 'active' : 'inactive',
            children: generateDeepMockNetwork(depth + 1, maxDepth, childrenPerNode),
            whatsapp: '', cpfCnpj: '', birthDate: '', registrationDate: '', hasPurchased: Math.random() > 0.5,
            address: { zipCode: '', street: '', number: '', neighborhood: '', city: '', state: '' },
            bankAccount: { bank: '', agency: '', accountNumber: '', accountType: 'checking', pixKey: '' }
        });
    }
    return children;
}

export const mockFullNetwork: NetworkNode = {
    ...mockUser,
    level: 0,
    children: generateDeepMockNetwork(1, 7, 4) // Generate a network 7 levels deep
};
// --- END DEEP MOCK NETWORK ---

// FIX: Extracted countNetworkNodes from ChatbotWidget to here, and exported it.
export const countNetworkNodes = (node: NetworkNode): number => {
    if (!node || node.isEmpty) {
        return 0;
    }
    let count = 1; // Count the current node
    if (node.children && node.children.length > 0) {
        count += node.children.reduce((acc, child) => acc + countNetworkNodes(child), 0);
    }
    return count;
};


export const mockAnticipationRequests: AnticipationRequest[] = [
  { id: 'ant-01', requestDate: '2024-07-10', requestedAmount: 500, feeAmount: 25, netAmount: 475, status: 'approved' },
  { id: 'ant-02', requestDate: '2024-06-25', requestedAmount: 300, feeAmount: 15, netAmount: 285, status: 'approved' },
];

// START: New training data structure
export const mockCourses: Course[] = [
  {
    id: 'c1',
    title: 'Mestres do Tráfego Pago',
    description: 'Aprenda a criar campanhas de alta conversão no Facebook Ads e Google Ads para atrair clientes qualificados.',
    iconName: 'IconChart',
    modules: [
      {
        id: 'm1-1',
        title: 'Módulo 1: Fundamentos do Anúncio',
        lessons: [
          { id: 'l1-1-1', title: 'Entendendo o Gerenciador de Anúncios', videoId: 'ZygeL4a2mGg', completed: true },
          { id: 'l1-1-2', title: 'Definindo seu Público-Alvo', videoId: 'ZygeL4a2mGg', completed: false },
        ]
      },
      {
        id: 'm1-2',
        title: 'Módulo 2: Campanhas no Google Ads',
        lessons: [
          { id: 'l1-2-1', title: 'Criando sua Primeira Campanha na Rede de Pesquisa', videoId: 'ZygeL4a2mGg', completed: false },
        ]
      }
    ]
  },
  {
    id: 'c2',
    title: 'O Poder do Tráfego Orgânico',
    description: 'Domine técnicas de SEO e marketing de conteúdo para gerar leads e vendas sem investir em anúncios.',
    iconName: 'IconUsers',
    modules: [
        {
            id: 'm2-1',
            title: 'Módulo 1: SEO para Iniciantes',
            lessons: [
                { id: 'l2-1-1', title: 'O que é SEO e por que é importante?', videoId: 'd5pAhc2ClYk', completed: true },
                { id: 'l2-1-2', title: 'Pesquisa de Palavras-Chave', videoId: 'd5pAhc2ClYk', completed: true },
                { id: 'l2-1-3', title: 'Otimização On-Page', videoId: 'd5pAhc2ClYk', completed: false },
            ]
        }
    ]
  },
  {
    id: 'c3',
    title: 'DNA RS Prólipsi',
    description: 'Aprofunde seu conhecimento sobre a empresa, nossos produtos, plano de negócios e cultura.',
    iconName: 'IconBuilding2',
    modules: [
        {
            id: 'm3-1',
            title: 'Módulo Único',
            lessons: [
                 { id: 'l3-1-1', title: 'Nossa História e Missão', videoId: 'Uh9643c2voY', completed: false },
                 { id: 'l3-1-2', title: 'Conhecendo o Plano de Carreira', videoId: 'Uh9643c2voY', completed: false },
            ]
        }
    ]
  },
];
// END: New training data structure

// START: New mock data for Centro de Distribuição
export const mockDistributionCenters = [
    { id: 'cd-federal', name: 'Federal - Sede', city: 'Brasília', isFederalSede: true, whatsapp: '5561999999999' },
    { id: 'cd-mg', name: 'CD - MG - João Costa', city: 'Belo Horizonte', isFederalSede: false, whatsapp: '5531966666666' },
    { id: 'cd-pr', name: 'CD - PR - Roberto Camargo', city: 'Piraquara', isFederalSede: false, whatsapp: '5541988888888' },
    { id: 'cd-rj', name: 'CD - RJ - Maria Silva', city: 'Rio de Janeiro', isFederalSede: false, whatsapp: '5521977777777' },
    { id: 'cd-ba', name: 'CD - BA - Carlos Santos', city: 'Salvador', isFederalSede: false, whatsapp: '5571944444444' },
    { id: 'cd-sp', name: 'CD - SP - Ana Oliveira', city: 'São Paulo', isFederalSede: false, whatsapp: '5511955555555' },
];

export const mockCDInfo: CDInfo = {
  name: "CD Ana Carolina - São Paulo",
  email: "cd.anacarolina@example.com",
  phone: "5511988887777",
  address: {
    zipCode: '04538-132',
    street: 'Av. Brigadeiro Faria Lima',
    number: '4500',
    neighborhood: 'Itaim Bibi',
    city: 'São Paulo',
    state: 'SP',
  },
  payment: {
    pixKey: {
      type: 'email',
      key: 'cd.anacarolina@example.com',
    },
    apiKeys: {
      mercadoPago: '',
      pagSeguro: '',
      cielo: '',
      getnet: '',
      stone: '',
      pagoFacil: '',
      redLink: '',
      emax: '',
    }
  },
  shipping: {
    allowLocalPickup: true,
    apiKeys: {
      melhorEnvio: 'ME_API_TOKEN_XYZ...',
      loggi: '',
      superFrete: '',
      correios: '',
      frenet: '',
    }
  }
};

export const mockCDProducts: CDProduct[] = [
    { id: 'cd-prod-01', name: 'InflaMax', imageUrl: 'https://via.placeholder.com/300x300.png/1a1a1a/FFD700?text=InflaMax', fullPrice: 60.00, discount: 15.5 },
    { id: 'cd-prod-02', name: 'Kit Essencial Prólipsi', imageUrl: 'https://via.placeholder.com/300x300.png/1a1a1a/FFD700?text=Pr%C3%B3lipsi', fullPrice: 199.90, discount: 15.5 },
    { id: 'cd-prod-03', name: 'Sérum Rejuvenescedor', imageUrl: 'https://via.placeholder.com/300x300.png/1a1a1a/FFD700?text=S%C3%A9rum', fullPrice: 120.00, discount: 15.5 },
    { id: 'cd-prod-04', name: 'Cápsulas de Colágeno', imageUrl: 'https://via.placeholder.com/300x300.png/1a1a1a/FFD700?text=Col%C3%A1geno', fullPrice: 89.90, discount: 15.5 },
];

export const mockCDConsultantOrders: CDConsultantOrder[] = [
  {
    id: 'CD-ORD-001',
    date: '2024-07-28',
    consultant: {
      name: 'Carlos Souza',
      email: 'carlos.s@example.com',
      phone: '5511911112222',
      avatarUrl: 'https://i.pravatar.cc/150?u=user-14'
    },
    items: [
      { productId: 'cd-prod-01', name: 'InflaMax', quantity: 2, unitPrice: 60.00 },
      { productId: 'cd-prod-03', name: 'Sérum Rejuvenescedor', quantity: 1, unitPrice: 120.00 },
    ],
    subtotal: 240.00,
    shipping: { type: 'delivery', cost: 15.00, address: { street: 'Rua das Flores, 123', city: 'São Paulo', zipCode: '01234-567' } },
    total: 255.00,
    status: 'pending_payment'
  },
  {
    id: 'CD-ORD-002',
    date: '2024-07-27',
    consultant: {
      name: 'Mariana Costa',
      email: 'mari.costa@example.com',
      phone: '5521933334444',
      avatarUrl: 'https://i.pravatar.cc/150?u=user-15'
    },
    items: [
      { productId: 'cd-prod-02', name: 'Kit Essencial Prólipsi', quantity: 1, unitPrice: 199.90 },
    ],
    subtotal: 199.90,
    shipping: { type: 'pickup', cost: 0.00 },
    total: 199.90,
    status: 'paid'
  },
   {
    id: 'CD-ORD-003',
    date: '2024-07-26',
    consultant: {
      name: 'Lucas Pereira',
      email: 'lucas.p@example.com',
      phone: '5531955556666',
      avatarUrl: 'https://i.pravatar.cc/150?u=user-16'
    },
    items: [
      { productId: 'cd-prod-01', name: 'InflaMax', quantity: 5, unitPrice: 60.00 },
    ],
    subtotal: 300.00,
    shipping: { type: 'delivery', cost: 22.50, address: { street: 'Av. Principal, 456', city: 'Belo Horizonte', zipCode: '30112-010' } },
    total: 322.50,
    status: 'shipped'
  },
];

export const mockCDInventory: CDInventoryItem[] = [
    { productId: 'cd-prod-01', name: 'InflaMax', quantity: 25, unitCost: 50.70 },
    { productId: 'cd-prod-02', name: 'Kit Essencial Prólipsi', quantity: 10, unitCost: 168.91 },
    { productId: 'cd-prod-03', name: 'Sérum Rejuvenescedor', quantity: 15, unitCost: 101.40 },
];
// END: New mock data for Centro de Distribuição

export const mockActivationHistory = [
    { month: '2024-07', status: 'Ativo', method: 'Compra Pessoal', value: 150.00 },
    { month: '2024-06', status: 'Ativo', method: 'Compra Pessoal', value: 120.50 },
    { month: '2024-05', status: 'Ativo', method: 'Venda a Cliente', value: 250.00 },
    { month: '2024-04', status: 'Inativo', method: '-', value: 0 },
    { month: '2024-03', status: 'Ativo', method: 'Compra Pessoal', value: 180.75 },
    { month: '2024-02', status: 'Ativo', method: 'Compra Pessoal', value: 140.00 },
    { month: '2024-01', status: 'Ativo', method: 'Primeira Compra', value: 99.90 },
];

export const mockNetworkReport = mockDirects.map((direct) => ({
    ...direct,
    personalVolume: (Math.random() * 400 + 100).toFixed(2),
    groupVolume: (Math.random() * 1500 + 500).toFixed(2),
    joinDate: `2024-0${Math.floor(Math.random() * 6) + 1}-${String(Math.floor(Math.random() * 28) + 1).padStart(2, '0')}`,
    totalDirects: Math.floor(Math.random() * 5),
    lastActivity: `2024-07-${String(Math.floor(Math.random() * 15) + 10).padStart(2, '0')}`,
    // NEW: Add totalCycles for each direct report
    totalCycles: Math.floor(Math.random() * 20) + 1, 
}));

// START: New mock data for Gamification
export const mockUserBadges = [
    { id: 'badge-1', name: 'Primeiro Indicado', icon: 'IconUser', description: 'Você cadastrou seu primeiro consultor direto.', acquired: true },
    { id: 'badge-2', name: 'Top Vendedor', icon: 'IconShoppingCart', description: 'Ficou entre os 10 maiores vendedores do mês.', acquired: true },
    { id: 'badge-3', name: 'Construtor de Equipe', icon: 'IconUsers', description: 'Sua rede atingiu 10 membros ativos.', acquired: true },
    { id: 'badge-4', name: 'Especialista SIGME', icon: 'IconGitFork', description: 'Completou 10 ciclos globais.', acquired: false },
];

export const mockActivityFeed = [
    { id: 'act-1', type: 'rank_up', user: { name: 'Mariana Costa', avatarUrl: 'https://i.pravatar.cc/150?u=user-15' }, details: 'atingiu o PIN de Prata!', timestamp: 'há 15 minutos' },
    { id: 'act-2', type: 'new_member', user: { name: 'Carlos Souza', avatarUrl: 'https://i.pravatar.cc/150?u=user-14' }, details: 'cadastrou um novo consultor: Ricardo Alves.', timestamp: 'há 1 hora' },
    { id: 'act-3', type: 'first_sale', user: { name: 'Juliana Almeida', avatarUrl: 'https://i.pravatar.cc/150?u=user-17' }, details: 'realizou sua primeira venda na RS Shop.', timestamp: 'há 3 horas' },
    { id: 'act-4', type: 'goal_achieved', user: { name: 'Ana Carolina', avatarUrl: mockUser.avatarUrl }, details: 'Você completou a meta de Bônus de Carreira!', timestamp: 'há 5 horas' },
    { id: 'act-5', type: 'rank_up', user: { name: 'Lucas Pereira', avatarUrl: 'https://i.pravatar.cc/150?u=user-16' }, details: 'atingiu o PIN de Bronze!', timestamp: 'há 1 dia' },
];
// END: New mock data for Gamification


// --- Common bonus data and helpers ---

// Helper for generating cycle data for depth/fidelity bonuses
const _generateBonusCycleData = (levelConfig: { peopleTarget: number; completedCycles: number; progressInCurrent: number; }): { cycleNumber: number; peopleCompleted: number; status: 'completed' | 'in_progress' | 'locked'; }[] => {
    const cycles = [];
    for (let i = 1; i <= 10; i++) {
        let status: 'completed' | 'in_progress' | 'locked' = 'locked';
        let peopleCompleted = 0;

        if (i < levelConfig.completedCycles + 1) {
            status = 'completed';
            peopleCompleted = levelConfig.peopleTarget;
        } else if (i === levelConfig.completedCycles + 1) {
            status = 'in_progress';
            peopleCompleted = Math.floor(levelConfig.peopleTarget * (levelConfig.progressInCurrent / 100));
        }
        
        cycles.push({
            cycleNumber: i,
            peopleCompleted,
            status,
        });
    }
    return cycles;
};

// Bonus Profundidade Data
export const BONUS_PROFUNDIDADE_BASE = 24.52; 

export const mockBonusDepthData = [
    { 
        level: 1, 
        percentage: 7, 
        peopleTarget: 6, 
        bonusPerPerson: BONUS_PROFUNDIDADE_BASE * 0.07,
        // FIX: Removed extraneous 'level' property from levelConfig object.
        cycles: _generateBonusCycleData({ peopleTarget: 6, completedCycles: 2, progressInCurrent: 50 }) // 2 cycles done, 3rd is 50%
    },
    { 
        level: 2, 
        percentage: 8, 
        bonusPerPerson: BONUS_PROFUNDIDADE_BASE * 0.08,
        // FIX: Removed extraneous 'level' property from levelConfig object.
        cycles: _generateBonusCycleData({ peopleTarget: 36, completedCycles: 1, progressInCurrent: 25 }) // 1 cycle done, 2nd is 25%
    },
    { 
        level: 3, 
        percentage: 10, 
        peopleTarget: 216, 
        bonusPerPerson: BONUS_PROFUNDIDADE_BASE * 0.10,
        // FIX: Removed extraneous 'level' property from levelConfig object.
        cycles: _generateBonusCycleData({ peopleTarget: 216, completedCycles: 0, progressInCurrent: 80 }) // 0 cycles done, 1st is 80%
    },
    { 
        level: 4, 
        percentage: 15, 
        peopleTarget: 1296, 
        bonusPerPerson: BONUS_PROFUNDIDADE_BASE * 0.15,
        // FIX: Removed extraneous 'level' property from levelConfig object.
        cycles: _generateBonusCycleData({ peopleTarget: 1296, completedCycles: 0, progressInCurrent: 10 })
    },
    { 
        level: 5, 
        percentage: 25, 
        peopleTarget: 7776, 
        bonusPerPerson: BONUS_PROFUNDIDADE_BASE * 0.25,
        // FIX: Removed extraneous 'level' property from levelConfig object.
        cycles: _generateBonusCycleData({ peopleTarget: 7776, completedCycles: 0, progressInCurrent: 2 })
    },
    { 
        level: 6, 
        percentage: 35, 
        peopleTarget: 46656, 
        bonusPerPerson: BONUS_PROFUNDIDADE_BASE * 0.35,
        // FIX: Removed extraneous 'level' property from levelConfig object.
        cycles: _generateBonusCycleData({ peopleTarget: 46656, completedCycles: 0, progressInCurrent: 0 })
    },
];

// Bonus Fidelidade Data
export const mockBonusFidelityData = [
    { level: 1, peopleTarget: 6, bonusPerPerson: 0.31, cycles: _generateBonusCycleData({ peopleTarget: 6, completedCycles: 2, progressInCurrent: 50 })},
    { level: 2, peopleTarget: 36, bonusPerPerson: 0.36, cycles: _generateBonusCycleData({ peopleTarget: 36, completedCycles: 1, progressInCurrent: 25 })},
    { level: 3, peopleTarget: 216, bonusPerPerson: 0.45, cycles: _generateBonusCycleData({ peopleTarget: 216, completedCycles: 0, progressInCurrent: 80 })},
    { level: 4, peopleTarget: 1296, bonusPerPerson: 0.67, cycles: _generateBonusCycleData({ peopleTarget: 1296, completedCycles: 0, progressInCurrent: 10 })},
    { level: 5, peopleTarget: 7776, bonusPerPerson: 1.12, cycles: _generateBonusCycleData({ peopleTarget: 7776, completedCycles: 0, progressInCurrent: 2 })},
    { level: 6, peopleTarget: 46656, bonusPerPerson: 1.57, cycles: _generateBonusCycleData({ peopleTarget: 46656, completedCycles: 0, progressInCurrent: 0 })},
];