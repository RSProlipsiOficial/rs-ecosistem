import React, { useState, useRef, ChangeEvent, FormEvent } from 'react';
import Card from '../components/Card';
import { IconUser, IconLock, IconMapPin, IconBuilding2, IconActive, IconCalendar, IconWhatsapp } from '../components/icons';
import { useUser } from './ConsultantLayout';

interface InputFieldProps {
    label: string; 
    type: string; 
    value: string; 
    onChange: (e: ChangeEvent<HTMLInputElement>) => void;
    name: string;
    gridSpan?: string;
    icon?: React.ElementType;
    onBlur?: () => void;
    placeholder?: string;
    required?: boolean;
    readOnly?: boolean;
    error?: string;
}

const InputField: React.FC<InputFieldProps> = ({ label, type, value, onChange, name, gridSpan = 'md:col-span-1', icon: Icon, onBlur, placeholder, required, readOnly, error }) => (
    <div className={gridSpan}>
        <label htmlFor={name} className="text-sm text-gray-400 block mb-1">{label}</label>
        <div className="relative">
            <input 
                id={name}
                name={name}
                type={type} 
                value={value} 
                onChange={onChange}
                onBlur={onBlur}
                placeholder={placeholder}
                required={required}
                readOnly={readOnly}
                className={`w-full bg-brand-gray p-3 rounded-md border border-brand-gray-light focus:ring-2 focus:ring-brand-gold focus:outline-none transition-shadow ${Icon ? 'pr-10' : ''} ${readOnly ? 'bg-brand-gray-light text-gray-400 cursor-not-allowed' : ''} ${error ? 'border-red-500' : ''}`}
            />
            {Icon && <Icon className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={20} />}
        </div>
        {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
    </div>
);

const SaveButton: React.FC<{ formId: string, label: string; saveStatus: string | null; }> = ({ formId, label, saveStatus }) => {
    const isSaving = saveStatus === formId;
    return (
        <button 
            type="submit" 
            disabled={isSaving}
            className={`font-bold px-6 py-3 rounded-lg transition-all duration-300 flex items-center justify-center min-w-[240px] ${
                isSaving 
                ? 'bg-green-500 text-white cursor-not-allowed' 
                : 'bg-brand-gold text-brand-dark hover:bg-yellow-400 shadow-lg shadow-brand-gold/20'
            }`}
        >
            {isSaving ? (
                <>
                    <IconActive className="mr-2" size={20} />
                    Salvo com sucesso!
                </>
            ) : (
                label
            )}
        </button>
    );
};
  
const Configuracoes: React.FC = () => {
    const { user, updateUser } = useUser();
    
    const [personalData, setPersonalData] = useState({ name: user.name, email: user.email, cpfCnpj: user.cpfCnpj, birthDate: user.birthDate, whatsapp: user.whatsapp });
    const [addressData, setAddressData] = useState(user.address);
    const [passwordData, setPasswordData] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
    const [bankData, setBankData] = useState(user.bankAccount);
    
    const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
    const [saveStatus, setSaveStatus] = useState<string | null>(null);
    const [showPasswordFields, setShowPasswordFields] = useState(false);
    const [cepError, setCepError] = useState('');
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleInputChange = (setter: React.Dispatch<React.SetStateAction<any>>) => (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        if (name === 'zipCode') setCepError('');
        setter((prev: any) => ({ ...prev, [name]: value }));
    };

    const handleAvatarChange = (e: ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onloadend = () => {
                const newAvatarUrl = reader.result as string;
                setAvatarPreview(newAvatarUrl);
                updateUser({ avatarUrl: newAvatarUrl });
            };
            reader.readAsDataURL(file);
        }
    };

    const fetchAddressFromCEP = async () => {
        const cep = addressData.zipCode.replace(/\D/g, '');
        if (cep.length !== 8) {
            if(addressData.zipCode) setCepError('CEP inválido. Deve conter 8 dígitos.');
            return;
        }

        try {
            const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
            const data = await response.json();
            if (data.erro) {
                setCepError('CEP não encontrado.');
            } else {
                setAddressData(prev => ({
                    ...prev,
                    street: data.logradouro || '',
                    neighborhood: data.bairro || '',
                    city: data.localidade || '',
                    state: data.uf || '',
                }));
                setCepError('');
            }
        } catch (error) {
            setCepError('Erro ao buscar o CEP. Tente novamente.');
        }
    };

    const handleSave = (e: FormEvent, formId: string) => {
        e.preventDefault();
        
        if (formId === 'dados-pessoais') {
            updateUser(personalData);
        } else if (formId === 'endereco') {
            updateUser({ address: addressData });
        } else if (formId === 'banco') {
            updateUser({ bankAccount: bankData });
        }
        
        setSaveStatus(formId);

        if (formId === 'senha') {
            setTimeout(() => {
                setSaveStatus(null);
                setShowPasswordFields(false); 
                setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
            }, 2500);
        } else {
            setTimeout(() => setSaveStatus(null), 2500);
        }
    };

    const handleContactSponsor = (whatsapp: string) => {
        if (!whatsapp) return;
        const message = `Olá! Vi seu contato no painel da RS Prólipsi e gostaria de conversar.`;
        const phoneNumber = whatsapp.replace(/\D/g, ''); // Remove non-numeric chars
        const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
        window.open(url, '_blank', 'noopener,noreferrer');
    };

    return (
        <div className="space-y-8 max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold text-brand-gold">Configurações da Conta</h1>

            {/* --- DADOS PESSOAIS --- */}
            <Card>
                <h2 className="text-xl font-bold text-white mb-6 flex items-center"><IconUser className="mr-3 text-brand-gold"/> Dados Pessoais</h2>
                <div className="flex items-center space-x-6 mb-8">
                    <img src={avatarPreview || user.avatarUrl} alt="Avatar" className="h-24 w-24 rounded-full border-4 border-brand-gold shadow-md shadow-brand-gold/20"/>
                    <div>
                        <h3 className="text-lg font-bold text-white">{personalData.name}</h3>
                        <p className="text-gray-400">{personalData.email}</p>
                        <input type="file" ref={fileInputRef} onChange={handleAvatarChange} accept="image/*" className="hidden"/>
                        <button onClick={() => fileInputRef.current?.click()} className="mt-2 bg-brand-gray px-4 py-2 rounded-lg text-sm hover:bg-brand-gray-light transition-colors">
                            Alterar Foto
                        </button>
                    </div>
                </div>
                <form className="space-y-6" onSubmit={(e) => handleSave(e, 'dados-pessoais')}>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <InputField label="Nome Completo" type="text" name="name" value={personalData.name} onChange={handleInputChange(setPersonalData)} gridSpan="md:col-span-2" />
                        <InputField label="E-mail" type="email" name="email" value={personalData.email} onChange={handleInputChange(setPersonalData)} />
                        <InputField label="WhatsApp" type="tel" name="whatsapp" value={personalData.whatsapp} onChange={handleInputChange(setPersonalData)} />
                        <InputField label="CPF / CNPJ" type="text" name="cpfCnpj" value={personalData.cpfCnpj} onChange={handleInputChange(setPersonalData)} readOnly/>
                        <InputField label="ID de Consultor" type="text" name="idConsultor" value={user.idConsultor || ''} onChange={() => {}} readOnly/>
                        <InputField label="Data de Nascimento" type="date" name="birthDate" value={personalData.birthDate} onChange={handleInputChange(setPersonalData)} icon={IconCalendar} />
                        <InputField label="Data de Cadastro" type="date" name="registrationDate" value={user.registrationDate || ''} onChange={() => {}} readOnly icon={IconCalendar}/>
                        
                        <div className="md:col-span-2">
                            <label className="text-sm text-gray-400 block mb-1">Seu Patrocinador</label>
                            <div className="bg-brand-gray p-3 rounded-md border border-brand-gray-light flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                                <div>
                                    <p className="font-semibold text-white">{user.upline?.name || 'Não informado'}</p>
                                    <p className="text-xs text-gray-400">ID: {user.upline?.idConsultor || 'N/A'}</p>
                                </div>
                                {user.upline?.whatsapp && (
                                    <button
                                        type="button"
                                        onClick={() => handleContactSponsor(user.upline.whatsapp as string)}
                                        className="flex items-center justify-center gap-2 bg-green-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-600 transition-colors text-sm w-full sm:w-auto"
                                    >
                                        <IconWhatsapp size={18}/>
                                        <span>Contatar Patrocinador</span>
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                    <div className="flex justify-end mt-4">
                        <SaveButton formId="dados-pessoais" label="Salvar Dados Pessoais" saveStatus={saveStatus} />
                    </div>
                </form>
            </Card>

            {/* --- ENDEREÇO --- */}
            <Card>
                <h2 className="text-xl font-bold text-white mb-6 flex items-center"><IconMapPin className="mr-3 text-brand-gold"/> Dados de Endereço</h2>
                <form className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6" onSubmit={(e) => handleSave(e, 'endereco')}>
                    <InputField label="CEP" type="text" name="zipCode" value={addressData.zipCode} onChange={handleInputChange(setAddressData)} onBlur={fetchAddressFromCEP} error={cepError} gridSpan="lg:col-span-2"/>
                    <InputField label="Rua / Logradouro" type="text" name="street" value={addressData.street} onChange={handleInputChange(setAddressData)} gridSpan="lg:col-span-4"/>
                    <InputField label="Número" type="text" name="number" value={addressData.number} onChange={handleInputChange(setAddressData)} gridSpan="lg:col-span-2"/>
                    <InputField label="Complemento" type="text" name="complement" value={addressData.complement || ''} onChange={handleInputChange(setAddressData)} gridSpan="lg:col-span-4"/>
                    <InputField label="Bairro" type="text" name="neighborhood" value={addressData.neighborhood} onChange={handleInputChange(setAddressData)} gridSpan="lg:col-span-3"/>
                    <InputField label="Cidade" type="text" name="city" value={addressData.city} onChange={handleInputChange(setAddressData)} gridSpan="lg:col-span-2"/>
                    <InputField label="Estado" type="text" name="state" value={addressData.state} onChange={handleInputChange(setAddressData)} gridSpan="lg:col-span-1"/>
                    <div className="lg:col-span-6 flex justify-end mt-4">
                        <SaveButton formId="endereco" label="Salvar Endereço" saveStatus={saveStatus} />
                    </div>
                </form>
            </Card>

            {/* --- SEGURANÇA --- */}
            <Card>
                <h2 className="text-xl font-bold text-white mb-6 flex items-center"><IconLock className="mr-3 text-brand-gold"/> Segurança</h2>
                {!showPasswordFields ? (
                    <div className="flex justify-between items-center">
                        <p className="text-gray-300">Altere sua senha de acesso.</p>
                        <button onClick={() => setShowPasswordFields(true)} className="bg-brand-gray px-4 py-2 rounded-lg text-sm font-semibold hover:bg-brand-gray-light transition-colors">
                            Alterar Senha
                        </button>
                    </div>
                ) : (
                <form className="space-y-4" onSubmit={(e) => handleSave(e, 'senha')}>
                    <InputField label="Senha Atual" type="password" name="currentPassword" value={passwordData.currentPassword} onChange={handleInputChange(setPasswordData)} required gridSpan="col-span-1" />
                    <InputField label="Nova Senha" type="password" name="newPassword" value={passwordData.newPassword} onChange={handleInputChange(setPasswordData)} required gridSpan="col-span-1" />
                    <InputField label="Confirmar Nova Senha" type="password" name="confirmPassword" value={passwordData.confirmPassword} onChange={handleInputChange(setPasswordData)} required gridSpan="col-span-1" />
                    <div className="flex justify-end items-center gap-4 mt-4">
                        <button type="button" onClick={() => setShowPasswordFields(false)} className="bg-brand-gray px-6 py-3 rounded-lg text-sm font-semibold hover:bg-brand-gray-light transition-colors">
                            Cancelar
                        </button>
                        <SaveButton formId="senha" label="Salvar Nova Senha" saveStatus={saveStatus} />
                    </div>
                </form>
                )}
            </Card>

            {/* --- DADOS BANCÁRIOS --- */}
            <Card>
                <h2 className="text-xl font-bold text-white mb-6 flex items-center"><IconBuilding2 className="mr-3 text-brand-gold"/> Dados Bancários</h2>
                <form className="grid grid-cols-1 md:grid-cols-2 gap-6" onSubmit={(e) => handleSave(e, 'banco')}>
                    <InputField label="Banco" type="text" name="bank" value={bankData.bank} onChange={handleInputChange(setBankData)} />
                    <div>
                        <label className="text-sm text-gray-400 block mb-1">Tipo de Conta</label>
                        <select name="accountType" value={bankData.accountType} onChange={handleInputChange(setBankData)} className="w-full bg-brand-gray p-3 rounded-md border border-brand-gray-light focus:ring-2 focus:ring-brand-gold focus:outline-none h-[50px]">
                            <option value="checking">Conta Corrente</option>
                            <option value="savings">Conta Poupança</option>
                        </select>
                    </div>
                    <InputField label="Agência" type="text" name="agency" value={bankData.agency} onChange={handleInputChange(setBankData)} />
                    <InputField label="Número da Conta" type="text" name="accountNumber" value={bankData.accountNumber} onChange={handleInputChange(setBankData)} />
                    <InputField label="Chave PIX" type="text" name="pixKey" value={bankData.pixKey} onChange={handleInputChange(setBankData)} gridSpan="md:col-span-2" />
                    <div className="md:col-span-2 flex justify-end mt-4">
                         <SaveButton formId="banco" label="Salvar Dados Bancários" saveStatus={saveStatus} />
                    </div>
                </form>
            </Card>
        </div>
    );
};

export default Configuracoes;