
import React from 'react';

type IconProps = React.SVGProps<SVGSVGElement> & {
  size?: number;
};

const createIcon = (path: React.ReactNode) => {
  const Icon: React.FC<IconProps> = ({ size = 24, className, ...props }) => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      {...props}
    >
      {path}
    </svg>
  );
  Icon.displayName = 'Icon';
  return Icon;
};

export const IconActive = createIcon(<><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" /></>);
export const IconAdjustments = createIcon(<><path d="M4 21v-7" /><path d="M4 8V3" /><path d="M12 21v-9" /><path d="M12 6V3" /><path d="M20 21v-5" /><path d="M20 10V3" /><path d="M1 14h6" /><path d="M9 8h6" /><path d="M17 16h6" /></>);
export const IconAlignCenter = createIcon(<><line x1="21" y1="10" x2="3" y2="10" /><line x1="21" y1="6" x2="3" y2="6" /><line x1="21" y1="14" x2="3" y2="14" /><line x1="21" y1="18" x2="3" y2="18" /></>);
export const IconAlignLeft = createIcon(<><line x1="21" y1="10" x2="3" y2="10" /><line x1="21" y1="6" x2="3" y2="6" /><line x1="15" y1="14" x2="3" y2="14" /><line x1="15" y1="18" x2="3" y2="18" /></>);
export const IconAlignRight = createIcon(<><line x1="21" y1="10" x2="3" y2="10" /><line x1="21" y1="6" x2="3" y2="6" /><line x1="21" y1="14" x2="9" y2="14" /><line x1="21" y1="18" x2="9" y2="18" /></>);
export const IconAlertTriangle = createIcon(<><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></>);
export const IconAward = createIcon(<><circle cx="12" cy="8" r="6" /><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11" /></>);
export const IconBell = createIcon(<><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" /><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" /></>);
export const IconBold = createIcon(<path d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z" /><path d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z" />);
export const IconBookOpen = createIcon(<><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></>);
export const IconBot = createIcon(<><path d="M12 8V4H8" /><rect width="16" height="12" x="4" y="8" rx="2" /><path d="M2 14h2" /><path d="M20 14h2" /><path d="M15 13v2" /><path d="M9 13v2" /></>);
export const IconBringToFront = createIcon(<><rect x="8" y="8" width="8" height="8" rx="2" /><path d="M4 4h8v2H6a2 2 0 0 1-2-2Z" /><path d="M4 6v8h2V6Z" /></>);
export const IconBuilding2 = createIcon(<><path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18" /><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2" /><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2" /><path d="M10 6h4" /><path d="M10 10h4" /><path d="M10 14h4" /><path d="M10 18h4" /></>);
export const IconCalendar = createIcon(<><rect width="18" height="18" x="3" y="4" rx="2" ry="2" /><line x1="16" x2="16" y1="2" y2="6" /><line x1="8" x2="8" y1="2" y2="6" /><line x1="3" x2="21" y1="10" y2="10" /></>);
export const IconChart = createIcon(<><path d="M3 3v18h18" /><path d="M18 17V9" /><path d="M13 17V5" /><path d="M8 17v-3" /></>);
export const IconCheckCircle = createIcon(<><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></>);
export const IconChevronDown = createIcon(<><path d="m6 9 6 6 6-6" /></>);
export const IconChevronLeft = createIcon(<><path d="m15 18-6-6 6-6" /></>);
export const IconChevronRight = createIcon(<><path d="m9 18 6-6-6-6" /></>);
export const IconCircle = createIcon(<circle cx="12" cy="12" r="10" />);
export const IconCopy = createIcon(<><rect width="14" height="14" x="8" y="8" rx="2" ry="2" /><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" /></>);
export const IconCopyPlus = createIcon(<><line x1="15" y1="12" x2="15" y2="18" /><line x1="12" y1="15" x2="18" y2="15" /><rect width="14" height="14" x="8" y="8" rx="2" ry="2" /><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" /></>);
export const IconCrown = createIcon(<><path d="m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14" /></>);
export const IconDashboard = createIcon(<><rect width="7" height="9" x="3" y="3" rx="1" /><rect width="7" height="5" x="14" y="3" rx="1" /><rect width="7" height="9" x="14" y="12" rx="1" /><rect width="7" height="5" x="3" y="16" rx="1" /></>);
export const IconEdit = createIcon(<><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></>);
export const IconDownload = createIcon(<><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" x2="12" y1="15" y2="3" /></>);
export const IconUpload = createIcon(<><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="17 8 12 3 7 8" /><line x1="12" x2="12" y1="3" y2="15" /></>);
export const IconExternalLink = createIcon(<><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><polyline points="15 3 21 3 21 9" /><line x1="10" x2="21" y1="14" y2="3" /></>);
export const IconFacebook = createIcon(<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />);
export const IconFileClock = createIcon(<><path d="M16 22h2a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v3" /><path d="M14 2v4a2 2 0 0 0 2 2h4" /><circle cx="8" cy="16" r="4" /><path d="M8 14v2l1 1" /></>);
export const IconFileText = createIcon(<><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" /><polyline points="14 2 14 8 20 8" /><line x1="16" x2="8" y1="13" y2="13" /><line x1="16" x2="8" y1="17" y2="17" /><line x1="10" x2="8" y1="9" y2="9" /></>);
export const IconFilter = createIcon(<><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" /></>);
export const IconFlipHorizontal = createIcon(<><path d="M8 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3" /><path d="M16 3h3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-3" /><path d="M12 20V4" /></>);
export const IconFlipVertical = createIcon(<><path d="M3 8V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v3" /><path d="M3 16v3a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-3" /><path d="M20 12H4" /></>);
export const IconGitFork = createIcon(<><circle cx="12" cy="18" r="3" /><circle cx="6" cy="6" r="3" /><circle cx="18" cy="6" r="3" /><path d="M18 9v2c0 .6-.4 1-1 1H7c-.6 0-1-.4-1-1V9" /><path d="M12 12v3" /></>);
export const IconHandCoins = createIcon(<><path d="M11 15h2a2 2 0 1 0 0-4h-3c-.6 0-1 .4-1 1v2a1 1 0 0 0 1 1Z" /><path d="M15 8.12A4.993 4.993 0 0 1 12 12.5a4.92 4.92 0 0 1-2.5-1.5" /><path d="M12 6.5A4.92 4.92 0 0 1 14.5 8" /><path d="m4.2 11.7 2.1 2.1" /><path d="m11.7 19.8 2.1 2.1" /><path d="M4 16.8V20a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3.2" /><path d="M7 16.8c0-1 2.2-2.8 4-4.5" /><path d="M12.5 10.7c.8.8 2.3 1.3 3.5 1.3" /><path d="M10 15a2 2 0 0 0-2-2" /><circle cx="1" cy="1" r="1" transform="matrix(1 0 0 -1 16 9)" /></>);
export const IconHelpCircle = createIcon(<><circle cx="12" cy="12" r="10" /><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" /><path d="M12 17h.01" /></>);
export const IconImage = createIcon(<><rect width="18" height="18" x="3" y="3" rx="2" ry="2" /><circle cx="9" cy="9" r="2" /><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" /></>);
export const IconInactive = createIcon(<><circle cx="12" cy="12" r="10" /><line x1="15" x2="9" y1="9" y2="15" /><line x1="9" x2="15" y1="9" y2="15" /></>);
export const IconItalic = createIcon(<><line x1="19" y1="4" x2="10" y2="4" /><line x1="14" y1="20" x2="5" y2="20" /><line x1="15" y1="4" x2="9" y2="20" /></>);
export const IconLink = createIcon(<><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.72" /><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.72-1.72" /></>);
export const IconLock = createIcon(<><rect width="18" height="11" x="3" y="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></>);
export const IconLogOut = createIcon(<><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" x2="9" y1="12" y2="12" /></>);
export const IconMapPin = createIcon(<><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" /><circle cx="12" cy="10" r="3" /></>);
export const IconMenu = createIcon(<><line x1="4" x2="20" y1="12" y2="12" /><line x1="4" x2="20" y1="6" y2="6" /><line x1="4" x2="20" y1="18" y2="18" /></>);
export const IconMessage = createIcon(<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />);
export const IconMic = createIcon(<><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></>);
export const IconMinus = createIcon(<path d="M5 12h14" />);
export const IconMoreVertical = createIcon(<><circle cx="12" cy="12" r="1" /><circle cx="12" cy="5" r="1" /><circle cx="12" cy="19" r="1" /></>);
export const IconMove = createIcon(<><polyline points="5 9 2 12 5 15"/><polyline points="9 5 12 2 15 5"/><polyline points="15 19 12 22 9 19"/><polyline points="19 9 22 12 19 15"/><line x1="2" x2="22" y1="12" y2="12"/><line x1="12" x2="12" y1="2" y2="22"/></>);
export const IconPalette = createIcon(<><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.667 0-.424-.163-.82-.426-1.125-.262-.304-.603-.497-.968-.497H10.5c-.552 0-1-.448-1-1s.448-1 1-1h1.5V14h-1c-.552 0-1-.448-1-1s.448-1 1-1h2.833c.552 0 1 .448 1 1v1h-1v1.5c0 .552.448 1 1 1h1.5c.552 0 1-.448 1-1s-.448-1-1-1h-2.5a2.5 2.5 0 0 0-2.5-2.5V12h3c.552 0 1-.448 1-1s-.448-1-1-1h-1.5a2.5 2.5 0 0 0-2.5-2.5V6h1.5c.552 0 1-.448 1-1s-.448-1-1-1H12V2Z"/></>);
export const IconPause = createIcon(<><rect x="6" y="4" width="4" height="16" /><rect x="14" y="4" width="4" height="16" /></>);
export const IconPending = createIcon(<><circle cx="12" cy="12" r="10" /><line x1="12" x2="12" y1="8" y2="12" /><line x1="12" x2="12.01" y1="16" y2="16" /></>);
export const IconPiggyBank = createIcon(<><path d="M19.4 12.18a3.99 3.99 0 0 0-2.34-2.34" /><path d="M13.5 12H10V8.5" /><path d="M16.5 4.5c-.9-.9-2.1-1.5-3.5-1.5-1.4 0-2.6.6-3.5 1.5" /><path d="M15.5 6.5c-.3-.3-.7-.5-1-1" /><path d="m21 13-1.3-1.3a1 1 0 0 0-1.4 0L17 13l-1.3-1.3a1 1 0 0 0-1.4 0L13 13l-1.3-1.3a1 1 0 0 0-1.4 0L9 13l-1.3-1.3a1 1 0 0 0-1.4 0L5 13l-1.3-1.3a1 1 0 0 0-1.4 0L1 13" /><path d="M5.3 16.3A3.99 3.99 0 0 0 8 18.18h8a4 4 0 0 0 2.7-1.9" /><path d="M12 13.5V21" /><path d="M8 21h8" /></>);
export const IconReceipt = createIcon(<><path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z" /><path d="M16 8h-6a2 2 0 1 0 0 4h6" /><path d="M12 18v-2" /><path d="M12 8v-2" /></>);
export const IconRepeat = createIcon(<><path d="m17 2 4 4-4 4" /><path d="M3 11v-1a4 4 0 0 1 4-4h14" /><path d="m7 22-4-4 4-4" /><path d="M21 13v1a4 4 0 0 1-4 4H3" /></>);
export const IconRotateCcw = createIcon(<><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" /><path d="M3 3v5h5" /></>);
export const IconRotateCw = createIcon(<><path d="M21 12a9 9 0 1 0-9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" /><path d="M21 21v-5h-5" /></>);
export const IconSave = createIcon(<><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" /><polyline points="17 21 17 13 7 13 7 21" /><polyline points="7 3 7 8 15 8" /></>);
export const IconSearch = createIcon(<><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></>);
export const IconSend = createIcon(<><path d="m22 2-7 20-4-9-9-4Z"/><path d="m22 2-11 11"/></>);
export const IconSendToBack = createIcon(<><rect x="8" y="8" width="8" height="8" rx="2" /><path d="M16 16v2a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /><path d="M18 4h-2a2 2 0 0 0-2 2v2" /></>);
export const IconSettings = createIcon(<><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 0 2l-.15.08a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.38a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1 0-2l.15.08a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" /><circle cx="12" cy="12" r="3" /></>);
export const IconShop = createIcon(<><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7" /><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" /><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4" /><path d="M2 7h20" /><path d="M22 7H12v2.5a.5.5 0 0 1-1 0V7H2" /></>);
export const IconShoppingCart = createIcon(<><circle cx="8" cy="21" r="1" /><circle cx="19" cy="21" r="1" /><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12" /></>);
export const IconSparkles = createIcon(<><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></>);
export const IconSquare = createIcon(<rect width="18" height="18" x="3" y="3" rx="2" ry="2" />);
export const IconStar = createIcon(<><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></>);
export const IconStore = createIcon(<><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7" /><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" /><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4" /><path d="M2 7h20" /><path d="M22 7H12v2.5a.5.5 0 0 1-1 0V7H2" /></>);
export const IconTrendingUp = createIcon(<><polyline points="22 7 13.5 15.5 8.5 10.5 2 17" /><polyline points="16 7 22 7 22 13" /></>);
export const IconTransfer = createIcon(<><path d="m14 16 4-4-4-4" /><path d="M8 16V4h10" /><path d="m10 8-4 4 4 4" /><path d="M16 8v12H6" /></>);
export const IconTrash = createIcon(<><path d="M3 6h18" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></>);
export const IconTruck = createIcon(<><path d="M5 18H3c-.6 0-1-.4-1-1V7c0-.6.4-1 1-1h10c.6 0 1 .4 1 1v11" /><path d="M14 9h4l4 4v4c0 .6-.4 1-1 1h-2" /><circle cx="7" cy="18" r="2" /><path d="M9 18h6" /><circle cx="18" cy="18" r="2" /></>);
export const IconType = createIcon(<><polyline points="4 7 4 4 20 4 20 7" /><line x1="9" y1="20" x2="15" y2="20" /><line x1="12" y1="4" x2="12" y2="20" /></>);
export const IconUser = createIcon(<><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></>);
export const IconUserCog = createIcon(<><circle cx="18" cy="15" r="3" /><circle cx="9" cy="7" r="4" /><path d="M12 15h-1a4 4 0 0 0-4 4v2" /><path d="m19.5 17.5-.4.4" /><path d="m21.5 13.5-.4.4" /><path d="m13.5 19.5-.4.4" /><path d="m15.5 11.5-.4.4" /><path d="M18 20.84V18" /><path d="M18 12v-1.16" /><path d="M21.16 15H18" /><path d="M15 15h-1.16" /></>);
export const IconUsers = createIcon(<><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></>);
export const IconWallet = createIcon(<><path d="M21 12V7H5a2 2 0 0 1 0-4h14v4" /><path d="M3 5v14a2 2 0 0 0 2 2h16v-5" /><path d="M18 12a2 2 0 0 0 0 4h4v-4Z" /></>);
export const IconWhatsapp = createIcon(<path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.42 1.29 4.89L2 22l5.25-1.38c1.41.8 3.02 1.25 4.79 1.25h.01c5.46 0 9.91-4.45 9.91-9.91s-4.45-9.91-9.91-9.91zM12.04 20.1c-1.48 0-2.91-.4-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.32a8.19 8.19 0 0 1-1.26-4.38c0-4.53 3.67-8.2 8.2-8.2 2.21 0 4.29.87 5.8 2.41s2.41 3.59 2.41 5.8-3.67 8.2-8.2 8.2zM15.42 13.4c-.16-.08-1-.49-1.16-.55-.16-.06-.28-.08-.4.08-.12.16-.44.55-.54.66-.1.11-.2.12-.36.04-.16-.08-.7-.25-1.33-.82s-1.03-1.3-1.15-1.52c-.12-.22-.01-.34.07-.44.07-.09.16-.22.24-.33.08-.11.1-.16.16-.28.06-.12.03-.22-.01-.3-.04-.08-.4-1-.54-1.37s-.27-.32-.37-.32h-.3c-.1 0-.26.04-.4.2s-.53.52-.53 1.28.54 1.48.62 1.59c.08.11 1 1.6 2.44 2.18.36.14.65.23.87.3.32.1.6.09.83-.05.27-.11.78-.32.89-.63.11-.3.11-.56.08-.63-.03-.08-.15-.12-.31-.2z" />);
export const IconX = createIcon(<><path d="M18 6 6 18" /><path d="m6 6 12 12" /></>);
export const IconYoutube = createIcon(<><path d="M2.5 17a24.12 24.12 0 0 1 0-10C2.5 6 7.5 4 12 4s9.5 2 9.5 3a24.12 24.12 0 0 1 0 10c0 1-4.5 3-9.5 3s-9.5-2-9.5-3z"/><path d="m10 15 5-3-5-3z"/></>);
export const IconZoomIn = createIcon(<><circle cx="11" cy="11" r="8" /><line x1="21" x2="16.65" y1="21" y2="16.65" /><line x1="11" x2="11" y1="8" y2="14" /><line x1="8" x2="14" y1="11" y2="11" /></>);
export const IconZoomOut = createIcon(<><circle cx="11" cy="11" r="8" /><line x1="21" x2="16.65" y1="21" y2="16.65" /><line x1="8" x2="14" y1="11" y2="11" /></>);
export const IconGoogle = createIcon(<><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /><path d="M12 11h-1v-1a2 2 0 1 1 4 0v1h-3v-1" /></>);
export const IconPinterest = createIcon(<><path d="M6.5 10c-1 2.5-1 4.5 1 6.5s4 3 6.5 1l4-4-2-2-4 2c-1.5-1.5-1.5-3.5 0-5l2-2-4-4c-2.5 2-4.5 4.5-5.5 7Z" /><circle cx="13" cy="11" r="2" /></>);
export const IconPlane = createIcon(<path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.7 5.7c.3.5.9.6 1.4.3l.5-.3c.5-.2.7-.8.5-1.3z" />);
export const IconPlay = createIcon(<polygon points="5 3 19 12 5 21 5 3" />);
export const IconPlus = createIcon(<><path d="M5 12h14" /><path d="M12 5v14" /></>);
export const IconTikTok = createIcon(<path d="M16.14 6.36a5.03 5.03 0 0 1-5.18 5.18v0a5.03 5.03 0 0 1-5.18-5.18c0-2.86 2.32-5.18 5.18-5.18h.27V12a3.2 3.2 0 1 0 3.2-3.2h0" />);
export const IconTaboola = createIcon(<><circle cx="12" cy="12" r="10" /><circle cx="12" cy="12" r="3" /></>);
export const IconSnapchat = createIcon(<path d="M16.5 2c-1.3 0-2 .7-2.5 1.5-.5-.8-1.2-1.5-2.5-1.5s-2 .7-2.5 1.5C8.5 2.7 7.8 2 6.5 2 4 2 2 4 2 6.5c0 1.2.7 2 1.5 2.5-.8.5-1.5 1.3-1.5 2.5C2 14 4 16 6.5 16c1.3 0 2-.7 2.5-1.5.5.8 1.2 1.5 2.5 1.5s2-.7 2.5-1.5c.5.8 1.2 1.5 2.5 1.5 2.5 0 4.5-2 4.5-4.5s-2-4.5-4.5-4.5c-1.3 0-2 .7-2.5 1.5-.5-.8-1.2-1.5-2.5-1.5s-2 .7-2.5 1.5C12.5 6.7 11.8 6 10.5 6c-1.3 0-2 .7-2.5 1.5C7.5 6.7 6.8 6 5.5 6 4 6 3 7 3 8.5c0 .8.4 1.2.8 1.5.4.3.4.5.4 1s-.1.7-.4 1c-.3.3-.8.5-1.3.5C2 12.5 2 12 2 11.5c0-1 .7-1.5 1.5-2 .8-.5 1.5-1.3 1.5-2.5S4 4.5 5.5 4.5c1.3 0 2 .7 2.5 1.5C8.5 5.2 9.2 4.5 10.5 4.5s2 .7 2.5 1.5c.5-.8 1.2-1.5 2.5-1.5s2 .7 2.5 1.5c.5-.8 1.2-1.5 2.5-1.5 2.5 0 4.5 2 4.5 4.5s-2 4.5-4.5-4.5Z" />);
export const IconTwitter = createIcon(<path d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.931ZM17.61 20.644h2.039L6.486 3.24H4.298Z" />);
export const IconLinkedin = createIcon(<><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" /><rect x="2" y="9" width="4" height="12" /><circle cx="4" cy="4" r="2" /></>);
export const IconLandmark = createIcon(<><path d="m21 17-5-5-4 4-5.5-5.5" /><path d="M16 3l-5.5 5.5" /><path d="M21 3v5h-5" /><path d="M3 21h18" /><path d="M5 21v-7l2-2 3 3 4-4 2 2v4" /><path d="M12 21v-4" /></>);
export const IconMaximize = createIcon(<><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" /></>);
export const IconMinimize = createIcon(<><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3" /></>);
// FIX: Added IconEye to the exported icons.
export const IconEye = createIcon(<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" /><circle cx="12" cy="12" r="3" />);
